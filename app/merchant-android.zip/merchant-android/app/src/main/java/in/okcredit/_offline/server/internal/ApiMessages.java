package in.okcredit._offline.server.internal;

import android.support.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import org.joda.time.DateTime;

public interface ApiMessages {

    final class Merchant {
        @SerializedName("id") public final String id;
        @SerializedName("name") public final String name;
        @SerializedName("mobile") public final String mobile;
        @SerializedName("created_at") public final DateTime createdAt;

        public Merchant(String id, String name, String mobile, DateTime createdAt) {
            this.id = id;
            this.name = name;
            this.mobile = mobile;
            this.createdAt = createdAt;
        }
    }

    final class Customer {
        @SerializedName("id") public final String id;
        @SerializedName("status") public final int status;
        @SerializedName("user_id") public final String userId;
        @SerializedName("mobile") public final String mobile;
        @SerializedName("description") public final String description;
        @SerializedName("created_at") public final DateTime createdAt;
        @SerializedName("updated_at") public final DateTime updatedAt;
        @SerializedName("balance") public final float balance;
        @SerializedName("tx_count") public final long transactionCount;
        @SerializedName("last_activity") public final DateTime lastActivity;
        @SerializedName("last_payment") public final DateTime lastPayment;
        @SerializedName("account_url") public final String accountUrl;
        @SerializedName("profile_image") public final String profileImage;
        @SerializedName("address") public final String address;
        @SerializedName("email") public final String email;

        public Customer(String id, int status, String userId, String mobile, String description, DateTime createdAt,
                        DateTime updatedAt, float balance, long transactionCount, DateTime lastActivity,
                        DateTime lastPayment, String accountUrl, String profileImage, String address, String email) {
            this.id = id;
            this.status = status;
            this.userId = userId;
            this.accountUrl = accountUrl;
            this.mobile = mobile;
            this.description = description;
            this.createdAt = createdAt;
            this.updatedAt = updatedAt;
            this.balance = balance;
            this.transactionCount = transactionCount;
            this.lastActivity = lastActivity;
            this.lastPayment = lastPayment;
            this.profileImage = profileImage;
            this.address = address;
            this.email = email;
        }
    }

    final class Transaction {
        @SerializedName("id") public final String id;
        @SerializedName("type") public final int type;
        @SerializedName("customer_id") public final String customerId;
        @SerializedName("amount") public final float amount;
        @SerializedName("receipt_url") public final String receiptUrl;
        @SerializedName("note") public final String note;
        @SerializedName("created_at") public final DateTime createdAt;
        @SerializedName("onboarding") public final boolean isOnboarding;
        @SerializedName("deleted") public final boolean isDeleted;
        @SerializedName("delete_time") public final DateTime deleteTime;

        public Transaction(String id, int type, String customerId, float amount, String receiptUrl, String note, DateTime createdAt, boolean isOnboarding, boolean isDeleted, DateTime deleteTime) {
            this.id = id;
            this.type = type;
            this.customerId = customerId;
            this.amount = amount;
            this.receiptUrl = receiptUrl;
            this.note = note;
            this.createdAt = createdAt;
            this.isOnboarding = isOnboarding;
            this.isDeleted = isDeleted;
            this.deleteTime = deleteTime;
        }
    }


    final class SetMerchantPreferenceRequest {
        @SerializedName("key") private String key;
        @SerializedName("value") private String value;

        public SetMerchantPreferenceRequest(String key, String value) {
            this.key = key;
            this.value = value;
        }
    }

    final class RegisterRequest {
        @SerializedName("method") private final String method = "otp";
        @SerializedName("mobile") private String mobile;
        @SerializedName("name") private String name;
        @SerializedName("password") private String password;
        @SerializedName("verification_token") private String token;
        @SerializedName("lang") private String lang;

        public RegisterRequest(String mobile, String name, String password, String token, String lang) {
            this.mobile = mobile;
            this.name = name;
            this.password = password;
            this.token = token;
            this.lang = lang;
        }
    }

    final class CheckMobileStatusRequest {
        @SerializedName("mobile") private String mobile;

        public CheckMobileStatusRequest(String mobile) {
            this.mobile = mobile;
        }
    }

    final class GetReferralLinkResponse {
        @SerializedName("referral_link") public final String referralLink;

        public GetReferralLinkResponse(String referralLink) {
            this.referralLink = referralLink;
        }
    }

    final class UpdateMerchantRequest {
        @SerializedName("name") private String name;

        public UpdateMerchantRequest(String name) {
            this.name = name;
        }
    }

    final class AddTransactionRequest {
        @SerializedName("customer_id") private final String customerId;
        @SerializedName("request_id") private final String requestId;
        @SerializedName("type") private final int type;
        @SerializedName("amount") private final float amount;
        @SerializedName("receipt_url") private final String receiptUrl;
        @SerializedName("note") private final String note;
        @SerializedName("lastActivity") private final DateTime timestamp;
        @SerializedName("onboarding") private final boolean isOnboarding;

        public AddTransactionRequest(String customerId, String requestId, int type, float amount, String receiptUrl, String note, DateTime timestamp, boolean isOnboarding) {
            this.customerId = customerId;
            this.requestId = requestId;
            this.type = type;
            this.amount = amount;
            this.receiptUrl = receiptUrl;
            this.note = note;
            this.timestamp = timestamp;
            this.isOnboarding = isOnboarding;
        }
    }

    final class GetTransactionStatusResponse {
        public static final int STATUS_PROCESSING = 1;
        public static final int STATUS_SUCCESS = 2;
        public static final int STATUS_FAILURE = 3;

        @SerializedName("customer_id") public final String customerId;
        @SerializedName("request_id") public final String requestId;
        @SerializedName("status") public final int status;
        @SerializedName("tx_id") public final String transactionId;
        @SerializedName("error") public final String errorJson;
        @SerializedName("created_at") public final DateTime createdAt;
        @SerializedName("updated_at") public final DateTime updatedAt;

        public GetTransactionStatusResponse(String customerId, String requestId, int status, String transactionId, String errorJson, DateTime createdAt, DateTime updatedAt) {
            this.customerId = customerId;
            this.requestId = requestId;
            this.status = status;
            this.transactionId = transactionId;
            this.errorJson = errorJson;
            this.createdAt = createdAt;
            this.updatedAt = updatedAt;
        }
    }

    final class AddCustomerRequest {
        @SerializedName("mobile") private final String mobile;
        @SerializedName("description") private final String desc;
        @SerializedName("reactivate") private final boolean reactivate;
        @SerializedName("profile_image") private final String profileImage;

        public AddCustomerRequest(String mobile, String desc, boolean reactivate, String profileImage) {
            this.mobile = mobile;
            this.desc = desc;
            this.reactivate = reactivate;
            this.profileImage = profileImage;
        }
    }

    final class UpdateCustomerRequest {
        @SerializedName("mobile") private final String mobile;
        @SerializedName("description") private final String desc;
        @SerializedName("address") private final String address;
        @SerializedName("customer_token") private final String customerToken;
        @SerializedName("profile_image") private final String profileImage;

        public UpdateCustomerRequest(String desc, String mobile, String address, String customerToken, String profileImage) {
            this.mobile = mobile;
            this.desc = desc;
            this.address = address;
            this.customerToken = customerToken;
            this.profileImage = profileImage;
        }
    }

    final class FeedbackRequest {
        @SerializedName("rating") private final int rating;
        @SerializedName("feedback") private final String feedback;

        public FeedbackRequest(int rating, String feedback) {
            this.rating = rating;
            this.feedback = feedback;
        }
    }

    final class GetNotificationResponse {
        @SerializedName("notification_id") public final String notificationId;
        @SerializedName("visible") public final String visible;
        @SerializedName("title") public final String title;
        @SerializedName("content") public final String content;
        @SerializedName("image_url") public final String imageUrl;
        @SerializedName("primary_action") public final String primaryAction;
        @SerializedName("btn_enabled") public final String btnEnabled;
        @SerializedName("btn_primary_label") public final String btnPrimaryLabel;
        @SerializedName("btn_secondary_label") public final String btnSecondaryLabel;
        @SerializedName("priority") public final String priority;
        @SerializedName("expire_time") public final String expireTime;
        @SerializedName("_campaign_id") public final String campaignId;
        @SerializedName("_subcampaign_id") public final String subcampaignId;


        public GetNotificationResponse(String notificationId, String visible, String title, String content, String image_url, String primary_action,
                                       String btn_enabled, String btn_primary_label, String btn_secondary_label,
                                       String priority, String expire_time, String _campaign_id, String _subcampaign_id) {
            this.notificationId = notificationId;
            this.visible = visible;
            this.title = title;
            this.content = content;
            this.imageUrl = image_url;
            this.primaryAction = primary_action;
            this.btnEnabled = btn_enabled;
            this.btnPrimaryLabel = btn_primary_label;
            this.btnSecondaryLabel = btn_secondary_label;
            this.priority = priority;
            this.expireTime = expire_time;
            this.campaignId = _campaign_id;
            this.subcampaignId = _subcampaign_id;
        }
    }

    final class AnswerRequest {
        @SerializedName("msg_id") private final String msgId;
        @SerializedName("response") private final String response;

        public AnswerRequest(String msgId, String response) {
            this.msgId = msgId;
            this.response = response;
        }
    }

    final class SendCustomerOtpRequest {
        @SerializedName("customer_id") private final String customerId;
        @SerializedName("mobile") private final String mobile;

        public SendCustomerOtpRequest(String customerId, String mobile) {
            this.customerId = customerId;
            this.mobile = mobile;
        }
    }

    final class VerifyCustomerOtpRequest {
        @SerializedName("request_id") private final String requestId;
        @SerializedName("otp") private final String otp;

        public VerifyCustomerOtpRequest(String requestId, String otp) {
            this.requestId = requestId;
            this.otp = otp;
        }
    }

    final class SendCustomerOtpResponce {
        @SerializedName("request_id") public final String requestId;
        @SerializedName("expiry_time") public final DateTime expiryTime;

        public SendCustomerOtpResponce(String requestId, DateTime expiryTime) {
            this.requestId = requestId;
            this.expiryTime = expiryTime;
        }
    }

    final class VerifyCustomerOtpResponce {
        @SerializedName("customer_token") public final String customerToken;

        public VerifyCustomerOtpResponce(String customerToken) {
            this.customerToken = customerToken;
        }
    }
}
