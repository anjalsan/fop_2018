package in.okcredit._offline.server.identity.internal;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Transaction;

@Dao
public abstract class IdentityDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public abstract void insertIdentityMapping(IdentityMapping mapping);

    @Query("SELECT serverId FROM identitymapping WHERE type = :type AND localId = :localId LIMIT 1")
    public abstract String getServerId(int type, String localId);

    @Query("SELECT localId FROM identitymapping WHERE type = :type AND serverId = :serverId LIMIT 1")
    public abstract String getLocalId(int type, String serverId);

    @Query("DELETE FROM identitymapping WHERE type = :type AND localId = :localId")
    public abstract void deleteByLocalId(int type, String localId);

    @Query("DELETE FROM identitymapping WHERE type = :type AND serverId = :serverId")
    public abstract void deleteByServerId(int type, String serverId);

    @Transaction
    public void putIdentityMapping(IdentityMapping mapping) {
        deleteByLocalId(mapping.type, mapping.localId);
        deleteByServerId(mapping.type, mapping.serverId);
        insertIdentityMapping(mapping);
    }
}
