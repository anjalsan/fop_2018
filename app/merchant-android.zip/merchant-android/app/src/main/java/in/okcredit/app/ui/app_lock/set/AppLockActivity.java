package in.okcredit.app.ui.app_lock.set;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.andrognito.patternlockview.PatternLockView;
import com.andrognito.patternlockview.listener.PatternLockViewListener;
import com.andrognito.patternlockview.utils.PatternLockUtils;

import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.R;
import in.okcredit.ThreadUtils;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.observers.DisposableObserver;

public class AppLockActivity extends BaseActivity implements AppLockContract.View {

    public static Intent startingIntent(Context context) {
        return new Intent(context, AppLockActivity.class);
    }

    @BindView(R.id.title)
    TextView title;

    @BindView(R.id.subtitle)
    TextView subtitle;

    @BindView(R.id.pattern_lock_view)
    PatternLockView patternLock;

    @BindView(R.id.action)
    Button button;

    @Inject
    AppLockContract.Presenter presenter;

    private String firstPattern, secondPattern;
    private boolean isFirstPatternSet;

    private boolean isAppLockActive;

    /* Lifecycle methods */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.screen_app_lock);
        ButterKnife.bind(this);

        firstPattern = "";
        secondPattern = "";
        isFirstPatternSet = false;

        button.setVisibility(View.INVISIBLE);

        patternLock.addPatternLockListener(new PatternLockViewListener() {
            @Override
            public void onStarted() {

                button.setVisibility(View.INVISIBLE);
            }

            @Override
            public void onProgress(List<PatternLockView.Dot> progressPattern) {

            }

            @Override
            public void onComplete(List<PatternLockView.Dot> pattern) {

                if (!isAppLockActive) {
                    button.setVisibility(View.VISIBLE);
                    if (!isFirstPatternSet) {
                        firstPattern = PatternLockUtils.patternToString(patternLock, pattern);
                    } else {
                        secondPattern = PatternLockUtils.patternToString(patternLock, pattern);
                    }
                } else {
                    presenter.disableAppLock(PatternLockUtils.patternToString(patternLock, pattern));
                }
            }

            @Override
            public void onCleared() {

            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!isFirstPatternSet) {
                    if (firstPattern == null || firstPattern.length() < 4) {
                        showInvalidPatternMessage();
                        isFirstPatternSet = false;
                        patternLock.setViewMode(PatternLockView.PatternViewMode.WRONG);
                        button.setVisibility(View.INVISIBLE);
                        subtitle.setVisibility(View.VISIBLE);
                        subtitle.setText(R.string.invalid_pattern);
                    } else {
                        isFirstPatternSet = true;
                        patternLock.clearPattern();
                        button.setVisibility(View.INVISIBLE);
                        subtitle.setText(getString(R.string.draw_patern_again));
                        button.setText(getString(R.string.confirm_pattern));
                        subtitle.setVisibility(View.VISIBLE);
                    }
                } else {
                    if (secondPattern == null) {
                        showPatternMismatchMessage();
                        patternLock.setViewMode(PatternLockView.PatternViewMode.WRONG);
                        button.setVisibility(View.INVISIBLE);
                        subtitle.setVisibility(View.VISIBLE);
                        subtitle.setText(R.string.pattern_mismatch);
                    } else {
                        if (secondPattern.equals(firstPattern)) {
                            patternLock.setViewMode(PatternLockView.PatternViewMode.CORRECT);
                            presenter.enableAppLock(firstPattern);
                        } else {
                            showPatternMismatchMessage();
                            patternLock.setViewMode(PatternLockView.PatternViewMode.WRONG);
                            button.setVisibility(View.INVISIBLE);
                            subtitle.setVisibility(View.VISIBLE);
                            subtitle.setText(R.string.pattern_mismatch);
                        }
                    }

                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.attachView(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        presenter.detachView();
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    public void setAppLockStatus(boolean isAppLockActive) {

        this.isAppLockActive = isAppLockActive;

        Analytics.track(
            AnalyticsEvents.APP_LOCK_SCREEN,
            EventProperties
                .create()
                .with("isAppLockActive", isAppLockActive)
        );

        if (isAppLockActive) {
            title.setText(getString(R.string.disable_app_lock));
            subtitle.setText(R.string.draw_unlock_pattern);
            button.setVisibility(View.INVISIBLE);
        } else {
            title.setText(getString(R.string.enable_app_lock));
            subtitle.setText(R.string.draw_unlock_pattern);
            button.setText(getString(R.string.set_pattern));
        }
    }

    @Override
    public void goToAppLockPrefActivity(boolean isAppLockEnabled) {

        Analytics.track(
            AnalyticsEvents.APP_LOCK_SCREEN_SUCCESS,
            EventProperties
                .create()
                .with("enabled", isAppLockEnabled)
        );

        if (isAppLockEnabled) {
            Toast.makeText(this, getString(R.string.app_lock_enabled), Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, getString(R.string.app_lock_disabled), Toast.LENGTH_SHORT).show();
        }

        finish();
    }

    @Override
    public void showIncorrectOldPatternMessage() {

        Analytics.track(
            AnalyticsEvents.APP_LOCK_WRONG_PATTERN,
            EventProperties
                .create()
                .with("state", isAppLockActive)
        );

        patternLock.setViewMode(PatternLockView.PatternViewMode.WRONG);
        button.setVisibility(View.INVISIBLE);
        subtitle.setVisibility(View.VISIBLE);
        subtitle.setText(R.string.incorrect_pattern);

        Observable.timer(1, TimeUnit.SECONDS, ThreadUtils.newThread())
                  .observeOn(AndroidSchedulers.mainThread())
                  .subscribe(new DisposableObserver<Long>() {
                      @Override
                      public void onNext(Long aLong) {
                          patternLock.clearPattern();
                      }

                      @Override
                      public void onError(Throwable e) {

                      }

                      @Override
                      public void onComplete() {

                      }
                  });
    }

    @Override
    public void showInvalidPatternMessage() {

    }

    @Override
    public void showPatternMismatchMessage() {
        Analytics.track(
            AnalyticsEvents.APP_LOCK_WRONG_PATTERN,
            EventProperties
                .create()
                .with("state", isAppLockActive)
        );
    }

    @Override
    public void showError() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "app lock screen")
                .with("type", "server error")
        );

        Toast.makeText(this, R.string.err_default, Toast.LENGTH_LONG).show();
        finish();
    }

    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(this, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
            }
        });
    }
}
