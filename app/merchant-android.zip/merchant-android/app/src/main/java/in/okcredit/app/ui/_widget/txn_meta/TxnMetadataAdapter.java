package in.okcredit.app.ui._widget.txn_meta;

import android.content.Context;
import android.support.v7.util.DiffUtil;
import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class TxnMetadataAdapter extends RecyclerView.Adapter<TxnMetadataViewHolder> {
    private Context context;
    private List<TxnMetadataView.TxnMetadata> metadataList;

    public TxnMetadataAdapter(Context context) {
        this.context = context;
        metadataList = new ArrayList<>();
    }

    public void add(TxnMetadataView.TxnMetadata metadata) {
        List<TxnMetadataView.TxnMetadata> updatedList = new ArrayList<>();
        boolean isAdded = false;
        for (TxnMetadataView.TxnMetadata m : metadataList) {
            if (m.type == metadata.type) {
                updatedList.add(metadata);
                isAdded = true;
            } else {
                updatedList.add(m);
            }
        }
        if (!isAdded)
            updatedList.add(metadata);

        refresh(updatedList);
    }

    public void remove(int type) {
        List<TxnMetadataView.TxnMetadata> updatedList = new ArrayList<>();
        for (TxnMetadataView.TxnMetadata m : metadataList) {
            if (m.type != type)
                updatedList.add(m);
        }
        refresh(updatedList);
    }

    @Override
    public TxnMetadataViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return TxnMetadataViewHolder.create(context, parent);
    }

    @Override
    public void onBindViewHolder(TxnMetadataViewHolder holder, int position) {
        holder.bind(metadataList.get(position));
    }

    @Override
    public int getItemCount() {
        return metadataList.size();
    }

    private void refresh(List<TxnMetadataView.TxnMetadata> updatedList) {
        final DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(
            new DiffUtil.Callback() {
                @Override
                public int getOldListSize() {
                    return metadataList.size();
                }

                @Override
                public int getNewListSize() {
                    return updatedList.size();
                }

                @Override
                public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
                    TxnMetadataView.TxnMetadata oldItem = metadataList.get(oldItemPosition);
                    TxnMetadataView.TxnMetadata newItem = updatedList.get(newItemPosition);
                    return oldItem.type == newItem.type;
                }

                @Override
                public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
                    TxnMetadataView.TxnMetadata oldItem = metadataList.get(oldItemPosition);
                    TxnMetadataView.TxnMetadata newItem = updatedList.get(newItemPosition);
                    return oldItem.type == newItem.type &&
                        oldItem.iconRes == newItem.iconRes &&
                        oldItem.msg.equals(newItem.msg) &&
                        oldItem.actionLabel.equals(newItem.actionLabel) &&
                        oldItem.onClickListener.equals(newItem.onClickListener);
                }
            },
            true);
        this.metadataList = updatedList;
        diffResult.dispatchUpdatesTo(this);
    }
}
