package in.okcredit._offline.server;

import android.arch.persistence.room.EmptyResultSetException;
import android.util.Pair;

import org.joda.time.DateTime;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import javax.annotation.Nullable;
import javax.inject.Inject;

import in.okcredit.ThreadUtils;
import in.okcredit._offline.common.Error;
import in.okcredit._offline.common.Utils;
import in.okcredit._offline.error.CustomerErrors;
import in.okcredit._offline.error.MerchantErrors;
import in.okcredit._offline.error.TransactionErrors;
import in.okcredit._offline.model.Customer;
import in.okcredit._offline.model.Merchant;
import in.okcredit._offline.model.Transaction;
import in.okcredit._offline.model.Version;
import in.okcredit._offline.server.identity.Identity;
import in.okcredit._offline.server.internal.ApiClient;
import in.okcredit._offline.server.internal.ApiEntityMapper;
import in.okcredit._offline.server.internal.ApiMessages;
import in.okcredit._offline.server.internal.TransactionMapper;
import in.okcredit.domain.otp.OtpErrors;
import in.okcredit.util.DateTimeMapper;
import io.reactivex.Completable;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import retrofit2.Response;
import timber.log.Timber;

public final class Server {
    private ApiClient apiClient;
    private Identity identity;
    private TransactionMapper transactionMapper;

    @Inject
    public Server(ApiClient apiClient, Identity identity, TransactionMapper transactionMapper) {
        this.apiClient = apiClient;
        this.identity = identity;
        this.transactionMapper = transactionMapper;
    }

    public Completable ping() {
        return apiClient.pingServer()
                        .subscribeOn(ThreadUtils.api())
                        .observeOn(ThreadUtils.worker())
                        .flatMapCompletable(res -> {
                            if (res.isSuccessful()) {
                                return Completable.complete();
                            } else {
                                return Completable.error(Error.parse(res));
                            }
                        });
    }

    public Single<Version> getLatestVersion() {
        return apiClient.getLatestVersion()
                        .subscribeOn(ThreadUtils.api())
                        .observeOn(ThreadUtils.worker())
                        .map(res -> {
                            if (res.isSuccessful()) {
                                return res.body();
                            } else {
                                throw Error.parse(res);
                            }
                        });
    }

    public Single<Boolean> checkMobileStatus(String mobile) {
        return apiClient.checkMobileStatus(new ApiMessages.CheckMobileStatusRequest(mobile))
                        .subscribeOn(ThreadUtils.api())
                        .observeOn(ThreadUtils.worker())
                        .map(res -> res.isSuccessful());
    }

    public Completable register(String mobile, String name, String password, String token, String lang) {
        return apiClient
            .register(new ApiMessages.RegisterRequest(mobile, name, password, token, lang))
            .subscribeOn(ThreadUtils.api())
            .observeOn(ThreadUtils.worker())
            .flatMapCompletable(response ->
            {
                if (response.isSuccessful()) {
                    return Completable.complete();
                } else {
                    return Completable.error(Error.parse(response));
                }
            });
    }

    public Single<Merchant> getActiveMerchant() {
        return apiClient.getActiveMerchant()
                        .subscribeOn(ThreadUtils.api())
                        .observeOn(ThreadUtils.worker())
                        .map(response -> {
                            if (response.isSuccessful()) {
                                return response.body();
                            } else {
                                throw Error.parse(response);
                            }
                        })
                        .map(merchant -> ApiEntityMapper.MERCHANT.convert(merchant));
    }

    public Completable updateMerchant(String name) {
        return apiClient.updateMerchant(new ApiMessages.UpdateMerchantRequest(name))
                        .subscribeOn(ThreadUtils.api())
                        .observeOn(ThreadUtils.worker())
                        .flatMapCompletable(res -> {
                            if (res.isSuccessful()) {
                                return Completable.complete();
                            } else {
                                Error error = Error.parse(res);
                                switch (error.getCode()) {
                                    case 400:
                                        return Completable.error(new MerchantErrors.InvalidName());

                                    case 403:
                                        return Completable.error(new MerchantErrors.NameChangeLimitExceeded());

                                    default:
                                        return Completable.error(error);
                                }
                            }
                        });
    }

    public Completable setMerchantPreference(String key, String value) {
        return apiClient.setPreference(new ApiMessages.SetMerchantPreferenceRequest(key, value))
                        .subscribeOn(ThreadUtils.api())
                        .observeOn(ThreadUtils.worker())
                        .flatMapCompletable(res ->
                        {
                            if (res.isSuccessful()) {
                                return Completable.complete();
                            } else {
                                return Completable.error(Error.parse(res));
                            }
                        });
    }

    public Single<Map<String, String>> getMerchantPreferences() {
        return apiClient.getMerchantPreferences(null)
                        .subscribeOn(ThreadUtils.api())
                        .observeOn(ThreadUtils.worker())
                        .map(res -> {
                            if (res.isSuccessful()) {
                                return res.body();
                            } else {
                                throw Error.parse(res);
                            }
                        });
    }

    public Completable linkDevice(String deviceId) {
        if (deviceId != null) {
            return apiClient.linkDevice(deviceId)
                .subscribeOn(ThreadUtils.api())
                .observeOn(ThreadUtils.worker())
                .flatMapCompletable(response -> {
                    if (response.isSuccessful()) {
                        return Completable.complete();
                    } else {
                        return Completable.error(Error.parse(response));
                    }
                });
        } else {
            return Completable.error(new Error(400, "device_id is null"));
        }
    }

    public Single<String> getReferralLink() {
        return apiClient.getReferralLink()
                        .subscribeOn(ThreadUtils.api())
                        .observeOn(ThreadUtils.worker())
                        .map(res -> {
                            if (res.isSuccessful()) {
                                return res.body().referralLink;
                            } else {
                                throw Error.parse(res);
                            }
                        });
    }

    public Single<List<Customer>> listCustomers(@Nullable String mobile) {
        return apiClient.listCustomers(mobile)
                        .subscribeOn(ThreadUtils.api())
                        .observeOn(ThreadUtils.worker())
                        .map(response -> {
                            if (response.isSuccessful()) {
                                return response.body();
                            } else {
                                throw Error.parse(response);
                            }
                        })
                        .map(customers -> Utils.mapList(customers, ApiEntityMapper.CUSTOMER));
    }

    public Single<Customer> getCustomer(String customerId) {
        return apiClient.getCustomer(customerId)
                        .subscribeOn(ThreadUtils.api())
                        .observeOn(ThreadUtils.worker())
                        .map(res -> {
                            if (res.isSuccessful()) {
                                return res.body();
                            } else {
                                throw Error.parse(res);
                            }
                        })
                        .map(customer -> ApiEntityMapper.CUSTOMER.convert(customer));
    }

    public Single<Customer> addCustomer(String description, String mobile, boolean reactivate, String profileImage, String email) {
        return apiClient
            .addCustomer(new ApiMessages.AddCustomerRequest(mobile, description, reactivate, profileImage))
            .subscribeOn(ThreadUtils.api())
            .observeOn(ThreadUtils.worker())
            .flatMap(res -> {
                if (res.isSuccessful()) {
                    // success
                    return Single.just(res.body())
                                 .map(customer -> ApiEntityMapper.CUSTOMER.convert(customer));
                } else {
                    Error error = Error.parse(res);
                    if (error.getCode() == 409 && "customer_exists".equals(error.getMessage())) {
                        // mobile already registered with another customer
                        // find that customer and throw an error
                        return apiClient
                            .listCustomers(mobile)
                            .subscribeOn(ThreadUtils.api())
                            .observeOn(ThreadUtils.worker())
                            .map(findByMobileRes -> {
                                if (findByMobileRes.isSuccessful()) {
                                    List<ApiMessages.Customer> customers = findByMobileRes
                                        .body();
                                    if (customers.size() != 1) {
                                        throw new IllegalAccessException("mobile conflict but find_by_mobile not valid");
                                    }
                                    return customers.get(0);
                                } else {
                                    throw Error.parse(findByMobileRes);
                                }
                            })
                            .map(customer -> ApiEntityMapper.CUSTOMER.convert(customer))
                            .flatMap(customer -> {
                                if (customer.getStatus() == 1) {
                                    return Single.<Customer>error(new CustomerErrors.MobileConflict(customer));
                                } else {
                                    return Single.<Customer>error(new CustomerErrors.DeletedCustomer(customer));
                                }
                            });

                    } else {
                        return Single.error(error);
                    }
                }
            });
    }

    public Completable deleteCustomer(String customerId) {
        return apiClient
            .deleteCustomer(customerId)
            .subscribeOn(ThreadUtils.api())
            .observeOn(ThreadUtils.worker())
            .flatMapCompletable(res -> {
                if (res.isSuccessful()) {
                    return Completable.complete();
                } else {
                    Error error = Error.parse(res);
                    if (error.getCode() == 409) {
                        return Completable.error(new CustomerErrors.DeletePermissionDenied());
                    } else {
                        return Completable.error(error);
                    }
                }
            });
    }

    public Single<List<Transaction>> listTransactions(String customerId, DateTime startTime, DateTime endTime) {
        return apiClient
            .listTransactions(
                customerId,
                DateTimeMapper.toEpoch(startTime),
                DateTimeMapper.toEpoch(endTime)
            )
            .subscribeOn(ThreadUtils.api())
            .observeOn(ThreadUtils.worker())
            .map(res -> {
                if (res.isSuccessful()) {
                    return res.body();
                } else {
                    throw Error.parse(res);
                }
            })
            .observeOn(ThreadUtils.database())
            .map(transactions -> Utils.mapList(transactions, transactionMapper))
            .observeOn(ThreadUtils.worker());
    }

    public Single<Transaction> getTransaction(String txnId) {
        Timber.i("GetTxn: local_id = %s", txnId);
        String serverId = identity.localToServer(Identity.TYPE_TRANSACTION, txnId);
        Timber.i("GetTxn: server_id = %s", serverId);
        if (serverId == null) {
            return Single.error(new NullPointerException());
        }

        return apiClient
            .getTransaction(serverId)
            .subscribeOn(ThreadUtils.api())
            .observeOn(ThreadUtils.worker())
            .map(res -> {
                if (res.isSuccessful()) {
                    return res.body();
                } else {
                    throw Error.parse(res);
                }
            })
            .observeOn(ThreadUtils.database())
            .map(transaction -> transactionMapper.convert(transaction))
            .observeOn(ThreadUtils.worker());
    }

    public Completable deleteTransaction(String txnId) {
        String serverId = identity.localToServer(Identity.TYPE_TRANSACTION, txnId);
        if (serverId == null) {
            return Completable.complete();
        }

        return apiClient
            .deleteTransaction(serverId)
            .subscribeOn(ThreadUtils.api())
            .observeOn(ThreadUtils.worker())
            .flatMapCompletable(res -> {
                if (res.isSuccessful()) {
                    return Completable.complete();
                } else {
                    throw Error.parse(res);
                }
            });
    }

    public Single<Transaction> addTransaction(String customerId,
                                              String localId,
                                              int type,
                                              float amount,
                                              String receiptUrl,
                                              String note,
                                              DateTime timestamp,
                                              boolean isOnboarding) {
        return Single
            .fromCallable(() -> {
                ApiMessages.AddTransactionRequest req = new ApiMessages.AddTransactionRequest(
                    customerId,
                    localId,
                    type,
                    amount,
                    receiptUrl,
                    note,
                    timestamp,
                    isOnboarding
                );

                Response<Void> addRes = apiClient.addTransaction(req).execute();
                if (!addRes.isSuccessful()) {
                    throw Error.parse(addRes);
                }

                while (true) {
                    Response<ApiMessages.GetTransactionStatusResponse> statusRes =
                        apiClient.getTransactionStatus(customerId, localId).execute();

                    if (statusRes.isSuccessful()) {

                        ApiMessages.GetTransactionStatusResponse statusResBody = statusRes.body();
                        assert statusResBody != null;

                        if (statusResBody.status == ApiMessages.GetTransactionStatusResponse.STATUS_SUCCESS) {
                            // successful, return transaction id
                            identity.createMapping(Identity.TYPE_TRANSACTION, localId, statusResBody.transactionId);
                            return statusResBody.transactionId;
                        } else if (statusResBody.status == ApiMessages.GetTransactionStatusResponse.STATUS_FAILURE) {
                            // failed, unknown error
                            throw new TransactionErrors.AddFailed();
                        } else {
                            // still processing, sleep for 200ms
                            Thread.sleep(200);
                            continue;
                        }

                    } else {

                        if (statusRes.code() == 404) {
                            // edge case (might still not be created on server), sleep for 200ms
                            Thread.sleep(200);
                            continue;
                        } else {

                            throw Error.parse(statusRes);
                        }
                    }
                }
            })
            .subscribeOn(ThreadUtils.api())
            .observeOn(ThreadUtils.worker())
            .flatMap(serverId -> getTransaction(localId));
    }

    public Single<Customer> updateCustomer(String customerId, String desc, String address, String profileImage, String mobile, String customerToken) {
        return apiClient.updateCustomer(customerId, new ApiMessages.UpdateCustomerRequest(desc, mobile, address, customerToken, profileImage))
                        .subscribeOn(ThreadUtils.api())
                        .observeOn(ThreadUtils.worker())
                        .flatMap(res -> {
                            if (res.isSuccessful()) {
                                // success
                                return Single.just(res.body())
                                             .map(customer -> ApiEntityMapper.CUSTOMER.convert(customer));
                            } else {
                                Error error = Error.parse(res);
                                if (error.getCode() == 403) {

                                    throw new CustomerErrors.MobileUpdateAccessDenied();
                                } else if (error.getCode() == 409 && "customer_exists".equals(error.getMessage())) {

                                    // mobile already registered with another customer
                                    // find that customer and throw an error
                                    return apiClient
                                        .listCustomers(mobile)
                                        .subscribeOn(ThreadUtils.api())
                                        .observeOn(ThreadUtils.worker())
                                        .map(findByMobileRes -> {
                                            if (findByMobileRes.isSuccessful()) {
                                                List<ApiMessages.Customer> customers = findByMobileRes
                                                    .body();
                                                if (customers.size() != 1) {
                                                    throw new IllegalAccessException("mobile conflict but find_by_mobile not valid");
                                                }
                                                return customers.get(0);
                                            } else {
                                                throw Error.parse(findByMobileRes);
                                            }
                                        })
                                        .map(customer -> ApiEntityMapper.CUSTOMER.convert(customer))
                                        .flatMap(customer -> Single.<Customer>error(new CustomerErrors.MobileConflict(customer)));
                                } else {

                                    return Single.error(error);
                                }
                            }
                        });
    }

    // contacts => (mobile, desc)
    public Single<Pair<List<Customer>, Map<String, Throwable>>> bulkAddCustomers(List<Pair<String, String>> contacts, boolean reactivate) {
        List<ApiMessages.AddCustomerRequest> req = new ArrayList<>();
        for (Pair<String, String> contact : contacts) {
            req.add(new ApiMessages.AddCustomerRequest(contact.first, contact.second, reactivate, null));
        }

        return apiClient
            .bulkAddCustomers(req)
            .subscribeOn(ThreadUtils.api())
            .observeOn(ThreadUtils.worker())
            .map(res -> {
                if (res.isSuccessful()) {
                    Map<String, Error> rawErrors = res.body();

                    // successfully added customers
                    List<String> success = new ArrayList<>();
                    for (Pair<String, String> contact : contacts) {
                        if (!rawErrors.containsKey(contact.first)) {
                            success.add(contact.first);
                        }
                    }

                    List<Customer> addedNow = new ArrayList<>();
                    if (success.size() > 0) {
                        List<Customer> allCustomers = listCustomers(null).blockingGet();
                        for (Customer customer : allCustomers) {
                            if (success.contains(customer.getMobile())) {
                                addedNow.add(customer);
                            }
                        }
                    }

                    // process errors
                    Map<String, Throwable> errors = new HashMap<>();
                    for (Map.Entry<String, Error> entry : rawErrors.entrySet()) {
                        String mobile = entry.getKey();
                        Error error = entry.getValue();
                        Timber.e("(%d, %s): %s, %s", error.getCode(), error.getError(), error.getCode() == 409,
                            "customer_exists".equals(error.getError()));
                        if (error.getCode() == 409 && "customer_exists".equals(error.getError())) {
                            try {
                                Customer customer = findCustomerByMobile(mobile).blockingGet();
                                if (customer.getStatus() != 1) {// not active
                                    errors.put(mobile, new CustomerErrors.DeletedCustomer(customer));
                                }
                            } catch (Exception e) {
                                Timber.w(e, "failed to get customer");
                            }
                        }

                        if (!errors.containsKey(mobile)) {
                            errors.put(mobile, new RuntimeException(error));
                        }
                    }

                    return new Pair<>(addedNow, errors);
                } else {
                    throw Error.parse(res);
                }
            });
    }

    private Single<Customer> findCustomerByMobile(String mobile) {
        return apiClient
            .listCustomers(mobile)
            .subscribeOn(ThreadUtils.api())
            .observeOn(ThreadUtils.worker())
            .map(res -> {
                if (res.isSuccessful()) {
                    List<ApiMessages.Customer> customers = res.body();
                    if (customers.size() == 0) {
                        throw new NoSuchElementException();
                    }
                    if (customers.size() == 1) {
                        return customers.get(0);
                    } else {
                        throw new IllegalStateException("find_by_mobile returned more than one customer");
                    }
                } else {
                    throw Error.parse(res);
                }
            })
            .map(customer -> ApiEntityMapper.CUSTOMER.convert(customer));
    }

    public Completable submitFeedback(String feedback, int rating) {
        return apiClient.submitFeedback(new ApiMessages.FeedbackRequest(rating, feedback))
                        .subscribeOn(ThreadUtils.api())
                        .observeOn(ThreadUtils.worker())
                        .flatMapCompletable(res -> {
                            if (res.isSuccessful()) {
                                return Completable.complete();
                            } else {
                                return Completable.error(Error.parse(res));
                            }
                        });
    }

    public Single<ApiMessages.SendCustomerOtpResponce> sendCustomerOtp(String customerId, String mobile) {
        return apiClient.sendCustomerOtp(new ApiMessages.SendCustomerOtpRequest(customerId, mobile))
                        .subscribeOn(ThreadUtils.api())
                        .observeOn(ThreadUtils.worker())
                        .map(res -> {
                            if (res.isSuccessful()) {
                                if (res.body() != null && res.body() != null) {
                                    return res.body();
                                } else {
                                    throw Error.parse(res);
                                }
                            } else {
                                throw Error.parse(res);
                            }
                        });
    }

    public Single<String> verifyCustomerOtp(String requestId, String otp) {
        return apiClient.verifyCustomerOtp(new ApiMessages.VerifyCustomerOtpRequest(requestId, otp))
                        .subscribeOn(ThreadUtils.api())
                        .observeOn(ThreadUtils.worker())
                        .map(res -> {
                            if (res.isSuccessful()) {
                                if (res.body() != null && res.body().customerToken != null) {
                                    return res.body().customerToken;
                                } else {
                                    throw Error.parse(res);
                                }
                            } else {
                                Error error = Error.parse(res);
                                switch (error.getError()) {
                                    case "invalid_otp":
                                        throw new OtpErrors.Invalid();
                                    case "otp_expired":
                                        throw new OtpErrors.Expired();
                                    default:
                                        throw Error.parse(res);
                                }
                            }
                        });
    }
}
