package in.okcredit._offline.usecase;

import javax.inject.Inject;

import in.okcredit._offline.error.MerchantErrors;
import in.okcredit._offline.server.Server;
import io.reactivex.Completable;

// Internet
public final class UpdateMerchant {
    private Server server;
    private FetchActiveMerchant fetchActiveMerchant;

    @Inject
    public UpdateMerchant(Server server, FetchActiveMerchant fetchActiveMerchant) {
        this.server = server;
        this.fetchActiveMerchant = fetchActiveMerchant;
    }

    public Completable execute(String name) {
        if (name == null || name.length() < 3) {
            return Completable.error(new MerchantErrors.InvalidName());
        }

        return server.updateMerchant(name)
                     .andThen(fetchActiveMerchant.execute());
    }
}
