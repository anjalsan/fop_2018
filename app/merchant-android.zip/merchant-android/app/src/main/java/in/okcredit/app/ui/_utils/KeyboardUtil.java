package in.okcredit.app.ui._utils;

import android.app.Activity;
import android.support.v4.app.Fragment;
import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import timber.log.Timber;

public class KeyboardUtil {
    public static void hideKeyboard(Activity activity, View view) {
        if (activity != null) {
            try {
                View focusedView = activity.getCurrentFocus();
                if (focusedView == null)
                    focusedView = new View(activity);

                InputMethodManager inputManager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
                inputManager.hideSoftInputFromWindow(focusedView.getWindowToken(), 0);
                focusedView.clearFocus();
            } catch (Exception e) {
                Timber.e(e, "Exception while closing keyboard");
            }
        }
    }

    public static void hideKeyboard(@NonNull Fragment fragment) {
        try {
            InputMethodManager inputManager = (InputMethodManager) fragment.getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            inputManager.hideSoftInputFromWindow(fragment.getView().getRootView().getWindowToken(), 0);
        } catch (Exception e) {
            Timber.e(e, "Exception while closing keyboard");
        }
    }

    public static void showKeyboard(@NonNull Context context, View view) {
        if (context != null) {
            try {
                InputMethodManager inputManager = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
                inputManager.showSoftInput(view, InputMethodManager.SHOW_FORCED);
                view.requestFocus();
            } catch (Exception e) {
                Timber.e(e, "Exception while showing keyboard");
            }
        }
    }
}
