package in.okcredit.app.ui._base;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.StringRes;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AppCompatDelegate;
import android.support.v7.widget.Toolbar;
import android.view.View;

import javax.inject.Inject;

import in.okcredit.App;
import in.okcredit.AppLockManager;
import in.okcredit.Constants;
import in.okcredit.LocaleManager;
import in.okcredit.R;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui.app_lock.prompt.AppLockPromptActivity;
import in.okcredit.app.ui.login.LoginActivity;
import timber.log.Timber;

public abstract class BaseActivity extends AppCompatActivity implements BaseView {
    protected Toolbar toolbar;

    @Inject
    AppLockManager appLockManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // vector drawable support
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (App.getInstance().wasAppInBackground)
        {
            AppLockManager.getInstance(this).setAppInBackground();
        }

        App.getInstance().stopActivityTransitionTimer();

        if (AppLockManager.getInstance(this).isAppLockAuthReqd()) {
            startActivity(AppLockPromptActivity.startingIntent(this));
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        App.getInstance().startActivityTransitionTimer();
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleManager.setLocale(base));
    }

    protected void setupActionBar(@StringRes int title) {
        try {
            toolbar = findViewById(R.id.toolbar);

            setSupportActionBar(toolbar);
            getSupportActionBar().setTitle(getString(title));
        } catch (Exception e) {
            Timber.e(e, "showActionBar() failed");
        }
    }

    /****************************************************************
     HELP
     ****************************************************************/
    public void startHelpFlow() {
        Analytics.track(AnalyticsEvents.HELP);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) !=
            PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE},
                0);
        } else {
            Intent intent = new Intent(Intent.ACTION_CALL);
            intent.setData(Uri.parse("tel:" + getHelpNumber()));
            startActivity(intent);
        }
    }

    /****************************************************************
     MVP methods (default implementation)
     ****************************************************************/
    public abstract void onNetworkFailure();

    @Override
    public void onAuthenticationFailure() {
        Analytics.track(AnalyticsEvents.AUTH_FAILURE);
        startActivityForResult(LoginActivity.startingIntent(this, LoginActivity.FLAG_AUTH_FAIL),
            21);
    }


    public void disableAutoFill() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                getWindow().getDecorView().setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
            }
        } catch (Exception e){

        }
    }

    public String getHelpNumber() {
        String languagePref = LocaleManager.getLanguage();
        if (languagePref != null && languagePref.equals(LocaleManager.LANGUAGE_MALAYALAM)) {
            return Constants.HELP_MOBILE_MALAYALAM;
        } else {
            return Constants.HELP_MOBILE;
        }
    }
}
