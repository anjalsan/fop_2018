package in.okcredit.app.ui.security;

import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;

public interface SecurityContract {
    interface Presenter extends MVP.Presenter<View>, BaseContracts.Online.Presenter<View>, BaseContracts.Authenticated.Presenter<View> {
        void logout(String password);
        void onResetPasswordClicked();
    }

    interface View extends MVP.View, BaseContracts.Online.View, BaseContracts.Authenticated.View {
        void gotoAppLockScreen();

        void onLogoutSuccessful();

        void gotoResetPasswordScreen(String mobile);

        void setAppLockStatus(boolean isAppLockActive);

        void displayInvalidCredentialsError();
    }
}
