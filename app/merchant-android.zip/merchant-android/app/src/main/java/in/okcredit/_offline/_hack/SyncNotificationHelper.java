package in.okcredit._offline._hack;

import android.app.NotificationChannel;
import android.content.Context;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v4.content.ContextCompat;

import javax.inject.Inject;

import in.okcredit.R;
import in.okcredit._di.AppContext;

public class SyncNotificationHelper {
    public static final String CHANNEL_ID = "sync";
    private static final int NOTIFICATION_ID = 7;

    private Context context;

    @Inject
    public SyncNotificationHelper(@AppContext Context context) {
        this.context = context;
    }

    public void showNotification() {
        createNotificationChannel();
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.noti_small_icon)
            .setContentTitle("Syncing your account")
            .setOngoing(true)
            .setColor(ContextCompat.getColor(context, R.color.primary))
            .setProgress(100, 100, true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setTimeoutAfter(300_000L) // dont show for more than 5mins
            .setAutoCancel(false);
        NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, builder.build());
    }

    public void hideNotification() {
        NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Sync";
            int importance = android.app.NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);

            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            android.app.NotificationManager notificationManager = context.getSystemService(android.app.NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
}
