package in.okcredit._offline.usecase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import in.okcredit._offline.database.CustomerRepo;
import in.okcredit._offline.database.TransactionRepo;
import in.okcredit._offline.model.Customer;
import in.okcredit._offline.model.Transaction;
import io.reactivex.Completable;
import io.reactivex.Single;

public final class SafelySaveCustomerList {
    private CustomerRepo customerRepo;
    private TransactionRepo transactionRepo;
    private SafelySaveCustomer safelySaveCustomer;

    @Inject
    public SafelySaveCustomerList(CustomerRepo customerRepo, TransactionRepo transactionRepo, SafelySaveCustomer safelySaveCustomer) {
        this.customerRepo = customerRepo;
        this.transactionRepo = transactionRepo;
        this.safelySaveCustomer = safelySaveCustomer;
    }


    public Completable execute(List<Customer> customers) {
        return getTransactionMap()
            .flatMapCompletable(txnMap -> {
                List<Customer> safeList = new ArrayList<>();
                for (Customer customer : customers) {
                    if (txnMap.containsKey(customer.getId())) {
                        List<Transaction> transactions = txnMap.get(customer.getId());
                        if (!transactions.isEmpty()) {
                            safeList.add(safelySaveCustomer.updateAccountSummary(customer, transactions));
                        } else {
                            safeList.add(customer);
                        }
                    } else {
                        safeList.add(customer);
                    }
                }
                return customerRepo.resetCustomerList(safeList);
            });
    }

    private Single<Map<String, List<Transaction>>> getTransactionMap() {
        return transactionRepo.listTransactions()
                              .firstOrError()
                              .map(transactions -> {
                                  Map<String, List<Transaction>> res = new HashMap<>();
                                  for (Transaction transaction : transactions) {
                                      if (!res.containsKey(transaction.getCustomerId())) {
                                          res.put(transaction.getCustomerId(), new ArrayList<>());
                                      }
                                      res.get(transaction.getCustomerId()).add(transaction);
                                  }
                                  return res;
                              });
    }
}