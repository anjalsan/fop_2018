package in.okcredit.app.ui.account_statement;

import org.joda.time.DateTime;

import java.util.List;

import javax.inject.Inject;

import in.okcredit._offline.model.TransactionWrapper;
import in.okcredit._offline.usecase.GetAccountStatement;
import in.okcredit.app.ui._base.ErrorHelper;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.observers.DisposableObserver;

public class AccountStatementPresenter implements AccountStatement.Presenter {
    private AccountStatement.View view;
    private CompositeDisposable tasks;
    private GetAccountStatement getAccountStatement;

    @Inject
    public AccountStatementPresenter(GetAccountStatement getAccountStatement) {
        tasks = new CompositeDisposable();
        this.getAccountStatement = getAccountStatement;
    }

    @Override
    public void attachView(AccountStatement.View view) {
        this.view = view;
    }

    @Override
    public void detachView() {
        view = null;
        tasks.clear();
    }

    @Override
    public void load(List<Integer> types, DateTime from, DateTime to) {
        if (view == null) {
            return;
        }

        view.showLoading();
        tasks.clear();
        tasks = new CompositeDisposable();

        Disposable task =
            getAccountStatement
                .execute(types, from, to)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableObserver<List<TransactionWrapper>>() {
                    @Override
                    public void onNext(List<TransactionWrapper> transactions) {
                        if (view == null) {
                            return;
                        }

                        if (transactions.isEmpty()) {
                            view.displayNoTransactionsMessage();
                        } else {
                            view.displayTransactions(transactions);
                        }
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        ErrorHelper.handleDefaults(view, e, "load");
                    }

                    @Override
                    public void onComplete() {
                    }
                });
        tasks.add(task);
    }
}
