package in.okcredit._offline.database.internal;


import android.arch.persistence.db.SupportSQLiteDatabase;
import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.arch.persistence.room.TypeConverters;
import android.arch.persistence.room.migration.Migration;
import android.content.Context;

@Database(
    version = CoreDatabase.DB_VERSION,
    entities = {
        DbEntities.Merchant.class,
        DbEntities.MerchantPreference.class,
        DbEntities.Customer.class,
        DbEntities.CustomerSync.class,
        DbEntities.Transaction.class
    }
)
@TypeConverters({DateTimeRoomCodec.class})
public abstract class CoreDatabase extends RoomDatabase {
    static final int DB_VERSION = 2;
    static final String DB_NAME = "okcredit-core.db";

    private static CoreDatabase INSTANCE;

    public static CoreDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(context, CoreDatabase.class, DB_NAME)
                           .addMigrations(MIGRATION_1_2)
                           .build();
        }
        return INSTANCE;
    }

    static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            database.execSQL("ALTER TABLE Customer " + " ADD COLUMN profileImage TEXT");
            database.execSQL("ALTER TABLE Customer " + " ADD COLUMN address TEXT");
            database.execSQL("ALTER TABLE Customer " + " ADD COLUMN email TEXT");
        }
    };

    public abstract MerchantDao merchantDao();

    public abstract CustomerDao customerDao();

    public abstract TransactionDao transactionDao();
}
