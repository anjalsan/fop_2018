package in.okcredit._offline.database;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import in.okcredit.ThreadUtils;
import in.okcredit._offline.common.Utils;
import in.okcredit._offline.database.internal.DbEntities;
import in.okcredit._offline.database.internal.DbEntityMapper;
import in.okcredit._offline.database.internal.TransactionDao;
import in.okcredit._offline.model.Transaction;
import io.reactivex.Completable;
import io.reactivex.Observable;
import io.reactivex.Single;

public class TransactionRepo {
    private TransactionDao transactionDao;

    @Inject
    public TransactionRepo(TransactionDao transactionDao) {
        this.transactionDao = transactionDao;
    }

    public Single<List<Transaction>> listDirtyTransactions(String customerId) {
        return transactionDao.listDirtyTransactions(true)
                             .subscribeOn(ThreadUtils.database())
                             .observeOn(ThreadUtils.worker())
                             .map(transactions ->
                                 Utils.mapList(transactions, DbEntityMapper.TRANSACTION.reverse())
                             )
                             .map(transactions -> {
                                 if (customerId == null || customerId.isEmpty()) {
                                     return transactions;
                                 } else {
                                     List<Transaction> filtered = new ArrayList<>();
                                     for (Transaction transaction : transactions) {
                                         if (transaction.getCustomerId().equals(customerId)) {
                                             filtered.add(transaction);
                                         }
                                     }
                                     return filtered;
                                 }
                             });
    }

    public Observable<List<Transaction>> listTransactions(String customerId) {
        return transactionDao.listTransactions(customerId)
                             .subscribeOn(ThreadUtils.database())
                             .observeOn(ThreadUtils.worker())
                             .map(transactions ->
                                 Utils.mapList(transactions, DbEntityMapper.TRANSACTION.reverse())
                             )
                             .toObservable();
    }

    public Observable<List<Transaction>> listTransactions() {
        return transactionDao.listTransactions()
                             .subscribeOn(ThreadUtils.database())
                             .observeOn(ThreadUtils.worker())
                             .map(transactions ->
                                 Utils.mapList(transactions, DbEntityMapper.TRANSACTION.reverse())
                             )
                             .toObservable();
    }

    // DANGEROUS: replaces existing transactions of same id
    public Completable putTransactions(List<Transaction> transactions) {
        return Completable
            .fromAction(() -> {
                DbEntities.Transaction[] list = Utils.mapList(transactions, DbEntityMapper.TRANSACTION)
                                                     .toArray(new DbEntities.Transaction[]{});
                transactionDao.insertTransaction(list);
            })
            .subscribeOn(ThreadUtils.database())
            .observeOn(ThreadUtils.worker());
    }

    public Completable putTransaction(Transaction transaction) {
        return Completable
            .fromAction(
                () -> transactionDao.insertTransaction(DbEntityMapper.TRANSACTION.convert(transaction))
            )
            .subscribeOn(ThreadUtils.database())
            .observeOn(ThreadUtils.worker());
    }

    public Completable clear() {
        return Completable.fromAction(() -> transactionDao.deleteAllTransactions())
                          .subscribeOn(ThreadUtils.database())
                          .observeOn(ThreadUtils.worker());
    }

    public Single<Boolean> isTransactionPresent(String txnId) {
        return transactionDao.isTransactionPresent(txnId)
                             .subscribeOn(ThreadUtils.database())
                             .observeOn(ThreadUtils.worker())
                             .map(count -> count == 1);
    }

    public Observable<Transaction> getTransaction(String txnId) {
        return transactionDao.getTransaction(txnId)
                             .subscribeOn(ThreadUtils.database())
                             .observeOn(ThreadUtils.worker())
                             .map(transaction ->
                                 DbEntityMapper.TRANSACTION.reverse().convert(transaction))
                             .toObservable();
    }
}
