package in.okcredit._offline.usecase;

import android.content.res.AssetFileDescriptor;
import android.net.Uri;
import android.support.annotation.NonNull;

import com.google.common.io.Files;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import in.okcredit.App;
import in.okcredit.ThreadUtils;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.service.aws.AwsService;
import in.okcredit.util.FileUtils;
import in.okcredit.util.ImageUtil;
import io.reactivex.Completable;
import io.reactivex.Single;
import timber.log.Timber;

public final class UploadFile {
    private AwsService awsService;

    @Inject
    public UploadFile(AwsService awsService) {
        this.awsService = awsService;
    }

    public Completable execute(String remoteUrl, String filePath) {
        File file = new File(filePath);
        if (!file.exists()) {
            return Completable.complete();
        }

        return Single.just(file)
                     .map(localFile -> ImageUtil.correctOrientation(localFile))
                     .map(bitmap -> ImageUtil.scale(bitmap, 1000, 1000))
                     .map(bitmap -> ImageUtil.compressedStream(bitmap, 25))
                     .subscribeOn(ThreadUtils.computation())
                     .flatMapCompletable(stream -> awsService.uploadReceipt(remoteUrl, stream))
                     .doOnComplete(() -> {
//                         if (new File(filePath).exists()) {
//                             new File(filePath).delete();
//                         }
                     })
                    .doOnError(throwable -> {
                        Analytics.track(
                            AnalyticsEvents.ERROR,
                            EventProperties
                                .create()
                                .with("type", "upload receipt failed")
                        );
                    });
    }

    public Completable schedule(String remoteUrl, final String local) {
        return Completable
            .fromAction(() -> {
                if (local == null) {
                    return;
                }
                String localFilePath = local;
                File file = new File(localFilePath);
                if (!file.exists()) {
                    String contactUrl = loadContactPhotoThumbnail(localFilePath);
                    String absolutePath = FileUtils.getUriRealPath(App.getInstance(), Uri.parse(contactUrl));
                    File file1 = new File(absolutePath);
                    if (contactUrl != null && file1.exists()) {
                        file = file1;
                        localFilePath = absolutePath;
                    } else {
                        return;
                    }
                }

                File localCopy = new File(awsService.getAwsStorageDir(), awsService.getFileName(remoteUrl));
                Files.copy(file, localCopy);

                Constraints constraints = new Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build();

                OneTimeWorkRequest workRequest = new OneTimeWorkRequest.Builder(UploadFile.Worker.class)
                    .setConstraints(constraints)
                    .setBackoffCriteria(BackoffPolicy.LINEAR, 30, TimeUnit.SECONDS)
                    .setInputData(
                        new Data.Builder()
                            .putString(Worker.REMOTE_URL, remoteUrl)
                            .putString(Worker.FILE_PATH, localFilePath)
                            .build()
                    )
                    .build();

//                WorkManager.getInstance().beginWith(workRequest).enqueue();
                WorkManager.getInstance()
                    .beginUniqueWork("upload-file", ExistingWorkPolicy.APPEND, workRequest)
                    .enqueue();

            })
            .subscribeOn(ThreadUtils.newThread());
    }

    private String loadContactPhotoThumbnail(String photoData) {
        // Creates an asset file descriptor for the thumbnail file.
        AssetFileDescriptor afd = null;
        FileOutputStream outputStream = null;
        InputStream inputStream = null;
        // try-catch block for file not found
        try {
            // Creates a holder for the URI.
            Uri thumbUri;
            // If Android 3.0 or later
            thumbUri = Uri.parse(photoData);
            /*
             * Retrieves an AssetFileDescriptor object for the thumbnail
             * URI
             * using ContentResolver.openAssetFileDescriptor
             */
            afd = App.getInstance().getContentResolver().
                openAssetFileDescriptor(thumbUri, "r");

            FileDescriptor fdd = afd.getFileDescriptor();
            inputStream = new FileInputStream(fdd);
            File file = File.createTempFile("PhoneContactProvider", "tmp");
            file.deleteOnExit();
            outputStream = new FileOutputStream(file);
            byte[] buffer = new byte[1024];
            int len;
            while ((len = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, len);
            }
            inputStream.close();
            outputStream.close();
            return "file://" + file.getAbsolutePath();
        } catch (Exception e) {
            Timber.e(this.getClass().getSimpleName(), e.getMessage());
        }
        // In all cases, close the asset file descriptor
        finally {
            if (afd != null) {
                try {
                    afd.close();
                } catch (IOException e) {
                }
            }
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                }
            }
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                }
            }
        }
        return null;
    }

    public static class Worker extends androidx.work.Worker {
        public static final String REMOTE_URL = "remote_url";
        public static final String FILE_PATH = "file_path";

        @Inject UploadFile uploadFile;

        @NonNull
        @Override
        public Result doWork() {
            App.appComponent().inject(this);

            String receiptUrl = getInputData().getString(REMOTE_URL);
            String filePath = getInputData().getString(FILE_PATH);
            if (receiptUrl == null || filePath == null) {
                return Result.FAILURE;
            }

            try {
                uploadFile.execute(receiptUrl, filePath).blockingAwait();
                return Result.SUCCESS;

            } catch (Exception e) {
                return Result.RETRY;
            }
        }
    }
}
