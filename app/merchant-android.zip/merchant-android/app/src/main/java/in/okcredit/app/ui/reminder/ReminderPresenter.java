package in.okcredit.app.ui.reminder;

import javax.inject.Inject;

import in.okcredit._di.UiThread;
import in.okcredit._offline.model.MerchantPreference;
import in.okcredit._offline.usecase.GetMerchantPreference;
import in.okcredit._offline.usecase.SetMerchantPreference;
import in.okcredit.app.ui._base_v2.BasePresenter;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.observers.DisposableCompletableObserver;

public class ReminderPresenter extends BasePresenter<ReminderContract.View> implements ReminderContract.Presenter {
    private SetMerchantPreference setMerchantPreference;
    private GetMerchantPreference getMerchantPreference;

    @Inject
    public ReminderPresenter(@UiThread Scheduler uiScheduler,
                             SetMerchantPreference setMerchantPreference,
                             GetMerchantPreference getMerchantPreference) {
        super(uiScheduler);
        this.setMerchantPreference = setMerchantPreference;
        this.getMerchantPreference = getMerchantPreference;
    }

    @Override
    protected void loadData() {
        addTask(
            getMerchantPreference
                .execute(MerchantPreference.REMINDER)
                .map(val -> Boolean.parseBoolean(val))
                .onErrorReturnItem(false)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(isReminderOn -> {
                        ifAttached(view -> view.setCheckbox(isReminderOn));
                    },
                    throwable -> {
                        if (isAuthenticationIssue(throwable))
                            ifAttached(view -> view.gotoLogin());
                        else if (isInternetIssue(throwable))
                            ifAttached(view -> view.showNoInternetMessage());
                        else
                            ifAttached(view -> view.showError());
                    }
                )
        );

    }

    @Override
    public void onInternetRestored() {

    }

    @Override
    public void toggleReminderStatus(boolean isReminderOn) {
        ifAttached(view -> view.showLoading());

        addTask(
            setMerchantPreference
                .execute(MerchantPreference.REMINDER, String.valueOf(isReminderOn))
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableCompletableObserver() {
                    @Override
                    public void onComplete() {
                        ifAttached(view -> view.hideLoading());
                    }

                    @Override
                    public void onError(Throwable e) {
                        ifAttached(view -> view.hideLoading());

                        if (isAuthenticationIssue(e))
                            ifAttached(view -> view.gotoLogin());
                        else if (isInternetIssue(e))
                            ifAttached(view -> view.showNoInternetMessage());
                        else
                            ifAttached(view -> view.showError());
                    }
                })
        );
    }

    @Override
    public void onAuthenticationRestored() {
        loadData();
    }
}
