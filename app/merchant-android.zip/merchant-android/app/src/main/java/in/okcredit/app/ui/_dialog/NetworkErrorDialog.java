package in.okcredit.app.ui._dialog;

import android.app.Activity;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import in.okcredit.R;
import in.okcredit.ThreadUtils;
import in.okcredit._offline.server.NetworkHelper;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;

public final class NetworkErrorDialog {
//    public static final int STATE_SERVICE_UNAVAILABLE = 1;
//    public static final int STATE_INTERNET_UNAVAILABLE = 2;
//
//    private static final long DELAY = 1000;

    public interface Listener {
        void onNetworkOk();

        void onCancel();
    }

    private String message;

    public NetworkErrorDialog() {
    }

    public NetworkErrorDialog(String message) {
        this.message = message;
    }

    public AlertDialog show(Activity activity, Listener listener) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setCancelable(false);

        LayoutInflater layoutInflater = activity.getLayoutInflater();
        View dialogView = layoutInflater.inflate(R.layout.dialog_no_internet, null);
        builder.setView(dialogView);

        if (!TextUtils.isEmpty(message)) {
            TextView msg = dialogView.findViewById(R.id.message);
            msg.setText(message);
        }

        AlertDialog alertDialog = builder.create();
        alertDialog.setCanceledOnTouchOutside(false);
        if(!activity.isFinishing()) {
            alertDialog.show();
        }

        Button tryAgain = dialogView.findViewById(R.id.tryAgain);
        Button cancel = dialogView.findViewById(R.id.cancel);

        tryAgain.setOnClickListener(v -> {
            Single.fromCallable(() -> NetworkHelper.isServerAvailable())
                  .subscribeOn(ThreadUtils.api())
                  .observeOn(AndroidSchedulers.mainThread())
                  .subscribe(
                      isAvailable -> {
                          if (isAvailable) {
                              if (listener != null) {
                                  listener.onNetworkOk();
                              }
                              alertDialog.dismiss();
                          }
                      }
                  );
        });

        cancel.setOnClickListener(v -> {
            if (listener != null) {
                listener.onCancel();
            }
            alertDialog.dismiss();
        });

        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", activity.getClass().getSimpleName())
                .with("type", "internet")
        );

        return alertDialog;
    }

//    private Disposable task;

//    public AlertDialog show(Activity activity, Listener listener) {
//        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
//        builder.setCancelable(false);
//
//        LayoutInflater layoutInflater = activity.getLayoutInflater();
//        View dialogView = layoutInflater.inflate(R.layout.view_error, null);
//        builder.setView(dialogView);
//
//        dialogView.findViewById(R.id.tryAgainContainer).setVisibility(View.GONE);
//
//        AlertDialog alertDialog = builder.create();
//        alertDialog.setCanceledOnTouchOutside(false);
//        alertDialog.show();
//
//        task = networkStatus()
//            .observeOn(AndroidSchedulers.mainThread())
//            .subscribe(
//                state -> {
//
//                    switch (state) {
//                        case STATE_INTERNET_UNAVAILABLE:
//                            ((TextView) dialogView.findViewById(R.id.errorTitle)).setText
//                                (R.string
//                                    .err_network_title);
//                            ((TextView) dialogView.findViewById(R.id.errorMessage))
//                                .setText(R.string
//                                    .err_network);
//                            break;
//                        case STATE_SERVICE_UNAVAILABLE:
//                            ((TextView) dialogView.findViewById(R.id.errorTitle)).setText
//                                (R.string
//                                    .err_service_unavailable_title);
//                            ((TextView) dialogView.findViewById(R.id.errorMessage))
//                                .setText(R.string
//                                    .err_service_unavailable);
//                            break;
//                        default:
//                            break;
//                    }
//                },
//                throwable -> {
//                    Timber.e(throwable, "Failed to get state of network/service");
//                },
//                () -> {
//                    try {
//                        if (alertDialog.isShowing()) {
//                            alertDialog.dismiss();
//                        }
//                    } catch (Exception e) {
//                        Timber.e(e, "failed to dismiss network error dialog");
//                    }
//
//                    if (listener != null) {
//                        listener.onNetworkOk();
//                    }
//                    task.dispose();
//                });
//
//        return alertDialog;
//    }

//    public boolean isInternetAvailable() {
//        try {
//            InetAddress ipAddr = InetAddress.getByName("google.com"); //You can replace it with
//            // your name
//            return !ipAddr.equals("");
//        } catch (Exception e) {
//            Timber.e(e);
//            return false;
//        }
//    }
//
//    public boolean isServiceAvailable() {
//        try {
//            App.appComponent().server().ping().blockingAwait();
//            return true;
//        } catch (Exception e) {
//            Timber.w(e, "api failed: server ping");
//            return false;
//        }
//    }
//
//    public Observable<Integer> networkStatus() {
//        return Observable
//            .create(new ObservableOnSubscribe<Integer>() {
//                @Override
//                public void subscribe(ObservableEmitter<Integer> e) throws Exception {
//                    while (true) {
//                        if (isServiceAvailable()) {
//                            e.onComplete();
//                            return;
//                        } else {
//                            if (isInternetAvailable()) {
//                                e.onNext(STATE_SERVICE_UNAVAILABLE);
//                            } else {
//                                e.onNext(STATE_INTERNET_UNAVAILABLE);
//                            }
//                            Thread.sleep(DELAY);
//                        }
//                    }
//                }
//            })
//            .subscribeOn(Schedulers.newThread());
//    }
}
