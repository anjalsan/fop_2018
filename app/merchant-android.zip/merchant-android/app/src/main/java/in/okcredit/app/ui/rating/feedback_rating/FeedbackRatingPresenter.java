package in.okcredit.app.ui.rating.feedback_rating;

import javax.inject.Inject;

import in.okcredit._di.PresenterParam;
import in.okcredit._offline.usecase.SubmitFeedback;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.app.ui._base_v2.BasePresenter;
import io.reactivex.android.schedulers.AndroidSchedulers;

public class FeedbackRatingPresenter extends BasePresenter<FeedbackRatingContract.View> implements
    FeedbackRatingContract.Presenter {

    private SubmitFeedback submitFeedback;

    private int rating;

    @Inject
    public FeedbackRatingPresenter(@PresenterParam("rating") int rating,
                                   SubmitFeedback submitFeedback) {
        super(AndroidSchedulers.mainThread());
        this.submitFeedback = submitFeedback;
        this.rating = rating;
    }

    private String sanitize(String s) {
        if (s == null || s.isEmpty()) {
            return null;
        } else {
            return s.trim();
        }
    }

    @Override
    public void onInternetRestored() {

    }

    @Override
    public void submitFeedback(String feedback, int rating) {
        feedback = sanitize(feedback);

        ifAttached(view -> view.showLoading());

        addTask(
            submitFeedback
                .execute(feedback, rating)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    () -> {
                        Analytics.track(AnalyticsEvents.RATING_SUBMIT_FEEDBACK_SUCCESS);
                        ifAttached(view -> view.hideLoading());
                        ifAttached(view -> view.goToHomeScreen());
                    },
                    throwable -> {
                        Analytics.track(AnalyticsEvents.RATING_SUBMIT_FEEDBACK_FAILED);
                        ifAttached(view -> view.hideLoading());
                        ifAttached(view -> view.showError());
                    })
        );
    }
}
