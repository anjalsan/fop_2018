package in.okcredit.app.ui._utils;

import android.content.Context;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.annotation.ColorRes;
import android.support.annotation.DrawableRes;
import android.support.graphics.drawable.VectorDrawableCompat;
import android.support.v4.content.ContextCompat;

import in.okcredit.R;

public class DrawableUtil {
    private DrawableUtil() {
    }

    public static Drawable getDrawableWithColor(Context context, @DrawableRes int drawableRes, @ColorRes int colorRes) {

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Drawable drawable = ContextCompat.getDrawable(context, drawableRes);
            if (drawable != null) {
                drawable.mutate();
                drawable.setColorFilter(ContextCompat.getColor(context, colorRes), PorterDuff.Mode.SRC_ATOP);
            }
            return drawable;
        } else {
            VectorDrawableCompat drawable = VectorDrawableCompat.create(context.getResources(), drawableRes, null);
            if (drawable != null) {
                drawable.mutate();
                drawable.setColorFilter(ContextCompat.getColor(context, colorRes), PorterDuff.Mode.SRC_ATOP);
            }
            return drawable;
        }
    }
}
