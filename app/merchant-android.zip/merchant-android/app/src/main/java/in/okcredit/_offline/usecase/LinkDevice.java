package in.okcredit._offline.usecase;

import android.support.annotation.NonNull;

import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import in.okcredit.App;
import in.okcredit._offline.server.Server;
import in.okcredit.domain.device.DeviceService;
import io.reactivex.Completable;
import timber.log.Timber;

public final class LinkDevice {
    private DeviceService deviceService;
    private Server server;

    @Inject
    public LinkDevice(DeviceService deviceService, Server server) {
        this.deviceService = deviceService;
        this.server = server;
    }

    public Completable execute() {
        return deviceService.getDevice()
                            .firstOrError()
                            .flatMapCompletable(device -> server.linkDevice(device.getId()));
    }

    public Completable schedule() {
        return Completable
            .fromAction(() -> {
                Constraints constraints = new Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build();

                OneTimeWorkRequest workRequest = new OneTimeWorkRequest.Builder(Worker.class)
                    .setBackoffCriteria(BackoffPolicy.LINEAR, 30, TimeUnit.SECONDS)
                    .setConstraints(constraints)
                    .build();

                WorkManager.getInstance()
                           .beginUniqueWork("link-device", ExistingWorkPolicy.KEEP, workRequest)
                           .enqueue();
            });
    }

    public static class Worker extends androidx.work.Worker {
        @Inject LinkDevice linkDevice;

        @NonNull
        @Override
        public Result doWork() {
            App.appComponent().inject(this);

            try {
                linkDevice.execute().blockingAwait();
                return Result.SUCCESS;
            } catch (Exception e) {
                Timber.w(e, "link device");
                return Result.RETRY;
            }
        }
    }
}
