package in.okcredit.app.ui.home;

import java.util.List;

import in.okcredit._offline.model.Customer;
import in.okcredit._offline.model.InAppNotification;
import in.okcredit._offline.model.Merchant;
import in.okcredit.app.ui._base.BasePresenter;
import in.okcredit.app.ui._base.BaseView;
import in.okcredit.service.phonebook.ContactModel;

public interface HomeScreenContract {
    int SORT_TYPE_NAME = 0;
    int SORT_TYPE_ABS_BALANCE = 1;
    int SORT_TYPE_RECENT_ACTIVITY = 2;
    int SORT_TYPE_LAST_PAYMENT = 3;

    interface Presenter extends BasePresenter<View> {
        void setSortType(int sortType);

        void logout();

        void refresh();

        void onReminderNotificationClicked();

        void onShareNotificationClicked();

        void onAppLockNotificationClicked();

        void onUpdateNotificationDismissed();

        void onRatingNotificationClicked();

        void proceedName(String name);

        void proceedPhone(String phone, String name, String profileImage, String email, boolean isFromContact);

        void loadContacts();
    }

    interface View extends BaseView {
        void displayMerchantDetails(Merchant merchant);

        void showLoading();

        void hideLoading();

        void displayCustomers(List<Customer> customers, int lifecycleStage);

        void displayNoAndOneCustomerMessage(boolean isEmpty);

        void showNotificaton(InAppNotification inAppNotification);

        void onLogoutSuccess();

        void setNetworkStatus(boolean isConnected);

        void setAddCustomerState(int state);

        void shakeNameContainer();

        void shakePhoneContainer();

        void showAddCustomerLoader();

        void hideAddCustomerLoader();

        void onMobileConflict(Customer customer);

        void showError();

        void addCustomerSuccess(Customer customer, boolean isFromContact);

        void setContactsLoadingPercentage(int percent);

        void displayContacts(List<ContactModel> contacts);

        void onClickImportContact();

        void setContactsLoadingVisibility(boolean visibility);

        void onInvalidName();
    }
}
