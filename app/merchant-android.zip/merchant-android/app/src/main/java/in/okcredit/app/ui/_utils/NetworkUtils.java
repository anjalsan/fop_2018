package in.okcredit.app.ui._utils;

public class NetworkUtils {
    public static boolean isInternetError(Throwable throwable) {
        return false;
    }

    private NetworkUtils() {
    }
}
