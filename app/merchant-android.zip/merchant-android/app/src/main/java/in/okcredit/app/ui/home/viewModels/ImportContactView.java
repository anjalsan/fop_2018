package in.okcredit.app.ui.home.viewModels;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.provider.ContactsContract;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.airbnb.epoxy.CallbackProp;
import com.airbnb.epoxy.ModelProp;
import com.airbnb.epoxy.ModelView;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.R;
import in.okcredit._offline.model.Customer;

@ModelView(autoLayout = ModelView.Size.MATCH_WIDTH_WRAP_HEIGHT)
public class ImportContactView extends LinearLayout {

    public interface ImportContactListener {
        void onClickImportContact();
    }

    @BindView(R.id.import_button)
    FrameLayout importContact;

    @BindView(R.id.percentage)
    TextView percentage;

    @BindView(R.id.progressBar)
    ProgressBar progressBar;

    @BindView(R.id.loader)
    FrameLayout loader;

    @BindView(R.id.image_add)
    ImageView imageAdd;

    @BindView(R.id.text_title)
    TextView textTitle;

    @BindView(R.id.text_desc)
    TextView textDesc;

    public ImportContactView(Context context) {
        super(context);
        initView();
    }

    public ImportContactView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public ImportContactView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public ImportContactView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        initView();
    }

    @ModelProp
    public void setPercentage(int percent) {
        if (percent > 0) {
            loader.setVisibility(VISIBLE);
            importContact.setVisibility(GONE);

            percentage.setText(String.format("%s%%", String.valueOf(percent)));
            progressBar.setProgress(percent);
        } else {
            importContact.setVisibility(VISIBLE);
            loader.setVisibility(GONE);
        }
    }

    @ModelProp
    public void setIconColor(boolean visible) {
        if (visible) {
            importContact.setBackground(ContextCompat.getDrawable(getContext(), R.drawable.circular_border));
            imageAdd.setColorFilter(getResources().getColor(R.color.grey400));
        } else {
            importContact.setBackground(ContextCompat.getDrawable(getContext(), R.drawable.circular_border_primary));
            imageAdd.setColorFilter(getResources().getColor(R.color.primary_light));
        }
    }

    @CallbackProp
    public void setListener(@Nullable ImportContactListener listener) {
        if (listener != null) {
            importContact.setOnClickListener((OnClickListener) v -> listener.onClickImportContact());
            textTitle.setOnClickListener((OnClickListener) v -> listener.onClickImportContact());
            textDesc.setOnClickListener((OnClickListener) v -> listener.onClickImportContact());
        }
    }

    private void initView() {
        setOrientation(LinearLayout.HORIZONTAL);
        inflate(getContext(), R.layout.import_contact, this);
        ButterKnife.bind(this);
    }
}
