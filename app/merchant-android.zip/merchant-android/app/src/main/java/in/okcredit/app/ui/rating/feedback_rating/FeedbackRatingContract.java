package in.okcredit.app.ui.rating.feedback_rating;


import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;

public interface FeedbackRatingContract {
    interface View extends MVP.View, BaseContracts.Online.View {
        void displayInvalidFeedbackError();
        void showLoading();
        void hideLoading();
        void goToHomeScreen();
    }

    interface Presenter extends MVP.Presenter<FeedbackRatingContract.View>, BaseContracts.Online
        .Presenter<FeedbackRatingContract.View> {
        void submitFeedback(String feedback, int rating);
    }
}
