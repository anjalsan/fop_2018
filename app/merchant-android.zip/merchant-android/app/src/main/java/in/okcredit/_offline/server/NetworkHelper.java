package in.okcredit._offline.server;

import java.net.InetAddress;

import in.okcredit.App;

public final class NetworkHelper {
    public static boolean isNetworkError(Throwable throwable) {
        NetworkError networkError = NetworkError.from(throwable);
        return networkError != null;
    }

    public static boolean isInternetConnected() {
        try {
            InetAddress ipAddr = InetAddress.getByName("google.com");
            return !ipAddr.equals("");
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean isServerAvailable() {
        try {
            App.appComponent().server().ping().blockingAwait();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private NetworkHelper() {
    }
}
