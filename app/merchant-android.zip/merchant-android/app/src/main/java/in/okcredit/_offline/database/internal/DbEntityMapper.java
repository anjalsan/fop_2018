package in.okcredit._offline.database.internal;

import com.google.common.base.Converter;

import in.okcredit._offline.model.Customer;
import in.okcredit._offline.model.Merchant;
import in.okcredit._offline.model.MerchantPreference;
import in.okcredit._offline.model.Transaction;

public final class DbEntityMapper {
    public static Converter<Merchant, DbEntities.Merchant> MERCHANT = new Converter<Merchant, DbEntities.Merchant>() {
        @Override
        protected DbEntities.Merchant doForward(Merchant merchant) {
            DbEntities.Merchant dbEntity = new DbEntities.Merchant();
            dbEntity.id = merchant.getId();
            dbEntity.name = merchant.getName();
            dbEntity.mobile = merchant.getMobile();
            dbEntity.createdAt = merchant.getCreatedAt();
            return dbEntity;
        }

        @Override
        protected Merchant doBackward(DbEntities.Merchant dbEntity) {
            return new Merchant(
                dbEntity.id,
                dbEntity.name,
                dbEntity.mobile,
                dbEntity.createdAt
            );
        }
    };

    public static Converter<MerchantPreference, DbEntities.MerchantPreference> MERCHANT_PREFERENCE = new Converter<MerchantPreference, DbEntities.MerchantPreference>() {
        @Override
        protected DbEntities.MerchantPreference doForward(MerchantPreference merchant) {
            DbEntities.MerchantPreference dbEntity = new DbEntities.MerchantPreference();
            dbEntity.merchantId = merchant.getMerchantId();
            dbEntity.key = merchant.getKey();
            dbEntity.value = merchant.getValue();
            return dbEntity;
        }

        @Override
        protected MerchantPreference doBackward(DbEntities.MerchantPreference dbEntity) {
            return new MerchantPreference(dbEntity.merchantId, dbEntity.key, dbEntity.value);
        }
    };

    public static Converter<Customer, DbEntities.Customer> CUSTOMER = new Converter<Customer, DbEntities.Customer>() {
        @Override
        protected DbEntities.Customer doForward(Customer customer) {
            DbEntities.Customer dbEntity = new DbEntities.Customer();
            dbEntity.id = customer.getId();
            dbEntity.status = customer.getStatus();
            dbEntity.mobile = customer.getMobile();
            dbEntity.description = customer.getDescription();
            dbEntity.createdAt = customer.getCreatedAt();
            dbEntity.balance = customer.getBalance();
            dbEntity.transactionCount = customer.getTransactionCount();
            dbEntity.lastActivity = customer.getLastActivity();
            dbEntity.lastPayment = customer.getLastPayment();
            dbEntity.accountUrl = customer.getAccountUrl();
            dbEntity.profileImage = customer.getProfileImage();
            dbEntity.address = customer.getAddress();
            dbEntity.email = customer.getEmail();
            return dbEntity;
        }

        @Override
        protected Customer doBackward(DbEntities.Customer dbEntity) {
            return new Customer(
                dbEntity.id,
                dbEntity.status,
                dbEntity.mobile,
                dbEntity.description,
                dbEntity.createdAt,
                dbEntity.balance,
                dbEntity.transactionCount,
                dbEntity.lastActivity,
                dbEntity.lastPayment,
                dbEntity.accountUrl,
                dbEntity.profileImage,
                dbEntity.address,
                dbEntity.email
            );
        }
    };

    public static Converter<Transaction, DbEntities.Transaction> TRANSACTION = new Converter<Transaction, DbEntities.Transaction>() {
        @Override
        protected DbEntities.Transaction doForward(Transaction transaction) {
            DbEntities.Transaction dbEntity = new DbEntities.Transaction();
            dbEntity.id = transaction.getId();
            dbEntity.type = transaction.getType();
            dbEntity.customerId = transaction.getCustomerId();
            dbEntity.amount = transaction.getAmount();
            dbEntity.receiptUrl = transaction.getReceiptUrl();
            dbEntity.note = transaction.getNote();
            dbEntity.createdAt = transaction.getCreatedAt();
            dbEntity.isOnboarding = transaction.isOnboarding();
            dbEntity.isDeleted = transaction.isDeleted();
            dbEntity.deleteTime = transaction.getDeleteTime();
            dbEntity.isDirty = transaction.isDirty();
            return dbEntity;
        }

        @Override
        protected Transaction doBackward(DbEntities.Transaction dbEntity) {
            return new Transaction(
                dbEntity.id,
                dbEntity.type,
                dbEntity.customerId,
                dbEntity.amount,
                dbEntity.receiptUrl,
                dbEntity.note,
                dbEntity.createdAt,
                dbEntity.isOnboarding,
                dbEntity.isDeleted,
                dbEntity.deleteTime,
                dbEntity.isDirty
            );
        }
    };
}
