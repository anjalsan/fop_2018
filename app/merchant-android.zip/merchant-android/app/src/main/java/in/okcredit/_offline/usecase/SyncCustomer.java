package in.okcredit._offline.usecase;

import android.support.annotation.NonNull;

import org.joda.time.DateTime;
import org.joda.time.Duration;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import in.okcredit.App;
import in.okcredit.ThreadUtils;
import in.okcredit._offline.common.RxJavaUtils;
import in.okcredit._offline.database.CustomerRepo;
import in.okcredit._offline.database.TransactionRepo;
import in.okcredit._offline.model.Customer;
import in.okcredit._offline.model.Transaction;
import in.okcredit._offline.server.Server;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import io.reactivex.Completable;
import io.reactivex.Single;
import timber.log.Timber;

public final class SyncCustomer {
    private Server server;
    private TransactionRepo transactionRepo;
    private SafelySaveCustomer safelySaveCustomer;
    private SyncDirtyTransaction syncDirtyTransaction;
    private CustomerRepo customerRepo;

    @Inject
    public SyncCustomer(Server server, TransactionRepo transactionRepo, SafelySaveCustomer safelySaveCustomer, SyncDirtyTransaction syncDirtyTransaction, CustomerRepo customerRepo) {
        this.server = server;
        this.transactionRepo = transactionRepo;
        this.safelySaveCustomer = safelySaveCustomer;
        this.syncDirtyTransaction = syncDirtyTransaction;
        this.customerRepo = customerRepo;
    }

    public Completable execute(String customerId, Customer serverCopy) {
        Single<Customer> fetchCustomer = server.getCustomer(customerId);
        if (serverCopy != null) {
            fetchCustomer = Single.just(serverCopy);
        }

        return syncDirtyTransactions(customerId)
            .andThen(syncTransactions(customerId))
            .andThen(fetchCustomer)
            .flatMapCompletable(customer -> safelySaveCustomer.execute(customer))
            .andThen(customerRepo.setCustomerSync(customerId))
            .doOnError(throwable -> Timber.e(throwable));
    }

    public Completable schedule(String customerId) {
        return Completable
            .fromAction(() -> {

                String workCategory = "sync_customer";
                String workName = "sync_customer_" + customerId;

                Constraints constraints = new Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build();

                OneTimeWorkRequest workRequest = new OneTimeWorkRequest.Builder(Worker.class)
                    .addTag(workCategory)
                    .setConstraints(constraints)
                    .setBackoffCriteria(BackoffPolicy.LINEAR, 30, TimeUnit.SECONDS)
                    .setInputData(
                        new Data.Builder()
                            .putString(Worker.CUSTOMER_ID, customerId)
                            .build()
                    )
                    .build();

                WorkManager.getInstance()
                           .beginUniqueWork(workName, ExistingWorkPolicy.KEEP, workRequest)
                           .enqueue();
                Timber.i("scheduled sync for %s", customerId);
            })
            .subscribeOn(ThreadUtils.newThread());
    }

    // sync all dirty transactions for this customer
    private Completable syncDirtyTransactions(String customerId) {
        return transactionRepo
            .listDirtyTransactions(customerId)
            .flatMapCompletable(transactions -> {
                List<Completable> jobs = new ArrayList<>();
                for (Transaction transaction : transactions) {
                    if (transaction.isDirty()) {
                        jobs.add(syncDirtyTransaction.execute(transaction.getId()));
                    }
                }
                return RxJavaUtils.runConcurrently(jobs, 4);
            });
    }

    private Completable syncTransactions(String customerId) {
        return customerRepo
            .getLastSyncTime(customerId)
            .flatMap(startTime -> server.listTransactions(customerId, startTime.minusSeconds(10), null))
            .onErrorResumeNext(throwable -> {
                if (throwable instanceof NullPointerException) {
                    // never synced
                    return server.listTransactions(customerId, null, null);
                } else {
                    return Single.error(throwable);
                }
            })
            .flatMapCompletable(transactions -> transactionRepo.putTransactions(transactions));
    }

    public static final class Worker extends androidx.work.Worker {
        public static final String CUSTOMER_ID = "customer_id";

        @Inject SyncCustomer syncCustomer;

        @NonNull
        @Override

        public Result doWork() {
            App.appComponent().inject(this);

            String customerId = getInputData().getString(CUSTOMER_ID);
            if (customerId == null) {
                return Result.FAILURE;
            }

            DateTime startTime = DateTime.now();
            Analytics.track(
                AnalyticsEvents.SYNC_START,
                EventProperties.create()
                               .with("type", "SyncCustomer")
                               .with("customer_id", customerId)
                               .with("attempt", String.valueOf(getRunAttemptCount()))
            );

            try {
                syncCustomer.execute(customerId, null).blockingAwait();

                Analytics.track(
                    AnalyticsEvents.SYNC_COMPLETE,
                    EventProperties.create()
                                   .with("type", "SyncCustomer")
                                   .with("customer_id", customerId)
                                   .with("time_taken", new Duration(startTime, DateTime.now()).getStandardSeconds())
                                   .with("attempt", String.valueOf(getRunAttemptCount()))
                );

                return Result.SUCCESS;

            } catch (Exception e) {

                Analytics.track(
                    AnalyticsEvents.SYNC_ERROR,
                    EventProperties.create()
                                   .with("type", "SyncCustomer")
                                   .with("customer_id", customerId)
                                   .with("reason", e.getMessage())
                                   .with("time_taken", new Duration(startTime, DateTime.now()).getStandardSeconds())
                                   .with("attempt", String.valueOf(getRunAttemptCount()))
                );

                return Result.RETRY;
            }
        }
    }
}
