package in.okcredit.app.ui.reset_pwd.password;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import dagger.android.AndroidInjection;
import dagger.android.support.AndroidSupportInjection;
import in.okcredit.R;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui._utils.KeyboardUtil;
import in.okcredit.app.ui.home.HomeActivity;
import in.okcredit.app.ui.reset_pwd.ResetPwdActivity;

public class PasswordFragment extends Fragment implements PasswordContract.View {
    public static final String ARG_MOBILE = "mobile";
    public static final String ARG_TOKEN = "token";
    public static final String ARG_REQUESTED_SCREEN = "requested_screen";

    public static PasswordFragment newInstance(String mobile, String token, String requestedScreen) {
        Bundle args = new Bundle();
        args.putString(ARG_MOBILE, mobile);
        args.putString(ARG_TOKEN, token);
        args.putString(ARG_REQUESTED_SCREEN, requestedScreen);
        PasswordFragment fragment = new PasswordFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @BindView(R.id.password) TextInputLayout password;
    @BindView(R.id.loading) ProgressBar loading;
    @BindView(R.id.ok) ViewGroup ok;

    @Inject PasswordContract.Presenter presenter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.resetpwd_fragment_password, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        AndroidSupportInjection.inject(this);
        Analytics.track(AnalyticsEvents.RESET_PWD_PWD_SCREEN);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (getContext() != null) {
            KeyboardUtil.showKeyboard(getContext(), password);
        }
        presenter.attachView(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        presenter.detachView();
        KeyboardUtil.hideKeyboard(this);
    }

    /****************************************************************
     * Listeners
     ****************************************************************/
    @OnClick(R.id.ok)
    public void onOkClicked() {
        if (password.getEditText() == null)
            return;

        presenter.resetPassword(password.getEditText().getText().toString());
    }

    /****************************************************************
     * MVP methods
     ****************************************************************/
    @Override
    public void showError() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "reset pwd set pwd")
                .with("type", "server error")
        );

        Toast.makeText(getActivity(), R.string.err_default, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showInvalidPasswordError() {
        Analytics.track(AnalyticsEvents.RESET_PWD_INVALID_PASSWORD);
        password.setError(getString(R.string.err_invalid_password));
        password.setErrorEnabled(true);
    }

    @Override
    public void gotoHomeScreen(String requestedScreen) {
        Toast.makeText(getActivity(), getString(R.string.reset_pwd_success), Toast.LENGTH_SHORT)
             .show();
        if (requestedScreen != null && requestedScreen.equals(ResetPwdActivity.REQUESTED_SCREEN_TX)){
            getActivity().finish();
        } else {
            startActivity(HomeActivity.startingIntent(getActivity()));
            getActivity().finish();
        }
    }

    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(getActivity(), new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
                getActivity().onBackPressed();
                KeyboardUtil.hideKeyboard(PasswordFragment.this);
            }
        });
    }

    @Override
    public void showLoading() {
        loading.setVisibility(View.VISIBLE);
        ok.setVisibility(View.GONE);
    }

    @Override
    public void hideLoading() {
        loading.setVisibility(View.GONE);
        ok.setVisibility(View.VISIBLE);
    }
}
