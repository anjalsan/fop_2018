package in.okcredit.app.ui.app_lock.forgot;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.R;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui.login.LoginActivity;

public class ForgotAppLockActivity extends BaseActivity {
    public static Intent startingIntent(Context context) {
        return new Intent(context, ForgotAppLockActivity.class);
    }

    @BindView(R.id.ok)
    Button ok;

    /* Lifecycle methods */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Analytics.track(AnalyticsEvents.FORGOT_APP_LOCK_SCREEN);

        setContentView(R.layout.screen_forgot_app_lock);
        ButterKnife.bind(this);

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(LoginActivity.startingIntent(ForgotAppLockActivity.this, LoginActivity.FLAG_FORGOT_PATTERN));
            }
        });
    }

    @Override
    public void onBackPressed() {
    }
}
