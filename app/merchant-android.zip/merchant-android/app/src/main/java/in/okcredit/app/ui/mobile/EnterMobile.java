package in.okcredit.app.ui.mobile;

import in.okcredit.app.ui._base.BasePresenter;
import in.okcredit.app.ui._base.BaseView;

public interface EnterMobile {
    interface View extends BaseView {
        void showLoading();

        void hideLoading();

        void displayInvalidMobileError();

        void gotoLoginScreen(String mobile);

        void gotoRegistrationScreen(String mobile);
    }

    interface Presenter extends BasePresenter<View> {
        void checkMobile(String mobile);
    }
}
