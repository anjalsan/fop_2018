package in.okcredit.app.ui.transaction;

import com.google.common.base.Strings;

import org.joda.time.DateTime;

import java.io.Serializable;

import in.okcredit.app.ui._base.BasePresenter;
import in.okcredit.app.ui._base.BaseView;

public interface TransactionScreenContract {
    interface View extends BaseView {
        void setTransaction(Transaction transaction, boolean isCancelVisible);

        void gotoDeleteScreen(in.okcredit._offline.model.Transaction transaction);

        void showLoading();

        void hideLoading();
    }

    interface Presenter extends BasePresenter<View> {

        void onDeleteClicked();

        void syncNow();
    }

    class Transaction implements Serializable {
        public static final int TYPE_CREDIT = 1;
        public static final int TYPE_PAYMENT = 2;
        public static final int TYPW_RETURN = 3;

        public static final int SYNC_STATUS_ENQUEUED = 0;
        public static final int SYNC_STATUS_RUNNING = 1;
        public static final int SYNC_STATUS_SUCCEEDED = 2;

        public String id;
        public int type;
        public Customer customer;
        public float amount;
        public DateTime createdAt;
        public String note;
        public String receiptUrl;
        public boolean isOnboarding;
        public boolean isDeleted;
        public DateTime deletedAt;
        public boolean isDirty;
        public boolean isSyncing;
    }

    class Customer implements Serializable {
        public String id;
        public String name;
        public float balance;
        public int status;
        public String mobile;
    }
}
