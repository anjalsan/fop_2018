package in.okcredit.app.ui.addtxn.addTxn;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.FileProvider;
import android.util.Log;

import com.google.common.base.Strings;

import java.io.File;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.List;
import java.util.UUID;

import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui._base_v2.PermissionGrantListener;
import timber.log.Timber;

public class GalleryHelper {
    private File image;
    private WeakReference<BaseActivity> activityRef;

    public GalleryHelper(BaseActivity activity) {
        activityRef = new WeakReference<>(activity);
    }

    public Intent getIntent(PermissionGrantListener permissionGrantListener) {
        BaseActivity activity = activityRef.get();
        if (activity == null)
            return null;

        if (activity.requestPermission(Manifest.permission.READ_EXTERNAL_STORAGE, permissionGrantListener))
            return null;

//        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
//        intent.setType("image/*");
//        return intent;

        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        intent.putExtra(Intent.EXTRA_LOCAL_ONLY, true);
        return intent;
    }

    public File getImage(Intent data, Context context) {
        final Uri uri_data = data.getData();
        if (uri_data == null){
            return null;
        }
        String path;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
            path = getRealPathFromURI_API19(context, uri_data);
        } else {
            path = getRealPathFromURI_API11to18(context, uri_data);
        }
        if (path != null) {
            return new File(path);
        } else {
            return null;
        }
    }

    @SuppressLint("NewApi")
    public  String getRealPathFromURI_API19(Context context, Uri uri){
        String filePath = "";
        String wholeID;
        try {
            wholeID = DocumentsContract.getDocumentId(uri);
            // Split at colon, use second item in the array
            String id = wholeID.split(":")[1];

            String[] column = { MediaStore.Images.Media.DATA };

            // where id is equal to
            String sel = MediaStore.Images.Media._ID + "=?";

            Cursor cursor = context.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                column, sel, new String[]{ id }, null);

            int columnIndex = cursor.getColumnIndex(column[0]);

            if (cursor.moveToFirst()) {
                filePath = cursor.getString(columnIndex);
            }
            cursor.close();
            return filePath;
        } catch (Exception e) {
            return getPathFromURI(uri, context);
        }
    }


    @SuppressLint("NewApi")
    public String getRealPathFromURI_API11to18(Context context, Uri contentUri) {
        String[] proj = { MediaStore.Images.Media.DATA };
        String result = null;

        CursorLoader cursorLoader = new CursorLoader(
            context,
            contentUri, proj, null, null, null);
        Cursor cursor = cursorLoader.loadInBackground();

        if(cursor != null){
            int column_index =
                cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            result = cursor.getString(column_index);
        }
        return result;
    }

    private String getPathFromURI(Uri contentUri, Context context) {
        try {
            String imagePathProfil = null;
            File myFile = new File(contentUri.getPath());
            String[] filePathColumn = {MediaStore.Images.Media.DATA};
            Cursor cursor = context.getContentResolver().query(contentUri,
                filePathColumn, null, null, null);

            // Move to first row
            if (cursor != null) {
                cursor.moveToFirst();
                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                imagePathProfil = cursor.getString(columnIndex);
                cursor.close();
            } else {
                // Get the cursor
                Uri uri = getImageContentUri(context, myFile);
                if (uri == null) {
                    return null;
                }
                cursor = context.getContentResolver().query(uri,
                    filePathColumn, null, null, null);
                // Move to first row
                if (cursor == null) {
                    return null;
                }
                cursor.moveToFirst();
                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                imagePathProfil = cursor.getString(columnIndex);
                cursor.close();
            }

            return imagePathProfil;
        } catch (Exception e) {
            return null;
        }
    }

    public static Uri getImageContentUri(Context context, File imageFile) {
        String filePath = imageFile.getAbsolutePath();
        Cursor cursor = context.getContentResolver().query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            new String[] { MediaStore.Images.Media._ID },
            MediaStore.Images.Media.DATA + "=? ",
            new String[] { filePath }, null);

        if (cursor != null && cursor.moveToFirst()) {
            int id = cursor.getInt(cursor
                .getColumnIndex(MediaStore.MediaColumns._ID));
            Uri baseUri = Uri.parse("content://media/external/images/media");
            return Uri.withAppendedPath(baseUri, "" + id);
        } else {
            if (imageFile.exists()) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DATA, filePath);
                return context.getContentResolver().insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            } else {
                return null;
            }
        }
    }
}
