package in.okcredit.app.ui.transaction;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.StrikethroughSpan;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.common.base.Strings;

import org.joda.time.DateTime;
import org.joda.time.Hours;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import dagger.android.AndroidInjection;
import in.okcredit.R;
import in.okcredit._offline.model.Transaction;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base.BaseActivity;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui._dialog.NoteDialog;
import in.okcredit.app.ui._dialog.ReceiptDialog;
import in.okcredit.app.ui._utils.CurrencyUtil;
import in.okcredit.app.ui._utils.DrawableUtil;
import in.okcredit.app.ui._widget.txn_meta.TxnMetadataView;
import in.okcredit.app.ui.delete_txn.DeleteTransactionActivity;
import in.okcredit.service.aws.AwsService;
import in.okcredit.util.DateTimeUtils;
import io.reactivex.android.schedulers.AndroidSchedulers;

public class TransactionActivity extends BaseActivity implements TransactionScreenContract.View {
    public static final String EXTRA_TRANSACTION_ID = "transaction_id";
    public static final String EXTRA_TRANSACTION = "transaction";
    public static final String EXTRA_IS_CANCEl_VISIBLE = "is_cancel_visible";

    public static Intent startingIntent(Context context, @NonNull String transactionId, int lifecycle, boolean isCancelVisible) {
        Intent intent = new Intent(context, TransactionActivity.class);
        intent.putExtra(EXTRA_TRANSACTION_ID, transactionId);
        intent.putExtra(EXTRA_IS_CANCEl_VISIBLE, isCancelVisible);
        return intent;
    }

    public static Intent startingIntent(Context context, @NonNull String transactionId,
                                        Transaction transaction, int lifecycle, boolean isCancelVisible) {
        Intent intent = new Intent(context, TransactionActivity.class);
        intent.putExtra(EXTRA_TRANSACTION_ID, transactionId);
        intent.putExtra(EXTRA_TRANSACTION, transaction);
        intent.putExtra(EXTRA_IS_CANCEl_VISIBLE, isCancelVisible);
        return intent;
    }

    @BindView(R.id.icon)
    ImageView icon;
    @BindView(R.id.amount)
    TextView amount;
    @BindView(R.id.typeLabel)
    TextView typeLabel;
    @BindView(R.id.customerName)
    TextView customerName;
    @BindView(R.id.timestamp)
    TextView timestamp;
    @BindView(R.id.meta)
    TxnMetadataView meta;
    @BindView(R.id.deleteContainer)
    LinearLayout deleteContainer;
    @BindView(R.id.delete)
    LinearLayout delete;
    @BindView(R.id.deleteMsg)
    TextView deleteMsg;
    @BindView(R.id.cstDeleteMsgContainer)
    LinearLayout cstDeleteMsgContainer;
    @BindView(R.id.cstDeletedMsg)
    TextView cstDeletedMsg;
    @BindView(R.id.txDeleteMsgContainer)
    LinearLayout txDeleteMsgContainer;
    @BindView(R.id.txDeletedMsg)
    TextView txDeletedMsg;
    @BindView(R.id.loading)
    LinearLayout loading;

    // sync into
    @BindView(R.id.sync_icon) ImageView syncIcon;
    @BindView(R.id.sync_loading) ProgressBar syncLoading;
    @BindView(R.id.sync_message) TextView syncMsg;
    @BindView(R.id.sync_action) Button syncAction;
    @BindView(R.id.smsMsg) LinearLayout smsMsg;

    @Inject
    TransactionScreenContract.Presenter presenter;

    @Inject AwsService awsService;

    private String receiptUrl;
    private String note;

    private TransactionScreenContract.Transaction transaction;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AndroidInjection.inject(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.transaction_activity);
        ButterKnife.bind(this);

        setupActionBar(R.string.title_customer);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                presenter.onDeleteClicked();
            }
        });

        deleteContainer.setVisibility(View.GONE);
        cstDeleteMsgContainer.setVisibility(View.GONE);
        txDeleteMsgContainer.setVisibility(View.GONE);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.attachView(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        presenter.detachView();
    }

    @Override
    public void onNetworkFailure() {
        new NetworkErrorDialog().show(this, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.attachView(TransactionActivity.this);
            }

            @Override
            public void onCancel() {
            }
        });
    }

    private void setTitle(String title) {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(title);
        }
    }

    @SuppressLint("CheckResult")
    public void onViewReceiptClicked() {
        Analytics.track(
            AnalyticsEvents.TX_VIEW_META,
            EventProperties
                .create()
                .with("type", "bill")
                .with("from", "txn")
                .with("txId", transaction.id)
        );

        awsService
            .getFile(getReceiptUrl())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(fileInfo -> {
                if (fileInfo.isLocal) {
                    ReceiptDialog.show(TransactionActivity.this, fileInfo.localFile);
                } else {
                    ReceiptDialog.show(TransactionActivity.this, fileInfo.url);
                }
            });
    }

    private String getReceiptUrl() {
        return receiptUrl;
    }

    public void onViewNoteClicked() {
        NoteDialog.show(this, note);
        Analytics.track(
            AnalyticsEvents.TX_VIEW_META,
            EventProperties
                .create()
                .with("type", "note")
                .with("from", "txn")
                .with("txId", transaction.id)
        );
    }

    /****************************************************************
     MVP methods
     ****************************************************************/
    @Override
    public void onError(String tag) {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "transaction")
                .with("type", "server error")
        );

        Toast.makeText(this, R.string.err_default, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void setTransaction(TransactionScreenContract.Transaction transaction, boolean isFromCustScreen) {

        this.transaction = transaction;

        Analytics.track(
            AnalyticsEvents.TX_SCREEN,
            EventProperties
                .create()
                .with("type", transaction.type)
                .with("txId", transaction.id)
        );
        amount.setText(CurrencyUtil.format(transaction.amount));

        if (!transaction.isDirty) {
            syncLoading.setVisibility(View.GONE);
            syncIcon.setImageDrawable(DrawableUtil.getDrawableWithColor(this, R.drawable.ic_sync_ok, R.color.grey400));
            syncIcon.setVisibility(View.VISIBLE);
            syncMsg.setText(R.string.txn_synced);
            syncAction.setVisibility(View.GONE);

            //TODO: Comparison with customer mobile number.
            if (Strings.isNullOrEmpty(transaction.customer.mobile)) {
                smsMsg.setVisibility(View.GONE);
            } else {
                smsMsg.setVisibility(View.VISIBLE);
            }
        } else {
            if (transaction.isSyncing) {
                syncLoading.setVisibility(View.VISIBLE);
                syncIcon.setVisibility(View.GONE);
                syncMsg.setText(R.string.txn_syncing);
                syncAction.setVisibility(View.GONE);
                smsMsg.setVisibility(View.GONE);
            } else {
                syncLoading.setVisibility(View.GONE);
                syncIcon.setImageDrawable(DrawableUtil.getDrawableWithColor(this, R.drawable.ic_sync_pending, R.color.grey400));
                syncIcon.setVisibility(View.VISIBLE);
                syncMsg.setText(R.string.txn_sync_pending);
                syncAction.setVisibility(View.VISIBLE);
                smsMsg.setVisibility(View.GONE);
                syncAction.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (presenter != null) {
                            presenter.syncNow();
                            Analytics.track(AnalyticsEvents.FORCE_SYNC);
                        }
                    }
                });
            }
        }

        switch (transaction.type) {
            case TransactionScreenContract.Transaction.TYPE_CREDIT:
                icon.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_credit));
                icon.setColorFilter(ContextCompat.getColor(this, R.color.tx_credit));
                if (transaction.isOnboarding) {
                    typeLabel.setText(R.string.tx_detail_old_credit_desc);
                    setTitle(getString(R.string.tx_detail_old_credit_title));
                } else {
                    typeLabel.setText(R.string.txn_credit_given_to);
                    setTitle(getString(R.string.txn_credit_title));
                }

                if (isFromCustScreen) {
                    if (!transaction.isDeleted) {
                        if (transactionCreatedWithin24Hours(transaction.createdAt)) {
                            deleteContainer.setVisibility(View.VISIBLE);
                            txDeleteMsgContainer.setVisibility(View.GONE);
                            deleteMsg.setText(getString(R.string.credit_delete_desc));
                        } else {
                            txDeleteMsgContainer.setVisibility(View.VISIBLE);
                            deleteContainer.setVisibility(View.GONE);
                            txDeletedMsg.setText(getString(R.string.tx_delete_not_allowed));
                        }
                    }
                }

                break;

            case TransactionScreenContract.Transaction.TYPE_PAYMENT:
                icon.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_payment));
                icon.setColorFilter(ContextCompat.getColor(this, R.color.tx_payment));
                if (transaction.isOnboarding) {
                    typeLabel.setText(R.string.tx_detail_old_payment_desc);
                    setTitle(getString(R.string.tx_detail_old_payment_title));
                } else {
                    typeLabel.setText(R.string.txn_payment_accepted_from);
                    setTitle(getString(R.string.txn_payment_title));
                }

                if (isFromCustScreen) {
                    if (!transaction.isDeleted) {
                        if (transactionCreatedWithin24Hours(transaction.createdAt)) {
                            deleteContainer.setVisibility(View.VISIBLE);
                            txDeleteMsgContainer.setVisibility(View.GONE);
                            deleteMsg.setText(getString(R.string.payment_delete_desc));
                        } else {
                            txDeleteMsgContainer.setVisibility(View.VISIBLE);
                            deleteContainer.setVisibility(View.GONE);
                            txDeletedMsg.setText(getString(R.string.tx_delete_not_allowed));
                        }
                    }
                }

                break;

            case TransactionScreenContract.Transaction.TYPW_RETURN:
                icon.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_return));
                icon.setColorFilter(ContextCompat.getColor(this, R.color.tx_return));
                typeLabel.setText(R.string.txn_returned_amount_to);
                setTitle(getString(R.string.txn_return_title));
                deleteContainer.setVisibility(View.GONE);
                break;
        }

        customerName.setText(transaction.customer.name);

        timestamp.setText(DateTimeUtils.formatLong(transaction.createdAt));

        receiptUrl = transaction.receiptUrl;
        if (!TextUtils.isEmpty(receiptUrl)) {
            meta.addOrReplace(TxnMetadataView.TxnMetadata.bill(this, view -> onViewReceiptClicked
                ()));
        }

        note = transaction.note;
        if (!TextUtils.isEmpty(note)) {
            meta.addOrReplace(TxnMetadataView.TxnMetadata.note(this, note, view ->
                onViewNoteClicked()));
        }

        if (transaction.customer.status == 2) {
            deleteContainer.setVisibility(View.GONE);
            cstDeleteMsgContainer.setVisibility(View.VISIBLE);
            cstDeletedMsg.setText(getString(R.string.cst_deleted_msg));

            String cstNameTrimmed = customerName.getText().toString().split("\\[")[0];

            SpannableString spannable = new SpannableString(cstNameTrimmed);
            spannable.setSpan(new StrikethroughSpan(), 0, cstNameTrimmed.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
            customerName.setText(spannable);

        }

        if (transaction.isDeleted) {
            deleteContainer.setVisibility(View.GONE);
            txDeleteMsgContainer.setVisibility(View.VISIBLE);
            txDeletedMsg.setText(getString(R.string.tx_deleted_msg, DateTimeUtils.formatLong(transaction.deletedAt)));
            icon.setColorFilter(ContextCompat.getColor(this, R.color.grey400));
            SpannableString spannable = new SpannableString(amount.getText().toString());
            spannable.setSpan(new StrikethroughSpan(), 0, amount.getText()
                                                                .toString()
                                                                .length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
            amount.setText(spannable);
        }
    }

    private boolean transactionCreatedWithin24Hours(DateTime createdAt) {
        DateTime now = DateTime.now();

        Hours hours = Hours.hoursBetween(createdAt, now);
        Hours allowedInterval = Hours.hours(24);

        return !hours.isGreaterThan(allowedInterval);
    }

    @Override
    public void gotoDeleteScreen(Transaction transaction) {
        startActivity(DeleteTransactionActivity.startingIntent(this, transaction.getId(), transaction));
        finish();
    }


    @Override
    public void showLoading() {
        loading.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideLoading() {
        loading.setVisibility(View.GONE);
    }
}
