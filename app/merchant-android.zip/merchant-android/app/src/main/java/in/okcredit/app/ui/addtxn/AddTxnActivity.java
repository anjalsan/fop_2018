package in.okcredit.app.ui.addtxn;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;

import javax.inject.Inject;

import butterknife.ButterKnife;
import dagger.android.AndroidInjector;
import dagger.android.DispatchingAndroidInjector;
import dagger.android.support.HasSupportFragmentInjector;
import in.okcredit.LifecycleState;
import in.okcredit.LocaleManager;
import in.okcredit.R;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui.addtxn.addTxn.AddTxnFragment;
import in.okcredit.app.ui.addtxn.confirmTxn.ConfirmTxnFragment;
import in.okcredit.app.ui.addtxn.result.ResultFragment;
import in.okcredit.app.ui.customer.CustomerActivity;

public class AddTxnActivity extends BaseActivity implements HasSupportFragmentInjector {
    public static final int MODE_DEFAULT = 0;
    public static final int MODE_RESULT = 1;

    public static final String EXTRA_CUSTOMER_ID = "customer_id";
    public static final String EXTRA_TXN_TYPE = "txn_type";
    public static final String EXTRA_MODE = "mode";
    public static final String EXTRA_AMOUNT = "amount";
    public static final String EXTRA_LIFECYCLE = "lifecycle";
    public static final String EXTRA_IS_OLD_BALANCE = "is_old_balance";

    private int lifecycle, txnType;
    private String customerId, audioLang;
    private boolean isOldBalance;

    public static Intent startingIntent(Context context, @NonNull String customerId, int txnType,
                                        int lifecycle, boolean isOldBalance) {
        Intent intent = new Intent(context, AddTxnActivity.class);
        intent.putExtra(EXTRA_CUSTOMER_ID, customerId);
        intent.putExtra(EXTRA_TXN_TYPE, txnType);
        intent.putExtra(EXTRA_MODE, MODE_DEFAULT);
        intent.putExtra(EXTRA_LIFECYCLE, lifecycle);
        intent.putExtra(EXTRA_IS_OLD_BALANCE, isOldBalance);
        return intent;
    }

    public static Intent startingIntent(Context context, @NonNull String customerId, int txnType,
                                        float amount, int mode, int lifecycle, boolean isOldBalance) {
        Intent intent = new Intent(context, AddTxnActivity.class);
        intent.putExtra(EXTRA_CUSTOMER_ID, customerId);
        intent.putExtra(EXTRA_TXN_TYPE, txnType);
        intent.putExtra(EXTRA_MODE, mode);
        intent.putExtra(EXTRA_AMOUNT, amount);
        intent.putExtra(EXTRA_LIFECYCLE, lifecycle);
        intent.putExtra(EXTRA_IS_OLD_BALANCE, isOldBalance);
        return intent;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addtxn_activity);
        ButterKnife.bind(this);
        showActionBar(true);

        lifecycle = getIntent().getIntExtra(EXTRA_LIFECYCLE, 0);
        customerId = getIntent().getStringExtra(EXTRA_CUSTOMER_ID);
        isOldBalance = getIntent().getBooleanExtra(EXTRA_IS_OLD_BALANCE, false);
        txnType = getIntent().getIntExtra(EXTRA_TXN_TYPE, txnType);

        audioLang = LocaleManager.getLanguage();

        Analytics.track(
            AnalyticsEvents.TX_STARTED,
            EventProperties
                .create()
                .with("lifecycle", lifecycle)
                .with("type", txnType)
                .with("isOldBalance", isOldBalance)
        );

        gotoAddTxnScreen();
    }

    @Override
    public void onBackPressed() {
        Analytics.track(
            AnalyticsEvents.TX_BACK
        );

        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();
        } else {
            finish();
        }
    }

    /****************************************************************
     Navigation
     ****************************************************************/
    public void gotoAddTxnScreen() {
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.fragmentContainer, AddTxnFragment.newInstance())
            .commit();
    }

    public void gotoConfirmScreen() {
        getSupportFragmentManager()
            .beginTransaction()
            .setCustomAnimations(R.animator.enter_from_right, R.animator.exit_to_left, R
                .animator.enter_from_left, R.animator.exit_to_right)
            .replace(R.id.fragmentContainer, ConfirmTxnFragment.newInstance())
            .addToBackStack(null)
            .commit();
    }

    public void gotoResultScreen() {
        clearFragmentBackStack();
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.fragmentContainer, ResultFragment.newInstance())
            .commit();
    }

    public void gotoCustomerScreen() {
        startActivity(CustomerActivity.startingIntent(this, customerId, LifecycleState
            .NORMAL_FLOW));
        finish();
    }

    public int getMode() {
        return getIntent().getIntExtra(EXTRA_MODE, MODE_DEFAULT);
    }

    public int getLifeCycle() {
        return lifecycle;
    }

    public boolean isOldBalance() {
        return isOldBalance;
    }

    public String getAudioLang() {
        return audioLang;
    }

    /****************************************************************
     Dependency Injection
     ****************************************************************/
    @Inject
    DispatchingAndroidInjector<Fragment> fragmentInjector;

    @Override
    public AndroidInjector<Fragment> supportFragmentInjector() {
        return fragmentInjector;
    }

}
