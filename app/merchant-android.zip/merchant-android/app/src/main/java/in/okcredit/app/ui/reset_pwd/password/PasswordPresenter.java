package in.okcredit.app.ui.reset_pwd.password;

import javax.inject.Inject;

import in.okcredit._di.PresenterParam;
import in.okcredit._offline.usecase.Signin;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BasePresenter;
import in.okcredit.domain.auth.AuthDomain;
import io.reactivex.android.schedulers.AndroidSchedulers;
import timber.log.Timber;

public class PasswordPresenter extends BasePresenter<PasswordContract.View> implements PasswordContract.Presenter {
    private AuthDomain authDomain;
    private String mobile;
    private String requestedScreen;
    private String token;
    private Signin signin;

    @Inject
    public PasswordPresenter(
        AuthDomain authDomain,
        @PresenterParam("mobile") String mobile,
        @PresenterParam("token") String token,
        @PresenterParam("requested_screen") String requestedScreen,
        Signin signin
    ) {
        super(AndroidSchedulers.mainThread());
        this.authDomain = authDomain;
        this.mobile = mobile;
        this.token = token;
        this.signin = signin;
        this.requestedScreen = requestedScreen;
    }

    @Override
    public void resetPassword(String newPassword) {
        if (newPassword == null || newPassword.length() < 6) {
            ifAttached(view -> view.showInvalidPasswordError());
            return;
        }

        ifAttached(view -> view.showLoading());
        addTask(authDomain
            .resetPassword(mobile, token, newPassword)
            .andThen(signin.execute(mobile, newPassword))
            .observeOn(uiScheduler)
            .subscribe(
                () ->
                {
                    Analytics.track(
                        AnalyticsEvents.RESET_PWD_SUCCESSFUL,
                        EventProperties
                            .create()
                            .with("error", "false")
                    );
                    ifAttached(view -> view.hideLoading());
                    ifAttached(view -> view.gotoHomeScreen(requestedScreen));
                },
                throwable ->
                {
                    Timber.e(throwable, "failed to reset password");
                    ifAttached(view -> view.hideLoading());
                    if (isInternetIssue(throwable)) {
                        Analytics.track(
                            AnalyticsEvents.RESET_PWD_SUCCESSFUL,
                            EventProperties
                                .create()
                                .with("error", "internet issue")
                        );
                        ifAttached(view -> view.showNoInternetMessage());
                    } else {
                        Analytics.track(
                            AnalyticsEvents.RESET_PWD_SUCCESSFUL,
                            EventProperties
                                .create()
                                .with("error", "true")
                        );
                        ifAttached(view -> view.showError());
                    }
                }
            )
        );
    }

    @Override
    public void onInternetRestored() {
    }
}
