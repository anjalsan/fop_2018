package in.okcredit._offline.usecase;

import javax.inject.Inject;

import in.okcredit._offline._hack.NotificationManager;
import in.okcredit._offline.model.InAppNotification;
import io.reactivex.Single;

// Offline
public final class GetInAppNotification {
    private NotificationManager notificationManager;

    @Inject
    public GetInAppNotification(NotificationManager notificationManager) {
        this.notificationManager = notificationManager;
    }

    public Single<InAppNotification> execute() {
        return notificationManager._getInAppNotification();
    }
}
