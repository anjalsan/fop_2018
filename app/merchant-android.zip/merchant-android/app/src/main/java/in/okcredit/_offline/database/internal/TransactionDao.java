package in.okcredit._offline.database.internal;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;

import java.util.List;

import io.reactivex.Flowable;
import io.reactivex.Single;

@Dao
public abstract class TransactionDao {

    @Query("SELECT * FROM `transaction` WHERE customerId = :customerId ORDER BY createdAt DESC")
    public abstract Flowable<List<DbEntities.Transaction>> listTransactions(String customerId);

    @Query("SELECT * FROM `transaction` ORDER BY createdAt DESC")
    public abstract Flowable<List<DbEntities.Transaction>> listTransactions();


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public abstract void insertTransaction(DbEntities.Transaction... transaction);


    @Query("DELETE FROM `transaction`")
    public abstract void deleteAllTransactions();

    @Query("SELECT count(*) FROM `Transaction` WHERE id = :txnId")
    public abstract Single<Integer> isTransactionPresent(String txnId);


    @Query("SELECT * FROM `Transaction` WHERE id = :txnId LIMIT 1")
    public abstract Flowable<DbEntities.Transaction> getTransaction(String txnId);

    @Query("SELECT * FROM `transaction` WHERE isDirty = :isDirty")
    public abstract Single<List<DbEntities.Transaction>> listDirtyTransactions(boolean isDirty);
}
