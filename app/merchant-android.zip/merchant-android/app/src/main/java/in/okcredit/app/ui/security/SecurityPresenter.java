package in.okcredit.app.ui.security;

import javax.inject.Inject;

import in.okcredit.AppLockManager;
import in.okcredit._di.UiThread;
import in.okcredit._offline.usecase.GetActiveMerchant;
import in.okcredit._offline.usecase.Signout;
import in.okcredit.app.ui._base_v2.BasePresenter;
import in.okcredit.domain.auth.AuthErrors;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.observers.DisposableCompletableObserver;
import timber.log.Timber;

public class SecurityPresenter extends BasePresenter<SecurityContract.View> implements SecurityContract.Presenter {
    private AppLockManager appLockManager;
    private Signout signout;

    private GetActiveMerchant getActiveMerchant;

    @Inject
    public SecurityPresenter(@UiThread Scheduler uiScheduler,
                             AppLockManager appLockManager,
                             GetActiveMerchant getActiveMerchant,
                             Signout signout) {
        super(uiScheduler);
        this.appLockManager = appLockManager;
        this.getActiveMerchant = getActiveMerchant;
        this.signout = signout;
    }

    @Override
    protected void loadData() {
        ifAttached(view -> view.setAppLockStatus(appLockManager.isAppLockActive()));
    }

    @Override
    public void logout(String password) {

        addTask(signout
            .execute(password)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeWith(new DisposableCompletableObserver() {
                @Override
                public void onComplete() {
                    ifAttached(view -> view.onLogoutSuccessful());
                }

                @Override
                public void onError(@NonNull Throwable e) {
                    if (e instanceof AuthErrors.IncorrectPassword) {
                        ifAttached(view -> view.displayInvalidCredentialsError());
                    } else {
                        if (isAuthenticationIssue(e))
                            ifAttached(view -> view.gotoLogin());
                        else if (isInternetIssue(e))
                            ifAttached(view -> view.showNoInternetMessage());
                        else
                            ifAttached(view -> view.showError());
                    }
                }
            }));
    }


    @Override
    public void onResetPasswordClicked() {
        addTask(
            getActiveMerchant
                .execute()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    merchant ->
                    {
                        ifAttached(view -> view.gotoResetPasswordScreen(merchant.getMobile()));
                    },
                    throwable -> Timber.e(throwable, "failed to get mobile for reset password")
                )
        );
    }

    @Override
    public void onInternetRestored() {
        loadData();
    }

    @Override
    public void onAuthenticationRestored() {
        loadData();
    }
}
