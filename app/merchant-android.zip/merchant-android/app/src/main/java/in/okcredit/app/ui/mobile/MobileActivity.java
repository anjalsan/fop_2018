package in.okcredit.app.ui.mobile;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.Arrays;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import dagger.android.AndroidInjection;
import in.okcredit.R;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base.BaseActivity;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui._register._RegisterActivity;
import in.okcredit.app.ui._utils.KeyboardUtil;
import in.okcredit.app.ui.login.LoginActivity;
import in.okcredit.app.ui.welcome.WelcomeActivity;
import in.okcredit.util.MobileUtils;
import timber.log.Timber;

public class MobileActivity extends BaseActivity implements EnterMobile.View {
    public static Intent startingIntent(Context context) {
        return new Intent(context, MobileActivity.class);
    }

    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.mobileContainer)
    TextInputLayout mobileContainer;
    @BindView(R.id.mobile)
    EditText mobile;
    @BindView(R.id.loading)
    ProgressBar loading;
    @BindView(R.id.ok)
    ViewGroup next;

    @Inject
    EnterMobile.Presenter presenter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AndroidInjection.inject(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.screen_mobile);
        ButterKnife.bind(this);

        // Disabling Android O auto-fill service
        disableAutoFill();
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("");
        }

        Analytics.track(AnalyticsEvents.MOBILE_SCREEN);

        mobile.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (editable.toString().length() > 11) {
                    String parsedMobile = MobileUtils.parseMobile(editable.toString());
                    mobile.setText(parsedMobile);
                    mobile.setSelection(parsedMobile.length());
                } else if (editable.toString().length() > 10) {
                    String  mobileString = editable.toString();
                    mobileString = mobileString.replaceFirst("^0+(?!$)", "");

                    if (mobileString.length() == 10) {
                        mobile.setText(mobileString);
                        mobile.setSelection(10);
                    } else {
                        mobile.setText(editable.toString().substring(0, 10));
                        mobile.setSelection(10);
                    }
                } else if (editable.toString().length() == 10) {
                    next.setVisibility(View.VISIBLE);
                } else {
                    next.setVisibility(View.GONE);
                    mobile.requestFocus();
                }
            }
        });

        next.setOnClickListener(view ->
        {
            presenter.checkMobile(mobile.getText().toString());

            Analytics.track(
                AnalyticsEvents.MOBILE_CLICK_NEXT,
                EventProperties
                    .create()
                    .with("mobile", mobile.getText().toString())
            );
        });

        if (mobile.getText().length() != 10) {
            next.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.attachView(this);
        KeyboardUtil.showKeyboard(this, mobile);
    }

    @Override
    protected void onPause() {
        super.onPause();
        presenter.detachView();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.clear();
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_with_help, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.help:
                startHelpFlow();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (grantResults.length > 0 && Arrays.asList(permissions).contains(Manifest.permission
            .CALL_PHONE) && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startHelpFlow();
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    @Override
    public void onBackPressed() {
        if (!isStartedForResult()) {
            startActivity(WelcomeActivity.startingIntent(this));
            finish();
        }
    }

    private boolean isStartedForResult() {
        Timber.i("isStartedForResult: %s", getCallingActivity());
        return getCallingActivity() != null;
    }

    /****************************************************************
     MVP methods
     ****************************************************************/
    @Override
    public void onAuthenticationFailure() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "mobile screen")
                .with("type", "auth error")
        );
    }

    @Override
    public void onError(String tag) {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "mobile screen")
                .with("type", "server error")
        );

        Toast.makeText(this, R.string.err_default, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showLoading() {
        loading.setVisibility(View.VISIBLE);
        next.setVisibility(View.GONE);
    }

    @Override
    public void hideLoading() {
        loading.setVisibility(View.GONE);
        next.setVisibility(View.VISIBLE);
    }

    @Override
    public void displayInvalidMobileError() {
        mobileContainer.setErrorEnabled(true);
        mobileContainer.setError(getString(R.string.err_invalid_mobile));
        KeyboardUtil.showKeyboard(this, mobile);
    }

    @Override
    public void gotoLoginScreen(String mobile) {
        Timber.d("GOING ");
        startActivity(LoginActivity.startingIntent(this, mobile));
        finish();
    }

    @Override
    public void gotoRegistrationScreen(String mobile) {
        startActivity(_RegisterActivity.startingIntent(this, mobile));
        finish();
    }

    @Override
    public void onNetworkFailure() {
        new NetworkErrorDialog().show(this, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
            }

            @Override
            public void onCancel() {
            }
        });
    }
}
