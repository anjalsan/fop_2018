package in.okcredit.app.ui.rating.playstore_rating;

import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;
import in.okcredit.app.ui.rating.RatingActivity;

public interface PlaystoreRatingContract {
    interface View extends MVP.View, BaseContracts.Online.View {
    }

    interface Presenter extends MVP.Presenter<View>, BaseContracts.Online.Presenter<View> {
        void goToPlaystore(RatingActivity activity);
    }
}
