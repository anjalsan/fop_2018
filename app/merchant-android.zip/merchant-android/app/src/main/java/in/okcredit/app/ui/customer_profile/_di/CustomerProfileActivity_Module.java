package in.okcredit.app.ui.customer_profile._di;

import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import in.okcredit._di.PresenterParam;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit._di.scope.FragmentScope;
import in.okcredit.app.ui.addtxn.AddTxnActivity;
import in.okcredit.app.ui.addtxn.addTxn.CameraHelper;
import in.okcredit.app.ui.addtxn.addTxn.GalleryHelper;
import in.okcredit.app.ui.customer_profile.CustomerProfileActivity;
import in.okcredit.app.ui.customer_profile.CustomerProfileContract;
import in.okcredit.app.ui.customer_profile.CustomerProfilePresenter;

@Module
public abstract class CustomerProfileActivity_Module {
    @Provides
    @ActivityScope
    @PresenterParam("customer_id")
    public static String customerId(CustomerProfileActivity activity) {
        return activity.getIntent().getStringExtra(CustomerProfileActivity.EXTRA_CUSTOMER_ID);
    }

    @Provides
    @ActivityScope
    @PresenterParam("is_edit_mobile")
    public static Boolean isEditMobile(CustomerProfileActivity activity) {
        return activity.getIntent().getBooleanExtra(CustomerProfileActivity.IS_EDIT_MOBILE, false);
    }

    @Provides
    @ActivityScope
    public static CameraHelper cameraHelper(CustomerProfileActivity activity) {
        return new CameraHelper(activity);
    }

    @Provides
    @ActivityScope
    public static GalleryHelper galleryHelper(CustomerProfileActivity activity) {
        return new GalleryHelper(activity);
    }

    @Binds
    @ActivityScope
    public abstract CustomerProfileContract.Presenter presenter(CustomerProfilePresenter presenter);
}
