package in.okcredit.app.ui.rating._di;

import dagger.Module;
import dagger.android.ContributesAndroidInjector;
import in.okcredit._di.scope.FragmentScope;
import in.okcredit.app.ui.rating.feedback_rating.FeedbackRatingFragment;
import in.okcredit.app.ui.rating.playstore_rating.PlaystoreRatingFragment;
import in.okcredit.app.ui.rating.select_rating.SelectRatingFragment;

@Module
public abstract class RatingActivity_FragmentModule {
    @FragmentScope
    @ContributesAndroidInjector(modules = {PlaystoreRatingFragment_Module.class})
    public abstract PlaystoreRatingFragment playstoreRatingFragment();

    @FragmentScope
    @ContributesAndroidInjector(modules = {FeedbackRatingFragment_Module.class})
    public abstract FeedbackRatingFragment feedbackRatingFragment();

    @FragmentScope
    @ContributesAndroidInjector(modules = {SelectRatingFragment_Module.class})
    public abstract SelectRatingFragment selectRatingFragment();
}
