package in.okcredit._offline.server.interceptor;

import com.google.common.base.Strings;

import java.io.IOException;

import in.okcredit.domain.auth.AuthDomain;
import in.okcredit.domain.auth.AuthErrors;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

public class AuthInterceptor implements Interceptor {
    public static final int RETRY_COUNT = 3;
    public static final String HEADER_AUTHORIZATION = "Authorization";

    private AuthDomain authDomain;

    public AuthInterceptor(AuthDomain authDomain) {
        this.authDomain = authDomain;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request req = chain.request();

        for(int i=0; i< RETRY_COUNT; i++) {
            try {
                String authHeader = authDomain.authorize().blockingGet();
                req = req.newBuilder()
                    .addHeader(HEADER_AUTHORIZATION, authHeader)
                    .build();
                if (!Strings.isNullOrEmpty(authHeader)) {
                    break;
                }
            } catch (Exception e) {
            }
        }

        Response response = chain.proceed(req);
        if (response.code() == 401) {
            throw new AuthErrors.Unauthenticated();
        } else {
            return response;
        }
    }
}
