package in.okcredit._offline.database;

import android.annotation.SuppressLint;

import javax.inject.Inject;

import in.okcredit.ThreadUtils;
import in.okcredit._offline.database.internal.DbEntityMapper;
import in.okcredit._offline.database.internal.MerchantDao;
import in.okcredit._offline.model.Merchant;
import in.okcredit._offline.model.MerchantPreference;
import io.reactivex.Completable;
import io.reactivex.Observable;
import io.reactivex.Single;
import io.reactivex.subjects.BehaviorSubject;

public final class MerchantRepo {
    private MerchantDao merchantDao;

    // in-memory cache
    private BehaviorSubject<Merchant> merchantCache;

    @Inject
    public MerchantRepo(MerchantDao merchantDao) {
        this.merchantDao = merchantDao;
    }

    @SuppressLint("CheckResult")
    public Observable<Merchant> getActiveMerchant() {
        if (merchantCache == null) {
            merchantCache = BehaviorSubject.create();
            merchantDao.getActiveMerchant()
                       .map(merchant -> DbEntityMapper.MERCHANT.reverse().convert(merchant))
                       .subscribeOn(ThreadUtils.database())
                       .observeOn(ThreadUtils.newThread())
                       .subscribe(merchant -> merchantCache.onNext(merchant));
        }
        return merchantCache.observeOn(ThreadUtils.worker());
    }

    public Completable setActiveMerchant(Merchant merchant) {
        return Completable.fromAction(() -> merchantDao.setActiveMerchant(DbEntityMapper.MERCHANT.convert(merchant)))
                          .subscribeOn(ThreadUtils.database())
                          .observeOn(ThreadUtils.worker());
    }

    public Single<Boolean> isMerchantPreferenceAvailable(MerchantPreference preference) {
        return getActiveMerchant()
            .flatMap(merchant ->
                merchantDao.isMerchantPreferenceAvailable(merchant.getId(), preference.getKey())
                           .subscribeOn(ThreadUtils.database())
                           .observeOn(ThreadUtils.worker())
                           .toObservable()
            )
            .map(count -> count == 1)
            .firstOrError();
    }

    public Observable<String> getMerchantPreference(MerchantPreference defaultPreference) {
        return isMerchantPreferenceAvailable(defaultPreference)
            .flatMapObservable(isAvailable -> {
                if (isAvailable) {
                    return getActiveMerchant()
                        .flatMap(
                            merchant ->
                                merchantDao
                                    .getMerchantPreference(merchant.getId(), defaultPreference.getKey())
                                    .subscribeOn(ThreadUtils.database())
                                    .observeOn(ThreadUtils.worker())
                                    .toObservable()
                        );
                } else {
                    return Observable.just(defaultPreference.getValue());
                }
            });
    }

    public Completable putMerchantPreference(MerchantPreference merchantPreference) {
        return Completable
            .fromAction(() ->
                merchantDao.insertMerchantPreference(DbEntityMapper.MERCHANT_PREFERENCE.convert(merchantPreference))
            )
            .subscribeOn(ThreadUtils.database())
            .observeOn(ThreadUtils.worker());
    }

    // DANGEROUS: clears entire customer list
    public Completable clear() {
        return Completable.fromAction(() -> merchantDao.deleteAllMerchants())
                          .subscribeOn(ThreadUtils.database())
                          .observeOn(ThreadUtils.worker());
    }
}
