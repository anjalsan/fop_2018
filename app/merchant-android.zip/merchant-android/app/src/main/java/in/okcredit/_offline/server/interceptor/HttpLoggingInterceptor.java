package in.okcredit._offline.server.interceptor;

import android.util.Log;

import java.io.IOException;

import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;
import okio.Buffer;
import okio.BufferedSource;
import timber.log.Timber;

public class HttpLoggingInterceptor implements Interceptor {
    private static final String TAG = "HTTP";

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request req = chain.request();
        Request reqCopy = req.newBuilder().build();
        long startTime = System.nanoTime();

        try {
            Response res = chain.proceed(req);

            // logging
            logRequest(reqCopy);
            logResponse(res, startTime);

            // analytics
//            addAnalytics(res, reqCopy, startTime, true);

            return res;
        } catch (IOException e) {
            // logging
            logRequest(reqCopy);
            logError(e, startTime);

            // analytics
//            addAnalytics(null, reqCopy, startTime, false);

            throw e;
        }
    }

    private static void addAnalytics(Response res, Request req, long startTime, boolean isSuccess) {
        if (isSuccess) {
            try {
                Analytics.track(
                    AnalyticsEvents.API_CALL,
                    EventProperties
                        .create()
                        .with("success", true)
                        .with("req_method", res.request().method())
                        .with("req_url", res.request().url().toString())
                        .with("http_status", String.valueOf(res.code()))
                        .with("time_taken_ms", toMillisecond(System.nanoTime() - startTime))
                        .with("res_size_bytes", res.body().contentLength())
                );

            } catch (Exception e) {
                Timber.tag(TAG).w(e, "failed to track analytics");
            }
        } else {
            try {
                Analytics.track(
                    AnalyticsEvents.API_CALL,
                    EventProperties
                        .create()
                        .with("success", false)
                        .with("req_method", req.method())
                        .with("req_url", req.url().toString())
                        .with("time_taken_ms", toMillisecond(System.nanoTime() - startTime))
                );

            } catch (Exception e) {
                Timber.tag(TAG).w(e, "failed to track analytics");
            }
        }
    }

    private static void logRequest(final Request reqCopy) {
        try {
            Timber.tag(TAG).i("%s %s", reqCopy.method(), reqCopy.url().toString());
            Timber.tag(TAG).v("Content-Type: %s", reqCopy.header("Content-Type"));
            Timber.tag(TAG).v("Authorization: %s", reqCopy.header("Authorization"));
            Timber.tag(TAG).v("User-Agent: %s", reqCopy.header("User-Agent"));
            if (reqCopy.body() != null)
                Timber.tag(TAG).v("%s", parseRequestBody(reqCopy));
        } catch (Exception e) {
            Timber.tag(TAG).w(e, "failed to log request");
        }
    }

    private static void logResponse(final Response res, long startTime) {
        try {
            long endTime = System.nanoTime();
            Timber.tag(TAG).i("status=%d time=%fms", res.code(), toMillisecond(endTime - startTime));
            String resBody = parseResponseBody(res);
            if (resBody != null)
                Timber.tag(TAG).v("%s", resBody);
        } catch (Exception e) {
            Timber.tag(TAG).w(e, "failed to log response");
        }
    }

    private static void logError(final Throwable t, long startTime) {
        long endTime = System.nanoTime();
        Timber.tag(TAG).e("time=%fms", toMillisecond(endTime - startTime));
    }

    private static String parseRequestBody(final Request request) throws IOException {
        try {
            final Buffer buffer = new Buffer();
            request.body().writeTo(buffer);
            return buffer.readUtf8();
        } catch (final IOException e) {
            throw new IOException("failed to parse request body", e);
        }
    }

    private static String parseResponseBody(final Response response) throws IOException {
        if (response.body() == null)
            return null;

        BufferedSource src = response.body().source();
        src.request(9223372036854775807L);
        Buffer b = src.buffer();
        return b.clone().readUtf8();
    }

    private static double toMillisecond(long nano) {
        return nano / Math.pow(10, 6);
    }
}
