package in.okcredit.app.ui.reminder;

/**
 * Created by harsh on 20/12/17.
 */

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import org.joda.time.DateTime;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.R;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.util.DateTimeUtils;

public class ReminderActivity extends BaseActivity implements ReminderContract.View {
    // Intent
    public static Intent startingIntent(Context context) {
        Intent intent = new Intent(context, ReminderActivity.class);
        return intent;
    }

    // UI Elements
    @BindView(R.id.reminderCheckbox)
    CheckBox checkBox;

    @BindView(R.id.reminderView)
    View reminderView;

    @BindView(R.id.reminderExplainationView)
    View reminderExplainationView;

    @BindView(R.id.loading)
    View loading;

    @BindView(R.id.reminderExplainationText)
    TextView reminderExplaination;

    // Presenter
    @Inject
    ReminderContract.Presenter presenter;

    // Lifecycle Methods
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.screen_reminder);
        ButterKnife.bind(this);
        showActionBar(true);
        setTitle(R.string.reminder_action_bar);

        checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                presenter.toggleReminderStatus(checkBox.isChecked());

                Analytics.track(
                    AnalyticsEvents.REMINDER_TOGGLED,
                    EventProperties
                        .create()
                        .with("type", checkBox.isChecked()));

                if (checkBox.isChecked()) {

                    DateTime today = DateTime.now().withTimeAtStartOfDay();
                    DateTime reminderDate = today.withDayOfMonth(5);
                    if (today.isAfter(reminderDate)) {
                        reminderDate = reminderDate.plusMonths(1);
                    }

                    reminderExplaination.setText(getString(R.string.reminder_next_date, DateTimeUtils
                        .formatDateOnly(reminderDate), DateTimeUtils.formatDateOnly(reminderDate
                        .minusDays(1))));
                } else {
                    reminderExplaination.setText(R.string.reminder_explaination);
                }
            }
        });

        Analytics.track(AnalyticsEvents.REMINDER_SCREEN);
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.attachView(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        presenter.detachView();
    }


    // View functions
    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(this, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
                onBackPressed();
            }
        });
    }

    @Override
    public void showLoading() {
        reminderView.setVisibility(View.GONE);
        reminderExplainationView.setVisibility(View.GONE);
        loading.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideLoading() {
        reminderView.setVisibility(View.VISIBLE);
        reminderExplainationView.setVisibility(View.VISIBLE);
        loading.setVisibility(View.GONE);
    }

    @Override
    public void showError() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "reminder")
                .with("type", "server error")
        );

        Toast.makeText(this, R.string.err_default, Toast.LENGTH_LONG).show();
        finish();
    }

    @Override
    public void setCheckbox(boolean isReminderOn) {
        reminderView.setVisibility(View.VISIBLE);
        reminderExplainationView.setVisibility(View.VISIBLE);
        loading.setVisibility(View.GONE);
        checkBox.setChecked(isReminderOn);

        if (isReminderOn) {
            DateTime today = DateTime.now().withTimeAtStartOfDay();
            DateTime reminderDate = today.withDayOfMonth(5);
            if (today.isAfter(reminderDate)) {
                reminderDate = reminderDate.plusMonths(1);
            }

            reminderExplaination.setText(getString(R.string.reminder_next_date, DateTimeUtils
                .formatDateOnly(reminderDate), DateTimeUtils.formatDateOnly(reminderDate
                .minusDays(1))));
        } else {
            reminderExplaination.setText(R.string.reminder_explaination);
        }
    }

    @Override
    public void gotoLogin() {
        super.gotoLogin();
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "reminder")
                .with("type", "auth error")
        );
    }
}
