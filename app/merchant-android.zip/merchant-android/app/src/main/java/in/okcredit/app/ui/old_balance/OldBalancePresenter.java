package in.okcredit.app.ui.old_balance;

import javax.inject.Inject;

import in.okcredit._di.PresenterParam;
import in.okcredit.app.ui._base_v2.BasePresenter;
import in.okcredit._offline.model.Customer;
import io.reactivex.android.schedulers.AndroidSchedulers;

public class OldBalancePresenter extends BasePresenter<OldBalanceContract.View> implements
    OldBalanceContract.Presenter {
    private int lifecycle;
    private Customer customer;

    @Inject
    public OldBalancePresenter(@PresenterParam("lifecycle") int lifecycle, @PresenterParam
        ("customer") Customer customer) {
        super(AndroidSchedulers.mainThread());
        this.lifecycle = lifecycle;
        this.customer = customer;
    }


    @Override
    public void onInternetRestored() {

    }

    @Override
    protected void loadData() {
        ifAttached(view -> view.displayCustomerDetails(customer));
        ifAttached(view -> view.setUpTutorialLayout(lifecycle));
    }

    @Override
    public void onAuthenticationRestored() {
        loadData();
    }
}
