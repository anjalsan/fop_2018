package in.okcredit._offline.usecase;

import javax.inject.Inject;

import in.okcredit._offline.database.CustomerRepo;
import in.okcredit._offline.database.TransactionRepo;
import in.okcredit._offline.model.Transaction;
import in.okcredit._offline.server.Server;
import in.okcredit.domain.auth.AuthDomain;
import io.reactivex.Completable;
import io.reactivex.Single;

public final class DeleteTransaction {
    private AuthDomain authDomain;
    private Server server;
    private TransactionRepo transactionRepo;
    private SyncCustomer syncCustomer;
    private CustomerRepo customerRepo;
    private SafelySaveCustomer safelySaveCustomer;

    @Inject
    public DeleteTransaction(AuthDomain authDomain, Server server, TransactionRepo transactionRepo, SyncCustomer syncCustomer, CustomerRepo customerRepo, SafelySaveCustomer safelySaveCustomer) {
        this.authDomain = authDomain;
        this.server = server;
        this.transactionRepo = transactionRepo;
        this.syncCustomer = syncCustomer;
        this.customerRepo = customerRepo;
        this.safelySaveCustomer = safelySaveCustomer;
    }

    public Completable execute(String txnId, String password) {
        return authDomain.verifyPassword(password)
                         .andThen(delete(txnId))
                         .flatMapCompletable(transaction ->
                             transactionRepo.putTransaction(transaction)
                                            .andThen(updateCustomerAccountSummary(transaction.getCustomerId()))
                                            .andThen(syncCustomer.schedule(transaction.getCustomerId()))
                         );
    }

    private Single<Transaction> delete(String txnId) {
        return transactionRepo
            .getTransaction(txnId)
            .firstOrError()
            .map(transaction -> transaction.asDeleted().withDirty(true));

//        return server.deleteTransaction(txnId)
//                     .andThen(server.getTransaction(txnId));
    }

    private Completable updateCustomerAccountSummary(String customerId) {
        return customerRepo.getCustomer(customerId)
                           .firstOrError()
                           .flatMapCompletable(customer -> safelySaveCustomer.execute(customer));
    }
}
