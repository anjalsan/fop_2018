package in.okcredit.app.ui.delete_txn;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.github.aakira.expandablelayout.ExpandableLayout;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import dagger.android.AndroidInjection;
import in.okcredit.LifecycleState;
import in.okcredit.R;
import in.okcredit._offline.model.Transaction;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui._utils.CurrencyUtil;
import in.okcredit.app.ui._utils.KeyboardUtil;
import in.okcredit.app.ui.transaction.TransactionActivity;
import in.okcredit.util.DateTimeUtils;

public class DeleteTransactionActivity extends BaseActivity implements DeleteTxnContract.View {

    public static final String EXTRA_TX_ID = "tx_id";
    public static final String EXTRA_TX = "tx";
    private String transactionId;

    public static Intent startingIntent(Context context, @NonNull String transactionId, Transaction transaction) {
        Intent intent = new Intent(context, DeleteTransactionActivity.class);
        intent.putExtra(EXTRA_TX, transaction);
        intent.putExtra(EXTRA_TX_ID, transactionId);
        return intent;
    }

    @BindView(R.id.icon)
    ImageView icon;
    @BindView(R.id.title)
    TextView title;
    @BindView(R.id.subtitle)
    TextView subtitle;
    @BindView(R.id.amount)
    TextView amount;
    @BindView(R.id.del_msg)
    TextView deleteMsg;
    @BindView(R.id.passwordLayout)
    ExpandableLayout passwordContainer;
    @BindView(R.id.delete)
    LinearLayout delete;
    @BindView(R.id.ok)
    LinearLayout ok;
    @BindView(R.id.loading)
    ProgressBar loading;
    @BindView(R.id.passwordContainer)
    TextInputLayout passwordTIL;
    @BindView(R.id.password)
    EditText password;
    @BindView(R.id.incorrectPasswordMsg)
    TextView incorrectPasswordMsg;

    @Inject
    DeleteTxnContract.Presenter presenter;

    private Transaction transaction;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AndroidInjection.inject(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.delete_txn_activity);
        ButterKnife.bind(this);
        showActionBar(true);

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                passwordContainer.expand();
                delete.setVisibility(View.GONE);

                Analytics.track(
                    AnalyticsEvents.DELETE_TRANSACTION_SCREEN_DELETE_CLICKED,
                    EventProperties
                        .create()
                        .with("type", transaction.getType())
                        .with("txId", transaction.getId())
                );
            }
        });

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                KeyboardUtil.hideKeyboard(DeleteTransactionActivity.this, password);
                Analytics.track(
                    AnalyticsEvents.TX_DELETE_CONFIRM,
                    EventProperties
                        .create()
                        .with("type", transaction.getType())
                        .with("txId", transaction.getId())
                );
                incorrectPasswordMsg.setVisibility(View.INVISIBLE);
                presenter.delete(password.getText().toString(), transactionId);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.attachView(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        presenter.detachView();
    }

    /****************************************************************
     * MVP methods
     ****************************************************************/
    @Override
    public void showError() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "delete txn")
                .with("type", "server error")
        );

        Toast.makeText(this, R.string.err_default, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(this, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
            }
        });
    }

    @Override
    public void setTransaction(Transaction transaction) {

        Analytics.track(
            AnalyticsEvents.DELETE_TRANSACTION_SCREEN,
            EventProperties
                .create()
                .with("type", transaction.getType())
                .with("txId", transaction.getId())
        );

        this.transactionId = transaction.getId();
        this.transaction = transaction;

        switch (transaction.getType()) {
            case Transaction.CREDIT:
                setTitle(R.string.credit_delete_desc);
                icon.setColorFilter(ContextCompat.getColor(this, R.color.tx_credit));
                icon.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_credit));

                if (transaction.isOnboarding()) {
                    if (transaction.getNote() == null || transaction.getNote().isEmpty()) {
                        title.setText(R.string.old_balance_title_credit);
                    } else {
                        title.setText(transaction.getNote());
                    }
                } else {

                    if (transaction.getNote() == null || transaction.getNote().isEmpty()) {
                        title.setText(R.string.txn_credit_title);
                    } else {
                        title.setText(transaction.getNote());
                    }
                }

                deleteMsg.setText(getString(R.string.del_credit_msg));

                break;

            case Transaction.PAYMENT:
                setTitle(R.string.payment_delete_desc);
                icon.setColorFilter(ContextCompat.getColor(this, R.color.tx_payment));
                icon.setImageDrawable(ContextCompat.getDrawable(this, R.drawable
                    .ic_payment));

                if (transaction.isOnboarding()) {

                    if (transaction.getNote() == null || transaction.getNote().isEmpty()) {
                        title.setText(R.string.old_balance_title_payment);
                    } else {
                        title.setText(transaction.getNote());
                    }
                } else {

                    if (transaction.getNote() == null || transaction.getNote().isEmpty()) {
                        title.setText(R.string.txn_payment_title);
                    } else {
                        title.setText(transaction.getNote());
                    }
                }

                deleteMsg.setText(getString(R.string.del_payment_msg));

                break;
        }

        subtitle.setText(DateTimeUtils.format(transaction.getCreatedAt()));
        amount.setText(CurrencyUtil.format(transaction.getAmount()));
    }

    @Override
    public void goToCustomerScreen() {
        Analytics.track(
            AnalyticsEvents.DELETE_TRANSACTION_SUCCESS,
            EventProperties
                .create()
                .with("type", transaction.getType())
                .with("txId", transaction.getId())
        );
        finish();
    }

    @Override
    public void showLoading() {
        ok.setVisibility(View.GONE);
        loading.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideLoading() {
        loading.setVisibility(View.GONE);
        ok.setVisibility(View.VISIBLE);
    }

    @Override
    public void showIncorrectPasswordError() {
        incorrectPasswordMsg.setVisibility(View.VISIBLE);

        Analytics.track(
            AnalyticsEvents.DELETE_INCORRECT_PASSWORD,
            EventProperties
                .create()
                .with("type", transaction.getType())
                .with("txId", transaction.getId())
        );
    }

    @Override
    public void gotoTransactionScreen(String transactionId) {
        startActivity(TransactionActivity.startingIntent(this, transactionId, LifecycleState.NORMAL_FLOW, true));
        finish();
    }

    @Override
    public void gotoLogin() {
        super.gotoLogin();
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "delete txn")
                .with("type", "auth error")
        );
    }

    @Override
    public void onBackPressed() {
        presenter.onBackPressed();
    }

    @Override
    protected void onUpPressed() {
        presenter.onBackPressed();
    }
}
