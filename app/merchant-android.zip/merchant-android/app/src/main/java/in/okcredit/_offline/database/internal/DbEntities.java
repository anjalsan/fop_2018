package in.okcredit._offline.database.internal;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

import org.joda.time.DateTime;

public interface DbEntities {

    @Entity
    final class Merchant {
        @NonNull
        @PrimaryKey
        public String id;
        public String name;
        public String mobile;
        public DateTime createdAt;
    }

    @Entity(primaryKeys = {"merchantId", "key"})
    final class MerchantPreference {
        @NonNull public String merchantId;
        @NonNull public String key;
        @NonNull public String value;
    }

    @Entity
    final class Customer {
        @NonNull
        @PrimaryKey
        public String id;
        public int status;
        public String mobile;
        public String description;
        public DateTime createdAt;
        public float balance;
        public long transactionCount;
        public DateTime lastActivity;
        public DateTime lastPayment;
        public String accountUrl;
        public String profileImage;
        public String address;
        public String email;
    }

    @Entity
    final class CustomerSync {
        @NonNull
        @PrimaryKey
        public String customerId;
        public DateTime lastSync;
    }

    @Entity
    final class Transaction {
        @NonNull
        @PrimaryKey
        public String id;
        public int type;
        public String customerId;
        public float amount;
        public String receiptUrl;
        public String note;
        public DateTime createdAt;
        public boolean isOnboarding;
        public boolean isDeleted;
        public DateTime deleteTime;
        public boolean isDirty;
    }
}
