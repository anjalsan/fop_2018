package in.okcredit.app.ui.home.viewModels;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.airbnb.epoxy.CallbackProp;
import com.airbnb.epoxy.ModelProp;
import com.airbnb.epoxy.ModelView;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.R;
import in.okcredit._offline.model.InAppNotification;

@ModelView(autoLayout = ModelView.Size.MATCH_WIDTH_WRAP_HEIGHT)
public class InAppNotificationView extends LinearLayout {

    public interface InAppNotificationListener {
        void onNotificationCardClicked(int type);
        void onNotificationCloseClicked(int type);
    }

    @BindView (R.id.notifiction_card)
    CardView notifictionCard;
    @BindView (R.id.noti_icon)
    ImageView notiIcon;
    @BindView (R.id.noti_title)
    TextView notiTitle;
    @BindView (R.id.noti_subtitle)
    TextView notiSubtitle;
    @BindView (R.id.noti_close)
    ImageView notiClose;

    private InAppNotification inAppNotification;

    public InAppNotificationView(Context context) {
        super(context);
        initView();
    }

    public InAppNotificationView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public InAppNotificationView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public InAppNotificationView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        initView();
    }

    @ModelProp
    public void setType(InAppNotification inAppNotification) {
        this.inAppNotification = inAppNotification;

        switch (inAppNotification.getType()) {
            case InAppNotification.TYPE_UPDATE:
                
                notiTitle.setText(getContext().getString(R.string.update_noti_title));
                notiSubtitle.setText(getContext().getString(R.string.update_noti_subtitle));
                notiIcon.setImageDrawable(ContextCompat.getDrawable(getContext(), R.drawable.ic_play_store));
                break;

            case InAppNotification.TYPE_REMINDER_TO_BE_SENT:

                notiTitle.setText(getContext().getString(R.string.reminder_noti_title));
                notiSubtitle.setText(getContext().getString(R.string.reminder_noti_subtitle));
                notiIcon.setImageDrawable(ContextCompat.getDrawable(getContext(), R.drawable.ic_reminder));
                break;

            case InAppNotification.TYPE_SHARE:

                notiTitle.setText(getContext().getString(R.string.share_noti_title));
                notiSubtitle.setText(getContext().getString(R.string.share_noti_subtitle));
                notiIcon.setImageDrawable(ContextCompat.getDrawable(getContext(), R.drawable.ic_whatsapp));
                break;

            case InAppNotification.TYPE_APP_LOCK:

                notiTitle.setText(getContext().getString(R.string.app_lock_noti_title));
                notiSubtitle.setText(getContext().getString(R.string.app_lock_noti_subtitle));
                notiIcon.setImageDrawable(ContextCompat.getDrawable(getContext(), R.drawable.ic_secure));
                break;

            case InAppNotification.TYPE_RATING:

                notiTitle.setText(getContext().getString(R.string.rating_noti_title));
                notiSubtitle.setText(getContext().getString(R.string.rating_noti_subtitle));
                notiIcon.setImageDrawable(ContextCompat.getDrawable(getContext(), R.drawable.ic_heart));
                break;

            case InAppNotification.TYPE_EMPTY:
                notifictionCard.setVisibility(View.GONE);
                break;

            default:
                break;
        }
        
    }

    @CallbackProp
    public void setListener(@Nullable InAppNotificationListener listener) {
        if (listener != null) {
            notifictionCard.setOnClickListener((OnClickListener) v -> listener.onNotificationCardClicked(inAppNotification.getType()));
            notiClose.setOnClickListener((OnClickListener) v -> listener.onNotificationCloseClicked(inAppNotification.getType()));
        }
    }

    private void initView() {
        setOrientation(LinearLayout.HORIZONTAL);
        inflate(getContext(), R.layout.notification_card, this);
        ButterKnife.bind(this);
    }
}
