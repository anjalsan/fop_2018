package in.okcredit.app.ui.home.viewModels;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.airbnb.epoxy.CallbackProp;
import com.airbnb.epoxy.ModelProp;
import com.airbnb.epoxy.ModelView;
import com.amulyakhare.textdrawable.TextDrawable;
import com.amulyakhare.textdrawable.util.ColorGenerator;

import org.joda.time.DateTime;
import org.joda.time.Duration;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.util.Date;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.App;
import in.okcredit.LocaleManager;
import in.okcredit.R;
import in.okcredit._offline.model.Customer;
import in.okcredit.app.ui._utils.CurrencyUtil;
import in.okcredit.util.GlideApp;
import io.reactivex.android.schedulers.AndroidSchedulers;
import timber.log.Timber;

@ModelView(autoLayout = ModelView.Size.MATCH_WIDTH_WRAP_HEIGHT)
public class CustomerItemView extends LinearLayout {
    private static DateTimeFormatter DATE_FORMATTER = DateTimeFormat.forPattern("dd MMM").withLocale(LocaleManager.getEnglishLocale());

    public interface CustomerSelectionListener {
        void onSelectedCustomer(Customer customer);
    }

    private Customer customer;

    @BindView(R.id.desc)
    TextView desc;

    @BindView(R.id.balance)
    TextView balance;

    @BindView(R.id.pic)
    ImageView _pic;

    @BindView(R.id.lastPayment)
    TextView lastPayment;

    @BindView(R.id.warning)
    ImageView warning;

    @BindView(R.id.balanceStatus)
    TextView balanceStatus;

    public CustomerItemView(Context context) {
        super(context);
        initView();
    }

    public CustomerItemView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public CustomerItemView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public CustomerItemView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        initView();
    }

    @ModelProp
    public void setCustomer(Customer customer) {
        this.customer = customer;

        warning.setVisibility(View.GONE);

        desc.setText(customer.getDescription());

        if (customer.getLastPayment() != null) {
            Duration duration = new Duration(customer.getLastPayment(), new DateTime().withTimeAtStartOfDay().plusDays(1));
            if (duration.getStandardDays() == 0)
                lastPayment.setText(getContext().getString(R.string.paid_today));
            else if (duration.getStandardDays() == 1)
                lastPayment.setText(getContext().getString(R.string.paid_yesterday));
            else if (duration.getStandardDays() > 30 && customer.getBalance() < 0) {
                warning.setVisibility(View.VISIBLE);
                lastPayment.setText(getContext().getString(R.string.paid_on_date, customer.getLastPayment()
                    .toString(DATE_FORMATTER)));
            } else
                lastPayment.setText(getContext().getString(R.string.paid_on_date, customer.getLastPayment()
                    .toString(DATE_FORMATTER)));
        } else {
            Duration duration = new Duration(customer.getCreatedAt(), DateTime.now());
            if (duration.getStandardDays() <= 30 || customer.getBalance() >= 0)
                lastPayment.setText(getContext().getString(R.string.not_paid));
            else {
                warning.setVisibility(View.VISIBLE);
                lastPayment.setText(getContext().getString(R.string.overdue_warning));
            }

        }

        float amount = customer.getBalance();
        if (customer.getBalance() <= 0) {
            amount *= -1.0;
            balanceStatus.setText(getContext().getString(R.string.due));
        }else{
            balanceStatus.setText(getContext().getString(R.string.advance));
        }

        if (customer.getDescription() != null && customer.getDescription().length() > 0) {
            Drawable defaultPic = TextDrawable
                .builder()
                .buildRound(
                    customer.getDescription().substring(0, 1).toUpperCase(),
                    ColorGenerator.MATERIAL.getColor(customer.getDescription())
                );
            if (customer.getProfileImage() != null) {
                try {
//                    GlideApp
//                        .with(getContext())
//                        .load(customer.getProfileImage())
//                        .circleCrop()
//                        .placeholder(defaultPic)
//                        .fallback(defaultPic)
//                        .into(_pic);
                    App.appComponent().getAwsService()
                        .getFile(customer.getProfileImage())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(fileInfo -> {
                            if (fileInfo.isLocal) {
                                Timber.i("Local Image Url");
                                GlideApp
                                    .with(getContext())
                                    .load(fileInfo.localFile)
                                    .circleCrop()
                                    .placeholder(defaultPic)
                                    .fallback(defaultPic)
                                    .into(_pic);
                            } else {
                                Timber.i("Remote Image Url");
                                GlideApp
                                    .with(getContext())
                                    .load(fileInfo.url)
                                    .circleCrop()
                                    .placeholder(defaultPic)
                                    .fallback(defaultPic)
                                    .into(_pic);
                            }
                        });
                } catch (Exception e) {
                    _pic.setImageDrawable(defaultPic);
                }
            } else {
                _pic.setImageDrawable(defaultPic);
            }
        }

        CurrencyUtil.render(customer.getBalance(), balance);
    }

    @CallbackProp
    public void setListener(@Nullable CustomerSelectionListener listener) {
        if (listener != null) {
            setOnClickListener((OnClickListener) v -> listener.onSelectedCustomer(customer));
        }
    }

    private void initView() {
        setOrientation(LinearLayout.VERTICAL);
        inflate(getContext(), R.layout.item_customer, this);
        ButterKnife.bind(this);
    }
}
