package in.okcredit.app.ui.delete_customer;

import javax.inject.Inject;

import in.okcredit._di.PresenterParam;
import in.okcredit._di.UiThread;
import in.okcredit._offline.model.Customer;
import in.okcredit._offline.usecase.DeleteCustomer;
import in.okcredit._offline.usecase.GetCustomer;
import in.okcredit.app.ui._base_v2.BasePresenter;
import in.okcredit.domain.auth.AuthDomain;
import in.okcredit.domain.auth.AuthErrors;
import io.reactivex.Scheduler;
import timber.log.Timber;

public class DeleteCustomerPresenter extends BasePresenter<DeleteCustomerContract.View>
    implements DeleteCustomerContract.Presenter {
    private String customerId;
    private Customer customer;

    private GetCustomer getCustomer;
    private DeleteCustomer deleteCustomer;
    private AuthDomain authDomain;

    @Inject
    public DeleteCustomerPresenter(@UiThread Scheduler uiScheduler,
                                   @PresenterParam("customer_id") String customerId,
                                   GetCustomer getCustomer,
                                   DeleteCustomer deleteCustomer,
                                   AuthDomain authDomain) {
        super(uiScheduler);
        this.customerId = customerId;
        this.getCustomer = getCustomer;
        this.deleteCustomer = deleteCustomer;
        this.authDomain = authDomain;
    }

    @Override
    protected void loadData() {
        addTask(getCustomer
            .execute(customerId)
            .observeOn(uiScheduler)
            .subscribe(
                customer ->
                {
                    this.customer = customer;
                    ifAttached(view -> view.setCustomer(customer));
                },
                throwable -> {
                    ifAttached(view -> view.hideLoading());
                    if (isAuthenticationIssue(throwable)) {
                        ifAttached(view -> view.gotoLogin());
                    } else if (isInternetIssue(throwable)) {
                        ifAttached(view -> view.showNoInternetMessage());
                    } else {
                        ifAttached(view -> view.showError());
                    }
                })
        );
    }

    @Override
    public void delete(String password) {
        ifAttached(view -> view.showLoading());
        addTask(
            authDomain
                .verifyPassword(password)
                .andThen(deleteCustomer
                .execute(customerId))
                .observeOn(uiScheduler)
                .subscribe(
                    () ->
                    {
                        ifAttached(view -> view.gotoHomeScreen());
                        ifAttached(view -> view.hideLoading());
                    },
                    throwable ->
                    {
                        Timber.e(throwable);
                        ifAttached(view -> view.hideLoading());
                        if (throwable instanceof AuthErrors.IncorrectPassword) {
                            ifAttached(view -> view.showIncorrectPasswordError());
                        }else if (isAuthenticationIssue(throwable)) {
                            ifAttached(view -> view.gotoLogin());
                        } else if (isInternetIssue(throwable)) {
                            ifAttached(view -> view.showNoInternetMessage());
                        } else {
                            ifAttached(view -> view.showError());
                        }
                    }
                )
        );
    }

    @Override
    public void settle() {
        if (customer == null) {
            return;
        }

        if (customer.getBalance() < 0.0) {
            ifAttached(view -> view.gotoAddTxnScreen(customerId, 2, Math.abs(customer.getBalance
                ())));
        } else if (customer.getBalance() > 0.0) {
            ifAttached(view -> view.gotoAddTxnScreen(customerId, 1, Math.abs(customer.getBalance
                ())));
        }
    }

    @Override
    public void onInternetRestored() {
        loadData();
    }

    @Override
    public void onAuthenticationRestored() {
        loadData();
    }
}
