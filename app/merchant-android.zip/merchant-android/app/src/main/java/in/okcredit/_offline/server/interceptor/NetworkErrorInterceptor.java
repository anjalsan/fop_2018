package in.okcredit._offline.server.interceptor;

import java.io.IOException;

import in.okcredit._offline.server.NetworkError;
import okhttp3.Interceptor;
import okhttp3.Response;

public final class NetworkErrorInterceptor implements Interceptor {
    @Override
    public Response intercept(Chain chain) throws IOException {
        try {
            return chain.proceed(chain.request());

        } catch (IOException e) {
            NetworkError networkError = NetworkError.from(e);
            if (networkError != null) {
                // process network related errors
                throw networkError;
            } else {
                // forward other errors
                throw e;
            }
        }
    }
}
