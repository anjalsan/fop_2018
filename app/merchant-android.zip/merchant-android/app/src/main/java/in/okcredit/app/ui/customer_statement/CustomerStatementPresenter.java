package in.okcredit.app.ui.customer_statement;

import javax.inject.Inject;

import in.okcredit._di.PresenterParam;
import in.okcredit._di.UiThread;
import in.okcredit._offline.model.Customer;
import in.okcredit._offline.model.CustomerStatement;
import in.okcredit._offline.server.NetworkHelper;
import in.okcredit._offline.usecase.GetActiveMerchant;
import in.okcredit._offline.usecase.GetCustomerStatement;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base.ErrorHelper;
import in.okcredit.app.ui._base_v2.BasePresenter;
import in.okcredit.domain.auth.AuthErrors;
import in.okcredit.domain.customer_statement.CustomerReportDomain;
import in.okcredit.util.ShareHelper;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.observers.DisposableObserver;
import io.reactivex.observers.DisposableSingleObserver;
import timber.log.Timber;

public class CustomerStatementPresenter extends BasePresenter<CustomerStatementContract.View> implements CustomerStatementContract.Presenter {
    private CompositeDisposable tasks;
    private CustomerStatementContract.View view;

    private GetActiveMerchant getActiveMerchant;
    private GetCustomerStatement getCustomerStatement;
    private CustomerReportDomain customerReportDomain;
    private String customerId;
    private int lifecycle;
    private ShareHelper shareHelper;
    private Disposable downloadPdfAndshareTask;

    @Inject
    public CustomerStatementPresenter(@PresenterParam("customer_id") String customerId,
                                      @PresenterParam("lifecycle") int lifecycle,
                                      @UiThread Scheduler uiScheduler,
                                      GetActiveMerchant getActiveMerchant,
                                      GetCustomerStatement getCustomerStatement,
                                      CustomerReportDomain customerReportDomain,
                                      ShareHelper shareHelper) {
        super(uiScheduler);
        this.customerId = customerId;
        tasks = new CompositeDisposable();
        this.lifecycle = lifecycle;
        this.getActiveMerchant = getActiveMerchant;
        this.getCustomerStatement = getCustomerStatement;
        this.customerReportDomain = customerReportDomain;
        this.shareHelper = shareHelper;
    }

    @Override
    protected void loadData() {

    }

    @Override
    public void onInternetRestored() {
        loadData();
    }

    @Override
    public void onAuthenticationRestored() {
        loadData();
    }

    @Override
    public void attachView(CustomerStatementContract.View view) {
        this.view = view;

        tasks.add(
            getActiveMerchant
                .execute()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    merchant -> {
                        if (view != null) {
                            view.setReminderDetails(merchant.getName());
                        }
                    },
                    throwable -> {
                        if (view != null) {
                            view.showReminderError();
                        }
                    }
                )
        );

        Disposable task = getCustomerStatement
            .execute(customerId)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeWith(new DisposableObserver<CustomerStatement>() {
                @Override
                public void onNext(CustomerStatement customerStatement) {
                    if (view == null) {
                        return;
                    }

                    view.hideLoading();
                    view.displayCustomerDetails(customerStatement.getCustomer());
                }

                @Override
                public void onError(Throwable e) {
                    if (view == null) {
                        return;
                    }

                    view.hideLoading();
                }

                @Override
                public void onComplete() {

                }
            });
        tasks.add(task);

    }

    @Override
    public void detachView() {
        view = null;
        tasks.clear();

        if (downloadPdfAndshareTask != null) {
            downloadPdfAndshareTask.dispose();
            downloadPdfAndshareTask = null;
        }
    }

    @Override
    public void sendReminderOnWhatsapp(Customer customer) {

        if (customer != null && view != null) {
            Analytics.track(
                AnalyticsEvents.CUSTOMER_STATEMENT_SEND_REMINDER_FAB_CLICKED,
                EventProperties
                    .create()
                    .with("cst_name", customer.getMobile())
            );

            view.sendReminderOnWhatsapp();
        }
    }

    @Override
    public void getMiniStatementUrl() {
        Disposable task =
            customerReportDomain
                .generateMiniStatementReport(customerId)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableSingleObserver<String>() {
                    @Override
                    public void onSuccess(@NonNull String reportUrl) {
                        if (view == null) {
                            return;
                        }
                        view.downloadMiniStatement(reportUrl);
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        if(NetworkHelper.isNetworkError(e)) {
                            view.showNoInternetMessage();
                        } else if ((e instanceof AuthErrors.Unauthenticated) || (e.getCause() instanceof AuthErrors.Unauthenticated)) {
                            view.gotoLogin();
                            view.showPdfError();
                        } else {
                            Analytics.track(
                                AnalyticsEvents.ERROR,
                                EventProperties
                                    .create()
                                    .with("screen", "customer statement")
                                    .with("type", "mini statement server error")
                            );
                            view.showError();
                        }
                        view.sharePdfFail();
                        Timber.d("Exception activity - " + e.getMessage());
                    }
                });
        tasks.add(task);
    }

    @Override
    public void getMonthlyReportUrl() {
        Disposable task =
            customerReportDomain
                .generateMonthlyReport(customerId)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableSingleObserver<String>() {
                    @Override
                    public void onSuccess(@NonNull String reportUrl) {
                        if (view == null) {
                            return;
                        }
                        view.downloadMonthlyReport(reportUrl);
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        if(NetworkHelper.isNetworkError(e)) {
                            view.showNoInternetMessage();
                        } else if ((e instanceof AuthErrors.Unauthenticated) || (e.getCause() instanceof AuthErrors.Unauthenticated)) {
                            view.gotoLogin();
                            view.showPdfError();
                        } else {
                            Analytics.track(
                                AnalyticsEvents.ERROR,
                                EventProperties
                                    .create()
                                    .with("screen", "customer statement")
                                    .with("type", "monthly report server error")
                            );
                            view.showError();
                        }
                        view.sharePdfFail();
                        Timber.e("Exception activity - " + e.getMessage());
                    }
                });
        tasks.add(task);
    }

    @Override
    public void downloadPdfFile(String url, String mobile, String fileName) {
        downloadPdfAndshareTask = shareHelper
            .getPdfIntent(url, mobile, fileName)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                sendIntent ->
                {
                    if (view != null) {
                        view.sharePdfSuccess(sendIntent);
                    }
                },
                throwable ->
                {
                    if (view != null) {
                        view.sharePdfFail();
                    }
                    Timber.d("Exception activity - " + throwable.getMessage());
                });
    }
}
