package in.okcredit._offline.usecase;

import javax.inject.Inject;

import in.okcredit._offline.database.MerchantRepo;
import in.okcredit._offline.model.Merchant;
import io.reactivex.Observable;

// Offline
public final class GetActiveMerchant {
    private MerchantRepo merchantRepo;

    @Inject
    public GetActiveMerchant(MerchantRepo merchantRepo) {
        this.merchantRepo = merchantRepo;
    }

    public Observable<Merchant> execute() {
        return merchantRepo.getActiveMerchant();
    }
}
