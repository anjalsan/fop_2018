package in.okcredit.app.ui.reminder;

import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;

public interface ReminderContract {
    interface View extends MVP.View, BaseContracts.Online.View, BaseContracts.Loading.View, BaseContracts.Authenticated.View {
        void setCheckbox(boolean isReminderOn);
    }

    interface Presenter extends MVP.Presenter<View>,
        BaseContracts.Loading.Presenter<View>,
        BaseContracts.Online.Presenter<View>,
        BaseContracts.Authenticated.Presenter<View> {
        void toggleReminderStatus(boolean isReminderOn);
    }
}
