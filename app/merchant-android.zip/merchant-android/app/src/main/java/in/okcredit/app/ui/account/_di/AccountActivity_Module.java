package in.okcredit.app.ui.account._di;

import dagger.Binds;
import dagger.Module;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit.app.ui.account.Account;
import in.okcredit.app.ui.account.AccountPresenter;

@Module
public abstract class AccountActivity_Module {
    @Binds
    @ActivityScope
    public abstract Account.Presenter presenter(AccountPresenter presenter);
}
