package in.okcredit._offline.database;

import android.arch.persistence.room.EmptyResultSetException;

import org.joda.time.DateTime;
import org.joda.time.ReadablePeriod;

import java.util.List;
import java.util.NoSuchElementException;

import javax.inject.Inject;

import in.okcredit.ThreadUtils;
import in.okcredit._offline.common.Utils;
import in.okcredit._offline.database.internal.CustomerDao;
import in.okcredit._offline.database.internal.DbEntities;
import in.okcredit._offline.database.internal.DbEntityMapper;
import in.okcredit._offline.model.Customer;
import io.reactivex.Completable;
import io.reactivex.Observable;
import io.reactivex.Single;
import timber.log.Timber;

public final class CustomerRepo {
    private CustomerDao customerDao;

    @Inject
    public CustomerRepo(CustomerDao customerDao) {
        this.customerDao = customerDao;
    }

    public Single<Customer> findCustomerMyDesc(String desc) {
        return customerDao.findCustomerByDesc(desc)
                          .subscribeOn(ThreadUtils.database())
                          .observeOn(ThreadUtils.worker())
                          .map(customer -> DbEntityMapper.CUSTOMER.reverse().convert(customer))
                          .onErrorResumeNext(throwable -> {
                              if (throwable instanceof EmptyResultSetException) {
                                  return Single.<Customer>error(new NoSuchElementException());
                              } else {
                                  return Single.<Customer>error(new RuntimeException(throwable));
                              }
                          });
    }

    public Single<Customer> findCustomerByMobile(String mobile) {
        return customerDao.findCustomerByMobile(mobile)
                          .subscribeOn(ThreadUtils.database())
                          .observeOn(ThreadUtils.worker())
                          .map(customer -> DbEntityMapper.CUSTOMER.reverse().convert(customer))
                          .onErrorResumeNext(throwable -> {
                              if (throwable instanceof EmptyResultSetException) {
                                  return Single.<Customer>error(new NoSuchElementException());
                              } else {
                                  return Single.<Customer>error(new RuntimeException(throwable));
                              }
                          });
    }

    public Observable<List<Customer>> listCustomers() {
        return customerDao.listCustomers()
                          .subscribeOn(ThreadUtils.database())
                          .observeOn(ThreadUtils.worker())
                          .map(customers -> Utils.mapList(customers, DbEntityMapper.CUSTOMER.reverse()))
                          .toObservable();
    }

    public Observable<Customer> getCustomer(String customerId) {
        return customerDao.getCustomer(customerId)
                          .subscribeOn(ThreadUtils.database())
                          .observeOn(ThreadUtils.worker())
                          .map(customer -> DbEntityMapper.CUSTOMER.reverse().convert(customer))
                          .toObservable();
    }

    public Completable putCustomer(Customer customer) {
        return Completable
            .fromAction(() -> customerDao.putCustomer(DbEntityMapper.CUSTOMER.convert(customer)))
            .subscribeOn(ThreadUtils.database())
            .observeOn(ThreadUtils.worker());
    }

    // DANGEROUS: replaces existing customers of same id
    public Completable resetCustomerList(List<Customer> customers) {
        return Completable
            .fromAction(() -> {
                DbEntities.Customer[] list = Utils.mapList(customers, DbEntityMapper.CUSTOMER)
                                                  .toArray(new DbEntities.Customer[]{});
                customerDao.resetCustomerList(list);
            })
            .subscribeOn(ThreadUtils.database())
            .observeOn(ThreadUtils.worker());
    }

    // DANGEROUS: clears entire customer list
    public Completable clear() {
        return Completable
            .fromAction(() -> {
                customerDao.deleteAllSyncData();
                customerDao.deleteAllCustomers();
            })
            .subscribeOn(ThreadUtils.database())
            .observeOn(ThreadUtils.worker());
    }

    public Single<DateTime> getLastSyncTime(String customerId) {
        return customerDao.isCustomerSynced(customerId)
                          .subscribeOn(ThreadUtils.database())
                          .observeOn(ThreadUtils.worker())
                          .map(count -> count == 1)
                          .flatMap(isSynced -> {
                              Timber.i("%s sync status: %s", customerId, isSynced);
                              if (isSynced) {
                                  return customerDao.getLastSyncTime(customerId)
                                                    .subscribeOn(ThreadUtils.database())
                                                    .observeOn(ThreadUtils.worker());
                              } else {
                                  return Single.error(new NullPointerException());
                              }
                          });
    }

    public Single<Boolean> isSyncedWithin(String customerId, ReadablePeriod period) {
        DateTime startTime = DateTime.now().minus(period);
        return getLastSyncTime(customerId)
            .map(lastSyncTime -> (period == null || lastSyncTime.isAfter(startTime)))
            .onErrorResumeNext(throwable -> {
                if (throwable instanceof NullPointerException) {
                    // never synced
                    return Single.just(false);
                } else {
                    return Single.error(throwable);
                }
            });
    }

    public Completable setCustomerSync(String customerId) {
        DbEntities.CustomerSync lastSync = new DbEntities.CustomerSync();
        lastSync.customerId = customerId;
        lastSync.lastSync = DateTime.now();
        return Completable.fromAction(() -> customerDao.insertCustomerSync(lastSync))
                          .subscribeOn(ThreadUtils.database())
                          .observeOn(ThreadUtils.worker());
    }
}
