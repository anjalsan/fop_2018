package in.okcredit.app.ui.addtxn;

public interface AddTxnUseCaseErrors {
    class InvalidAmount extends IllegalArgumentException {
    }
}
