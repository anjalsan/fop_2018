package in.okcredit._offline.usecase;

import javax.inject.Inject;

import in.okcredit._offline.server.Server;
import io.reactivex.Completable;

public final class RefreshCustomers {
    private Server server;
    private SafelySaveCustomerList safelySaveCustomerList;

    @Inject
    public RefreshCustomers(Server server, SafelySaveCustomerList safelySaveCustomerList) {
        this.server = server;
        this.safelySaveCustomerList = safelySaveCustomerList;
    }

    public Completable execute() {
        return server.listCustomers(null)
                     .flatMapCompletable(customers -> safelySaveCustomerList.execute(customers));
    }
}
