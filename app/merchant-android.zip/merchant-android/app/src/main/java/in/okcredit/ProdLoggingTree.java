package in.okcredit;

import android.util.Log;

import com.crashlytics.android.Crashlytics;

import timber.log.Timber;

public class ProdLoggingTree extends Timber.Tree {
    @Override
    protected void log(int priority, String tag, String message, Throwable throwable) {
        if (priority >= Log.WARN)
            Crashlytics.log(priority, tag, message);

        if (throwable != null)
            Crashlytics.logException(throwable);
    }
}
