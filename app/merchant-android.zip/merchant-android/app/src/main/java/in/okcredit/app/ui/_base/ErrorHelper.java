package in.okcredit.app.ui._base;

import java.io.IOException;

import in.okcredit._offline.common.Error;
import in.okcredit._offline.server.NetworkError;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.domain.auth.AuthErrors;
import timber.log.Timber;

public final class ErrorHelper {
    public static void handleDefaults(BaseView view, Throwable throwable, String errorTag) {
        if (view == null) {
            return;
        }

        Timber.e("[%s: %s] %s", errorTag, view.getClass().getSimpleName(), throwable.getClass()
                                                                                    .getSimpleName());

        if (throwable instanceof AuthErrors.Unauthenticated) {
            Analytics.track(
                AnalyticsEvents.ERROR,
                EventProperties
                    .create()
                    .with("screen", view.getClass().getSimpleName())
                    .with("type", "auth error")
            );

            view.onAuthenticationFailure();

        } else if (throwable instanceof Error) {

            Analytics.track(
                AnalyticsEvents.ERROR,
                EventProperties
                    .create()
                    .with("screen", view.getClass().getSimpleName())
                    .with("type", "server error")
                    .with("error", ((Error) throwable).getError())
            );

            view.onError(errorTag);

        } else if (throwable instanceof NetworkError ||
            throwable instanceof IOException ||
            throwable.getCause() instanceof IOException) {

            Analytics.track(
                AnalyticsEvents.ERROR,
                EventProperties
                    .create()
                    .with("screen", view.getClass().getSimpleName())
                    .with("type", "internet")
            );

            view.onNetworkFailure();

        } else {
            Timber.wtf("BOOM BOOM BOOM BOOM (Unexpected Exception)");
            throw new RuntimeException(throwable);
        }
    }

    private ErrorHelper() {
    }
}
