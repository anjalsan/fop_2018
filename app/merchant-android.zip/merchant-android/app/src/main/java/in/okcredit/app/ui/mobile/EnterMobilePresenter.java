package in.okcredit.app.ui.mobile;

import javax.inject.Inject;

import in.okcredit._offline.server.NetworkHelper;
import in.okcredit._offline.usecase.CheckMobileStatus;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.observers.DisposableSingleObserver;

public class EnterMobilePresenter implements EnterMobile.Presenter {
    private CheckMobileStatus checkMobileStatus;
    private CompositeDisposable tasks;

    private EnterMobile.View view;

    @Inject
    public EnterMobilePresenter(CheckMobileStatus checkMobileStatus) {
        this.checkMobileStatus = checkMobileStatus;
        tasks = new CompositeDisposable();
    }

    @Override
    public void attachView(EnterMobile.View view) {
        this.view = view;
    }

    @Override
    public void detachView() {
        tasks.clear();
        view = null;
    }

    @Override
    public void checkMobile(String mobile) {
        if (view == null)
            return;

        String normalizedMobile = mobile == null ? null : mobile.trim();
        if (normalizedMobile == null || normalizedMobile.length() != 10) {
            view.displayInvalidMobileError();
            return;
        }

        view.showLoading();
        Disposable task = checkMobileStatus
            .execute(normalizedMobile)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeWith(new DisposableSingleObserver<Boolean>() {
                @Override
                public void onSuccess(Boolean isRegistered) {
                    if (view == null)
                        return;

                    view.hideLoading();
                    if (isRegistered)
                        view.gotoLoginScreen(normalizedMobile);
                    else
                        view.gotoRegistrationScreen(normalizedMobile);
                }

                @Override
                public void onError(Throwable e) {
                    if (view == null) {
                        return;
                    }

                    view.hideLoading();
                    if (NetworkHelper.isNetworkError(e)) {
                        view.onNetworkFailure();
                    } else {
                        view.onError("checkMobile");
                    }
                }
            });
        tasks.add(task);
    }
}
