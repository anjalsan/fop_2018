package in.okcredit.app.ui.help.main;

import android.content.ContentProviderOperation;
import android.content.Context;
import android.provider.ContactsContract;

import java.util.ArrayList;

import javax.inject.Inject;

import in.okcredit.App;
import in.okcredit.Constants;
import in.okcredit.LocaleManager;
import in.okcredit.R;
import in.okcredit.ThreadUtils;
import in.okcredit._di.UiThread;
import in.okcredit.app.ui._base_v2.BasePresenter;
import in.okcredit.domain.help.HelpService;
import io.reactivex.Completable;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import timber.log.Timber;

public class HelpPresenter extends BasePresenter<HelpContract.View> implements HelpContract.Presenter {
    private HelpService helpService;

    @Inject
    public HelpPresenter(HelpService helpService, @UiThread Scheduler uiScheduler) {
        super(uiScheduler);
        this.helpService = helpService;
    }

    @Override
    protected void loadData() {
        ifAttached(view -> view.showLoading());

        String language = LocaleManager.getLanguage();
        addTask(helpService
            .getHelp(language)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                help ->
                {
//                    ifAttached(view -> view.setYoutube(help.getIntroVideoId()));
                    ifAttached(view -> view.setSections(help.getSections()));
                    ifAttached(view -> view.hideLoading());
                },
                throwable ->
                {
                    ifAttached(view -> view.hideLoading());
                    if (isAuthenticationIssue(throwable))
                        ifAttached(view -> view.gotoLogin());
                    else if (isInternetIssue(throwable))
                        ifAttached(view -> view.showNoInternetMessage());
                    else
                        ifAttached(view -> view.showError());
                }
            ));
    }

    @Override
    public void onWhatsappClicked(boolean addContact) {
        if (addContact) {
            addContact().observeOn(uiScheduler)
                .subscribe(
                    () -> ifAttached(view -> view.openWhatsapp()),
                    throwable ->
                    {
                        Timber.e(throwable, "failed to add contact");
                        ifAttached(view -> view.openWhatsapp());
                    }
                );
        } else {
            ifAttached(view -> view.openWhatsapp());
        }
    }

    @Override
    public void onInternetRestored() {
        loadData();
    }

    @Override
    public void onAuthenticationRestored() {
        loadData();
    }

    public Completable addContact() {
        return Completable
            .fromAction(() ->
            {
                Context appContext = App.getInstance();
                String displayName = appContext.getString(R.string.app_name);
                String mobile;

                String languagePref = LocaleManager.getLanguage();
                if (languagePref != null && languagePref.equals(LocaleManager.LANGUAGE_MALAYALAM)) {
                    mobile = Constants.HELP_MOBILE_MALAYALAM;
                } else {
                    mobile = Constants.HELP_MOBILE;
                }

                ArrayList<ContentProviderOperation> ops = new ArrayList<>();

                ops.add(ContentProviderOperation
                    .newInsert(ContactsContract.RawContacts.CONTENT_URI)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                    .build());

                //------------------------------------------------------ Names
                ops.add(ContentProviderOperation
                    .newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE, ContactsContract
                        .CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.StructuredName
                        .DISPLAY_NAME, displayName)
                    .build());

                //------------------------------------------------------ Mobile Number
                ops.add(ContentProviderOperation.
                    newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE, ContactsContract
                        .CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, mobile)
                    .withValue(ContactsContract.CommonDataKinds.Phone.TYPE,
                        ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                    .build());

                // Asking the Contact provider to create a new contact
                try {
                    appContext.getContentResolver().applyBatch(ContactsContract.AUTHORITY, ops);
                } catch (Exception e) {
                    Timber.e(e, "Failed to add contact");
                }
            })
            .subscribeOn(ThreadUtils.newThread());
    }
}
