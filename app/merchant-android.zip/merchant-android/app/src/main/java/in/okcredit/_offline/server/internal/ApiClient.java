package in.okcredit._offline.server.internal;

import java.util.List;
import java.util.Map;

import in.okcredit._offline.common.Error;
import in.okcredit._offline.model.Version;
import io.reactivex.Single;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiClient {
    // server health
    @GET("/v1.0/")
    Single<Response<ResponseBody>> pingServer();

    // get latest app version info
    @GET("version")
    Single<Response<Version>> getLatestVersion();

    // check if mobile is registered
    @POST("check")
    Single<Response<Void>> checkMobileStatus(@Body ApiMessages.CheckMobileStatusRequest req);

    // register new merchant
    @POST("register")
    Single<Response<Void>> register(@Body ApiMessages.RegisterRequest req);

    // get active merchant
    @GET("me")
    Single<Response<ApiMessages.Merchant>> getActiveMerchant();

    // update active merchant profile
    @POST("me")
    Single<Response<Void>> updateMerchant(@Body ApiMessages.UpdateMerchantRequest req);

    // link device with active merchant
    @POST("devices/{device_id}/link")
    Single<Response<Void>> linkDevice(@Path("device_id") String deviceId);

    // set merchant preference
    @POST("preference")
    Single<Response<Void>> setPreference(@Body ApiMessages.SetMerchantPreferenceRequest req);

    @GET("preference")
    Single<Response<Map<String, String>>> getMerchantPreferences(@Query("key") String key);

    // get referral link
    @GET("referral/link")
    Single<Response<ApiMessages.GetReferralLinkResponse>> getReferralLink();

    // list all customers/serch customer by mobile
    @GET("customer")
    Single<Response<List<ApiMessages.Customer>>> listCustomers(@Query("mobile") String mobile);

    // get customer by id
    @GET("customer/{customer_id}")
    Single<Response<ApiMessages.Customer>> getCustomer(@Path("customer_id") String customerId);

    // add customer
    @POST("customer")
    Single<Response<ApiMessages.Customer>> addCustomer(@Body ApiMessages.AddCustomerRequest request);

    // delete customer
    @DELETE("customer/{customer_id}")
    Single<Response<Void>> deleteCustomer(@Path("customer_id") String customerId);

    // update customer
    @PUT("customer/{customer_id}")
    Single<Response<ApiMessages.Customer>> updateCustomer(@Path("customer_id") String customerId, @Body ApiMessages.UpdateCustomerRequest request);

    // batch add customers
    @POST("customer/batchAdd")
    Single<Response<Map<String, Error>>> bulkAddCustomers(@Body List<ApiMessages.AddCustomerRequest> request);

    // list transactions
    @GET("transaction")
    Single<Response<List<ApiMessages.Transaction>>> listTransactions(
        @Query("customer_id") String customerId, @Query("after") long fromTimestamp, @Query("before") long toTimestamp);

    // get transaction by id
    @GET("transaction/{tx_id}")
    Single<Response<ApiMessages.Transaction>> getTransaction(@Path("tx_id") String txnId);

    // delete transaction by id
    @DELETE("transaction/{tx_id}")
    Single<Response<Void>> deleteTransaction(@Path("tx_id") String txnId);

    // add transaction
    @POST("transaction")
    Call<Void> addTransaction(@Body ApiMessages.AddTransactionRequest req);

    // check status of a transaction after creating it
    @GET("transaction/status")
    Call<ApiMessages.GetTransactionStatusResponse> getTransactionStatus(@Query("customer_id") String customerId, @Query("request_id") String requestId);

    // update active merchant profile
    @POST("feedback")
    Single<Response<Void>> submitFeedback(@Body ApiMessages.FeedbackRequest req);

    //TODO: API For getting referred users.
    // update active merchant profile
    @GET("referred")
    Single<Response<Void>> getReferredUsers(@Query("customer_id") String customerId);

    @GET("notification")
    Single<Response<ApiMessages.GetNotificationResponse>> getNotification(@Header("X-DeviceId") String deviceId);

    @POST("notification/respond")
    Single<Response<Void>> submitAnswer(@Body ApiMessages.AnswerRequest req);

    // send Customer Otp
    @POST("otp/request/customer")
    Single<Response<ApiMessages.SendCustomerOtpResponce>> sendCustomerOtp(@Body ApiMessages.SendCustomerOtpRequest request);

    // verify Customer Otp
    @POST("otp/verify/customer")
    Single<Response<ApiMessages.VerifyCustomerOtpResponce>> verifyCustomerOtp(@Body ApiMessages.VerifyCustomerOtpRequest request);
}
