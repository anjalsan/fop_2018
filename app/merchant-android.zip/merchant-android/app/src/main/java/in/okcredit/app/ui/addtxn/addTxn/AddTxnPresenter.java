package in.okcredit.app.ui.addtxn.addTxn;

import java.io.File;

import javax.inject.Inject;

import in.okcredit._di.UiThread;
import in.okcredit.app.ui._base_v2.BasePresenter;
import in.okcredit.app.ui.addtxn.AddTxnUseCase;
import in.okcredit.app.ui.addtxn.AddTxnUseCaseErrors;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import timber.log.Timber;

public class AddTxnPresenter extends BasePresenter<AddTxnContract.View> implements AddTxnContract
    .Presenter {
    private AddTxnUseCase addTxnUseCase;

    @Inject
    public AddTxnPresenter(@UiThread Scheduler uiScheduler, AddTxnUseCase addTxnUseCase) {
        super(AndroidSchedulers.mainThread());
        this.addTxnUseCase = addTxnUseCase;
    }

    @Override
    protected void loadData() {
        int lifecycle = addTxnUseCase.getLifecycleState();

        addTask(addTxnUseCase
            .txnType()
            .observeOn(uiScheduler)
            .subscribe(
                txnType -> {
                    ifAttached(view -> view.setTxnType(txnType, lifecycle));
                    ifAttached(view -> view.setupTutorialLayout(lifecycle, txnType));
                },
                throwable ->
                {
                    Timber.e(throwable, "failed to get txn type");
                    if (isAuthenticationIssue(throwable)) {
                        ifAttached(view -> view.gotoLogin());
                    } else if (isInternetIssue(throwable)) {
                        ifAttached(view -> view.showNoInternetMessage());
                    } else {
                        ifAttached(view -> view.showError());
                    }
                }
            )
        );

        addTask(addTxnUseCase
            .customer()
            .observeOn(uiScheduler)
            .subscribe(
                customer -> ifAttached(view -> view.setCustomerName(customer
                    .getDescription())),
                throwable ->
                {
                    Timber.e(throwable, "failed to get customer name");
                    if (isAuthenticationIssue(throwable)) {
                        ifAttached(view -> view.gotoLogin());
                    } else if (isInternetIssue(throwable)) {
                        ifAttached(view -> view.showNoInternetMessage());
                    } else {
                        ifAttached(view -> view.showError());
                    }
                }
            )
        );

        addTask(addTxnUseCase
            .receipt()
            .observeOn(uiScheduler)
            .subscribe(
                receipt -> ifAttached(view -> view.displayReceipt(receipt)),
                throwable ->
                {
                    Timber.e(throwable, "unexpected failure on receipt stream");
                    if (isAuthenticationIssue(throwable)) {
                        ifAttached(view -> view.gotoLogin());
                    } else if (isInternetIssue(throwable)) {
                        ifAttached(view -> view.showNoInternetMessage());
                    } else {
                        ifAttached(view -> view.showError());
                    }
                }
            )
        );
        addTask(addTxnUseCase
            .note()
            .observeOn(uiScheduler)
            .subscribe(
                note -> ifAttached(view -> view.displayNote(note)),
                throwable ->
                {
                    Timber.e(throwable, "unexpected failure on note stream");
                    if (isAuthenticationIssue(throwable)) {
                        ifAttached(view -> view.gotoLogin());
                    } else if (isInternetIssue(throwable)) {
                        ifAttached(view -> view.showNoInternetMessage());
                    } else {
                        ifAttached(view -> view.showError());
                    }
                }
            )
        );
    }

    @Override
    public void addTxn(float amount, File receipt, String note) {
        addTask(addTxnUseCase
            .createRequest(amount, receipt, note)
            .observeOn(uiScheduler)
            .subscribe(
                () -> {

                    ifAttached(AddTxnContract.View::gotoConfirmation);
                },
                throwable ->
                {
                    if (throwable instanceof AddTxnUseCaseErrors.InvalidAmount) {
                        ifAttached(view -> view.showInvalidAmountError());
                    } else if (isAuthenticationIssue(throwable)) {
                        ifAttached(view -> view.gotoLogin());
                    } else if (isInternetIssue(throwable)) {
                        ifAttached(view -> view.showNoInternetMessage());
                    } else {
                        ifAttached(view -> view.showError());
                    }
                }
            )
        );
    }

    @Override
    public void onInternetRestored() {
        loadData();
    }

    @Override
    public void onAuthenticationRestored() {
        loadData();
    }
}
