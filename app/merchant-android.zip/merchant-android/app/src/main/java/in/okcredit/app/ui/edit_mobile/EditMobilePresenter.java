package in.okcredit.app.ui.edit_mobile;

import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import in.okcredit.ThreadUtils;
import in.okcredit._di.PresenterParam;
import in.okcredit._di.UiThread;
import in.okcredit._offline.error.CustomerErrors;
import in.okcredit._offline.model.Customer;
import in.okcredit._offline.model.OtpRequestKey;
import in.okcredit._offline.usecase.CustomerAuth;
import in.okcredit._offline.usecase.GetCustomer;
import in.okcredit._offline.usecase.UpdateCustomer;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BasePresenter;
import in.okcredit.domain.otp.OtpErrors;
import io.reactivex.Observable;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

public class EditMobilePresenter extends BasePresenter<EditMobileContract.View> implements
    EditMobileContract.Presenter {

    private final UpdateCustomer updateCustomer;
    private GetCustomer getCustomer;
    private CustomerAuth customerAuth;
    private Disposable timerTask;
    private String customerId;
    private OtpRequestKey otpRequestKey;
    private Customer customer;

    @Inject
    public EditMobilePresenter(@UiThread Scheduler uiScheduler,
                               GetCustomer getCustomer,
                               @PresenterParam("customer_id") String customerId,
                               CustomerAuth customerAuth,
                               UpdateCustomer updateCustomer) {
        super(uiScheduler);
        this.getCustomer = getCustomer;
        this.customerId = customerId;
        this.customerAuth = customerAuth;
        this.updateCustomer = updateCustomer;
    }

    @Override
    protected void loadData() {
        addTask(
            getCustomer
                .execute(customerId)
                .observeOn(uiScheduler)
                .subscribe(
                    customer ->
                    {
                        this.customer = customer;
                        ifAttached(view -> view.setCustomerName(customer.getDescription()));
                    },
                    throwable ->
                    {
                        if (isInternetIssue(throwable))
                            ifAttached(view -> view.showNoInternetMessage());
                        else if (isAuthenticationIssue(throwable))
                            ifAttached(view -> view.gotoLogin());
                        else
                            ifAttached(view -> view.showError());
                    }
                )
        );

        addTask(
            customerAuth
                .isCustomerMobileState(customerId)
                .observeOn(uiScheduler)
                .subscribe(
                    otpRequestKey ->
                    {
                        this.otpRequestKey = otpRequestKey;
                        if (otpRequestKey != null && otpRequestKey.getCustomerId() != null) {
                            ifAttached(view -> view.setCustomerNewNumber(otpRequestKey.getMobile()));
                        }
                    },
                    throwable -> {
                        ifAttached(view -> view.showError());
                    }
                )
        );
    }

    @Override
    public void onInternetRestored() {
        loadData();
    }

    @Override
    public void onAuthenticationRestored() {
        loadData();
    }

    @Override
    public void cancelMobileEditRequest() {
        addTask(
            customerAuth
                .deleteKey(customerId)
                .observeOn(uiScheduler)
                .subscribe(
                    () -> {
                        ifAttached(view -> view.canceledRequest());
                    },
                    throwable -> {
                        ifAttached(view -> view.showError());
                    }
                )
        );
    }

    @Override
    public void requestOtp() {
        if (timerTask != null && !timerTask.isDisposed()) {
            return;
        }

        if (otpRequestKey == null) {
            return;
        }

        ifAttached(view -> view.disableReset());
        ifAttached(view -> view.setResetTimer(30));
        addTask(customerAuth
            .requestOtp(customerId, otpRequestKey.getMobile(), otpRequestKey.getCurrentMobile())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                () -> {
                    ifAttached(view -> view.showSendOpt());
                    timerTask = Observable
                        .interval(1, TimeUnit.SECONDS, ThreadUtils.newThread())
                        .observeOn(uiScheduler)
                        .subscribe(
                            secondsElapsed -> {
                                ifAttached(view -> view.setResetTimer(30 - secondsElapsed));
                                if (secondsElapsed == 30) {
                                    ifAttached(view -> view.enableReset());
                                    timerTask.dispose();
                                }
                            },
                            throwable -> {

                            });

                    addTask(timerTask);
                },
                e -> {
                    ifAttached(view -> view.enableReset());
                    Timber.w(e, "sending otp failed");
                    if (e instanceof CustomerErrors.MobileConflict) {
                        // mobile conflict
                        ifAttached(view -> view.onMobileConflict(
                            ((CustomerErrors.MobileConflict) e).getConflict())
                        );
                    } else if (isAuthenticationIssue(e)) {
                        ifAttached(view -> view.gotoLogin());
                    } else if (isInternetIssue(e)) {
                        ifAttached(view -> view.showNoInternetMessage());
                    } else {
                        ifAttached(view -> view.showError());
                    }
                }
            )
        );
    }

    @Override
    public void verifyOtp(String otp) {
        ifAttached(view -> view.hideErrorText());
        addTask(customerAuth
            .verifyOtp(customerId, otpRequestKey.getRequestId(), otp, otpRequestKey.getMobile(), customer
                .getDescription(), customer.getAddress())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(token -> updateMobile(token),
                e -> {
                    Timber.w(e, "verifying otp failed");
                    if (isAuthenticationIssue(e)) {
                        ifAttached(view -> view.gotoLogin());
                    } else if (isInternetIssue(e)) {
                        ifAttached(view -> view.showNoInternetMessage());
                    } else if (e instanceof OtpErrors.Invalid) {
                        ifAttached(view -> view.showInvalidOtpError());
                    } else if (e instanceof OtpErrors.Expired) {
                        ifAttached(view -> view.showExpiredOtpError());
                    } else {
                        ifAttached(view -> view.showError());
                    }
                }
            )
        );
    }

    private void updateMobile(String token) {
        if (token == null) {
            return;
        }

        addTask(updateCustomer
            .execute(customerId, customer.getDescription(), customer.getAddress(), customer.getProfileImage(), otpRequestKey
                .getMobile(), token)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                () -> {
                    ifAttached(view -> view.showChangeMobileSuccess());
                    Analytics.track(
                        AnalyticsEvents.EDIT_CUSTOMER_MOBILE_UPDATED,
                        EventProperties
                            .create()
                            .with("error", "false")
                    );
                    cancelMobileEditRequest();
                },
                e -> {
                    if (e instanceof CustomerErrors.MobileConflict) {
                        ifAttached(view -> view.onMobileConflict(((CustomerErrors
                            .MobileConflict) e).getConflict()));
                        Analytics.track(
                            AnalyticsEvents.EDIT_CUSTOMER_MOBILE_UPDATED,
                            EventProperties
                                .create()
                                .with("error", "mobile conflict")
                        );
                    } else if (e instanceof CustomerErrors.DeletedCustomer) {
                        ifAttached(view -> view.onMobileConflict(((CustomerErrors
                            .DeletedCustomer) e).getConflict()));
                    } else if (isAuthenticationIssue(e)) {
                        ifAttached(view -> view.gotoLogin());
                        Analytics.track(
                            AnalyticsEvents.EDIT_CUSTOMER_MOBILE_UPDATED,
                            EventProperties
                                .create()
                                .with("error", "authentication failure")
                        );
                    } else if (isInternetIssue(e)) {
                        Analytics.track(
                            AnalyticsEvents.EDIT_CUSTOMER_MOBILE_UPDATED,
                            EventProperties
                                .create()
                                .with("error", "internet issue")
                        );
                        ifAttached(view -> view.showNoInternetMessage());
                    } else {
                        Analytics.track(
                            AnalyticsEvents.EDIT_CUSTOMER_MOBILE_UPDATED,
                            EventProperties
                                .create()
                                .with("error", "true")
                        );
                        ifAttached(view -> view.showError());
                    }
                }
            )
        );
    }
}
