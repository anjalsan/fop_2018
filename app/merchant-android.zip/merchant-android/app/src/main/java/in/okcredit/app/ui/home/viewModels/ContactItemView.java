package in.okcredit.app.ui.home.viewModels;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.airbnb.epoxy.CallbackProp;
import com.airbnb.epoxy.ModelProp;
import com.airbnb.epoxy.ModelView;
import com.amulyakhare.textdrawable.TextDrawable;
import com.amulyakhare.textdrawable.util.ColorGenerator;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.R;
import in.okcredit.service.phonebook.ContactModel;
import in.okcredit.util.GlideApp;

@ModelView(autoLayout = ModelView.Size.MATCH_WIDTH_WRAP_HEIGHT)
public class ContactItemView extends LinearLayout {
    public interface ContactSelectionListener {
        void onAddContact(ContactModel contact);
    }

    private ContactModel contact;

    @BindView(R.id.pic)
    ImageView _pic;

    @BindView(R.id.name)
    TextView _name;

    @BindView(R.id.mobile)
    TextView _mobile;

    @BindView(R.id.add_customer)
    TextView _add;

    public ContactItemView(Context context) {
        super(context);
        initView();
    }

    public ContactItemView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public ContactItemView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public ContactItemView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        initView();
    }

    @ModelProp
    public void setContact(ContactModel contact) {
        this.contact = contact;
        _name.setText(contact.name);
        _mobile.setText(contact.mobile);

        Drawable defaultPic = TextDrawable
            .builder()
            .buildRound(
                contact.name.substring(0, 1).toUpperCase(),
                ColorGenerator.MATERIAL.getColor(contact.name)
            );

        try {
            Uri picUri = Uri.parse(contact.picUri);
            GlideApp.with(getContext())
                .load(picUri)
                .circleCrop()
                .placeholder(defaultPic)
                .fallback(defaultPic)
                .into(_pic);
        } catch (Exception e) {
            _pic.setImageDrawable(defaultPic);
        }
    }

    @CallbackProp
    public void setListener(@Nullable ContactSelectionListener listener) {
        if (listener != null) {
            _add.setOnClickListener((OnClickListener) v -> listener.onAddContact(contact));
        }
    }

    private void initView() {
        setOrientation(LinearLayout.VERTICAL);
        inflate(getContext(), R.layout.importcontacts_item, this);
        ButterKnife.bind(this);
    }
}
