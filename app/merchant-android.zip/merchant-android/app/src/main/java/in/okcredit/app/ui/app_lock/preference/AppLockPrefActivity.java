package in.okcredit.app.ui.app_lock.preference;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.R;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui.app_lock.set.AppLockActivity;

public class AppLockPrefActivity extends BaseActivity implements AppLockPrefContract.View {

    public static Intent startingIntent(Context context) {
        return new Intent(context, AppLockPrefActivity.class);
    }

    @BindView(R.id.loading)
    LinearLayout loading;

    @BindView(R.id.appLockText)
    TextView appLockText;

    @BindView(R.id.appLockExplainationView)
    LinearLayout appLockExplainationView;

    @BindView(R.id.appLockLayoutContainer)
    LinearLayout appLockLayoutContainer;

    @BindView(R.id.appLockTextSubtitle)
    TextView appLockTextSubtitle;

    @Inject
    AppLockPrefContract.Presenter presenter;

    /* Lifecycle methods */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.screen_app_lock_pref);
        ButterKnife.bind(this);

        showActionBar(true);
        setTitle(R.string.security_app_lock);

        appLockLayoutContainer.setVisibility(View.GONE);
        appLockExplainationView.setVisibility(View.GONE);
        loading.setVisibility(View.VISIBLE);

        appLockLayoutContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(AppLockActivity.startingIntent(AppLockPrefActivity.this));
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.attachView(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        presenter.detachView();
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    public void setAppLockStatus(boolean isAppLockActive) {

        Analytics.track(
            AnalyticsEvents.APP_LOCK_PREF_SCREEN,
            EventProperties
                .create()
                .with("isAppLockActive", isAppLockActive)
        );

        if (isAppLockActive) {
            appLockText.setText(getString(R.string.app_lock_enabled));
            appLockTextSubtitle.setText(R.string.app_lock_disable);
            appLockTextSubtitle.setTextColor(ContextCompat.getColor(this, R.color.tx_credit));
        } else {
            appLockText.setText(getString(R.string.app_lock_disabled));
            appLockTextSubtitle.setText(R.string.app_lock_enable);
            appLockTextSubtitle.setTextColor(ContextCompat.getColor(this, R.color.primary));
        }

        appLockLayoutContainer.setVisibility(View.VISIBLE);
        appLockExplainationView.setVisibility(View.VISIBLE);
        loading.setVisibility(View.GONE);
    }

    @Override
    public void showError() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "app lock screen")
                .with("type", "server error")
        );

        Toast.makeText(this, R.string.err_default, Toast.LENGTH_LONG).show();
        finish();
    }

    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(this, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
            }
        });
    }
}
