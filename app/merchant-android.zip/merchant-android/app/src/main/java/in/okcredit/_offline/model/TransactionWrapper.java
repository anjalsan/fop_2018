package in.okcredit._offline.model;

public final class TransactionWrapper {
    private final Transaction transaction;
    private final String customerName;
    private boolean isActive;

    public TransactionWrapper(Transaction transaction, String customerName, boolean isActive) {
        this.transaction = transaction;
        this.customerName = customerName;
        this.isActive = isActive;
    }

    public Transaction getTransaction() {
        return transaction;
    }

    public String getCustomerName() {
        return customerName;
    }

    public boolean isActive() {
        return isActive;
    }
}
