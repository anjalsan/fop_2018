package in.okcredit._offline.usecase;

import android.support.annotation.NonNull;

import org.joda.time.DateTime;
import org.joda.time.Duration;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import in.okcredit.App;
import in.okcredit._offline._hack.SyncNotificationHelper;
import in.okcredit._offline.common.RxJavaUtils;
import in.okcredit._offline.database.MerchantRepo;
import in.okcredit._offline.model.Customer;
import in.okcredit._offline.server.Server;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.domain.auth.AuthDomain;
import io.reactivex.Completable;

// Syncs all customers: profile as well as transactions
public final class SyncEverything {
    public static final int LOAD_FACTOR = 2;

    private Server server;
    private SyncCustomer syncCustomer;
    private MerchantRepo merchantRepo;
    private AuthDomain authDomain;
    private SyncMerchantPreferences syncMerchantPreferences;

    @Inject
    public SyncEverything(Server server, SyncCustomer syncCustomer, MerchantRepo merchantRepo, AuthDomain authDomain, SyncMerchantPreferences syncMerchantPreferences) {
        this.server = server;
        this.syncCustomer = syncCustomer;
        this.merchantRepo = merchantRepo;
        this.authDomain = authDomain;
        this.syncMerchantPreferences = syncMerchantPreferences;
    }

    public void schedule() {
        Constraints constraints = new Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build();

        PeriodicWorkRequest workRequest = new PeriodicWorkRequest.Builder(
            Worker.class,
            24,
            TimeUnit.HOURS,
            5,
            TimeUnit.HOURS)
            .addTag("sync_everything")
            .setConstraints(constraints)
            .build();

        WorkManager.getInstance()
                   .enqueueUniquePeriodicWork("sync_everything", ExistingPeriodicWorkPolicy.REPLACE, workRequest);
    }

    public Completable execute() {
        return authDomain.isAccessTokenAvailable()
                         .firstOrError()
                         .flatMapCompletable(isAuthenticated -> {
                             if (isAuthenticated) {
                                 return syncActiveMerchant().andThen(syncCustomers());
                             } else {
                                 return Completable.complete();
                             }
                         });
    }

    private Completable syncActiveMerchant() {
        return server.getActiveMerchant()
                     .flatMapCompletable(merchant -> merchantRepo.setActiveMerchant(merchant))
                     .andThen(syncMerchantPreferences.execute());
    }

    private Completable syncCustomers() {
        return server
            .listCustomers(null)
            .flatMapCompletable(customers -> {

                List<Completable> jobs = new ArrayList<>();
                for (Customer customer : customers) {
                    jobs.add(syncCustomer.execute(customer.getId(), customer));
                }

                return RxJavaUtils.runConcurrently(jobs, 4);
            });
    }

    public static final class Worker extends androidx.work.Worker {
        @Inject SyncEverything syncEverything;
        @Inject SyncNotificationHelper syncNotificationHelper;

        @NonNull
        @Override
        public Result doWork() {
            App.appComponent().inject(this);

            DateTime startTime = DateTime.now();
            try {
                Analytics.track(
                    AnalyticsEvents.SYNC_START,
                    EventProperties.create()
                                   .with("type", "SyncEverything")
                                   .with("attempt", String.valueOf(getRunAttemptCount()))
                );

                syncNotificationHelper.showNotification();
                syncEverything.execute().blockingAwait();
                syncNotificationHelper.hideNotification();

                Analytics.track(
                    AnalyticsEvents.SYNC_COMPLETE,
                    EventProperties.create()
                                   .with("type", "SyncEverything")
                                   .with("time_taken", new Duration(startTime, DateTime.now()).getStandardSeconds())
                                   .with("attempt", String.valueOf(getRunAttemptCount()))
                );

                return Result.SUCCESS;

            } catch (Exception e) {
                syncNotificationHelper.hideNotification();

                Analytics.track(
                    AnalyticsEvents.SYNC_ERROR,
                    EventProperties.create()
                                   .with("type", "SyncEverything")
                                   .with("reason", e.getMessage())
                                   .with("time_taken", new Duration(startTime, DateTime.now()).getStandardSeconds())
                                   .with("attempt", String.valueOf(getRunAttemptCount()))
                );

                return Result.RETRY;
            }
        }
    }
}
