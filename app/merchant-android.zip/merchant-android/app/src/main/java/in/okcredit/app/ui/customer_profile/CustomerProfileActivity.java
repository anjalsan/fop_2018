package in.okcredit.app.ui.customer_profile;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.transition.TransitionManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.CardView;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.bumptech.glide.request.RequestOptions;

import java.io.File;
import java.text.MessageFormat;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import in.okcredit.R;
import in.okcredit._offline.model.Customer;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui._base_v2.PermissionGrantListener;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui.addtxn.addTxn.CameraHelper;
import in.okcredit.app.ui.addtxn.addTxn.GalleryHelper;
import in.okcredit.app.ui.delete_customer.DeleteCustomerActivity;
import in.okcredit.app.ui.edit_mobile.EditMobileActivity;
import in.okcredit.util.AnimationUtils;
import in.okcredit.util.GlideApp;
import in.okcredit.util.keyboardUtils.KeyboardVisibilityEvent;
import in.okcredit.util.keyboardUtils.KeyboardVisibilityEventListener;
import io.reactivex.Completable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;

public class CustomerProfileActivity extends BaseActivity implements CustomerProfileContract.View,
    PermissionGrantListener, BottomSheetMediaFragment.OnBottomSheetFragmentListner {
    public static final String EXTRA_CUSTOMER_ID = "customer_id", IS_EDIT_MOBILE = "is_edit_mobile";
    private static final int REQUEST_CODE_CAMERA = 11, REQUEST_CODE_GALLERY = 12;
    private File profileImg = null;

    public static Intent startingIntent(Context context, @NonNull String customerId, Boolean isEditMobile) {
        Intent intent = new Intent(context, CustomerProfileActivity.class);
        intent.putExtra(EXTRA_CUSTOMER_ID, customerId);
        intent.putExtra(IS_EDIT_MOBILE, isEditMobile);
        return intent;
    }

    @BindView(R.id.rootView)
    CoordinatorLayout rootView;

    @BindView(R.id.name)
    TextView name;

    @BindView(R.id.mobile)
    TextView mobile;

    @BindView(R.id.address)
    TextView address;

    @BindView(R.id.profile_image)
    ImageView profileImage;

    @BindView(R.id.camera)
    ImageView camera;

    @BindView(R.id.edit_name_icon)
    ImageView editNameIcon;

    @BindView(R.id.edit_phone_icon)
    ImageView editPhoneIcon;

    @BindView(R.id.edit_address_icon)
    ImageView editAddressIcon;

    @BindView(R.id.call_icon)
    ImageView callIcon;

    @BindView(R.id.home_icon)
    ImageView addressIcon;

    @BindView(R.id.deleteContainer)
    LinearLayout deleteContainer;

    @BindView(R.id.delete_text)
    TextView deleteText;

    @BindView(R.id.name_container)
    RelativeLayout nameContainer;

    @BindView(R.id.phone_container)
    RelativeLayout phoneContainer;

    @BindView(R.id.address_container)
    RelativeLayout addressContainer;

    @BindView(R.id.input_name)
    EditText inputName;

    @BindView(R.id.name_button)
    FloatingActionButton nameDone;

    @BindView(R.id.edit_name_loader)
    CardView editNameLoader;

    @BindView(R.id.error_name)
    TextView errorName;

    @BindView(R.id.counter_name)
    TextView counterName;

    @BindView(R.id.button_container_name)
    FrameLayout buttonContainerName;

    @BindView(R.id.input_address)
    EditText inputAddress;

    @BindView(R.id.address_button)
    FloatingActionButton addressDone;

    @BindView(R.id.edit_address_loader)
    CardView editAddressLoader;

    @BindView(R.id.error_address)
    TextView errorAddress;

    @BindView(R.id.counter_address)
    TextView counterAddress;

    @BindView(R.id.button_container_address)
    FrameLayout buttonContainerAddress;

    @BindView(R.id.input_phone)
    EditText inputPhone;

    @BindView(R.id.phone_button)
    FloatingActionButton phoneDone;

    @BindView(R.id.error_phone)
    TextView errorPhone;

    @BindView(R.id.counter_phone)
    TextView counterPhone;

    @BindView(R.id.loader)
    CardView editPhoneloader;

    @BindView(R.id.mobile_confirm_container)
    LinearLayout mobileConfirmContainer;

    @BindView(R.id.mobile_confirm)
    TextView mobileConfirm;

    @BindView(R.id.mobile_current_confirm)
    TextView mobileCurrentConfirm;

    @BindView(R.id.media_bottom_sheet)
    LinearLayout mediaBottomSheet;

    @BindView(R.id.call_container)
    RelativeLayout callContainer;

    @BindView(R.id.home_container)
    RelativeLayout homeContainer;

    @BindView(R.id.dimLayout)
    FrameLayout dimLayout;

    @Inject
    CustomerProfileContract.Presenter presenter;

    @Inject
    CameraHelper cameraHelper;

    @Inject
    GalleryHelper galleryHelper;

    private Context context;
    private BottomSheetMediaFragment bottomSheet;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.custpr_activity);
        ButterKnife.bind(this);
        showActionBar(true);
        setTitle(R.string.account_profile);
        context = this;

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        bottomSheet = BottomSheetMediaFragment.newInstance();

        inputPhone.setHint(getString(R.string.mobile));
        phoneDone.setImageResource(R.drawable.ic_check);
        phoneDone.setVisibility(View.VISIBLE);

        setepKeyBoard();
        textChangedListener();
        textActionListner();
        Analytics.track(AnalyticsEvents.CUSTOMER_PROFILE_SCREEN);
    }

    private void textActionListner() {
        inputPhone.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                presenter.showOtpDialogue(inputPhone.getText().toString());
                return true;
            }
            return false;
        });

        inputName.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event){
                if(actionId == EditorInfo.IME_ACTION_DONE){
                    onSubmitNameClicked();
                    return true;
                }
                return false;
            }
        });

        inputAddress.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event){
                if(actionId == EditorInfo.IME_ACTION_DONE){
                    onSubmitAddressClicked();
                    return true;
                }
                return false;
            }
        });
    }

    private void setepKeyBoard() {
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        KeyboardVisibilityEvent.setEventListener(
            ((Activity)context),
            new KeyboardVisibilityEventListener() {
                @Override
                public void onVisibilityChanged(boolean isOpen) {
                    if (!isOpen){
                        inputName.clearFocus();
                        inputPhone.clearFocus();
                        inputAddress.clearFocus();
                        phoneContainer.setVisibility(View.GONE);
                        nameContainer.setVisibility(View.GONE);
                        addressContainer.setVisibility(View.GONE);

                        AnimationUtils.fadeOut(dimLayout);
                        Disposable subscribe = Completable
                            .timer(500, TimeUnit.MILLISECONDS, AndroidSchedulers.mainThread())
                            .subscribe(() -> dimLayout.setVisibility(View.GONE));
                    } else {
                        if (nameContainer.getVisibility() == View.VISIBLE ||
                            phoneContainer.getVisibility() == View.VISIBLE ||
                            addressContainer.getVisibility() == View.VISIBLE) {
                            dimLayout.setVisibility(View.VISIBLE);
                            AnimationUtils.fadeIn(dimLayout);
                        }
                    }
                }
            });
    }

    private void textChangedListener() {
        inputName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                String text = editable.toString();

                if (text.length() == 0 || text.length() == 1 || text.length() == 29 ||text.length() == 30 || text.length() == 31) {
                    TransitionManager.beginDelayedTransition(nameContainer);
                }

                if (text.length() > 0) {
                    nameDone.setVisibility(View.VISIBLE);
                    buttonContainerName.setVisibility(View.VISIBLE);
                } else {
                    nameDone.setVisibility(View.GONE);
                    buttonContainerName.setVisibility(View.GONE);
                }
                if (text.length() == 30) {
                    errorName.setVisibility(View.VISIBLE);
                    errorName.setText(getString(R.string.name_should_not));

                    counterName.setVisibility(View.VISIBLE);
                    counterName.setText(String.format("%d/30", text.length()));
                } else {
                    errorName.setVisibility(View.GONE);
                    counterName.setVisibility(View.GONE);
                }
            }
        });

        inputAddress.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                String text = editable.toString();

                if (text.length() == 0 || text.length() == 1 || text.length() == 49 || text.length() == 50 || text.length() == 51) {
                    TransitionManager.beginDelayedTransition(addressContainer);
                }

                if (text.length() > 0) {
                    addressDone.setVisibility(View.VISIBLE);
                    buttonContainerAddress.setVisibility(View.VISIBLE);
                } else {
                    addressDone.setVisibility(View.GONE);
                    buttonContainerAddress.setVisibility(View.GONE);
                }
                if (text.length() == 50) {
                    errorAddress.setVisibility(View.VISIBLE);
                    errorAddress.setText(getString(R.string.address_should_not));

                    counterAddress.setVisibility(View.VISIBLE);
                    counterAddress.setText(String.format("%d/50", text.length()));
                } else {
                    errorAddress.setVisibility(View.GONE);
                    counterAddress.setVisibility(View.GONE);
                }
            }
        });

        inputPhone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                String text = editable.toString();

                if (text.length() == 0 || text.length() == 1 || text.length() == 10 || text.length() == 11) {
                    TransitionManager.beginDelayedTransition(phoneContainer);
                }

                if (text.length() > 0) {
                    phoneDone.setImageResource(R.drawable.ic_check);
                } else {
                    phoneDone.setImageResource(R.drawable.ic_arrow_right);
                }

                if (text.length() > 10) {
                    errorPhone.setText(getString(R.string.invalid_phone));
                    errorPhone.setVisibility(View.VISIBLE);

                    counterPhone.setText(String.format("%d/10", text.length()));
                    counterPhone.setVisibility(View.VISIBLE);
                } else {
                    errorPhone.setVisibility(View.GONE);
                    counterPhone.setVisibility(View.GONE);
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.attachView(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        presenter.detachView();
    }

    @Override
    public void onBackPressed() {
        if(KeyboardVisibilityEvent.isKeyboardVisible((Activity) context)){
            KeyboardVisibilityEvent.hideKeyboard(((Activity) context));
        } else if (nameContainer.getVisibility() == View.VISIBLE ||
            phoneContainer.getVisibility() == View.VISIBLE ||
            addressContainer.getVisibility() == View.VISIBLE) {
            nameContainer.setVisibility(View.GONE);
            phoneContainer.setVisibility(View.GONE);
            addressContainer.setVisibility(View.GONE);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode  == REQUEST_CODE_CAMERA && resultCode == Activity.RESULT_OK) {
            profileImg = cameraHelper.getImage();
            presenter.setProfileImage(profileImg);
        } else if (requestCode == REQUEST_CODE_GALLERY && resultCode == Activity.RESULT_OK && data != null) {
            profileImg = galleryHelper.getImage(data, context);
            if (profileImg != null) {
                presenter.setProfileImage(profileImg);
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void displayProfileImageFile(File image) {
        if (image == null || !image.exists() || image.length() == 0) {
            return;
        }
        GlideApp
            .with(context)
            .load(Uri.fromFile(image))
            .apply(RequestOptions.bitmapTransform(new CircleCrop()))
            .into(profileImage);
    }

    @Override
    public void setProfileImageLocal(File localFile) {
        if (localFile == null || !localFile.exists() || localFile.length() == 0) {
            return;
        }
        GlideApp
            .with(context)
            .load(localFile)
            .placeholder(ContextCompat.getDrawable(context, R.drawable.ic_account_125dp))
            .apply(RequestOptions.bitmapTransform(new CircleCrop()))
            .into(profileImage);
    }

    @Override
    public void setProfileImageRemote(String url) {
        GlideApp
            .with(context)
            .load(url)
            .placeholder(ContextCompat.getDrawable(context, R.drawable.ic_account_125dp))
            .apply(RequestOptions.bitmapTransform(new CircleCrop()))
            .into(profileImage);
    }

    /****************************************************************
     * Listeners
     ****************************************************************/

    @OnClick(R.id.deleteContainer)
    public void onDeleteClicked() {
        presenter.onDeleteClicked();

        Analytics.track(AnalyticsEvents.CUSTOMER_PROFILE_SCREEN_DELETE_CLICKED);
    }

    @OnClick(R.id.camera)
    public void onCameraClicked() {
        bottomSheet.show(getSupportFragmentManager(), bottomSheet.getTag());
    }

    @OnClick(R.id.edit_name_icon)
    public void onNameEditClicked() {
        nameContainer.setVisibility(View.VISIBLE);
        phoneContainer.setVisibility(View.GONE);
        addressContainer.setVisibility(View.GONE);
        KeyboardVisibilityEvent.showKeyboard(context, inputName, rootView);
        Analytics.track(AnalyticsEvents.EDIT_CUSTOMER_NAME_CLICKED);
    }

    @OnClick(R.id.edit_phone_icon)
    public void onPhoneEditClicked() {
        presenter.onEditMobileClicked();
        Analytics.track(AnalyticsEvents.EDIT_CUSTOMER_MOBILE_CLICKED);
    }

    @OnClick(R.id.edit_address_icon)
    public void onAddressEditClicked() {
        nameContainer.setVisibility(View.GONE);
        phoneContainer.setVisibility(View.GONE);
        addressContainer.setVisibility(View.VISIBLE);
        KeyboardVisibilityEvent.showKeyboard(context, inputAddress, rootView);
        Analytics.track(AnalyticsEvents.EDIT_CUSTOMER_ADDRESS_CLICKED);
    }

    @OnClick(R.id.name_button)
    public void onSubmitNameClicked() {
        presenter.saveName(inputName.getText().toString());
    }

    @OnClick(R.id.address_button)
    public void onSubmitAddressClicked() {
        presenter.saveAddress(inputAddress.getText().toString());
    }

    @OnClick(R.id.phone_button)
    public void onSubmitPhoneClicked() {
        presenter.saveMobile(inputPhone.getText().toString());
    }

    @Override
    public void onPermissionGranted(String permission) {
        if (permission.equals(Manifest.permission.CAMERA)) {
            Analytics.track(AnalyticsEvents.CUSTOMER_PROFILE_SCREEN_CAM_PERMISSION_GRANTED);
            openCamera();
        } else if (permission.equals(Manifest.permission.READ_EXTERNAL_STORAGE)) {
            Analytics.track(AnalyticsEvents.CUSTOMER_PROFILE_SCREEN_GALLERY_PERMISSION_GRANTED);
            openGallery();
        }
    }

    @Override
    public void onPermissionDenied(String permission) {
        if (permission.equals(Manifest.permission.CAMERA)) {
            Analytics.track(AnalyticsEvents.CUSTOMER_PROFILE_SCREEN_CAM_PERMISSION_DENIED);
            Toast.makeText(context, R.string.customer_profile_camera_permission_msg, Toast.LENGTH_SHORT)
                .show();
        } else if (permission.equals(Manifest.permission.READ_EXTERNAL_STORAGE)){
            Analytics.track(AnalyticsEvents.CUSTOMER_PROFILE_SCREEN_GALLERY_PERMISSION_DENIED);
            Toast.makeText(context, R.string.customer_profile_gallery_permission_msg, Toast.LENGTH_SHORT)
                .show();
        }
    }

    /****************************************************************
     * MVP methods
     ****************************************************************/
    @Override
    public void showError() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "cst profile")
                .with("type", "server error")
        );

        Toast.makeText(this, R.string.err_default, Toast.LENGTH_SHORT).show();
        finish();
    }

    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(this, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
            }
        });
    }

    @Override
    public void setName(String customerName) {
        if (customerName != null) {
            name.setText(customerName);
            inputName.setText(customerName);
            inputName.setSelection(customerName.length());
        }
    }

    @Override
    public void setMobile(String mob) {
        if (mob != null) {
            mobile.setText(mob);
            inputPhone.setText(mob);
            inputPhone.setSelection(mob.length());
            mobile.setTextColor(ContextCompat.getColor(context, R.color.text_default));
            callIcon.setColorFilter(ContextCompat.getColor(context, R.color.grey400), PorterDuff.Mode.SRC_IN);
            editPhoneIcon.setVisibility(View.VISIBLE);
        } else {
            mobile.setText(getString(R.string.custpr_add_mobile));
            mobile.setTextColor(ContextCompat.getColor(context, R.color.primary));
            callIcon.setColorFilter(ContextCompat.getColor(context, R.color.primary), PorterDuff.Mode.SRC_IN);
            editPhoneIcon.setVisibility(View.GONE);

            callContainer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onPhoneEditClicked();
                }
            });
        }
    }

    @Override
    public void setAddress(String addr) {
        if (addr != null) {
            address.setText(addr);
            inputAddress.setText(addr);
            inputAddress.setSelection(addr.length());
            address.setTextColor(ContextCompat.getColor(context, R.color.text_default));
            addressIcon.setColorFilter(ContextCompat.getColor(context, R.color.grey400), PorterDuff.Mode.SRC_IN);
            editAddressIcon.setVisibility(View.VISIBLE);
        } else {
            address.setText(getString(R.string.custpr_add_address));
            address.setTextColor(ContextCompat.getColor(context, R.color.primary));
            addressIcon.setColorFilter(ContextCompat.getColor(context, R.color.primary), PorterDuff.Mode.SRC_IN);
            editAddressIcon.setVisibility(View.GONE);

            homeContainer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onAddressEditClicked();
                }
            });
        }
    }

    @Override
    public void showNameLoading() {
        nameDone.setVisibility(View.GONE);
        editNameLoader.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideNameLoading() {
        nameDone.setVisibility(View.VISIBLE);
        editNameLoader.setVisibility(View.GONE);
        KeyboardVisibilityEvent.hideKeyboard(context, inputName);
        nameContainer.setVisibility(View.GONE);
    }

    @Override
    public void displayInvalidNameError() {
        errorName.setVisibility(View.VISIBLE);
        errorName.setText(getString(R.string.invalid_name));
    }

    @Override
    public void showAddressLoading() {
        addressDone.setVisibility(View.GONE);
        editAddressLoader.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideAddressLoading() {
        addressDone.setVisibility(View.VISIBLE);
        editAddressLoader.setVisibility(View.GONE);
        KeyboardVisibilityEvent.hideKeyboard(context, inputAddress);
        addressContainer.setVisibility(View.GONE);
    }

    @Override
    public void displayInvalidAddressError() {
        errorAddress.setVisibility(View.VISIBLE);
        errorAddress.setText(getString(R.string.invalid_address));
    }

    @Override
    public void displayInvalidMobileError() {
        errorPhone.setVisibility(View.VISIBLE);
        errorPhone.setText(getString(R.string.invalid_mobile));
    }

    @Override
    public void showMobileLoading() {
        phoneDone.setVisibility(View.GONE);
        editPhoneloader.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideMobileLoading() {
        phoneDone.setVisibility(View.VISIBLE);
        editPhoneloader.setVisibility(View.GONE);
        KeyboardVisibilityEvent.hideKeyboard(context, inputPhone);
        phoneContainer.setVisibility(View.GONE);
    }

    @Override
    public void setMobileVerificationState(String current__mobile, String new_mobile) {
        mobile.setVisibility(View.GONE);
        mobileConfirmContainer.setVisibility(View.VISIBLE);
        mobileConfirm.setText(MessageFormat.format("{0} {1}", getString(R.string.txn_confirm_title), new_mobile));
        if (current__mobile != null) {
            mobileCurrentConfirm.setText(getString(R.string.currently_using, current__mobile));
        } else {
            mobileCurrentConfirm.setText(getString(R.string.currently_no_number));
        }
        editPhoneIcon.setVisibility(View.GONE);
        mobile.setTextColor(ContextCompat.getColor(context, R.color.text_default));
        callIcon.setColorFilter(ContextCompat.getColor(context, R.color.grey400), PorterDuff.Mode.SRC_IN);

        callContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mobile.getVisibility() == View.VISIBLE) {
                    onPhoneEditClicked();
                } else {
                    presenter.onConfirmOtpClicked();
                }
            }
        });

        mobileConfirmContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                presenter.onConfirmOtpClicked();
            }
        });
    }

    @Override
    public void hideMobileConfirmContainer() {
        mobile.setVisibility(View.VISIBLE);
        mobileConfirmContainer.setVisibility(View.GONE);
    }

    @Override
    public void onMobileConflict(Customer customer) {
        Analytics.track(AnalyticsEvents.CUSTOMER_PROFILE_SCREEN_MOBILE_CONFLICT);

        errorPhone.setVisibility(View.VISIBLE);
        if (customer == null) {
            errorPhone.setText(getString(R.string.err_mobile_conflict_default));
        } else {
            errorPhone.setText(getString(R.string.err_mobile_conflict, customer
                .getDescription()));
        }
        phoneDone.setVisibility(View.VISIBLE);
        editPhoneloader.setVisibility(View.GONE);
    }

    @Override
    public void gotoDeleteScreen(String customerId) {
        startActivity(DeleteCustomerActivity.startingIntent(this, customerId));
    }

    @Override
    public void gotoEditMobileScreen(String customerId) {
        Analytics.track(AnalyticsEvents.EDIT_CUSTOMER_CONFIRM_MOBILE_CLICKED);
        startActivity(EditMobileActivity.startingIntent(this, customerId));
    }

    @Override
    public void gotoLogin() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "cst profile")
                .with("type", "auth error")
        );

        super.gotoLogin();
    }

    @Override
    public void openCamera() {
        Intent cameraIntent = cameraHelper.getIntent(this);
        if (cameraIntent != null) {
            startActivityForResult(cameraIntent, REQUEST_CODE_CAMERA);
        }
    }

    @Override
    public void openGallery() {
        Intent galleryIntent = galleryHelper.getIntent(this);
        if (galleryIntent != null) {
            startActivityForResult(Intent.createChooser(galleryIntent, "Select Picture"), REQUEST_CODE_GALLERY);
        }
    }

    @Override
    public void showMobileEditBox() {
        nameContainer.setVisibility(View.GONE);
        phoneContainer.setVisibility(View.VISIBLE);
        addressContainer.setVisibility(View.GONE);
        KeyboardVisibilityEvent.showKeyboard(context, inputPhone, rootView);
        Analytics.track(AnalyticsEvents.EDIT_CUSTOMER_MOBILE_CLICKED);
    }

    @Override
    public void onClickCamera() {
        presenter.onCameraClicked();
        bottomSheet.dismiss();
    }

    @Override
    public void onClickGallery() {
        presenter.onGalleryClicked();
        bottomSheet.dismiss();
    }

    @Override
    public void showAlertDialogue(String mobileNumber, String customerName) {
        Analytics.track(AnalyticsEvents.CUSTOMER_PROFILE_SCREEN_SHOW_OTP_POPUP);
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setCancelable(false);

        LayoutInflater layoutInflater = ((Activity)context).getLayoutInflater();
        View dialogView = layoutInflater.inflate(R.layout.dialog_send_otp, null);
        builder.setView(dialogView);

        AlertDialog alertDialog = builder.create();
        alertDialog.setCanceledOnTouchOutside(false);
        if(!((Activity)context).isFinishing()) {
            alertDialog.show();
        }

        TextView mobile = (TextView) dialogView.findViewById(R.id.mobile);
        TextView cancel = (TextView) dialogView.findViewById(R.id.cancel);
        TextView send = (TextView) dialogView.findViewById(R.id.send);
        TextView otpText = (TextView) dialogView.findViewById(R.id.otp_text);

        otpText.setText(Html.fromHtml(context.getString(R.string.send_otp_message, customerName)));

        mobile.setText(mobileNumber);
        send.setOnClickListener(v -> {
            Analytics.track(AnalyticsEvents.CUSTOMER_PROFILE_SCREEN_SEND_OTP_POPUP);
            alertDialog.dismiss();
            presenter.editMobile(mobileNumber);
        });

        cancel.setOnClickListener(v -> {
            Analytics.track(AnalyticsEvents.CUSTOMER_PROFILE_SCREEN_CANCEL_OTP_POPUP);
            alertDialog.dismiss();
        });

        alertDialog.show();
    }
}
