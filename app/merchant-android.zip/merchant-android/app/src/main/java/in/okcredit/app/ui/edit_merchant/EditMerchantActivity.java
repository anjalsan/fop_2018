package in.okcredit.app.ui.edit_merchant;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import dagger.android.AndroidInjection;
import in.okcredit.R;
import in.okcredit._offline.model.Merchant;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;

public class EditMerchantActivity extends BaseActivity implements EditMerchantContract.View {
    public static Intent startingIntent(Context context) {
        Intent intent = new Intent(context, EditMerchantActivity.class);
        return intent;
    }

    /* UI Elements */
    @BindView(R.id.name)
    TextInputLayout name;
    @BindView(R.id.ok)
    ViewGroup ok;
    @BindView(R.id.loading)
    ProgressBar loading;

    /* Presenter */
    @Inject
    EditMerchantContract.Presenter presenter;

    /* Lifecycle methods */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AndroidInjection.inject(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editmercant_activity);
        ButterKnife.bind(this);
        showActionBar(true);
        setTitle(R.string.editmerchant_title_name);
        Analytics.track(
            AnalyticsEvents.EDIT_MERCHANT_SCREEN);
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.attachView(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        presenter.detachView();
    }

    /****************************************************************
     * Listeners
     ****************************************************************/
    @OnClick(R.id.ok)
    public void onOk() {
        EditText et = name.getEditText();
        if (et == null)
            return;
        presenter.save(et.getText().toString());
    }

    /****************************************************************
     * MVP methods
     ****************************************************************/

    @Override
    public void showLoading() {
        loading.setVisibility(View.VISIBLE);
        ok.setVisibility(View.GONE);
    }

    @Override
    public void hideLoading() {
        loading.setVisibility(View.GONE);
        ok.setVisibility(View.VISIBLE);
    }

    @Override
    public void displayInvalidNameError() {
        name.setErrorEnabled(true);
        name.setError(getString(R.string.err_invalid_desc));
    }

    @Override
    public void setMerchant(Merchant merchant) {
        EditText et = name.getEditText();
        if (et == null)
            return;

        et.setText(merchant.getName());
        et.setSelection(et.length());
    }

    @Override
    public void goToMerchantProfileScreen() {
        finish();
    }

    @Override
    public void showError() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "edit merchant")
                .with("type", "server error")
        );

        Toast.makeText(this, R.string.err_default, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(this, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
            }
        });
    }

    @Override
    public void gotoLogin() {
        super.gotoLogin();

        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "edit merchant")
                .with("type", "auth error")
        );
    }
}
