package in.okcredit.app.ui.customer_profile;

import android.widget.ImageView;

import java.io.File;

import in.okcredit._offline.model.Customer;
import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;

public interface CustomerProfileContract {
    interface View extends MVP.View,
        BaseContracts.Online.View,
        BaseContracts.Authenticated.View {
        void setName(String customerName);

        void setMobile(String mobile);

        void gotoDeleteScreen(String customerId);

        void gotoEditMobileScreen(String customerId);

        void openCamera();

        void openGallery();

        void showMobileEditBox();

        void setAddress(String address);

        void showNameLoading();

        void hideNameLoading();

        void showAddressLoading();

        void hideAddressLoading();

        void displayInvalidNameError();

        void displayInvalidAddressError();

        void showMobileLoading();

        void hideMobileLoading();

        void setMobileVerificationState(String current__mobile, String new_mobile);

        void onMobileConflict(Customer conflict);

        void displayInvalidMobileError();

        void hideMobileConfirmContainer();

        void displayProfileImageFile(File profileImage);

        void setProfileImageLocal(File localFile);

        void setProfileImageRemote(String url);

        void showAlertDialogue(String mobile, String cusName);
    }

    interface Presenter extends MVP.Presenter<View>,
        BaseContracts.Authenticated.Presenter<View>,
        BaseContracts.Online.Presenter<View> {
        void onConfirmOtpClicked();

        void onDeleteClicked();

        void onCameraClicked();

        void onGalleryClicked();

        void saveName(String description);

        void saveAddress(String address);

        void onEditMobileClicked();

        void editMobile(String mobile);

        void setProfileImage(File profileImage);

        void showOtpDialogue(String s);

        void saveMobile(String s);
    }
}
