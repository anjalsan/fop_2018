package in.okcredit.app.ui.reset_pwd.otp;

import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;

public interface OtpContract {
    interface View extends MVP.View, BaseContracts.Online.View, BaseContracts.Loading.View {
        void setMobile(String mobile);

        void showIncorrectOtpError();

        void gotoPasswordScreen(String mobile, String token);

        void showExpiredOtpError();

        void showAutoreadLoading();

        void setTimer(long secondsRemaining);

        void showVerificationLoading();

        void showVerificationSuccess(String mobile, String token);
    }

    interface Presenter extends MVP.Presenter<View>, BaseContracts.Online.Presenter<View>, BaseContracts.Loading.Presenter<View> {
        void verifyOtp(String otp);
    }
}
