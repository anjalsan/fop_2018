package in.okcredit.app.ui._base_v2;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;

import dagger.android.AndroidInjection;
import dagger.android.support.AndroidSupportInjection;

public class BaseFragment<A extends BaseActivity> extends Fragment {
    protected A activity;

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        AndroidSupportInjection.inject(this);
        super.onActivityCreated(savedInstanceState);
        activity = (A) getActivity();
    }
}
