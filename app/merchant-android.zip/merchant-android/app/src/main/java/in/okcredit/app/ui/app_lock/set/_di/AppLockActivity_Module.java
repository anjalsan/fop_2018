package in.okcredit.app.ui.app_lock.set._di;

import dagger.Binds;
import dagger.Module;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit.app.ui.app_lock.set.AppLockContract;
import in.okcredit.app.ui.app_lock.set.AppLockPresenter;

@Module
public abstract class AppLockActivity_Module {

    @Binds
    @ActivityScope
    public abstract AppLockContract.Presenter presenter(AppLockPresenter presenter);
}
