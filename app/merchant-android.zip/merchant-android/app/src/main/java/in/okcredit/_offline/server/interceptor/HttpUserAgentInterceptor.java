package in.okcredit._offline.server.interceptor;

import java.io.IOException;

import in.okcredit.BuildConfig;
import in.okcredit.domain.device.DeviceService;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

public class HttpUserAgentInterceptor implements Interceptor {
    private DeviceService deviceService;

    public HttpUserAgentInterceptor(DeviceService deviceService) {
        this.deviceService = deviceService;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        String deviceId = null;
        try {
            deviceId = deviceService.getDevice().blockingFirst().getId();
        } catch (Exception e) {
        }

        Request req = chain.request();
        Request reqCopy;

        if (deviceId == null) {
            reqCopy = req.newBuilder()
                .addHeader("User-Agent", String.format("%s/%d", BuildConfig.APPLICATION_ID, BuildConfig.VERSION_CODE))
                .build();
        } else {
            reqCopy = req.newBuilder()
                .addHeader("User-Agent", String.format("%s/%d", BuildConfig.APPLICATION_ID, BuildConfig.VERSION_CODE))
                .addHeader("X-DeviceId", deviceId)
                .build();
        }

        return chain.proceed(reqCopy);
    }
}
