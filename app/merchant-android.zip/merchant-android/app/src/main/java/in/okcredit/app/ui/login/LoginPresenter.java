package in.okcredit.app.ui.login;

import android.support.annotation.Nullable;

import javax.inject.Inject;

import in.okcredit._di.PresenterParam;
import in.okcredit._offline.server.NetworkHelper;
import in.okcredit._offline.usecase.Signin;
import in.okcredit.domain.auth.AuthDomain;
import in.okcredit.domain.auth.AuthErrors;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.observers.DisposableCompletableObserver;

public class LoginPresenter implements Login.Presenter {
    private Login.View view;
    private CompositeDisposable tasks;
    private String mobile;
    private Signin signin;

    @Inject
    public LoginPresenter(@Nullable @PresenterParam("mobile") String mobile,
                          AuthDomain authDomain,
                          Signin signin) {
        tasks = new CompositeDisposable();
        this.signin = signin;

        if (mobile == null)
            this.mobile = authDomain.getUsername();
        else
            this.mobile = mobile;
    }

    @Override
    public void attachView(Login.View view) {
        this.view = view;
        if (mobile == null)
            view.gotoMobileScreen();
        else
            this.view.setMobile(mobile);
    }

    @Override
    public void detachView() {
        view = null;
        tasks.clear();
    }

    @Override
    public void login(String password) {
        if (view == null)
            return;

        view.showLoading();
        Disposable task =
            signin
                .execute(mobile, password)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableCompletableObserver() {
                    @Override
                    public void onComplete() {
                        if (view == null)
                            return;

                        view.hideLoading();
                        view.onSuccess();
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        if (view == null)
                            return;

                        view.hideLoading();
                        if (e instanceof AuthErrors.IncorrectPassword) {
                            view.displayInvalidCredentialsError();
                        } else if (NetworkHelper.isNetworkError(e)) {
                            view.onNetworkFailure();
                        } else {
                            view.onError("login");
                        }
                    }
                });
        tasks.add(task);
    }
}
