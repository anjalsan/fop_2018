package in.okcredit.app.ui._widget.txn_meta;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.R;

public class TxnMetadataViewHolder extends RecyclerView.ViewHolder {
    public static TxnMetadataViewHolder create(Context context, ViewGroup parent) {
        return new TxnMetadataViewHolder(
            context,
            LayoutInflater
                .from(context)
                .inflate(R.layout.widget_txn_meta_item, parent, false)
        );
    }

    @BindView(R.id.icon) ImageView icon;
    @BindView(R.id.msg) TextView msg;
    @BindView(R.id.action) Button action;

    private Context context;

    public TxnMetadataViewHolder(Context context, View itemView) {
        super(itemView);
        ButterKnife.bind(this, itemView);
        this.context = context;
    }

    public void bind(TxnMetadataView.TxnMetadata metadata) {
        icon.setImageDrawable(ContextCompat.getDrawable(context, metadata.iconRes));
        msg.setText(metadata.msg);
        if (metadata.actionLabel == null || metadata.onClickListener == null) {
            action.setVisibility(View.GONE);
        } else {
            action.setText(metadata.actionLabel);
            action.setOnClickListener(metadata.onClickListener);
            itemView.setOnClickListener(metadata.onClickListener);
        }
    }
}
