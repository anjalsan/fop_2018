package in.okcredit._offline.error;

public final class TransactionErrors {
    public static class AddFailed extends Exception {
    }

    private TransactionErrors() {
    }
}
