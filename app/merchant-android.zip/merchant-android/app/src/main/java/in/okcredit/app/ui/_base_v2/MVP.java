package in.okcredit.app.ui._base_v2;

public interface MVP {
    interface View {
        void showError();
    }

    interface Presenter<V extends View> {
        void attachView(V v);

        void detachView();
    }
}
