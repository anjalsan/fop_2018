package in.okcredit.app.ui.account;

import in.okcredit.app.ui._base.BasePresenter;
import in.okcredit.app.ui._base.BaseView;
import in.okcredit._offline.model.Merchant;

public interface Account {
    interface Presenter extends BasePresenter<View> {
        void generateYesterdayReport();
    }

    interface View extends BaseView {
        void displayMerchantDetails(Merchant merchant);

        void displayMerchantAccountSummary(float outstandingBalance, int customerCount);

        void onReportGenerated(String reportUrl);

        void setReminderStatus(boolean isReminderActive);
    }
}
