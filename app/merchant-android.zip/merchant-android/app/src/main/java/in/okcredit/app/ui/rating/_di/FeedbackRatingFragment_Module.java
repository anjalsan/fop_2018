package in.okcredit.app.ui.rating._di;

import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import in.okcredit._di.PresenterParam;
import in.okcredit._di.scope.FragmentScope;
import in.okcredit.app.ui.rating.feedback_rating.FeedbackRatingContract;
import in.okcredit.app.ui.rating.feedback_rating.FeedbackRatingFragment;
import in.okcredit.app.ui.rating.feedback_rating.FeedbackRatingPresenter;

@Module
public abstract class FeedbackRatingFragment_Module {
    @Binds
    @FragmentScope
    public abstract FeedbackRatingContract.Presenter presenter(FeedbackRatingPresenter presenter);

    @Provides
    @FragmentScope
    @PresenterParam("rating")
    public static int rating(FeedbackRatingFragment fragment) {
        return fragment.getArguments().getInt(FeedbackRatingFragment.ARG_RATING);
    }
}
