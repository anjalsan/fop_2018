package in.okcredit.app.ui.reset_pwd.otp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.goodiebag.pinview.Pinview;

import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import dagger.android.support.AndroidSupportInjection;
import in.okcredit.R;
import in.okcredit.ThreadUtils;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui._utils.KeyboardUtil;
import in.okcredit.app.ui.reset_pwd.ResetPwdActivity;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.observers.DisposableObserver;
import timber.log.Timber;

public class OtpFragment extends Fragment implements OtpContract.View {
    public static final String ARG_MOBILE = "mobile";

    public static OtpFragment newInstance(String mobile) {
        Bundle args = new Bundle();
        args.putString(ARG_MOBILE, mobile);
        OtpFragment fragment = new OtpFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @BindView(R.id.mobile)
    TextView mobile;
    @BindView(R.id.otp)
    Pinview otp;

    @BindView(R.id.otp_error)
    LinearLayout otpError;

    @BindView(R.id.loading_autoread)
    LinearLayout loadingAutoread;

    @BindView(R.id.timer)
    TextView timer;

    @BindView(R.id.loading_verify)
    LinearLayout loadingVerify;

    @BindView(R.id.verify_success)
    LinearLayout verifySuccess;

    @BindView(R.id.otp_error_msg)
    TextView otpErrorMsg;

    @Inject
    OtpContract.Presenter presenter;
    @Inject
    SmsHelper smsHelper;

    private boolean isAutosms = false;
    private CompositeDisposable tasks = new CompositeDisposable();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle
        savedInstanceState) {
        View view = inflater.inflate(R.layout.resetpwd_fragment_otp, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        AndroidSupportInjection.inject(this);
        Analytics.track(AnalyticsEvents.RESET_PWD_OTP_SCREEN);

        otpError.setVisibility(View.GONE);
        loadingAutoread.setVisibility(View.GONE);
        loadingVerify.setVisibility(View.GONE);
        verifySuccess.setVisibility(View.GONE);

        otp.setPinViewEventListener((pinview, fromUser) ->
        {
            otpError.setVisibility(View.GONE);
            presenter.verifyOtp(otp.getValue());
        });

        tasks.add(smsHelper
            .otp()
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                o ->
                {
                    Analytics.track(
                        AnalyticsEvents.PASSWORD_OTP_ENTERED,
                        EventProperties
                            .create()
                            .with("type", isAutosms ? "auto" : "manual")
                    );
                    otp.setValue(o);
                    isAutosms = true;
                },
                throwable -> Timber.e(throwable, "otp auto read channel failed")
            )
        );

        otp.requestFocus();
    }

    @Override
    public void onResume() {
        super.onResume();
        smsHelper.startListening();
        presenter.attachView(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        smsHelper.stopListening();
        presenter.detachView();
    }

    /****************************************************************
     * MVP methods
     ****************************************************************/
    @Override
    public void showLoading() {

    }

    @Override
    public void hideLoading() {

    }

    @Override
    public void setMobile(String m) {
        mobile.setText(m);
    }

    @Override
    public void showIncorrectOtpError() {
        otpError.setVisibility(View.VISIBLE);
        loadingAutoread.setVisibility(View.GONE);
        loadingVerify.setVisibility(View.GONE);
        verifySuccess.setVisibility(View.GONE);

        otpErrorMsg.setText(R.string.register_err_incorrect_otp);
    }

    @Override
    public void showExpiredOtpError() {
        otpError.setVisibility(View.VISIBLE);
        loadingAutoread.setVisibility(View.GONE);
        loadingVerify.setVisibility(View.GONE);
        verifySuccess.setVisibility(View.GONE);

        otpErrorMsg.setText(R.string.reset_pwd_otp_expired);
    }

    @Override
    public void showAutoreadLoading() {
        otpError.setVisibility(View.GONE);
        loadingAutoread.setVisibility(View.VISIBLE);
        loadingVerify.setVisibility(View.GONE);
        verifySuccess.setVisibility(View.GONE);
    }

    @Override
    public void setTimer(long secondsRemaining) {
        timer.setText(String.valueOf(secondsRemaining) + " seconds");
    }

    @Override
    public void showVerificationLoading() {
        otpError.setVisibility(View.GONE);
        loadingAutoread.setVisibility(View.GONE);
        loadingVerify.setVisibility(View.VISIBLE);
        verifySuccess.setVisibility(View.GONE);
    }

    @Override
    public void showVerificationSuccess(String mobile, String token) {
        otpError.setVisibility(View.GONE);
        loadingAutoread.setVisibility(View.GONE);
        loadingVerify.setVisibility(View.GONE);
        verifySuccess.setVisibility(View.VISIBLE);

        Observable.timer(1, TimeUnit.SECONDS, ThreadUtils.newThread())
                  .observeOn(AndroidSchedulers.mainThread())
                  .subscribe(new DisposableObserver<Long>() {
                      @Override
                      public void onNext(Long aLong) {
                          gotoPasswordScreen(mobile, token);
                      }

                      @Override
                      public void onError(Throwable e) {

                      }

                      @Override
                      public void onComplete() {

                      }
                  });
    }

    @Override
    public void gotoPasswordScreen(String mobile, String token) {
        if (((ResetPwdActivity) getActivity()) != null) {
            ((ResetPwdActivity) getActivity()).showPasswordFragment(mobile, token);
        }
    }

    @Override
    public void showError() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "reset pwd otp")
                .with("type", "server error")
        );

        Toast.makeText(getActivity(), R.string.err_default, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(getActivity(), new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
                KeyboardUtil.hideKeyboard(OtpFragment.this);
                getActivity().onBackPressed();
            }
        });
    }
}
