package in.okcredit._offline.usecase;

import android.annotation.SuppressLint;

import org.joda.time.DateTime;

import javax.inject.Inject;

import in.okcredit.ThreadUtils;
import in.okcredit._offline.Constants;
import in.okcredit._offline.database.MerchantRepo;
import in.okcredit._offline.server.Server;
import in.okcredit.analytics.Analytics;
import in.okcredit.service.keyval.KeyValService;
import in.okcredit.util.DateTimeMapper;
import io.reactivex.Completable;

public class ResumeAuthScope {
    private KeyValService keyValService;
    private Server server;
    private MerchantRepo merchantRepo;
    private LinkDevice linkDevice;
    private SafelySaveCustomerList safelySaveCustomerList;
    private SyncMerchantPreferences syncMerchantPreferences;

    @Inject
    public ResumeAuthScope(KeyValService keyValService,
                           Server server,
                           MerchantRepo merchantRepo,
                           LinkDevice linkDevice,
                           SafelySaveCustomerList safelySaveCustomerList,
                           SyncMerchantPreferences syncMerchantPreferences) {

        this.keyValService = keyValService;
        this.server = server;
        this.merchantRepo = merchantRepo;
        this.linkDevice = linkDevice;
        this.safelySaveCustomerList = safelySaveCustomerList;
        this.syncMerchantPreferences = syncMerchantPreferences;
    }

    public Completable execute() {
        return keyValService
            .contains(Constants.KEY_AUTH_SYNC_TIME)
            .flatMapCompletable(isStarted -> {
                if (isStarted) {
                    return Completable.complete();
                } else {
                    return fetchActiveMerchant() // fetch active merchant (requestOtp)
                                                 .andThen(fetchCustomerList()) // fetch customer list (requestOtp)
                                                 .andThen(linkAnalytics()) // setup "user" for analytics (schedule)
                                                 .andThen(linkDevice.schedule()) // link active merchant with device (schedule)
                                                 .andThen(syncMerchantPreferences.schedule())
                                                 .andThen(markSyncComplete());
                }
            });
    }

    @SuppressLint("CheckResult")
    private Completable linkAnalytics() {
        merchantRepo.getActiveMerchant()
                    .take(1)
                    .subscribe(merchant -> Analytics.setActiveMerchant(merchant));
        return Completable.complete();
    }

    private Completable markSyncComplete() {
        return keyValService
            .put(Constants.KEY_AUTH_SYNC_TIME, String.valueOf(DateTimeMapper.toEpoch(DateTime.now())))
            .subscribeOn(ThreadUtils.database());
    }

    // fetch active merchant
    private Completable fetchActiveMerchant() {
        return server.getActiveMerchant()
                     .flatMapCompletable(merchant -> merchantRepo.setActiveMerchant(merchant));
    }

    // fetch customer list
    private Completable fetchCustomerList() {
        return server.listCustomers(null)
                     .flatMapCompletable(customers -> safelySaveCustomerList.execute(customers));
    }
}
