package in.okcredit.app.ui.help.section;

import java.util.List;

import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;
import in.okcredit.domain.help.HelpItem;

public interface SectionContract {
    interface View extends MVP.View, BaseContracts.Online.View, BaseContracts.Loading.View {
        void setHelpItems(String id, List<HelpItem> helpItems);

        void setActionBarTitle(String title);

        void setYoutube(String videoId);

        void gotoLogin();
    }

    interface Presenter extends MVP.Presenter<View>,
        BaseContracts.Loading.Presenter<View>,
        BaseContracts.Online.Presenter<View> {
    }
}
