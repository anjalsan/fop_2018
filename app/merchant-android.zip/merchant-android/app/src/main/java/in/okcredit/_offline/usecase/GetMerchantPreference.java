package in.okcredit._offline.usecase;

import javax.inject.Inject;

import in.okcredit._offline.database.MerchantRepo;
import in.okcredit._offline.model.MerchantPreference;
import io.reactivex.Observable;

// Offline
public final class GetMerchantPreference {
    private MerchantRepo merchantRepo;
    private SyncMerchantPreferences syncMerchantPreferences;

    @Inject
    public GetMerchantPreference(MerchantRepo merchantRepo, SyncMerchantPreferences syncMerchantPreferences) {
        this.merchantRepo = merchantRepo;
        this.syncMerchantPreferences = syncMerchantPreferences;
    }

    public Observable<String> execute(MerchantPreference preference) {
        return syncMerchantPreferences.schedule()
                                      .andThen(merchantRepo.getMerchantPreference(preference));
    }
}
