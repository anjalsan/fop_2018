package in.okcredit.app.ui.addtxn.confirmTxn;

import android.support.annotation.Nullable;

import java.io.File;

import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;

public interface ConfirmTxnContract {
    interface View extends MVP.View,
        BaseContracts.Loading.View,
        BaseContracts.Online.View,
        BaseContracts.Authenticated.View {
        void setTxnType(int txnType, int lifecycle);

        void setCustomerName(String name);

        void setAmount(float amount);

        void showNote(String note);

        void showReceipt(File receipt);

        void showIncorrectPasswordError();

        void gotoSuccess();

        void gotoFailure();

        void setupTutorialLayout(int lifecycle, int txType);

        void forgotPassword(String mobile);
    }

    interface Presenter extends MVP.Presenter<View>,
        BaseContracts.Loading.Presenter<View>,
        BaseContracts.Online.Presenter<View>,
        BaseContracts.Authenticated.Presenter<View> {
        void confirmTxn(@Nullable String password);
        void forgotPassword();
    }
}
