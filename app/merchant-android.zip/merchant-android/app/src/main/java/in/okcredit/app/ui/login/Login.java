package in.okcredit.app.ui.login;

import in.okcredit.app.ui._base.BasePresenter;
import in.okcredit.app.ui._base.BaseView;

public interface Login {
    interface Presenter extends BasePresenter<View> {
        void login(String password);
    }

    interface View extends BaseView {
        void setMobile(String mobile);

        void showLoading();

        void hideLoading();

        void onSuccess();

        void displayInvalidCredentialsError();

        void gotoMobileScreen();
    }
}
