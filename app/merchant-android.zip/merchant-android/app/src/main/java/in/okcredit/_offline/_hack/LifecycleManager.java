package in.okcredit._offline._hack;

import android.annotation.SuppressLint;

import javax.inject.Inject;

import in.okcredit.LifecycleState;
import in.okcredit._offline.database.CustomerRepo;
import in.okcredit._offline.database.MerchantRepo;
import in.okcredit._offline.model.Customer;
import in.okcredit._offline.model.Merchant;
import io.reactivex.Observable;
import io.reactivex.subjects.BehaviorSubject;

public final class LifecycleManager {
    private MerchantRepo merchantRepo;
    private CustomerRepo customerRepo;
    private BehaviorSubject<Integer> lifecycleState;

    @Inject
    public LifecycleManager(MerchantRepo merchantRepo, CustomerRepo customerRepo) {
        this.merchantRepo = merchantRepo;
        this.customerRepo = customerRepo;
    }

    @SuppressLint("CheckResult")
    public Observable<Integer> getLifecycleState() {
        if (lifecycleState == null) {
            lifecycleState = BehaviorSubject.create();
            Observable
                .combineLatest(
                    merchantRepo.getActiveMerchant(),
                    customerRepo.listCustomers(),
                    (merchant, customers) -> {
                        int numberOfCustomers = customers.size();

                        if (numberOfCustomers == 0) {
                            return LifecycleState.TRIAL_ADD_CUSTOMER;

                        } else if (numberOfCustomers == 1) {

                            Customer customer = customers.get(0);
                            if (isTestCustomer(customer, merchant)) {
                                long txCount = customer.getTransactionCount();

                                if (txCount == 0) {
                                    return LifecycleState.TRIAL_TRANSACTION;
                                } else {
                                    return LifecycleState.TRIAL_ADD_CUSTOMER;
                                }
                            }

                        }
                        return LifecycleState.NORMAL_FLOW;
                    }
                )
                .subscribe(state -> lifecycleState.onNext(state));
        }
        return lifecycleState;
    }

    private boolean isTestCustomer(Customer customer, Merchant merchant) {
        return customer.getMobile() != null && customer.getMobile().equals(merchant.getMobile());
    }
}
