package in.okcredit.app.ui.transaction;

import javax.inject.Inject;

import androidx.work.State;
import androidx.work.WorkManager;
import in.okcredit._di.PresenterParam;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit._offline.model.Transaction;
import in.okcredit._offline.server.NetworkHelper;
import in.okcredit._offline.usecase.SyncCustomer;
import in.okcredit.app.ui._base.ErrorHelper;
import in.okcredit.app.ui.help.main.HelpContract;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.observers.DisposableObserver;
import io.reactivex.subjects.BehaviorSubject;
import timber.log.Timber;

@ActivityScope
public class TransactionScreenPresenter implements TransactionScreenContract.Presenter {
    private TransactionScreenContract.View view;

    private GetTransactionUseCase getTransactionUseCase;
    private SyncCustomer syncCustomer;

    private CompositeDisposable tasks;
    private boolean isCancelVisible;

    private TransactionScreenContract.Transaction transaction;
    private BehaviorSubject<Integer> syncStatus;

    @Inject
    public TransactionScreenPresenter(GetTransactionUseCase getTransactionUseCase, SyncCustomer syncCustomer, @PresenterParam("is_cancel_visible") boolean isCancelVisible) {
        this.getTransactionUseCase = getTransactionUseCase;
        tasks = new CompositeDisposable();
        this.syncCustomer = syncCustomer;
        this.isCancelVisible = isCancelVisible;
        syncStatus = BehaviorSubject.create();

        getTransactionUseCase
            .transactionObservable()
            .subscribe(
                txn -> {
                    WorkManager
                        .getInstance()
                        .getStatusesForUniqueWork("sync_customer_" + txn.getCustomerId())
                        .observeForever(workStatuses -> {
                            if (workStatuses.isEmpty()) {
                                syncStatus.onNext(TransactionScreenContract.Transaction.SYNC_STATUS_SUCCEEDED);
                            } else {
                                State state = workStatuses.get(0).getState();
                                if (state == State.ENQUEUED) {
                                    syncStatus.onNext(TransactionScreenContract.Transaction.SYNC_STATUS_ENQUEUED);
                                } else if (state == State.RUNNING) {
                                    syncStatus.onNext(TransactionScreenContract.Transaction.SYNC_STATUS_RUNNING);
                                } else {
                                    syncStatus.onNext(TransactionScreenContract.Transaction.SYNC_STATUS_SUCCEEDED);
                                }
                            }
                        });
                },
                throwable -> {
                }
            );
    }

    @Override
    public void attachView(TransactionScreenContract.View view) {
        this.view = view;
        view.showLoading();
        Disposable task = getTransactionUseCase
            .getObservable()
            .flatMap(
                txn -> syncStatus.map(status -> {
                    txn.isSyncing = (status == TransactionScreenContract.Transaction.SYNC_STATUS_RUNNING);
                    return txn;
                })
            )
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeWith(new DisposableObserver<TransactionScreenContract.Transaction>() {
                @Override
                public void onNext(TransactionScreenContract.Transaction transaction) {
                    if (view == null) {
                        return;
                    }
                    view.hideLoading();
                    view.setTransaction(transaction, isCancelVisible);
                    TransactionScreenPresenter.this.transaction = transaction;
                }

                @Override
                public void onError(Throwable throwable) {
                    view.hideLoading();
                    Timber.e(throwable, "failed to fetch transaction");
                    ErrorHelper.handleDefaults(view, throwable, "attachView");
                }

                @Override
                public void onComplete() {
                }
            });
        tasks.add(task);
    }

    @Override
    public void detachView() {
        tasks.clear();
        view = null;
    }

    @Override
    public void onDeleteClicked() {

        Disposable task = getTransactionUseCase
            .transactionObservable()
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeWith(new DisposableObserver<Transaction>() {
                @Override
                public void onNext(Transaction transaction) {
                    if (view == null) {
                        return;
                    }
                    view.gotoDeleteScreen(transaction);
                }

                @Override
                public void onError(Throwable throwable) {
                    Timber.e(throwable, "failed to fetch transaction");
                    ErrorHelper.handleDefaults(view, throwable, "attachView");
                }

                @Override
                public void onComplete() {
                }
            });
        tasks.add(task);
    }

    @Override
    public void syncNow() {
        if (transaction == null || transaction.customer == null || transaction.customer.id == null) {
            return;
        }

        tasks.add(
            syncCustomer
                .execute(transaction.customer.id, null)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    () -> {
                    },
                    throwable -> {
                        if (view != null) {
                            if(NetworkHelper.isNetworkError(throwable)) {
                                view.onNetworkFailure();
                            } else {
                                view.onError("syncNot");
                            }
                        }
                    }
                )
        );
    }
}
