package in.okcredit.app.ui.addtxn._di;

import dagger.Binds;
import dagger.Module;
import in.okcredit._di.scope.FragmentScope;
import in.okcredit.app.ui.addtxn.confirmTxn.ConfirmTxnContract;
import in.okcredit.app.ui.addtxn.confirmTxn.ConfirmTxnPresenter;

@Module
public abstract class ConfirmTxnFragment_Module {
    @Binds
    @FragmentScope
    public abstract ConfirmTxnContract.Presenter presenter(ConfirmTxnPresenter presenter);
}
