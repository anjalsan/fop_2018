package in.okcredit.app.ui.addtxn._di;

import dagger.Module;
import dagger.android.ContributesAndroidInjector;
import in.okcredit._di.scope.FragmentScope;
import in.okcredit.app.ui.addtxn.addTxn.AddTxnFragment;
import in.okcredit.app.ui.addtxn.confirmTxn.ConfirmTxnFragment;
import in.okcredit.app.ui.addtxn.result.ResultFragment;

@Module
public abstract class AddTxnActivity_FragmentModule {
    @FragmentScope
    @ContributesAndroidInjector(modules = {AddTxnFragment_Module.class})
    public abstract AddTxnFragment addTxnFragment();

    @FragmentScope
    @ContributesAndroidInjector(modules = {ConfirmTxnFragment_Module.class})
    public abstract ConfirmTxnFragment confirmTxnFragment();

    @FragmentScope
    @ContributesAndroidInjector(modules = {ResultFragment_Module.class})
    public abstract ResultFragment successFragment();
}
