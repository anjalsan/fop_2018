package in.okcredit.app.ui._dialog;

import android.app.Activity;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import in.okcredit.R;

public final class NoteDialog {
    public static AlertDialog show(Activity activity, String noteStr) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setCancelable(true);

        LayoutInflater layoutInflater = activity.getLayoutInflater();
        View dialogView = layoutInflater.inflate(R.layout.dialog_note, null);
        builder.setView(dialogView);
        TextView note = dialogView.findViewById(R.id.note);
        note.setText(noteStr);
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
        return alertDialog;
    }

    private NoteDialog() {
    }
}
