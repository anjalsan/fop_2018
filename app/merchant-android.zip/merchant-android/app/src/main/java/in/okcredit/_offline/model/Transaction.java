package in.okcredit._offline.model;

import org.joda.time.DateTime;

import java.io.Serializable;

public final class Transaction implements Serializable {
    public static final int CREDIT = 1;
    public static final int PAYMENT = 2;
    public static final int RETURN = 3;

    private String id;
    private int type;
    private String customerId;
    private float amount;
    private String receiptUrl;
    private String note;
    private DateTime createdAt;
    private boolean isOnboarding;
    private boolean isDeleted;
    private DateTime deleteTime;
    private boolean isDirty;

    public Transaction(String id, int type, String customerId, float amount, String receiptUrl, String note, DateTime createdAt, boolean isOnboarding, boolean isDeleted, DateTime deleteTime, boolean isDirty) {
        this.id = id;
        this.type = type;
        this.customerId = customerId;
        this.amount = amount;
        this.receiptUrl = receiptUrl;
        this.note = note;
        this.createdAt = createdAt;
        this.isOnboarding = isOnboarding;
        this.isDeleted = isDeleted;
        this.deleteTime = deleteTime;
        this.isDirty = isDirty;
    }

    public DateTime getDeleteTime() {
        return deleteTime;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public String getId() {
        return id;
    }

    public int getType() {
        return type;
    }

    public String getCustomerId() {
        return customerId;
    }

    public float getAmount() {
        return amount;
    }

    public String getReceiptUrl() {
        return receiptUrl;
    }

    public DateTime getCreatedAt() {
        return createdAt;
    }

    public String getNote() {
        return note;
    }

    public boolean isOnboarding() {
        return isOnboarding;
    }

    public boolean isDirty() {
        return isDirty;
    }

    public DateTime lastActivity() {
        return isDeleted ? deleteTime : createdAt;
    }

    public Transaction withDirty(boolean isDirty) {
        return new Transaction(
            id,
            type,
            customerId,
            amount,
            receiptUrl,
            note,
            createdAt,
            isOnboarding,
            isDeleted,
            deleteTime,
            isDirty
        );
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Transaction that = (Transaction) o;
        return id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }

    public Transaction asDeleted() {
        return new Transaction(
            id,
            type,
            customerId,
            amount,
            receiptUrl,
            note,
            createdAt,
            isOnboarding,
            true,
            DateTime.now(),
            isDirty
        );
    }
}
