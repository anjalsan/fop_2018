package in.okcredit.app.ui.app_lock.set;

import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;

public interface AppLockContract {
    interface Presenter extends MVP.Presenter<View>, BaseContracts.Online.Presenter<View>, BaseContracts.Authenticated.Presenter<View> {
        void enableAppLock(String pattern);

        void disableAppLock(String oldPatternAttempt);
    }

    interface View extends MVP.View, BaseContracts.Online.View, BaseContracts.Authenticated.View {
        void setAppLockStatus(boolean isActive);

        void goToAppLockPrefActivity(boolean isAppLockEnabled);

        void showIncorrectOldPatternMessage();

        void showInvalidPatternMessage();

        void showPatternMismatchMessage();
    }
}
