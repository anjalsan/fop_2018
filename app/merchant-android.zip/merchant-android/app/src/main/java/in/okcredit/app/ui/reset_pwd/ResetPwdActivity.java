package in.okcredit.app.ui.reset_pwd;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import javax.inject.Inject;

import butterknife.ButterKnife;
import dagger.android.AndroidInjector;
import dagger.android.DispatchingAndroidInjector;
import dagger.android.support.HasSupportFragmentInjector;
import in.okcredit.R;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui.reset_pwd.otp.OtpFragment;
import in.okcredit.app.ui.reset_pwd.password.PasswordFragment;

public class ResetPwdActivity extends BaseActivity implements HasSupportFragmentInjector {
    public static final String EXTRA_MOBILE = "ResetPwdActivity.mobile";
    public static final String EXTRA_REQUESTED_SCREEN = "ResetPwdActivity.requested_screen";

    public static final String REQUESTED_SCREEN_LOGIN = "LOGIN_SCREEN";
    public static final String REQUESTED_SCREEN_SECURITY = "SECURITY_SCREEN";
    public static final String REQUESTED_SCREEN_TX = "TX_SCREEN";

    public static Intent startingIntent(Context context, @NonNull String mobile, String requestedScreen) {
        Intent intent = new Intent(context, ResetPwdActivity.class);
        intent.putExtra(EXTRA_MOBILE, mobile);
        intent.putExtra(EXTRA_REQUESTED_SCREEN, requestedScreen);
        return intent;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.resetpwd_activity);
        ButterKnife.bind(this);
        showActionBar(false);
        setTitle(getString(R.string.reset_pwd_title));

        showOtpFragment();

        Analytics.track(AnalyticsEvents.RESET_PWD_STARTED);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.clear();
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_with_help, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.help:
                help();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    /****************************************************************
     * Navigation
     ****************************************************************/
    public void showOtpFragment() {
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.fragmentContainer, OtpFragment.newInstance(getIntent().getStringExtra(EXTRA_MOBILE)))
            .commitAllowingStateLoss();
    }

    public void showPasswordFragment(String mobile, String token) {
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.fragmentContainer, PasswordFragment.newInstance(mobile, token, getIntent().getStringExtra(EXTRA_REQUESTED_SCREEN)))
            .commitAllowingStateLoss();
    }

    /****************************************************************
     Dependency Injection
     ****************************************************************/
    @Inject
    DispatchingAndroidInjector<Fragment> fragmentInjector;

    @Override
    public AndroidInjector<Fragment> supportFragmentInjector() {
        return fragmentInjector;
    }
}
