package in.okcredit.app.ui.edit_merchant._di;

import dagger.Binds;
import dagger.Module;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit.app.ui.edit_merchant.EditMerchantContract;
import in.okcredit.app.ui.edit_merchant.EditMerchantPresenter;

@Module
public abstract class EditMerchantActivity_Module {
    @Binds
    @ActivityScope
    public abstract EditMerchantContract.Presenter presenter(EditMerchantPresenter presenter);
}
