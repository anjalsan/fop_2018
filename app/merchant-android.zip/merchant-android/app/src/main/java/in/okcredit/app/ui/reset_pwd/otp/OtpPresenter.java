package in.okcredit.app.ui.reset_pwd.otp;

import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import in.okcredit.ThreadUtils;
import in.okcredit._di.PresenterParam;
import in.okcredit.app.ui._base_v2.BasePresenter;
import in.okcredit.domain.otp.OtpErrors;
import in.okcredit.domain.otp.OtpService;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;

public class OtpPresenter extends BasePresenter<OtpContract.View> implements OtpContract.Presenter {
    private OtpService otpService;
    private String mobile;
    private boolean isOtpSent;
    private Disposable timerTask;

    @Inject
    public OtpPresenter(OtpService otpService, @PresenterParam("mobile") String mobile) {
        super(AndroidSchedulers.mainThread());
        this.otpService = otpService;
        this.mobile = mobile;
    }

    @Override
    public void attachView(OtpContract.View v) {
        super.attachView(v);
        sendOtp();
        ifAttached(view -> view.setMobile(mobile));

        ifAttached(view -> view.showAutoreadLoading());
        ifAttached(view -> view.setTimer(10));

        timerTask = Observable.interval(1, TimeUnit.SECONDS, ThreadUtils.newThread())
                              .observeOn(uiScheduler)
                              .subscribe(
                                  secondsElapsed -> {

                                      ifAttached(view -> view.setTimer(10 - secondsElapsed));

                                      if (secondsElapsed == 10) {
                                          timerTask.dispose();
                                      }
                                  },
                                  throwable -> {

                                  });

        addTask(timerTask);
    }

    @Override
    public void verifyOtp(String otp) {
        ifAttached(view -> view.showVerificationLoading());
        addTask(otpService
            .verifyOtp(mobile, otp)
            .observeOn(uiScheduler)
            .subscribe(
                token ->
                {
                    ifAttached(view -> view.showVerificationSuccess(mobile, token));
                },
                throwable ->
                {
                    ifAttached(view -> view.hideLoading());
                    if (throwable instanceof OtpErrors.Invalid)
                        ifAttached(view -> view.showIncorrectOtpError());
                    else if (throwable instanceof OtpErrors.Expired)
                        ifAttached(view -> view.showExpiredOtpError());
                    else if (isInternetIssue(throwable))
                        ifAttached(view -> view.showNoInternetMessage());
                    else
                        ifAttached(view -> view.showError());
                }
            )
        );
    }

    @Override
    public void onInternetRestored() {
        sendOtp();
    }

    private void sendOtp() {
        if (!isOtpSent) {
            addTask(otpService
                .sendOtp(mobile)
                .observeOn(uiScheduler)
                .subscribe(
                    () -> isOtpSent = true,
                    throwable -> {
                        if (isInternetIssue(throwable)) {
                            ifAttached(view -> view.showNoInternetMessage());
                        } else {
                            ifAttached(view -> view.showError());
                        }
                    }
                )
            );
        }
    }
}
