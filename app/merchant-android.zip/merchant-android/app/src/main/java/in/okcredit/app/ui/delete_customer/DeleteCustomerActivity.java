package in.okcredit.app.ui.delete_customer;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import dagger.android.AndroidInjection;
import in.okcredit.LifecycleState;
import in.okcredit.R;
import in.okcredit._offline.model.Customer;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui._utils.CurrencyUtil;
import in.okcredit.app.ui.addtxn.AddTxnActivity;
import in.okcredit.app.ui.home.HomeActivity;

public class DeleteCustomerActivity extends BaseActivity implements DeleteCustomerContract.View {
    public static final String EXTRA_CUSTOMER_ID = "customer_id";

    public static Intent startingIntent(Context context, @NonNull String customerId) {
        Intent intent = new Intent(context, DeleteCustomerActivity.class);
        intent.putExtra(EXTRA_CUSTOMER_ID, customerId);
        return intent;
    }

    @BindView(R.id.name)
    TextView name;
    @BindView(R.id.balance)
    TextView balance;
    @BindView(R.id.balanceLabel)
    TextView balanceLabel;
    @BindView(R.id.msg)
    TextView msg;
    @BindView(R.id.loading)
    ProgressBar loading;
    @BindView(R.id.delete)
    ViewGroup delete;
    @BindView(R.id.deleteContainer)
    LinearLayout deleteContainer;
    @BindView(R.id.passwordContainer)
    TextInputLayout passwordContainer;
    @BindView(R.id.password)
    EditText password;
    @BindView(R.id.settlement)
    ViewGroup settlement;
    @BindView(R.id.settlementIcon)
    ImageView settlementIcon;
    @BindView(R.id.settlementLabel)
    TextView settlementLabel;

    @Inject
    DeleteCustomerContract.Presenter presenter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AndroidInjection.inject(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.delcst_activity);
        ButterKnife.bind(this);
        showActionBar(true);
        setTitle(R.string.delcst_title);

        Analytics.track(AnalyticsEvents.DELETE_CUSTOMER_SCREEN);
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.attachView(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        presenter.detachView();
    }

    /****************************************************************
     * Listeners
     ****************************************************************/
    @OnClick(R.id.delete)
    public void onDeleteClicked() {
        Analytics.track(AnalyticsEvents.DELETE_CUSTOMER_SCREEN_CLICK_DELETE);
        presenter.delete(password.getText().toString());
    }

    @OnClick(R.id.settlement)
    public void onSettleClicked() {
        Analytics.track(AnalyticsEvents.DELETE_CUSTOMER_SCREEN_CLICK_SETTLEMENT);
        presenter.settle();
    }

    /****************************************************************
     * MVP methods
     ****************************************************************/
    @Override
    public void showError() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "delete cst")
                .with("type", "server error")
        );

        Toast.makeText(this, R.string.err_default, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(this, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
            }
        });
    }

    @Override
    public void setCustomer(Customer customer) {
        name.setText(customer.getDescription());
        CurrencyUtil.render(customer.getBalance(), balance);

        if (customer.getBalance() == 0.0) {
            balanceLabel.setText(R.string.balance);
            if (customer.getMobile() == null) {
                msg.setText(R.string.delcst_msg_no_mobile);
            } else {
                msg.setText(R.string.delcst_msg);
            }

            deleteContainer.setVisibility(View.VISIBLE);
            settlement.setVisibility(View.GONE);
        } else {
            msg.setText(R.string.delcst_msg_settlement);
            if (customer.getBalance() < 0.0) {
                balanceLabel.setText(R.string.balance);
                settlementIcon.setImageDrawable(ContextCompat.getDrawable(this, R.drawable
                    .ic_payment));
                settlementLabel.setText(getString(R.string.delcst_settlement_label_payment,
                    CurrencyUtil.format(customer.getBalance())));
            } else if (customer.getBalance() > 0.0) {
                balanceLabel.setText(R.string.advance);
                settlementIcon.setImageDrawable(ContextCompat.getDrawable(this, R.drawable
                    .ic_credit));
                settlementLabel.setText(getString(R.string.delcst_settlement_label_credit,
                    CurrencyUtil.format(customer.getBalance())));
            }
            deleteContainer.setVisibility(View.GONE);
            settlement.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void gotoAddTxnScreen(String customerId, int type, float amount) {
        startActivity(AddTxnActivity.startingIntent(this, customerId, type, amount,
            AddTxnActivity.MODE_RESULT, LifecycleState.NORMAL_FLOW, false));
    }

    @Override
    public void gotoHomeScreen() {
        startActivity(HomeActivity.startingIntent(this));
        finish();
    }

    @Override
    public void showIncorrectPasswordError() {
        passwordContainer.setErrorEnabled(true);
        passwordContainer.setError(getString(R.string.txn_incorrect_password));

        Analytics.track(AnalyticsEvents.DELETE_CUSTOMER_INCORRECT_PASSWORD);
    }

    @Override
    public void showLoading() {
        loading.setVisibility(View.VISIBLE);
        deleteContainer.setVisibility(View.GONE);
    }

    @Override
    public void hideLoading() {
        loading.setVisibility(View.GONE);
        deleteContainer.setVisibility(View.VISIBLE);
    }

    @Override
    public void gotoLogin() {
        super.gotoLogin();
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "delete cst")
                .with("type", "auth error")
        );
    }
}
