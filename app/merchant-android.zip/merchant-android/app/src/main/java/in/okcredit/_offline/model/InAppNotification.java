package in.okcredit._offline.model;

/**
 * Created by harsh on 17/01/18.
 */

public class InAppNotification {
    public static final int TYPE_APP_LOCK = 1;
    public static final int TYPE_UPDATE = 2;
    public static final int TYPE_REMINDER_TO_BE_SENT = 3;
    public static final int TYPE_SHARE = 4;
    public static final int TYPE_EMPTY = 5;
    public static final int TYPE_RATING = 6;

    private int type;
    private int day;

    public InAppNotification(int type, int day) {
        this.type = type;
        this.day = day;
    }

    public InAppNotification(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }

    public int getDay() {
        return day;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        InAppNotification that = (InAppNotification) o;

        return type == that.type;
    }

    @Override
    public int hashCode() {
        return type;
    }
}
