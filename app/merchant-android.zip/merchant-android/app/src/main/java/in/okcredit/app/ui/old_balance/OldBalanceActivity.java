package in.okcredit.app.ui.old_balance;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.joda.time.DateTime;

import java.util.HashMap;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import dagger.android.AndroidInjection;
import in.okcredit.AudioUrl;
import in.okcredit.LifecycleState;
import in.okcredit.LocaleManager;
import in.okcredit.R;
import in.okcredit.ThreadUtils;
import in.okcredit._offline.model.Customer;
import in.okcredit._offline.model.Transaction;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui.addtxn.AddTxnActivity;
import in.okcredit.util.DateTimeUtils;
import io.reactivex.Completable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

public class OldBalanceActivity extends in.okcredit.app.ui._base_v2.BaseActivity implements
    OldBalanceContract.View {
    public static final String ARG_CUSTOMER = "customer";
    public static final String ARG_LIFECYCLE = "lifecycle";

    public static Intent startingIntent(Context context, @NonNull Customer customer, int lifecycle) {
        Intent intent = new Intent(context, OldBalanceActivity.class);
        intent.putExtra(ARG_CUSTOMER, customer);
        intent.putExtra(ARG_LIFECYCLE, lifecycle);
        return intent;
    }

    /* UI Elements */
    @BindView(R.id.addCredit)
    View addCredit;

    @BindView(R.id.addPayment)
    View addPayment;

    @BindView(R.id.tut_layout)
    RelativeLayout tutorialLayout;

    @BindView(R.id.title)
    TextView tutorialLayoutTitle;

    @BindView(R.id.description)
    TextView tutorialLayoutDesc;

    @BindView(R.id.fabPlay)
    FloatingActionButton fabPlay;

    @BindView(R.id.skip)
    Button skip;

    @BindView(R.id.actionButton)
    LinearLayout tutorialLayoutActionButton;

    @BindView(R.id.name)
    TextView customerName;

    private MediaPlayer mediaPlayer;
    private boolean isAudioPlaying;
    private CompositeDisposable tasks;

    /* Presenter */
    @Inject
    OldBalanceContract.Presenter presenter;

    private Customer customer;
    private int lifecycle;
    private String audioLang;

    /* Lifecycle methods */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AndroidInjection.inject(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.screen_old_balance);
        ButterKnife.bind(this);

        showActionBar(true);
        setTitle(R.string.old_balance_activity_title_bar);

        Analytics.track(AnalyticsEvents.OLD_BALANCE_SCREEN);

        tutorialLayout.setVisibility(View.GONE);

        mediaPlayer = new MediaPlayer();
        tasks = new CompositeDisposable();

        lifecycle = 0;
        audioLang = LocaleManager.getLanguage();

        // Add credit flow
        addCredit.setOnClickListener(v ->
        {
            Analytics.track(
                AnalyticsEvents.OLD_BALANCE_SCREEN_CREDIT_CLICKED,
                EventProperties
                    .create()
                    .with("lifecycle", lifecycle)
            );

            gotoAddCreditScreen(getCustomer());

        });

        // Add payment flow
        addPayment.setOnClickListener(v ->
        {
            Analytics.track(
                AnalyticsEvents.OLD_BALANCE_SCREEN_PAYMENT_CLICKED,
                EventProperties
                    .create()
                    .with("lifecycle", lifecycle)
            );

            gotoAddPaymentScreen(getCustomer());
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.attachView(this);

        if (mediaPlayer == null) {
            mediaPlayer = new MediaPlayer();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        presenter.detachView();
        releaseMediaPlayer();
    }

    private Customer getCustomer() {
        return customer;
    }

    /****************************************************************
     Navigation
     ****************************************************************/
    private void gotoAddCreditScreen(Customer customer) {
        if (customer == null) {
            return;
        }

        if (lifecycle == 0) {
            lifecycle = LifecycleState.NORMAL_FLOW;
        }

        startActivity(AddTxnActivity.startingIntent(this, customer.getId(), Transaction.CREDIT,
            lifecycle, true));
    }

    private void gotoAddPaymentScreen(Customer customer) {
        if (customer == null) {
            return;
        }

        startActivity(AddTxnActivity.startingIntent(this, customer.getId(), Transaction.PAYMENT,
            lifecycle, true));
    }

    @Override
    public void showLoading() {

    }

    @Override
    public void hideLoading() {

    }

    /****************************************************************
     MVP methods
     ****************************************************************/
    @Override
    public void displayCustomerDetails(Customer customer) {
        this.customer = customer;

        customerName.setText(customer.getDescription());
    }

    @Override
    public void setUpTutorialLayout(int lifecycle) {
        this.lifecycle = lifecycle;

        tutorialLayout.setVisibility(View.VISIBLE);
        tutorialLayoutActionButton.setVisibility(View.GONE);
        tutorialLayoutTitle.setVisibility(View.GONE);
        tutorialLayoutDesc.setVisibility(View.VISIBLE);
        skip.setVisibility(View.INVISIBLE);
        tutorialLayoutDesc.setText(getString(R.string.old_balance_screen_tut_desc, DateTimeUtils.formatDateOnly(DateTime
            .now())));

        if (lifecycle == LifecycleState.TRIAL_ADD_CUSTOMER) {
            fabPlay.show();

            switch (audioLang) {
                case LocaleManager.LANGUAGE_ENGLISH:
                    setAudio(AudioUrl.OLD_BALANCE_SCREEN_EN);
                    break;
                case LocaleManager.LANGUAGE_HINDI:
                    setAudio(AudioUrl.OLD_BALANCE_SCREEN_HI);
                    break;
                case LocaleManager.LANGUAGE_MALAYALAM:
                    setAudio(AudioUrl.OLD_BALANCE_SCREEN_ML);
                    break;
                default:
                    setAudio(AudioUrl.OLD_BALANCE_SCREEN_HI);
                    break;
            }

            fabPlay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Analytics.track(
                        AnalyticsEvents.AUDIO_CLICKED,
                        EventProperties
                            .create()
                            .with("screen", "old balance")
                            .with("wasAudioPlaying", isAudioPlaying)
                            .with("lifecycle", lifecycle)
                    );

                    isAudioPlaying = !isAudioPlaying;
                    setAudioState(isAudioPlaying);
                }
            });
        } else {
            fabPlay.hide();
            releaseMediaPlayer();
        }
    }

    public void setAudio(String audioUrl) {
        fabPlay.setImageDrawable(ContextCompat.getDrawable(OldBalanceActivity.this, R
            .drawable.ic_pause));

        fabPlay.setClickable(false);

        Disposable task = Completable
            .fromAction(() -> {
                mediaPlayer.setDataSource(this, Uri.parse(audioUrl), new HashMap<>());
                mediaPlayer.prepare();
            })
            .subscribeOn(ThreadUtils.newThread())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                () -> {
                    Analytics.track(
                        AnalyticsEvents.AUDIO_STARTED,
                        EventProperties
                            .create()
                            .with("screen", "old balance")
                            .with("lifecycle", lifecycle)
                    );

                    setAudioState(true);
                    fabPlay.setClickable(true);
                },
                throwable -> Timber.e(throwable)
            );

        if (mediaPlayer != null) {
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    Analytics.track(
                        AnalyticsEvents.AUDIO_COMPLETE,
                        EventProperties
                            .create()
                            .with("screen", "old balance")
                            .with("lifecycle", lifecycle)
                    );

                    fabPlay.setImageDrawable(ContextCompat.getDrawable(OldBalanceActivity.this, R
                        .drawable.ic_play));
                    isAudioPlaying = false;
                }
            });
        }

        tasks.add(task);
    }

    private void setAudioState(boolean playAudio) {
        if (mediaPlayer == null) {
            return;
        }

        isAudioPlaying = playAudio;
        if (playAudio) {
            mediaPlayer.start();
            fabPlay.setImageDrawable(ContextCompat.getDrawable(OldBalanceActivity.this, R
                .drawable.ic_pause));
        } else {
            mediaPlayer.pause();
            fabPlay.setImageDrawable(ContextCompat.getDrawable(OldBalanceActivity.this, R
                .drawable.ic_play));
        }
    }

    private void releaseMediaPlayer() {
        try {
            if (mediaPlayer != null) {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                mediaPlayer.release();
                mediaPlayer = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void showError() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "old balance")
                .with("type", "server error")
        );

        Toast.makeText(this, R.string.err_default, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(this, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
            }
        });
    }
}
