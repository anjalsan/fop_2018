package in.okcredit.app.ui.customer_statement._di;

import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import in.okcredit._di.PresenterParam;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit.app.ui.customer.CustomerActivity;
import in.okcredit.app.ui.customer.CustomerDetails;
import in.okcredit.app.ui.customer.CustomerDetailsPresenter;
import in.okcredit.app.ui.customer_statement.CustomerStatementActivity;
import in.okcredit.app.ui.customer_statement.CustomerStatementContract;
import in.okcredit.app.ui.customer_statement.CustomerStatementPresenter;

@Module
public class CustomerStatementActivity_Module {

//    @Binds
//    @ActivityScope
//    public abstract CustomerStatementContract.Presenter presenter(CustomerStatementPresenter presenter);

    @Provides
    @ActivityScope
    @PresenterParam("customer_id")
    public String customerId(CustomerStatementActivity activity) {
        return activity.getIntent().getStringExtra(CustomerStatementActivity.ARG_CUSTOMER_ID);
    }

    @Provides
    @ActivityScope
    @PresenterParam("lifecycle")
    public int lifecycle(CustomerStatementActivity activity) {
        return activity.getIntent().getIntExtra(CustomerStatementActivity.ARG_LIFECYCLE, 0);
    }

    @Provides
    @ActivityScope
    public CustomerStatementContract.Presenter presenter(CustomerStatementPresenter presenter) {
        return presenter;
    }
}
