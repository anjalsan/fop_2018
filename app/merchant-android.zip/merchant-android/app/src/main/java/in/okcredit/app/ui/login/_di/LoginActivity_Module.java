package in.okcredit.app.ui.login._di;

import android.support.annotation.Nullable;

import dagger.Module;
import dagger.Provides;
import in.okcredit._di.PresenterParam;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit.app.ui.login.Login;
import in.okcredit.app.ui.login.LoginActivity;
import in.okcredit.app.ui.login.LoginPresenter;

@Module
public class LoginActivity_Module {
    @Provides
    @ActivityScope
    @Nullable
    @PresenterParam("mobile")
    public String mobile(LoginActivity activity) {
        return activity.getIntent().getStringExtra(LoginActivity.ARG_MOBILE);
    }

    @Provides
    @ActivityScope
    public Login.Presenter presenter(LoginPresenter presenter) {
        return presenter;
    }
}
