package in.okcredit.app.ui.delete_txn;

import javax.inject.Inject;

import in.okcredit._di.PresenterParam;
import in.okcredit._di.UiThread;
import in.okcredit._offline.usecase.DeleteTransaction;
import in.okcredit._offline.usecase.GetTransaction;
import in.okcredit.app.ui._base_v2.BasePresenter;
import in.okcredit.domain.auth.AuthErrors;
import io.reactivex.Scheduler;

public class DeleteTxnPresenter extends BasePresenter<DeleteTxnContract.View>
    implements DeleteTxnContract.Presenter {

    private String transactionId;

    private GetTransaction getTransaction;
    private DeleteTransaction deleteTransaction;

    @Inject
    public DeleteTxnPresenter(@UiThread Scheduler uiScheduler,
                              @PresenterParam("tx_id") String transactionId,
                              GetTransaction getTransaction,
                              DeleteTransaction deleteTransaction) {
        super(uiScheduler);
        this.transactionId = transactionId;
        this.getTransaction = getTransaction;
        this.deleteTransaction = deleteTransaction;
    }

    @Override
    protected void loadData() {

        addTask(
            getTransaction
                .execute(transactionId)
                .observeOn(uiScheduler)
                .subscribe(
                    transaction1 -> ifAttached(view -> view.setTransaction(transaction1)),
                    throwable -> ifAttached(view -> view.showError())
                )
        );
    }

    @Override
    public void onInternetRestored() {
        loadData();
    }

    @Override
    public void onAuthenticationRestored() {
        loadData();
    }

    @Override
    public void delete(String password, String transactionId) {

        ifAttached(view -> view.showLoading());

        addTask(deleteTransaction
            .execute(transactionId, password)
            .observeOn(uiScheduler)
            .subscribe(
                () -> {
                    ifAttached(view -> view.hideLoading());
                    ifAttached(view -> view.goToCustomerScreen());
                },
                throwable -> {
                    if (throwable instanceof AuthErrors.IncorrectPassword) {
                        ifAttached(view -> view.hideLoading());
                        ifAttached(view -> view.showIncorrectPasswordError());
                    } else {
                        ifAttached(view -> view.hideLoading());
                        ifAttached(view -> view.showError());
                    }
                }));
    }

    @Override
    public void onBackPressed() {
        ifAttached(view -> view.gotoTransactionScreen(transactionId));
    }
}
