package in.okcredit.app.ui._dialog;

import android.app.Activity;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import in.okcredit.R;

public final class UpdatePasswordDialog {
    public interface Listener {
        void onConfirm(String oldPassword, String newPassword);
    }

    public static AlertDialog show(Activity activity, Listener listener) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setCancelable(true);

        LayoutInflater layoutInflater = activity.getLayoutInflater();
        View dialogView = layoutInflater.inflate(R.layout.view_update_password, null);
        builder.setView(dialogView);

        TextInputLayout passwordContainer = dialogView.findViewById(R.id.passwordContainer);
        EditText password = dialogView.findViewById(R.id.password);
        TextInputLayout newPasswordContainer = dialogView.findViewById(R.id.newPasswordContainer);
        EditText newPassword = dialogView.findViewById(R.id.newPassword);
        Button save = dialogView.findViewById(R.id.save);

        passwordContainer.setErrorEnabled(false);
        newPasswordContainer.setErrorEnabled(false);

        AlertDialog alertDialog = builder.create();
        save.setOnClickListener(v ->
        {
            if (listener == null)
                return;

            boolean isError = false;
            if (TextUtils.isEmpty(password.getText().toString())) {
                passwordContainer.setErrorEnabled(true);
                passwordContainer.setError(activity.getString(R.string.err_invalid_password));
                isError = true;
            }

            if (newPassword == null || newPassword.getText().toString().length() < 6) {
                newPasswordContainer.setErrorEnabled(true);
                newPasswordContainer.setError(activity.getString(R.string.err_invalid_password));
                isError = true;
            }

            if (!isError)
                listener.onConfirm(password.getText().toString(), newPassword.getText().toString());
        });
        alertDialog.show();
        return alertDialog;
    }

    private UpdatePasswordDialog() {
    }
}
