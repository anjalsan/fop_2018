package in.okcredit.app.ui.language._di;

import dagger.Module;

@Module
public abstract class InAppLanguageActivity_Module {
}
