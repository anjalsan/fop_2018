package in.okcredit._offline.usecase;

import android.support.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import in.okcredit.App;
import in.okcredit._offline.database.MerchantRepo;
import in.okcredit._offline.model.MerchantPreference;
import in.okcredit._offline.server.Server;
import io.reactivex.Completable;

public final class SyncMerchantPreferences {
    private Server server;
    private MerchantRepo merchantRepo;

    @Inject
    public SyncMerchantPreferences(Server server, MerchantRepo merchantRepo) {
        this.server = server;
        this.merchantRepo = merchantRepo;
    }

    public Completable schedule() {
        return Completable
            .fromAction(() -> {
                String id = "sync-merchant-preferences";

                Constraints constraints = new Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build();

                OneTimeWorkRequest workRequest = new OneTimeWorkRequest.Builder(Worker.class)
                    .setConstraints(constraints)
                    .setBackoffCriteria(BackoffPolicy.LINEAR, 30, TimeUnit.SECONDS)
                    .build();

                WorkManager.getInstance()
                           .beginUniqueWork(id, ExistingWorkPolicy.KEEP, workRequest)
                           .enqueue();
            });
    }

    public Completable execute() {
        return merchantRepo
            .getActiveMerchant()
            .firstOrError()
            .flatMapCompletable(merchant ->
                server.getMerchantPreferences()
                      .flatMapCompletable(prefs -> {
                          List<Completable> putPrefs = new ArrayList<>();
                          for (Map.Entry<String, String> pref : prefs.entrySet()) {
                              putPrefs.add(merchantRepo.putMerchantPreference(new MerchantPreference(merchant
                                  .getId(), pref.getKey(), pref.getValue())));
                          }
                          return Completable.merge(putPrefs);
                      })
            );
    }

    public static final class Worker extends androidx.work.Worker {
        @Inject SyncMerchantPreferences syncMerchantPreferences;

        @NonNull
        @Override
        public Result doWork() {
            App.appComponent().inject(this);

            try {
                syncMerchantPreferences.execute();
                return Result.SUCCESS;

            } catch (Exception e) {
                return Result.RETRY;
            }
        }
    }
}
