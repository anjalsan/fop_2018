package in.okcredit.app.ui._dialog;

import android.app.Activity;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import in.okcredit.R;

public final class LogoutConfirmationDialog {
    public interface Listener {
        void onLogoutConfirmed(String password);
    }

    public static AlertDialog show(Activity activity, boolean isPasswordRequired, Listener listener) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setCancelable(true);

        LayoutInflater layoutInflater = activity.getLayoutInflater();
        View dialogView = layoutInflater.inflate(R.layout.view_logout, null);
        builder.setView(dialogView);

        View passwordContainer = dialogView.findViewById(R.id.passwordContainer);
        TextInputLayout passwordTil = dialogView.findViewById(R.id.passwordTil);
        EditText password = dialogView.findViewById(R.id.password);
        Button logout = dialogView.findViewById(R.id.logout);
        Button cancel = dialogView.findViewById(R.id.cancel);

        if (isPasswordRequired)
            passwordContainer.setVisibility(View.VISIBLE);
        else
            passwordContainer.setVisibility(View.GONE);

        AlertDialog alertDialog = builder.create();
        logout.setOnClickListener(v ->
        {
            if (listener != null)
                listener.onLogoutConfirmed(password.getText().toString());
        });
        cancel.setOnClickListener(v -> alertDialog.dismiss());
        alertDialog.show();

        if (isPasswordRequired) {
            password.requestFocus();
            alertDialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }

        return alertDialog;
    }

    private LogoutConfirmationDialog() {
    }
}
