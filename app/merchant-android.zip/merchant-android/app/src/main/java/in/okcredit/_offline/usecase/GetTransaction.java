package in.okcredit._offline.usecase;

import javax.inject.Inject;

import in.okcredit._offline.database.TransactionRepo;
import in.okcredit._offline.server.Server;
import in.okcredit._offline.model.Transaction;
import io.reactivex.Observable;

public final class GetTransaction {
    private TransactionRepo transactionRepo;
    private Server server;

    @Inject
    public GetTransaction(TransactionRepo transactionRepo, Server server) {
        this.transactionRepo = transactionRepo;
        this.server = server;
    }

    public Observable<Transaction> execute(String txnId) {
        return transactionRepo
            .isTransactionPresent(txnId)
            .flatMapObservable(isPresent -> {
                if (isPresent) {
                    return transactionRepo.getTransaction(txnId);
                } else {
                    return server
                        .getTransaction(txnId)
                        .flatMapCompletable(transaction -> transactionRepo.putTransaction(transaction))
                        .andThen(transactionRepo.getTransaction(txnId));
                }
            });
    }
}
