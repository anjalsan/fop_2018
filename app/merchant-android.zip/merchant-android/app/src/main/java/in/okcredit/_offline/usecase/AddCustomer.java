package in.okcredit._offline.usecase;

import android.util.Pair;
import com.google.common.base.Strings;
import java.util.NoSuchElementException;
import java.util.UUID;
import javax.inject.Inject;
import in.okcredit.Constants;
import in.okcredit._offline.database.CustomerRepo;
import in.okcredit._offline.error.CustomerErrors;
import in.okcredit._offline.model.Customer;
import in.okcredit._offline.server.Server;
import io.reactivex.Single;
import io.reactivex.SingleSource;
import io.reactivex.functions.Function;

public final class AddCustomer {
    private CustomerRepo customerRepo;
    private Server server;
    private SafelySaveCustomer safelySaveCustomer;
    private UploadFile uploadFile;

    @Inject
    public AddCustomer(CustomerRepo customerRepo, Server server, SafelySaveCustomer safelySaveCustomer, UploadFile uploadFile) {
        this.customerRepo = customerRepo;
        this.server = server;
        this.safelySaveCustomer = safelySaveCustomer;
        this.uploadFile = uploadFile;
    }

    public Single<Customer> execute(String desc, String mobile, String localProfileImage, String email) {
        String profileRemoteUrl = null;
        if (localProfileImage != null) {
            profileRemoteUrl = Constants.AWS_RECEIPT_BASE_URL + "/" + UUID.randomUUID().toString() + ".jpg";
        }
        String finalProfileRemoteUrl = profileRemoteUrl;

        return Single
            .zip(
                validateMobile(mobile),
                validateDesc(desc, 0),
                (_mobile, _desc) -> new Pair<>(_desc, _mobile)
            )
            .flatMap(data -> server.addCustomer(data.first, data.second, false, finalProfileRemoteUrl, null))
            .flatMap(customer ->
                safelySaveCustomer.execute(customer)
                                  .andThen(customerRepo.setCustomerSync(customer.getId()))
                                  .andThen(uploadFile.schedule(finalProfileRemoteUrl, localProfileImage))
                                  .andThen(Single.just(customer))
            );
    }

    private Single<String> validateMobile(String mobile) {
        if (Strings.isNullOrEmpty(mobile) || mobile.length() != 10) {
            return Single.just("");
        } else {
            return customerRepo
                .findCustomerByMobile(mobile)
                .flatMap(customer -> {
                    if (customer.getStatus() == 1) {
                        return Single.<String>error(new CustomerErrors.MobileConflict(customer));
                    } else {
                        return Single.just(mobile);
                    }
                })
                .onErrorResumeNext((Function<Throwable, SingleSource<String>>) throwable -> {
                    if (throwable instanceof NoSuchElementException) {
                        return Single.just(mobile);
                    } else {
                        return Single.error(throwable);
                    }
                });
        }
    }

    private Single<String> validateDesc(String desc, int suffix) {
        if (desc == null || desc.length() < 1 || desc.length() > 30) {
            return Single.error(new CustomerErrors.InvalidName());
        }
        return Single.just(desc);

//        String temp = desc;
//        if (suffix > 0) {
//            temp = temp + " " + suffix;
//        }
//        final String _desc = temp;
//
//        return customerRepo
//            .findCustomerMyDesc(_desc)
//            .flatMap(customer -> validateDesc(desc, suffix + 1))
//            .onErrorResumeNext(throwable -> {
//                if (throwable instanceof NoSuchElementException) {
//                    return Single.just(_desc);
//                } else {
//                    return Single.error(throwable);
//                }
//            });
    }
}
