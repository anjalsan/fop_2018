package in.okcredit._offline.usecase;

import android.support.annotation.NonNull;

import org.joda.time.DateTime;
import org.joda.time.Duration;

import java.util.concurrent.TimeUnit;
import javax.inject.Inject;
import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import in.okcredit.App;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.service.phonebook.PhonebookServiceImpl;
import timber.log.Timber;

// Syncs all contacts: profile as well as transactions
public final class SyncContacts {
    public static final int LOAD_FACTOR = 2;

    @Inject
    public SyncContacts() {
    }

    public void schedule() {
        String id = "sync/contacts/*";

        PeriodicWorkRequest workRequest = new PeriodicWorkRequest.Builder(
            Worker.class,
            24,
            TimeUnit.HOURS,
            5,
            TimeUnit.HOURS)
            .build();

        WorkManager.getInstance()
                   .enqueueUniquePeriodicWork(id, ExistingPeriodicWorkPolicy.REPLACE, workRequest);
    }


    public static final class Worker extends androidx.work.Worker {
        @Inject
        SyncContacts syncContacts;

        @Inject PhonebookServiceImpl
            phonebookService;

        @NonNull
        @Override
        public Result doWork() {
            App.appComponent().inject(this);
            try {
                Analytics.track(
                    AnalyticsEvents.SYNC_COMPLETE,
                    EventProperties.create()
                        .with("type", "syncContacts")
                        .with("attempt", String.valueOf(getRunAttemptCount()))
                );

                phonebookService.fetchContacts(null);
                Timber.i("fetch Contacts completed");
                return Result.SUCCESS;
            } catch (Exception e) {
                Analytics.track(
                    AnalyticsEvents.SYNC_ERROR,
                    EventProperties.create()
                        .with("type", "syncContacts")
                        .with("reason", e.getMessage())
                        .with("attempt", String.valueOf(getRunAttemptCount()))
                );

                return Result.RETRY;
            }
        }
    }
}
