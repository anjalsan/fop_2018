package in.okcredit.app.ui.edit_mobile;

import in.okcredit._offline.model.Customer;
import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;

public interface EditMobileContract {
    interface Presenter extends MVP.Presenter<View>,
        BaseContracts.Loading.Presenter<View>,
        BaseContracts.Online.Presenter<View>,
        BaseContracts.Authenticated.Presenter<View> {
        void cancelMobileEditRequest();

        void requestOtp();

        void verifyOtp(String value);
    }

    interface View extends MVP.View, BaseContracts.Loading.View, BaseContracts.Online.View, BaseContracts.Authenticated.View {

        void setCustomerName(String description);

        void setCustomerNewNumber(String mobile);

        void canceledRequest();

        void setResetTimer(long l);

        void enableReset();

        void disableReset();

        void onMobileConflict(Customer conflict);

        void showSendOpt();

        void showChangeMobileSuccess();

        void showExpiredOtpError();

        void showInvalidOtpError();

        void hideErrorText();
    }
}
