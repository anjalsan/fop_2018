package in.okcredit.app.ui.help.main;

import java.util.List;

import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;
import in.okcredit.domain.help.HelpSection;

public interface HelpContract {
    interface View extends MVP.View, BaseContracts.Online.View, BaseContracts.Loading.View, BaseContracts.Authenticated.View {
//        void setYoutube(String videoId);

        void setSections(List<HelpSection> sections);

        void openWhatsapp();
    }

    interface Presenter extends MVP.Presenter<View>,
        BaseContracts.Loading.Presenter<View>,
        BaseContracts.Online.Presenter<View>,
        BaseContracts.Authenticated.Presenter<View> {
        void onWhatsappClicked(boolean addContact);
    }
}
