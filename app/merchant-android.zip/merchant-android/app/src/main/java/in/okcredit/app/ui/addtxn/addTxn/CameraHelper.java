package in.okcredit.app.ui.addtxn.addTxn;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.List;
import java.util.UUID;

import in.okcredit.BuildConfig;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui._base_v2.PermissionGrantListener;
import timber.log.Timber;

public class CameraHelper {
    private File image;
    private WeakReference<BaseActivity> activityRef;

    public CameraHelper(BaseActivity activity) {
        activityRef = new WeakReference<>(activity);
    }

    public Intent getIntent(PermissionGrantListener permissionGrantListener) {
        BaseActivity activity = activityRef.get();
        if (activity == null)
            return null;

        if (activity.requestPermission(Manifest.permission.CAMERA, permissionGrantListener))
            return null;

        Intent captureImageIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (captureImageIntent.resolveActivity(activity.getPackageManager()) == null) {
            Timber.w("No activity to handle image capture");
            return null;
        }

        try {
            image = createImageFile(activity);
        } catch (IOException e) {
            Timber.e(e, "failed to create file");
            return null;
        }

        Uri photoURI = FileProvider.getUriForFile(activity, BuildConfig.APPLICATION_ID + ".provider", image);
        captureImageIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

        // Grant permission to use image file
        List<ResolveInfo> resInfoList = activity
            .getPackageManager()
            .queryIntentActivities(captureImageIntent, PackageManager.MATCH_DEFAULT_ONLY);
        for (ResolveInfo resolveInfo : resInfoList) {
            activity.grantUriPermission(
                resolveInfo.activityInfo.packageName,
                photoURI,
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION
            );
        }
        return captureImageIntent;
    }

    public File getImage() {
        return image;
    }

    private static File createImageFile(Context context) throws IOException {
        File storageDir = new File(context.getFilesDir(), "images");
        if (!storageDir.exists())
            storageDir.mkdirs();
        String fileName = UUID.randomUUID().toString() + ".jpg";
        File image = new File(storageDir, fileName);
        image.createNewFile();
        return image;
    }
}
