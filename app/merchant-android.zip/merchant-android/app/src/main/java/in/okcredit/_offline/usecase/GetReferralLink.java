package in.okcredit._offline.usecase;

import javax.inject.Inject;

import in.okcredit._offline.server.Server;
import io.reactivex.Single;

// Internet
public final class GetReferralLink {
    // todo
    public static final String DEFAULT_REFERRAL_LINK = "https://get.okcredit.in";

    private Server server;

    @Inject
    public GetReferralLink(Server server) {
        this.server = server;
    }

    public Single<String> execute() {
        return server.getReferralLink()
                     .onErrorReturnItem(DEFAULT_REFERRAL_LINK);
    }
}
