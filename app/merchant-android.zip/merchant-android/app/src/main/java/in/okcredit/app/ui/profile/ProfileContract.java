package in.okcredit.app.ui.profile;

import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;
import in.okcredit._offline.model.Merchant;

public interface ProfileContract {
    interface View extends MVP.View,
        BaseContracts.Online.View,
        BaseContracts.Authenticated.View {
        void setMerchant(Merchant merchant);

        void gotoEditNameScreen();
    }

    interface Presenter extends MVP.Presenter<View>,
        BaseContracts.Authenticated.Presenter<View>,
        BaseContracts.Online.Presenter<View> {
        void onEditNameClicked();
    }
}
