package in.okcredit.app.ui.help.section;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerFragment;
import com.google.common.io.LineReader;

import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.Constants;
import in.okcredit.R;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui.help.item.HelpItemActivity;
import in.okcredit.domain.help.HelpItem;
import in.okcredit.domain.help.HelpSection;
import timber.log.Timber;

/**
 * Created by harsh on 20/12/17.
 */

public class HelpSectionActivity extends BaseActivity implements SectionContract.View, HelpItemSelectionListener {
    public static final String EXTRA_HELP_SECTION = "help_section";
    public static final String EXTRA_HELP_SECTION_ID = "help_section_id";

    // Intent
    public static Intent startingIntent(Context context, HelpSection helpSection) {
        Intent intent = new Intent(context, HelpSectionActivity.class);
        intent.putExtra(EXTRA_HELP_SECTION, helpSection);
        intent.putExtra(EXTRA_HELP_SECTION_ID, "");
        return intent;
    }

    // Youtube Fragment
    private YouTubePlayerFragment youtube;

    @BindView(R.id.helpItems)
    RecyclerView helpItems;

    @BindView(R.id.loading)
    LinearLayout loading;

    @BindView(R.id.youtube)
    FrameLayout youtubeLayout;

    // Adapter
    @Inject HelpItemAdapter helpItemAdapter;

    // Presenter
    @Inject SectionContract.Presenter presenter;

    // Lifecycle Methods
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.help_section_activity);
        ButterKnife.bind(this);
        showActionBar(true);

        helpItems.setLayoutManager(new LinearLayoutManager(this));
        helpItems.setAdapter(helpItemAdapter);
        helpItemAdapter.setItemSelectionListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.attachView(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        presenter.detachView();
    }

    @Override
    public void showError() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "help section")
                .with("type", "server error")
        );
        finish();
    }

    @Override
    public void onSelected(HelpItem helpItem) {
        goToItemScreen(helpItem);
    }

    private void goToItemScreen(HelpItem helpItem) {
        startActivity(HelpItemActivity.startingIntent(this, helpItem));
    }

    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(this, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
                onBackPressed();
            }
        });
    }

    @Override
    public void setHelpItems(String helpSectionId, List<HelpItem> helpItems) {
        Analytics.track(
            AnalyticsEvents.HELP_SECTION_SCREEN,
            EventProperties
                .create()
                .with("type", helpSectionId));

        helpItemAdapter.setItems(helpItems);
    }

    @Override
    public void setActionBarTitle(String title) {
        setTitle(title);
    }

    @Override
    public void setYoutube(String videoId) {
        youtube = YouTubePlayerFragment.newInstance();
        getFragmentManager()
            .beginTransaction()
            .replace(R.id.youtube, youtube)
            .commit();

        youtube.initialize(Constants.GOOGLE_API_KEY, new YouTubePlayer.OnInitializedListener() {
            @Override
            public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer
                player, boolean b) {
                player.loadVideo(videoId);
                player.setShowFullscreenButton(false);
                player.setPlayerStateChangeListener(new YouTubePlayer.PlayerStateChangeListener() {
                    @Override
                    public void onLoading() {
                    }

                    @Override
                    public void onLoaded(String s) {
                    }

                    @Override
                    public void onAdStarted() {
                    }

                    @Override
                    public void onVideoStarted() {
                        Analytics.track(
                            AnalyticsEvents.HELP_SECTION_VIDEO_STARTED,
                            EventProperties
                                .create()
                                .with("type", videoId));
                    }

                    @Override
                    public void onVideoEnded() {
                        Analytics.track(
                            AnalyticsEvents.HELP_SECTION_VIDEO_ENDED,
                            EventProperties
                                .create()
                                .with("type", videoId));
                    }

                    @Override
                    public void onError(YouTubePlayer.ErrorReason errorReason) {
                        Timber.e(errorReason.toString());
                        Analytics.track(
                            AnalyticsEvents.HELP_SECTION_VIDEO_FAILED,
                            EventProperties
                                .create()
                                .with("type", videoId));
                    }
                });
            }

            @Override
            public void onInitializationFailure(YouTubePlayer.Provider provider,
                                                YouTubeInitializationResult res) {
                Timber.e("youtube init failed");
                Analytics.track(
                    AnalyticsEvents.HELP_SECTION_VIDEO_FAILED,
                    EventProperties
                        .create()
                        .with("type", videoId));
            }
        });
    }

    @Override
    public void showLoading() {
        youtubeLayout.setVisibility(View.GONE);
        helpItems.setVisibility(View.GONE);
        loading.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideLoading() {
        youtubeLayout.setVisibility(View.VISIBLE);
        helpItems.setVisibility(View.VISIBLE);
        loading.setVisibility(View.GONE);
    }

    @Override
    public void gotoLogin() {
        super.gotoLogin();
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "help section")
                .with("type", "auth error")
        );
    }
}
