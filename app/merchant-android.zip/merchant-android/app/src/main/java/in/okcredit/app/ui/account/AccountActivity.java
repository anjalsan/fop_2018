package in.okcredit.app.ui.account;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.esafirm.rxdownloader.RxDownloader;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;

import java.util.Arrays;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import dagger.android.AndroidInjection;
import in.okcredit.LocaleManager;
import in.okcredit.R;
import in.okcredit._offline.model.Merchant;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base.BaseActivity;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui._utils.CurrencyUtil;
import in.okcredit.app.ui.account_statement.AccountStatementActivity;
import in.okcredit.app.ui.language.InAppLanguageActivity;
import in.okcredit.app.ui.profile.ProfileActivity;
import in.okcredit.app.ui.reminder.ReminderActivity;
import in.okcredit.app.ui.security.SecurityActivity;

public class AccountActivity extends BaseActivity implements Account.View {
    public static Intent startingIntent(Context context) {
        return new Intent(context, AccountActivity.class);
    }

    /* UI Elements */
    @BindView(R.id.balanceLabel)
    TextView balanceLabel;

    @BindView(R.id.balance)
    TextView balance;

    @BindView(R.id.customerCount)
    TextView customerCount;

    @BindView(R.id.accountSummary)
    View accountSummary;

    @BindView(R.id.backup)
    View report;

    @BindView(R.id.profile)
    View profile;

    @BindView(R.id.reminder)
    View reminder;

    @BindView(R.id.language)
    View language;

    @BindView(R.id.security)
    View security;

    @BindView(R.id.reminderStatus)
    TextView reminderStatus;

    @BindView(R.id.activeLanguage)
    TextView activeLanguage;

    AlertDialog updatePasswordDialog;
    ProgressDialog loading;

    boolean reportGenerationInProgress;
    private boolean isReminderStatusFetched;
    private boolean isReminderOn;

    /* Presenter */
    @Inject
    Account.Presenter presenter;

    /* Lifecycle Methods */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AndroidInjection.inject(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.screen_account);
        ButterKnife.bind(this);

        setupActionBar(R.string.account);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        Analytics.track(AnalyticsEvents.ACCOUNT_SCREEN);

        accountSummary.setOnClickListener(v -> gotoAccountStatementScreen());

        report.setOnClickListener(v ->
        {
            Analytics.track(AnalyticsEvents.ACCOUNT_CLICK_DOWNLOAD_REPORT);

            reportGenerationInProgress = true;
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission
                .WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission
                    .WRITE_EXTERNAL_STORAGE}, 0);
                return;
            }
            reportGenerationInProgress = false;
            loading = ProgressDialog.show(AccountActivity.this, "", getString(R.string
                .account_report_loading));
            loading.show();
            presenter.generateYesterdayReport();
        });

        reminder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToReminderActivity();
            }
        });

        language.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToInAppLanguageActivity();
            }
        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToProfileActivity();
            }
        });

        security.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToSecurityScreen();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.attachView(this);
        setLanguage();
    }

    private void setLanguage() {
        String languagePref = LocaleManager.getLanguage();

        switch (languagePref) {
            case LocaleManager.LANGUAGE_ENGLISH:
                activeLanguage.setText(R.string.language_english);
                return;
            case LocaleManager.LANGUAGE_HINDI:
                activeLanguage.setText(R.string.language_hindi);
                return;
            case LocaleManager.LANGUAGE_PUNJABI:
                activeLanguage.setText(R.string.language_punjabi);
                return;
            case LocaleManager.LANGUAGE_MALAYALAM:
                activeLanguage.setText(R.string.language_malayalam);
                return;
            case LocaleManager.LANGUAGE_HINGLISH:
                activeLanguage.setText(R.string.hinglish);
                return;
            default:
                activeLanguage.setText("");
                return;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        presenter.detachView();
        hideDialogs();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == 0) {
            int pos = Arrays.asList(permissions).indexOf(Manifest.permission
                .WRITE_EXTERNAL_STORAGE);
            if (pos != -1) {
                if (grantResults[pos] == PackageManager.PERMISSION_GRANTED) {
                    if (reportGenerationInProgress) {
                        reportGenerationInProgress = false;
                        loading = ProgressDialog.show(AccountActivity.this, "", getString(R.string.report_loading_msg));
                        loading.show();
                        presenter.generateYesterdayReport();
                    }
                }
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    /****************************************************************
     Navigation
     ****************************************************************/
    private void gotoAccountStatementScreen() {
        startActivity(AccountStatementActivity.startingIntent(this));
    }

    private void goToInAppLanguageActivity() {
        startActivity(InAppLanguageActivity.startingIntent(this));
    }

    private void goToReminderActivity() {
        if (isReminderStatusFetched) {
            startActivity(ReminderActivity.startingIntent(this));
        }
    }

    private void goToProfileActivity() {
        startActivity(ProfileActivity.startingIntent(this));
    }

    private void goToSecurityScreen() {
        startActivity(SecurityActivity.startingIntent(this));
    }

    /****************************************************************
     MVP methods
     ****************************************************************/

    @Override
    public void setReminderStatus(boolean isReminderActive) {
        isReminderStatusFetched = true;
        isReminderOn = isReminderActive;

        if (isReminderOn) {
            reminderStatus.setText(R.string.reminder_on);
        } else {
            reminderStatus.setText(R.string.reminder_off);
        }

    }

    @Override
    public void displayMerchantDetails(Merchant merchant) {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(merchant.getName());
        }
    }

    @Override
    public void displayMerchantAccountSummary(float outstandingBalance, int count) {
        customerCount.setText(String.valueOf(count));
        CurrencyUtil.render(outstandingBalance, balance);
        if (outstandingBalance > 0) {
            balanceLabel.setText(R.string.advance);
        } else {
            balanceLabel.setText(R.string.balance);
        }
    }

    @Override
    public void onReportGenerated(String reportUrl) {
        Toast.makeText(this, R.string.account_report_download_started, Toast
            .LENGTH_SHORT).show();

        DateTime yesterdayStart = DateTime.now().withTimeAtStartOfDay();
        String name = String.format("OkCredit_%s_Backup.pdf", yesterdayStart.toString
            (DateTimeFormat.forPattern("dd-MM-yyyy")));
        hideDialogs();

        RxDownloader rxDownloader = new RxDownloader(this);

        rxDownloader
            .download(reportUrl, name, "application/pdf", true) // url, filename, and mimeType
            .subscribe(path ->
            {
            }, throwable ->
            {
            });
    }


    @Override
    public void onError(String tag) {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "account")
                .with("type", tag)
        );

        hideDialogs();
        switch (tag) {
            case "updatePassword":
                Toast.makeText(this, R.string.update_password_failed, Toast.LENGTH_SHORT)
                     .show();
                break;

            case "logout":
                Toast.makeText(this, R.string.logout_failed, Toast.LENGTH_SHORT).show();
                break;

            case "generateYesterdayReport":
                Toast.makeText(this, R.string.report_generation_failed, Toast.LENGTH_SHORT)
                     .show();
                break;

            default:
                Toast.makeText(this, R.string.err_default, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onNetworkFailure() {
        new NetworkErrorDialog().show(this, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                hideDialogs();
                presenter.attachView(AccountActivity.this);
            }

            @Override
            public void onCancel() {
                hideDialogs();
            }
        });
    }

    /* Helper methods */
    private void hideDialogs() {
        if (updatePasswordDialog != null) {
            updatePasswordDialog.dismiss();
            updatePasswordDialog = null;
        }

        if (loading != null) {
            loading.dismiss();
            loading = null;
        }
    }
}
