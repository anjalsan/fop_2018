package in.okcredit.app.ui.help.section;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.R;
import in.okcredit.domain.help.HelpItem;
import in.okcredit.util.GlideApp;

/**
 * Created by harsh on 20/12/17.
 */

public class HelpItemViewHolder extends RecyclerView.ViewHolder {
    public static HelpItemViewHolder create(Context context, ViewGroup parent, HelpItemSelectionListener listener) {
        return new HelpItemViewHolder(
            context,
            LayoutInflater
                .from(context)
                .inflate(R.layout.help_section_item, parent, false),
            listener
        );
    }

    @BindView(R.id.title)
    TextView title;

    @BindView(R.id.subtitle)
    TextView subtitle;

    @BindView(R.id.icon)
    ImageView icon;

    private Context context;
    private HelpItemSelectionListener listener;

    public HelpItemViewHolder(Context context, View itemView, HelpItemSelectionListener listener) {
        super(itemView);
        ButterKnife.bind(this, itemView);
        this.context = context;
        this.listener = listener;
    }

    public void bind(HelpItem helpItem) {
        title.setText(helpItem.getTitle());
        subtitle.setText(helpItem.getSubtitle());

        if (helpItem.getIconUrl() != null) {
            GlideApp.with(context)
                .load(helpItem.getIconUrl())
                .placeholder(R.drawable.ic_placeholder_help)
                .error(R.drawable.ic_placeholder_help)
                .into(icon);
        }

        itemView.setOnClickListener(v ->
        {
            if (listener != null)
                listener.onSelected(helpItem);
        });
    }
}
