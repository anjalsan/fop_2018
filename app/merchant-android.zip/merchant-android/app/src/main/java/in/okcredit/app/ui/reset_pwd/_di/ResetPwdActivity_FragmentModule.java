package in.okcredit.app.ui.reset_pwd._di;

import dagger.Module;
import dagger.android.ContributesAndroidInjector;
import in.okcredit._di.scope.FragmentScope;
import in.okcredit.app.ui.reset_pwd.otp.OtpFragment;
import in.okcredit.app.ui.reset_pwd.password.PasswordFragment;

@Module
public abstract class ResetPwdActivity_FragmentModule {
    @FragmentScope
    @ContributesAndroidInjector(modules = {OtpFragment_Module.class})
    public abstract OtpFragment otpFragment();

    @FragmentScope
    @ContributesAndroidInjector(modules = {PasswordFragment_Module.class})
    public abstract PasswordFragment passwordFragment();
}
