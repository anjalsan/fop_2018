package in.okcredit.app.ui.home;

import com.airbnb.epoxy.AutoModel;
import com.airbnb.epoxy.EpoxyController;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import in.okcredit._offline.model.Customer;
import in.okcredit._offline.model.InAppNotification;
import in.okcredit.app.ui.home.viewModels.AddCustomerViewModel_;
import in.okcredit.app.ui.home.viewModels.ContactHeaderViewModel_;
import in.okcredit.app.ui.home.viewModels.ContactItemViewModel_;
import in.okcredit.app.ui.home.viewModels.CustomerItemViewModel_;
import in.okcredit.app.ui.home.viewModels.ImportContactViewModel_;
import in.okcredit.app.ui.home.viewModels.InAppNotificationViewModel_;
import in.okcredit.service.phonebook.ContactModel;

public class HomeController extends EpoxyController {
    private HomeActivity homeActivity;

    private List<Customer> customers;
    private List<ContactModel> contacts;
    private int percentage = 0;
    private boolean contactImportViewVisibility = false;
    private boolean addCustomerViewVisibility = false;
    private boolean inAppNotificationVisibility = false;
    private boolean inContactPermissionDenied = false;
    private String searchQuery = "";
    private InAppNotification inAppNotification;

    @AutoModel
    ImportContactViewModel_ importContactViewModel_;

    @AutoModel
    ContactHeaderViewModel_ contactHeaderViewModel_;

    @AutoModel
    AddCustomerViewModel_ addCusomerViewModel_;

    @AutoModel
    InAppNotificationViewModel_ inAppNotificationViewModel_;

    @Inject
    public HomeController(HomeActivity homeActivity) {
        this.homeActivity = homeActivity;
        setDebugLoggingEnabled(true);
    }

    public void setCustomers(List<Customer> customers) {
        this.customers = customers;
        this.contacts = filterContacts(contacts, customers);
        requestModelBuild();
    }

    public void setCustomersAndContacts(List<Customer> customers, List<ContactModel> contacts) {
        this.customers = customers;
        this.contacts = filterContacts(contacts, customers);
        requestModelBuild();
    }

    public void setContacts(List<ContactModel> contacts) {
        this.contacts = filterContacts(contacts, customers);
        requestModelBuild();
    }

    private List<ContactModel> filterContacts(List<ContactModel> contacts, List<Customer> customers) {
        if(customers == null || customers.size() == 0 || contacts == null || contacts.size() == 0) {
            return contacts;
        } else {
            List<ContactModel> filteredContacts = new ArrayList<>();
            for (ContactModel contactModel: contacts) {
                boolean found = false;
                for (Customer customer: customers){
                    if (customer.getMobile() != null && customer.getMobile().equals(contactModel.mobile)) {
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    filteredContacts.add(contactModel);
                }
            }
            return filteredContacts;
        }
    }

    public void setPercentage(int percentage) {
        this.percentage = percentage;
        requestModelBuild();
    }

    public void setIsPermissionContactDenied(boolean visible) {
        this.inContactPermissionDenied = visible;
    }

    public void setContactImportViewVisibility(boolean visibility) {
        this.contactImportViewVisibility = visibility;
    }

    public void setAddCustomerViewVisibility(boolean visibility, String query) {
        this.addCustomerViewVisibility = visibility;
        this.searchQuery = query;
        requestModelBuild();
    }

    public void setInAppNotification(InAppNotification inAppNotification) {
        this.inAppNotification = inAppNotification;
    }

    public void setInAppNotificationVisibility(boolean visibility) {
        this.inAppNotificationVisibility = visibility;
        requestModelBuild();
    }

    @Override
    protected void buildModels() {
        if (inAppNotificationVisibility){
            inAppNotificationViewModel_
                .listener(homeActivity)
                .type(inAppNotification)
                .addTo(this);
        }
        if (customers != null && customers.size() > 0) {
            for (int i=0; i< customers.size(); i++) {
                new CustomerItemViewModel_()
                    .id(customers.get(i).getId())
                    .customer(customers.get(i))
                    .listener(homeActivity)
                    .addTo(this);
            }
        } else if (addCustomerViewVisibility){
            addCusomerViewModel_
                .listener(homeActivity)
                .query(searchQuery)
                .addTo(this);
        }
        if (contacts != null && contacts.size() > 0 && percentage == 0) {
            contactHeaderViewModel_
                .listener(homeActivity)
                .addTo(this);

            for (ContactModel contact : contacts) {
                new ContactItemViewModel_()
                    .id(contact.id)
                    .contact(contact)
                    .listener(homeActivity)
                    .addTo(this);
            }
        } else if (contactImportViewVisibility) {
            importContactViewModel_
                .listener(homeActivity)
                .iconColor(inContactPermissionDenied)
                .percentage(percentage)
                .addTo(this);
        }
    }
}
