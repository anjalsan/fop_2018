package in.okcredit.app.ui.home;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.transition.TransitionManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.airbnb.deeplinkdispatch.DeepLink;
import com.amulyakhare.textdrawable.TextDrawable;
import com.amulyakhare.textdrawable.util.ColorGenerator;
import com.appsee.Appsee;
import com.arlib.floatingsearchview.FloatingSearchView;
import com.getkeepsafe.taptargetview.TapTarget;
import com.getkeepsafe.taptargetview.TapTargetView;
import com.google.gson.Gson;
import com.mikepenz.materialdrawer.AccountHeader;
import com.mikepenz.materialdrawer.AccountHeaderBuilder;
import com.mikepenz.materialdrawer.Drawer;
import com.mikepenz.materialdrawer.DrawerBuilder;
import com.mikepenz.materialdrawer.model.DividerDrawerItem;
import com.mikepenz.materialdrawer.model.PrimaryDrawerItem;
import com.mikepenz.materialdrawer.model.ProfileDrawerItem;

import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import dagger.android.AndroidInjection;
import in.okcredit.AudioUrl;
import in.okcredit.BuildConfig;
import in.okcredit.Constants;
import in.okcredit.LifecycleState;
import in.okcredit.LocaleManager;
import in.okcredit.R;
import in.okcredit.ThreadUtils;
import in.okcredit._offline.model.Customer;
import in.okcredit._offline.model.InAppNotification;
import in.okcredit._offline.model.Merchant;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.service.notification.DeepLinkUrl;
import in.okcredit.app.service.notification.NotificationWorker;
import in.okcredit.app.ui._base.BaseActivity;
import in.okcredit.app.ui._dialog.LogoutConfirmationDialog;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui._utils.CurrencyUtil;
import in.okcredit.app.ui._utils.DrawableUtil;
import in.okcredit.app.ui._utils.KeyboardUtil;
import in.okcredit.app.ui.account.AccountActivity;
import in.okcredit.app.ui.app_lock.preference.AppLockPrefActivity;
import in.okcredit.app.ui.customer.CustomerActivity;
import in.okcredit.app.ui.help.main.HelpActivity;
import in.okcredit.app.ui.home.viewModels.AddCustomerView;
import in.okcredit.app.ui.home.viewModels.ContactHeaderView;
import in.okcredit.app.ui.home.viewModels.ContactItemView;
import in.okcredit.app.ui.home.viewModels.CustomerItemView;
import in.okcredit.app.ui.home.viewModels.ImportContactView;
import in.okcredit.app.ui.home.viewModels.InAppNotificationView;
import in.okcredit.app.ui.language.LanguageActivity;
import in.okcredit.app.ui.rating.RatingActivity;
import in.okcredit.app.ui.share.ShareActivity;
import in.okcredit.service.keyval.KeyValService;
import in.okcredit.service.phonebook.ContactModel;
import in.okcredit.util.AnimationUtils;
import in.okcredit.util.ShareHelper;
import in.okcredit.util.fabAnimation.FabToBottomContainerAnim;
import in.okcredit.util.keyboardUtils.KeyboardVisibilityEvent;
import in.okcredit.util.keyboardUtils.KeyboardVisibilityEventListener;
import io.reactivex.Completable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import timber.log.Timber;

@DeepLink(DeepLinkUrl.HOME)
public class HomeActivity extends BaseActivity implements HomeScreenContract.View,
    CustomerItemView.CustomerSelectionListener, ImportContactView.ImportContactListener,
    ContactHeaderView.ContactHeaderListener, ContactItemView.ContactSelectionListener,
    AddCustomerView.AddCustomerListener, InAppNotificationView.InAppNotificationListener {

    public static final int ADD_CUSTOMER_STATE_BUTTON = 0, ADD_CUSTOMER_STATE_NAME_TEXT = 1, ADD_CUSTOMER_STATE_PHONE_TEXT = 2;
    private static final int REQ_CODE_CONTACT_PERMISSION = 1;
    private HomeController homeController;
    private List<ContactModel> contacts = new ArrayList<>();
    private TapTargetView tapTargetView;

    private static final String KEY_ADD_CUSTOMER_TUTORIAL_VIEWED = "tutorial.add_customer_viewed";
    private static final String KEY_ADD_CUSTOMER_NAME_TUTORIAL_VIEWED = "tutorial.add_customer_name_viewed";
    private static final String KEY_ADD_CUSTOMER_MOBILE_TUTORIAL_VIEWED = "tutorial.add_customer_mobile_viewed";

    public static Intent startingIntent(Context context) {
        Intent intent = new Intent(context, HomeActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return intent;
    }

    /* UI Elements */

    @BindView(R.id.search)
    FloatingSearchView search;

    @BindView(R.id.sort)
    View sort;

    @BindView(R.id.loading)
    View loading;

    @BindView(R.id.customerList)
    RecyclerView customerList;

    @BindView(R.id.dimLayout)
    FrameLayout dimLayout;

    @BindView(R.id.search_layout)
    LinearLayout searchLayout;

    @BindView(R.id.listContainer)
    LinearLayout listContainer;

    @BindView(R.id.customer_tile)
    View customerTile;

    @BindView(R.id.desc)
    TextView customerName;

    @BindView(R.id.lastPayment)
    TextView lastPayment;

    @BindView(R.id.balance)
    TextView balance;

    @BindView(R.id.pic)
    ImageView pic;

    @BindView(R.id.balanceStatus)
    TextView balanceStatus;

    @BindView(R.id.warning)
    ImageView warning;

    @BindView(R.id.tut_card)
    View tutCard;

    @BindView(R.id.title)
    TextView tutTitle;

    @BindView(R.id.subtitle)
    TextView tutSubtitle;

    @BindView(R.id.input_name)
    AppCompatEditText inputName;

    @BindView(R.id.input_phone)
    EditText inputPhone;

    @BindView(R.id.icon)
    ImageView tutIcon;

    @BindView(R.id.audioButton)
    ImageView tutAudioButton;

    @BindView(R.id.rootView)
    CoordinatorLayout rootView;

    @BindView(R.id.name_container)
    RelativeLayout nameContainer;

    @BindView(R.id.phone_container)
    RelativeLayout phoneContainer;

    @BindView(R.id.name_button)
    FloatingActionButton nameDone;

    @BindView(R.id.phone_button)
    FloatingActionButton phoneDone;

    // Error
    @BindView(R.id.error)
    View error;

    @BindView(R.id.errorMessage)
    TextView errorMessage;

    @BindView(R.id.tryAgain)
    Button tryAgain;

    @BindView(R.id.fabAddCustomer)
    FloatingActionButton fabAddCustomer;

    @BindView(R.id.loader)
    CardView addCustomerLoader;

    @BindView(R.id.error_name)
    TextView errorName;

    @BindView(R.id.counter_name)
    TextView counterName;

    @BindView(R.id.error_phone)
    TextView errorPhone;

    @BindView(R.id.counter_phone)
    TextView counterPhone;

    @BindView(R.id.button_container_name)
    FrameLayout buttonContainerName;

    AlertDialog logoutConfirmationDialog;
    PopupMenu sortMenu;

    // Navigation Drawer
    Drawer drawer;
    AccountHeader accountHeader;
    ProfileDrawerItem profile;
    PrimaryDrawerItem account;
    PrimaryDrawerItem share;
    PrimaryDrawerItem help;
    PrimaryDrawerItem about;
    PrimaryDrawerItem privacy;
    PrimaryDrawerItem logout;

    @BindView(R.id.placeholder) View placeholder;

    /* Presenter */
    @Inject
    HomeScreenContract.Presenter presenter;

    List<Customer> customers;
    String query;

    private MediaPlayer mediaPlayer;
    private boolean isAudioPlaying;
    private CompositeDisposable tasks;
    private Context context;
    private FabToBottomContainerAnim anim;
    private boolean isSinglePressed = false;

    @Inject
    ShareHelper shareHelper;

    @Inject
    NotificationWorker notificationWorker;

    @Inject
    KeyValService keyValService;

    Disposable shareImageTask;

    private int lifecycle;
    private String audioLang;
    private int addCustomerCurrentState = ADD_CUSTOMER_STATE_BUTTON;

    // internet handling
    MenuItem sync;
    boolean isInternetAvailable = true;

    @OnClick(R.id.fabAddCustomer)
    public void onAddCustomerFabClicked() {
        Analytics.track(AnalyticsEvents.HOME_CLICK_ADD_CUSTOMER_FAB);

        setAddCustomerState(ADD_CUSTOMER_STATE_NAME_TEXT);
    }

    /* Lifecycle methods */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AndroidInjection.inject(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.screen_home);
        ButterKnife.bind(this);
        context = this;
        anim = new FabToBottomContainerAnim(context, fabAddCustomer, nameContainer);

//        if (BuildConfig.DEBUG) {
//            callNotificationTesting();
//        }

        Analytics.track(AnalyticsEvents.HOME_SCREEN);

        // Setup toolbar
        setupActionBar(R.string.app_name);

        // Navigation drawer
        setupNavigationDrawer();

        // Disabling Android O auto-fill service
        disableAutoFill();

        mediaPlayer = new MediaPlayer();
        tasks = new CompositeDisposable();

        homeController = new HomeController(this);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
        homeController.getAdapter()
          .registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
              @Override
              public void onItemRangeInserted(int positionStart, int itemCount) {
                  if (positionStart == 0) {
                      linearLayoutManager.scrollToPosition(0);
                  }
              }
          });
        customerList.setLayoutManager(linearLayoutManager);
        customerList.setAdapter(homeController.getAdapter());

        tutCard.setVisibility(View.GONE);
        homeController.setInAppNotificationVisibility(false);

        lifecycle = 0;
        audioLang = LocaleManager.getLanguage();

        // Setup search
        search.setOnQueryChangeListener((oldQuery, newQuery) ->
        {
            query = newQuery;
            if (contacts == null || contacts.size() == 0) {
                homeController.setContactImportViewVisibility(true);
            }
            if(query != null && query.length() == 1) {
                disableCollapse();
            } else if(query.length() == 0){
                enableCollapse();
            }
            if(oldQuery == null) {
                oldQuery="";
            }
            if(newQuery == null) {
                newQuery="";
            }
            if(oldQuery.length() > 1 && newQuery.length() == 0){
                search.clearFocus();
            }
            if(oldQuery.length() == 0 && newQuery.length() == 1){
                Analytics.track(AnalyticsEvents.SEARCH_BAR_CLICKED);
            }

            refreshRecyclerView();
        });

        // Setup "try again"
        tryAgain.setOnClickListener(v ->
        {
            presenter.refresh();
            Analytics.track(AnalyticsEvents.HOME_TRY_AGAIN);
        });

        customerList.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }
        });

        customerList.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dy > 0 && fabAddCustomer.getVisibility() == View.VISIBLE && addCustomerCurrentState == ADD_CUSTOMER_STATE_BUTTON) {
                    fabAddCustomer.hide();
                } else if (dy < 0 && fabAddCustomer.getVisibility() != View.VISIBLE && addCustomerCurrentState == ADD_CUSTOMER_STATE_BUTTON) {
                    fabAddCustomer.show();
                }
            }
        });

        tutAudioButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Analytics.track(
                    AnalyticsEvents.AUDIO_CLICKED,
                    EventProperties
                        .create()
                        .with("screen", "home")
                        .with("wasAudioPlaying", isAudioPlaying)
                        .with("lifecycle", lifecycle)
                );

                isAudioPlaying = !isAudioPlaying;
                setAudioState(isAudioPlaying);
            }
        });

        nameDone.setOnClickListener(view -> {
            presenter.proceedName(inputName.getText().toString());
            Analytics.track(AnalyticsEvents.ADD_CUSTOMER_NAME_ENTERED);
        });

        inputName.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event){
                if(actionId == EditorInfo.IME_ACTION_DONE){
                    presenter.proceedName(inputName.getText().toString());
                    Analytics.track(AnalyticsEvents.ADD_CUSTOMER_NAME_ENTERED);
                    return true;
                }
                return false;
            }
        });

        phoneDone.setOnClickListener(view -> {
            presenter.proceedPhone(inputPhone.getText().toString(), inputName.getText().toString(), null, null, false);
        });

        inputPhone.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                presenter.proceedPhone(inputPhone.getText().toString(), inputName.getText().toString(), null, null, false);
                return true;
            }
            return false;
        });

        sort.setOnClickListener(view -> showSortMenu());
        setepKeyBoard();
        textChangedListener();
    }

    private void callNotificationTesting() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("primary_action", "https://okcredit.app/merchant/v1/help");
//        map.put("primary_action", null);
//        map.put("primary_action", "https://www.google.com/");
        map.put("title", "title");
        map.put("content", "desc");
        map.put("visible", "true");
        map.put("priority", "5");
        map.put("expire_time", "1932603200");
        map.put("btn_enabled", "false");
        map.put("btn_primary_label", "Yes");
        map.put("btn_secondary_label", "No");
        map.put("_campaign_id", "this_is_campaign_id");
        map.put("_subcampaign_id", "this_is_subcampaign_id");
        map.put("image_url", "https://wallpapercave.com/wp/p143WJX.jpg");
//
        String value = new Gson().toJson(map);
//
        notificationWorker
            .schedule("asfdsfsdf", value)
            .subscribeOn(Schedulers.io())
            .subscribe(
                () -> Timber.i("notification successfully scheduled"),
                throwable -> Timber.e(throwable, "notification failed")
            );
    }

    private void textChangedListener() {
        inputPhone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                String text = editable.toString();

                if (text.length() == 0 || text.length() == 1 || text.length() == 10 || text.length() == 11) {
                    TransitionManager.beginDelayedTransition(phoneContainer);
                }

                if (text.length() > 0) {
                    phoneDone.setImageResource(R.drawable.ic_check);
                } else {
                    phoneDone.setImageResource(R.drawable.ic_arrow_right);
                }

                if (text.length() > 10) {
                    errorPhone.setText(getString(R.string.invalid_phone));
                    errorPhone.setVisibility(View.VISIBLE);

                    counterPhone.setText(String.format("%d/10", text.length()));
                    counterPhone.setVisibility(View.VISIBLE);
                } else {
                    errorPhone.setVisibility(View.GONE);
                    counterPhone.setVisibility(View.GONE);
                }
            }
        });

        inputName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                String text = editable.toString();

                if (text.length() == 0 || text.length() == 1 || text.length() == 29 || text.length() == 30 || text.length() == 31) {
                    TransitionManager.beginDelayedTransition(nameContainer);
                }

                if (text.length() > 0) {
                    nameDone.setVisibility(View.VISIBLE);
                    buttonContainerName.setVisibility(View.VISIBLE);
                } else {
                    nameDone.setVisibility(View.GONE);
                    buttonContainerName.setVisibility(View.GONE);
                }
                if (text.length() == 30) {
                    errorName.setVisibility(View.VISIBLE);
                    errorName.setText(getString(R.string.name_should_not));

                    counterName.setVisibility(View.VISIBLE);
                    counterName.setText(String.format("%d/30", text.length()));
                } else {
                    errorName.setVisibility(View.GONE);
                    counterName.setVisibility(View.GONE);
                }
            }
        });
    }

    private void setepKeyBoard() {
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        KeyboardVisibilityEvent.setEventListener(
            HomeActivity.this,
            new KeyboardVisibilityEventListener() {
                @Override
                public void onVisibilityChanged(boolean isOpen) {
                    if (!isOpen) {
                        inputName.clearFocus();
                        if (query == null ){
                            query = "";
                        }
                        if (query.length() == 0) {
                            if (addCustomerCurrentState == ADD_CUSTOMER_STATE_BUTTON) {
                                setAddCustomerState(ADD_CUSTOMER_STATE_BUTTON);
                            } else if(addCustomerCurrentState == ADD_CUSTOMER_STATE_NAME_TEXT) {
                                setAddCustomerState(ADD_CUSTOMER_STATE_BUTTON);
                            } else if(addCustomerCurrentState == ADD_CUSTOMER_STATE_PHONE_TEXT) {
                                setAddCustomerState(ADD_CUSTOMER_STATE_NAME_TEXT);
                                return;
                            }
                        } else if(addCustomerCurrentState == ADD_CUSTOMER_STATE_NAME_TEXT){
                            KeyboardVisibilityEvent.showKeyboard(context, inputName, rootView);
                        }
                        AnimationUtils.fadeOut(dimLayout);
                        Disposable subscribe = Completable
                            .timer(300, TimeUnit.MILLISECONDS)
                            .subscribeOn(Schedulers.io())
                            .observeOn(AndroidSchedulers.mainThread())
                            .subscribe(() -> dimLayout.setVisibility(View.GONE));
                    } else {
                        if (nameContainer.getVisibility() == View.VISIBLE ||
                            phoneContainer.getVisibility() == View.VISIBLE) {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                dimLayout.setVisibility(View.VISIBLE);
                                AnimationUtils.fadeIn(dimLayout);
                            }
                        } else {
                            fabAddCustomer.hide();
                        }
                    }
                }
            });
    }

    public void disableCollapse() {
        AppBarLayout.LayoutParams p = (AppBarLayout.LayoutParams) toolbar.getLayoutParams();
        p.setScrollFlags(0);
        toolbar.setLayoutParams(p);
    }

    public void enableCollapse() {
        AppBarLayout.LayoutParams params = (AppBarLayout.LayoutParams) toolbar.getLayoutParams();
        params.setScrollFlags(AppBarLayout.LayoutParams.SCROLL_FLAG_SCROLL
            | AppBarLayout.LayoutParams.SCROLL_FLAG_ENTER_ALWAYS);
        toolbar.setLayoutParams(params);
    }

    @Override
    public void onMobileConflict(Customer customer) {
        inputPhone.setText("");
        if (customer == null) {
            errorPhone.setVisibility(View.VISIBLE);
            errorPhone.setText(getString(R.string.err_mobile_conflict_default));
            Analytics.track(
                AnalyticsEvents.ADD_CUSTOMER_CONFLICT_MOBILE,
                EventProperties
                    .create()
                    .with("type", "deleted_customer")
                    .with("lifecycle", lifecycle)
            );
        } else {
            errorPhone.setVisibility(View.VISIBLE);
            errorPhone.setText(getString(R.string.err_mobile_conflict, customer.getDescription()));
            Analytics.track(
                AnalyticsEvents.ADD_CUSTOMER_CONFLICT_MOBILE,
                EventProperties
                    .create()
                    .with("type", "normal")
                    .with("lifecycle", lifecycle)
            );
        }
    }

    @Override
    public void showError() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "add cst phone")
                .with("type", "server error")
        );

        Toast.makeText(context, R.string.err_default, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void addCustomerSuccess(Customer customer, boolean isFromContact) {
        setAddCustomerState(ADD_CUSTOMER_STATE_BUTTON);
        inputName.setText("");
        inputPhone.setText("");
        KeyboardVisibilityEvent.hideKeyboard((Activity) context);

        if (isFromContact) {
            Analytics.track(
                AnalyticsEvents.ADD_CUSTOMER_SUCCESS,
                EventProperties
                    .create()
                    .with("type", "contact")
            );
        } else {
            Analytics.track(
                AnalyticsEvents.ADD_CUSTOMER_SUCCESS,
                EventProperties
                    .create()
                    .with("type", "manual")
            );
        }

        gotoCustomerScreen(customer.getId(), LifecycleState.NORMAL_FLOW);
    }

    @Override
    public void setAddCustomerState(int addCustomerState) {
        switch (addCustomerState) {
            case ADD_CUSTOMER_STATE_BUTTON:
                phoneContainer.setVisibility(View.GONE);
                fabAddCustomer.show();
                if (addCustomerCurrentState == ADD_CUSTOMER_STATE_NAME_TEXT || addCustomerCurrentState == ADD_CUSTOMER_STATE_PHONE_TEXT) {
                    anim.hideNavigationView();
                } else {
                    fabAddCustomer.show();
                    nameContainer.setVisibility(View.GONE);
                }

                addCustomerCurrentState = ADD_CUSTOMER_STATE_BUTTON;
                break;

            case ADD_CUSTOMER_STATE_NAME_TEXT:
                phoneContainer.setVisibility(View.GONE);

                if (addCustomerCurrentState == ADD_CUSTOMER_STATE_BUTTON) {
                    anim.showNavigationView();
                    Disposable subscribe = Completable
                        .timer(150, TimeUnit.MILLISECONDS)
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(() -> KeyboardVisibilityEvent.showKeyboard(context, inputName, rootView));
                } else {
                    fabAddCustomer.hide();
                    nameContainer.setVisibility(View.VISIBLE);
                }

                if (addCustomerCurrentState == ADD_CUSTOMER_STATE_PHONE_TEXT) {
                    KeyboardVisibilityEvent.showKeyboard(context, inputName, rootView);
                }

                if (lifecycle == LifecycleState.TRIAL_ADD_CUSTOMER) {
                    boolean isCustomerNameTutorialViewed = false;
                    try {
                        if (keyValService.contains(KEY_ADD_CUSTOMER_NAME_TUTORIAL_VIEWED)
                                         .blockingGet()) {
                            String value = keyValService.get(KEY_ADD_CUSTOMER_NAME_TUTORIAL_VIEWED)
                                                        .blockingFirst();
                            if (value != null && value.equals("true")) {
                                isCustomerNameTutorialViewed = true;
                            }
                        }
                    } catch (Exception ignored) {
                    }

                    if (!isCustomerNameTutorialViewed) {
                        final Disposable subscribe = keyValService.put(KEY_ADD_CUSTOMER_NAME_TUTORIAL_VIEWED, String.valueOf(true))
                          .subscribeOn(ThreadUtils.database())
                          .observeOn(AndroidSchedulers.mainThread())
                          .subscribe(
                              () -> {
                                  if (mediaPlayer == null) {
                                      mediaPlayer = new MediaPlayer();
                                  }

                                  setAudioState(true);
                                  switch (audioLang) {
                                      case LocaleManager.LANGUAGE_ENGLISH:
                                          setAudio(AudioUrl.ADD_CUSTOMER_NAME_EN);
                                          break;
                                      case LocaleManager.LANGUAGE_HINDI:
                                          setAudio(AudioUrl.ADD_CUSTOMER_NAME_HI);
                                          break;
                                      case LocaleManager.LANGUAGE_MALAYALAM:
                                          setAudio(AudioUrl.ADD_CUSTOMER_NAME_ML);
                                          break;
                                      default:
                                          setAudio(AudioUrl.ADD_CUSTOMER_NAME_HI);
                                          break;
                                  }
                              },
                              throwable -> Timber.e(throwable)
                          );
                    }
                }

                addCustomerCurrentState = ADD_CUSTOMER_STATE_NAME_TEXT;
                break;

            case ADD_CUSTOMER_STATE_PHONE_TEXT:
                nameContainer.setVisibility(View.GONE);
                phoneContainer.setVisibility(View.VISIBLE);
                hideAddCustomerLoader();

                inputName.clearFocus();
                inputPhone.requestFocus();


                if (lifecycle == LifecycleState.TRIAL_ADD_CUSTOMER) {
                    boolean isTutorialViewed = false;
                    try {
                        if (keyValService.contains(KEY_ADD_CUSTOMER_MOBILE_TUTORIAL_VIEWED)
                                         .blockingGet()) {
                            String value = keyValService.get(KEY_ADD_CUSTOMER_MOBILE_TUTORIAL_VIEWED)
                                                        .blockingFirst();
                            if (value != null && value.equals("true")) {
                                isTutorialViewed = true;
                            }
                        }
                    } catch (Exception ignored) {
                    }

                    if (!isTutorialViewed) {
                        final Disposable subscribe = keyValService.put(KEY_ADD_CUSTOMER_MOBILE_TUTORIAL_VIEWED, String
                            .valueOf(true))
                                                                  .subscribeOn(ThreadUtils.database())
                                                                  .subscribe(
                                                                      () -> {
                                                                          releaseMediaPlayer();
                                                                          if (mediaPlayer == null) {
                                                                              mediaPlayer = new MediaPlayer();
                                                                          }

                                                                          setAudioState(true);
                                                                          switch (audioLang) {
                                                                              case LocaleManager.LANGUAGE_ENGLISH:
                                                                                  setAudio(AudioUrl.ADD_CUSTOMER_MOBILE_EN);
                                                                                  break;
                                                                              case LocaleManager.LANGUAGE_HINDI:
                                                                                  setAudio(AudioUrl.ADD_CUSTOMER_MOBILE_HI);
                                                                                  break;
                                                                              case LocaleManager.LANGUAGE_MALAYALAM:
                                                                                  setAudio(AudioUrl.ADD_CUSTOMER_MOBILE_ML);
                                                                                  break;
                                                                              default:
                                                                                  setAudio(AudioUrl.ADD_CUSTOMER_MOBILE_HI);
                                                                                  break;
                                                                          }
                                                                      },
                                                                      throwable -> Timber.e(throwable)
                                                                  );
                    }
                }

                addCustomerCurrentState = ADD_CUSTOMER_STATE_PHONE_TEXT;
                break;

        }
    }

    @Override
    public void shakeNameContainer() {
        AnimationUtils.shake(nameContainer);
    }

    @Override
    public void shakePhoneContainer() {
        AnimationUtils.shake(phoneContainer);
    }

    @Override
    public void showAddCustomerLoader() {
        addCustomerLoader.setVisibility(View.VISIBLE);
        phoneDone.setVisibility(View.GONE);
    }

    @Override
    public void hideAddCustomerLoader() {
        addCustomerLoader.setVisibility(View.GONE);
        phoneDone.setVisibility(View.VISIBLE);
    }

    private void showSortMenu() {
        sortMenu = new PopupMenu(this, sort);
        MenuInflater inflater = sortMenu.getMenuInflater();
        inflater.inflate(R.menu.menu_home_sort, sortMenu.getMenu());
        sortMenu.setOnMenuItemClickListener(menuItem ->
        {
            switch (menuItem.getItemId()) {
                case R.id.sort_name:
                    if (presenter != null) {
                        presenter.setSortType(HomeScreenContract.SORT_TYPE_NAME);
                    }
                    Analytics.track(AnalyticsEvents.HOME_SORT, EventProperties.create().with
                        ("type", "name"));
                    return true;

                case R.id.sort_balance:
                    if (presenter != null) {
                        presenter.setSortType(HomeScreenContract.SORT_TYPE_ABS_BALANCE);
                    }
                    Analytics.track(AnalyticsEvents.HOME_SORT, EventProperties.create().with
                        ("type", "balance"));
                    return true;

                case R.id.sort_recent:
                    if (presenter != null) {
                        presenter.setSortType(HomeScreenContract.SORT_TYPE_RECENT_ACTIVITY);
                    }
                    Analytics.track(AnalyticsEvents.HOME_SORT, EventProperties.create().with
                        ("type", "recent"));
                    return true;

                case R.id.sort_last_payment:
                    if (presenter != null) {
                        presenter.setSortType(HomeScreenContract.SORT_TYPE_LAST_PAYMENT);
                    }
                    Analytics.track(AnalyticsEvents.HOME_SORT, EventProperties.create().with
                        ("type", "last_payment"));
                    return true;

                default:
                    return false;
            }
        });
        sortMenu.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.clear();
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_home, menu);
        sync = menu.findItem(R.id.refresh);
        setupRefreshOption();
        return true;
    }

    private void setupRefreshOption() {
        if (sync == null) {
            return;
        }

        if (isInternetAvailable) {
            sync.setIcon(R.drawable.ic_refresh);
            if (isInternetAvailable) {
                sync.setOnMenuItemClickListener(item -> {
                    refresh();
                    return true;
                });
            }
        } else {
            sync.setIcon(R.drawable.ic_no_internet);
            sync.setOnMenuItemClickListener(item -> {
                buildNetworkSnackbar(false).show();
                return true;
            });
        }
    }

    private void refresh() {
        if (presenter != null) {
            presenter.refresh();
            releaseMediaPlayer();
        }
        Analytics.track(AnalyticsEvents.HOME_REFRESH);
        releaseMediaPlayer();
    }

    @Override
    protected void onResume() {
        Timber.d("ABC - OnResume Home");
        super.onResume();
        query = null;
        search.clearQuery();
        presenter.attachView(this);

        if (mediaPlayer == null) {
            mediaPlayer = new MediaPlayer();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        presenter.detachView();
        if (logoutConfirmationDialog != null) {
            logoutConfirmationDialog.dismiss();
            logoutConfirmationDialog = null;
        }

        if (shareImageTask != null) {
            shareImageTask.dispose();
            shareImageTask = null;
        }

        if (sortMenu != null) {
            sortMenu.dismiss();
            sortMenu = null;
        }

        releaseMediaPlayer();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == REQ_CODE_CONTACT_PERMISSION) {
            int pos = Arrays.asList(permissions).indexOf(Manifest.permission.READ_CONTACTS);
            if (pos != -1) {
                if (grantResults[pos] == PackageManager.PERMISSION_GRANTED) {
                    Analytics.track(AnalyticsEvents.HOME_SCREEN_CONTACT_PERMISSION_ACCEPTED);
                    onClickImportContact();
                } else {
                    boolean showRationale = false;
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        showRationale = shouldShowRequestPermissionRationale(permissions[pos]);
                    }
                    if (! showRationale) {
                        showPermissionAlertDialogue();
                    } else {
                        homeController.setIsPermissionContactDenied(true);
                        Analytics.track(AnalyticsEvents.HOME_SCREEN_CONTACT_PERMISSION_DENIED);
                    }
                }
            }
        } else if (grantResults.length > 0 && Arrays.asList(permissions)
                                                    .contains(Manifest.permission
                                                        .CALL_PHONE) && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startHelpFlow();
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    public void showPermissionAlertDialogue() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.permission_text);
        builder.setMessage(R.string.contact_permission_denied);

        // add the buttons
        builder.setPositiveButton(R.string.settings_title, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", getPackageName(), null);
                intent.setData(uri);
                startActivityForResult(intent, 101);
            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        // create and show the alert dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    @Override
    public void onBackPressed() {
        if (drawer != null && drawer.isDrawerOpen()) {
            drawer.closeDrawer();
        } else if (addCustomerCurrentState == ADD_CUSTOMER_STATE_PHONE_TEXT) {
            setAddCustomerState(ADD_CUSTOMER_STATE_NAME_TEXT);
        } else if (addCustomerCurrentState == ADD_CUSTOMER_STATE_NAME_TEXT) {
            setAddCustomerState(ADD_CUSTOMER_STATE_BUTTON);
        } else if (!isSinglePressed){
            Toast.makeText(context, R.string.touch_again_exit, Toast.LENGTH_SHORT).show();
            isSinglePressed = true;
            Disposable subscribe = Completable
                .timer(2000, TimeUnit.MILLISECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(() -> isSinglePressed = false);
        } else {
            super.onBackPressed();
        }
    }

    /****************************************************************
     Navigation
     ****************************************************************/
    private void gotoCustomerScreen(@NonNull String customerId, int lifecycle) {
        KeyboardUtil.hideKeyboard((Activity) context, rootView);
        startActivity(CustomerActivity.startingIntent(this, customerId, lifecycle));
    }

    private void gotoAccountScreen() {
        startActivity(AccountActivity.startingIntent(this));
    }

    private void startAboutFlow() {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(Constants.ABOUT_URL));
        startActivity(intent);
    }

    private void startPrivacyPolicyFlow() {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(Constants.PRIVACY_POLICY_URL));
        startActivity(intent);
    }

    private void gotoRatingScreen() {
        startActivity(RatingActivity.startingIntent(this));
    }

    private void gotoHelpScreen() {
        startActivity(HelpActivity.startingIntent(this));
    }

    private void gotoShareScreen() {
        startActivity(ShareActivity.startingIntent(this));
    }

    /****************************************************************
     MVP methods
     ****************************************************************/
    @Override
    public void showNotificaton(InAppNotification inAppNotification) {

        //analytics
        String type = null;
        switch (inAppNotification.getType()) {
            case InAppNotification.TYPE_APP_LOCK:
                type = "app lock";
                break;
            case InAppNotification.TYPE_RATING:
                type = "rating";
                break;
            case InAppNotification.TYPE_SHARE:
                type = "share";
                break;
            case InAppNotification.TYPE_UPDATE:
                type = "update";
                break;
            case InAppNotification.TYPE_REMINDER_TO_BE_SENT:
                type = "reminder to be sent";
                break;
        }
        if (type != null) {
            Analytics.track(
                AnalyticsEvents.IN_APP_NOTI_DISPLAYED,
                EventProperties
                    .create()
                    .with("type", type));

            Timber.i(AnalyticsEvents.IN_APP_NOTI_DISPLAYED);
        }


        homeController.setInAppNotificationVisibility(true);
        homeController.setInAppNotification(inAppNotification);
    }

    @Override
    public void setNetworkStatus(boolean isConnected) {
        if (isInternetAvailable != isConnected) {
            buildNetworkSnackbar(isConnected).show();
        }
        isInternetAvailable = isConnected;
        setupRefreshOption();
    }

    private Snackbar buildNetworkSnackbar(boolean isInternetAvailable) {
        if (!isInternetAvailable) {
            Snackbar snackbar = Snackbar.make(fabAddCustomer, R.string.home_no_internet_msg, Snackbar.LENGTH_SHORT);
            TextView textView = snackbar.getView()
                                        .findViewById(android.support.design.R.id.snackbar_text);
            textView.setTextColor(ContextCompat.getColor(this, R.color.text_title_inverse));
            textView.setCompoundDrawablesWithIntrinsicBounds(
                DrawableUtil.getDrawableWithColor(this, R.drawable.ic_no_internet, R.color.text_title_inverse),
                null,
                null,
                null
            );
            textView.setCompoundDrawablePadding(getResources().getDimensionPixelOffset(R.dimen._16dp));
            return snackbar;
        } else {
            Snackbar snackbar = Snackbar.make(fabAddCustomer, R.string.home_internet_connected, Snackbar.LENGTH_SHORT);
            TextView textView = snackbar.getView()
                                        .findViewById(android.support.design.R.id.snackbar_text);
            textView.setTextColor(ContextCompat.getColor(this, R.color.text_title_inverse));
            return snackbar;
        }
    }

    @Override
    public void onLogoutSuccess() {
        startActivity(LanguageActivity.startingIntent(this));
        finish();
    }

    @Override
    public void displayMerchantDetails(Merchant merchant) {
        if (merchant.getName() != null) {
            getSupportActionBar().setTitle(merchant.getName());
            profile = profile.withName(merchant.getName());
            profile = profile.withEmail(merchant.getMobile());
            accountHeader.updateProfile(profile);
        }
    }

    @Override
    public void showLoading() {
        if (fabAddCustomer.isShown()) {
            fabAddCustomer.hide();
        }
        customerList.setVisibility(View.GONE);
        error.setVisibility(View.GONE);
        tutCard.setVisibility(View.GONE);
        homeController.setInAppNotificationVisibility(false);

        loading.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideLoading() {
        loading.setVisibility(View.GONE);
    }

    @Override
    public void displayCustomers(List<Customer> customers, int lifecycleStage) {
        this.lifecycle = lifecycleStage;

        switch (lifecycleStage) {
            case LifecycleState.NORMAL_FLOW:
                searchLayout.setVisibility(View.VISIBLE);
                if (addCustomerCurrentState == ADD_CUSTOMER_STATE_BUTTON) {
                    fabAddCustomer.show();
                }
                tutCard.setVisibility(View.GONE);
                loading.setVisibility(View.GONE);
                customerTile.setVisibility(View.GONE);

                this.customers = customers;
                refreshRecyclerView();

                break;
            case LifecycleState.TRIAL_TRANSACTION:
                Analytics.track(
                    AnalyticsEvents.TUTORIAL_STARTED,
                    EventProperties
                        .create()
                        .with("type", "tx")
                );

                searchLayout.setVisibility(View.GONE);
                fabAddCustomer.hide();
                tutCard.setVisibility(View.VISIBLE);
                homeController.setInAppNotificationVisibility(false);
                loading.setVisibility(View.GONE);
                customerList.setVisibility(View.GONE);

                tutTitle.setText(getString(R.string.record_first_credit_title));
                tutSubtitle.setText(getString(R.string.record_first_tx));
                tutAudioButton.setVisibility(View.VISIBLE);
                tutAudioButton.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_pause));
                tutIcon.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.add_first_credit));

                if (mediaPlayer == null) {
                    mediaPlayer = new MediaPlayer();
                }

                switch (audioLang) {
                    case LocaleManager.LANGUAGE_ENGLISH:
                        setAudio(AudioUrl.HOME_TRANSACTION_EN);
                        break;
                    case LocaleManager.LANGUAGE_HINDI:
                        setAudio(AudioUrl.HOME_TRANSACTION_HI);
                        break;
                    case LocaleManager.LANGUAGE_MALAYALAM:
                        setAudio(AudioUrl.HOME_TRANSACTION_ML);
                        break;
                    default:
                        setAudio(AudioUrl.HOME_TRANSACTION_HI);
                        break;
                }

                if (customers != null) {
                    if (customers.size() > 0) {
                        Customer customer = customers.get(0);
                        customerTile.setVisibility(View.VISIBLE);
                        customerTile.setOnClickListener(view -> {
                            String query = getQuery();
                            if (query == null) {
                                query = "";
                            }
                            Analytics.track(
                                AnalyticsEvents.CST_TILE_CLICKED,
                                EventProperties
                                    .create()
                                    .with("account_id", customer.getId())
                                    .with("search", query.length() > 0)
                                    .with("type", "add tx")
                            );
                            gotoCustomerScreen(customer.getId
                                (), LifecycleState.TRIAL_TRANSACTION);
                        });

                        tutCard.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {

                                Analytics.track(
                                    AnalyticsEvents.TUTORIAL_CARD_CLICKED,
                                    EventProperties
                                        .create()
                                        .with("type", "add tx")
                                );

                                gotoCustomerScreen(customer.getId(), LifecycleState.TRIAL_TRANSACTION);
                            }
                        });

                        CurrencyUtil.render(customer.getBalance(), balance);
                        lastPayment.setText(getString(R.string.not_paid));
                        customerName.setText(customer.getDescription());

                        Drawable defaultPic = TextDrawable
                            .builder()
                            .buildRound(
                                customer.getDescription().substring(0, 1).toUpperCase(),
                                ColorGenerator.MATERIAL.getColor(customer.getDescription())
                            );

                        pic.setImageDrawable(defaultPic);

                        if (customer.getBalance() > 0) {
                            balanceStatus.setText(getString(R.string.advance));
                        } else {
                            balanceStatus.setText(getString(R.string.due));
                        }
                    }
                }

                showIncreaseVolumeSnackbar();

                break;
            case LifecycleState.TRIAL_ADD_CUSTOMER:
                Analytics.track(
                    AnalyticsEvents.TUTORIAL_STARTED,
                    EventProperties
                        .create()
                        .with("type", "add customer")
                );

                displayNoAndOneCustomerMessage(false);

                if (customers != null) {
                    if (customers.size() > 0) {
                        customerList.setVisibility(View.VISIBLE);
                        homeController.setCustomers(customers);

                    } else {
                        customerTile.setVisibility(View.GONE);
                    }
                }

                showIncreaseVolumeSnackbar();

                break;
        }
    }

    private void showIncreaseVolumeSnackbar() {
        AudioManager audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        if (audio == null) {
            return;
        }

        int currentVolume = audio.getStreamVolume(AudioManager.STREAM_MUSIC);

        int maxVolume = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);

        float volumeLevel = (currentVolume * 1.0f) / maxVolume;

        if (volumeLevel < 0.2f) {

            Analytics.track(AnalyticsEvents.HOME_SCREEN_AUDIO_LOW);

            Snackbar snackbar = Snackbar.make(tutCard, R.string.volume_low, Snackbar
                .LENGTH_LONG);
            snackbar.getView().setBackgroundColor(ContextCompat.getColor(this, R.color.white));
            snackbar.show();

        }
    }

    @Override
    public void displayNoAndOneCustomerMessage(boolean isEmpty) {
        if (isEmpty) {
            customerList.setVisibility(View.VISIBLE);
            homeController.requestModelBuild();

            tutCard.setVisibility(View.VISIBLE);
            tutTitle.setText(getString(R.string.add_first_cst_title));
            tutSubtitle.setText(getString(R.string.add_first_cst_desc));
            tutIcon.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.add_first_cst));
            tutAudioButton.setVisibility(View.GONE);
        } else {
            tutCard.setVisibility(View.GONE);
            customerList.setVisibility(View.GONE);
        }
        searchLayout.setVisibility(View.GONE);
        fabAddCustomer.show();
        homeController.setInAppNotificationVisibility(false);
        loading.setVisibility(View.GONE);

        if (addCustomerCurrentState == ADD_CUSTOMER_STATE_BUTTON && fabAddCustomer.getVisibility() == View.VISIBLE && tapTargetView == null) {
            boolean isTutorialViewed = false;
            try {
                if (keyValService.contains(KEY_ADD_CUSTOMER_TUTORIAL_VIEWED).blockingGet()) {
                    String value = keyValService.get(KEY_ADD_CUSTOMER_TUTORIAL_VIEWED)
                                                .blockingFirst();
                    if (value != null && value.equals("true")) {
                        isTutorialViewed = true;
                    }
                }
            } catch (Exception ignored) {
            }

            if (!isTutorialViewed) {
                final Disposable subscribe = keyValService.put(KEY_ADD_CUSTOMER_TUTORIAL_VIEWED, String
                    .valueOf(true))
                                                          .subscribeOn(ThreadUtils.database())
                                                          .subscribe(
                                                              () -> {
                                                              },
                                                              throwable -> Timber.e(throwable)
                                                          );

                lifecycle = LifecycleState.TRIAL_ADD_CUSTOMER;
                Analytics.track(AnalyticsEvents.HOME_SCREEN_TUTORIAL_ADD_CUSTOMER_FAB);

                tapTargetView = TapTargetView.showFor(this,
                    TapTarget.forView(fabAddCustomer,
                        getString(R.string.add_first_customer))
                             // All options below are optional
                             .outerCircleColor(R.color.primary)      // Specify a color for the outer circle
                             .outerCircleAlpha(0.96f)            // Specify the alpha amount for the outer circle
                             .targetCircleColor(R.color.white)   // Specify a color for the target circle
                             .titleTextSize(20)                  // Specify the size (in sp) of the title text
                             .titleTextColor(R.color.white)      // Specify the color of the title text
                             .descriptionTextSize(10)            // Specify the size (in sp) of the description text
                             .descriptionTextColor(R.color.white)  // Specify the color of the description text
                             .textColor(R.color.white)            // Specify a color for both the title and description text
                             .textTypeface(Typeface.SANS_SERIF)  // Specify a typeface for the text
                             .dimColor(R.color.black)            // If set, will dim behind the view with 30% opacity of the given color
                             .drawShadow(true)                   // Whether to draw a drop shadow or not
                             .cancelable(true)                  // Whether tapping outside the outer circle dismisses the view
                             .tintTarget(true)                   // Whether to tint the target view's color
                             .transparentTarget(true)           // Specify whether the target is transparent (displays the content underneath)
                             .icon(ContextCompat.getDrawable(context, R.drawable.ic_add_customer))                     // Specify a custom drawable to draw as the target
                             .targetRadius(60),                  // Specify the target radius (in dp)
                    new TapTargetView.Listener() {          // The listener can listen for regular clicks, long clicks or cancels
                        @Override
                        public void onTargetClick(TapTargetView view) {
                            super.onTargetClick(view);
                            releaseMediaPlayer();
                            setAddCustomerState(ADD_CUSTOMER_STATE_NAME_TEXT);
                            Analytics.track(AnalyticsEvents.HOME_SCREEN_TUTORIAL_ADD_CUSTOMER_FAB_TARGET_CLICKED);
                            tapTargetView = null;
                        }

                        @Override
                        public void onTargetCancel(TapTargetView view) {
                            super.onTargetClick(view);
                            releaseMediaPlayer();
                            Analytics.track(AnalyticsEvents.HOME_SCREEN_TUTORIAL_ADD_CUSTOMER_FAB_TARGET_CANCELLED);
                            tapTargetView = null;
                        }
                    });

                if (mediaPlayer == null) {
                    mediaPlayer = new MediaPlayer();
                }

                switch (audioLang) {
                    case LocaleManager.LANGUAGE_ENGLISH:
                        setAudio(AudioUrl.HOME_ADD_FIRST_CUSTOMER_EN);
                        break;
                    case LocaleManager.LANGUAGE_HINDI:
                        setAudio(AudioUrl.HOME_ADD_FIRST_CUSTOMER_HI);
                        break;
                    case LocaleManager.LANGUAGE_MALAYALAM:
                        setAudio(AudioUrl.HOME_ADD_FIRST_CUSTOMER_ML);
                        break;
                    default:
                        setAudio(AudioUrl.HOME_ADD_FIRST_CUSTOMER_HI);
                        break;
                }
            }
        }

        tutCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Analytics.track(
                    AnalyticsEvents.TUTORIAL_CARD_CLICKED,
                    EventProperties
                        .create()
                        .with("type", "add cst")
                );

                onAddCustomerFabClicked();
            }
        });

        customerTile.setVisibility(View.GONE);
    }

    @Override
    public void onError(String tag) {
        if (fabAddCustomer.isShown()) {
            fabAddCustomer.hide();
        }
        loading.setVisibility(View.GONE);
        customerList.setVisibility(View.GONE);
        tutCard.setVisibility(View.GONE);
        homeController.setInAppNotificationVisibility(false);

        error.setVisibility(View.VISIBLE);
        errorMessage.setText(R.string.err_load_customers);

        Analytics.track(AnalyticsEvents.HOME_ERROR);
    }

    @Override
    public void onNetworkFailure() {
        new NetworkErrorDialog().show(this, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                if (logoutConfirmationDialog != null) {
                    logoutConfirmationDialog.dismiss();
                    logoutConfirmationDialog = null;
                }

                presenter.attachView(HomeActivity.this);
            }

            @Override
            public void onCancel() {
                presenter.attachView(HomeActivity.this);
            }
        });
    }

    /****************************************************************
     Helpers
     ****************************************************************/
    private void logout() {
        presenter.logout();
    }

    private String getQuery() {
        return query;
    }

    private void refreshRecyclerView() {
        loading.setVisibility(View.GONE);
        error.setVisibility(View.GONE);
        customerList.setVisibility(View.VISIBLE);

        if (TextUtils.isEmpty(query)) {
            homeController.setCustomersAndContacts(customers, contacts);
        } else {
            List<Customer> visibleCustomers = new ArrayList<>();
            List<ContactModel> visibleContacts = new ArrayList<>();

            if (customers != null) {
                for (Customer customer : customers) {
                    if (customer.getDescription().toLowerCase().contains(query.toLowerCase()) ||
                        (customer.getMobile() != null &&
                            customer.getMobile().contains(query.toLowerCase().trim()))) {
                        visibleCustomers.add(customer);
                    }
                }
            }

            if (contacts != null) {
                for (ContactModel contact : contacts) {
                    if (contact.name.toLowerCase().contains(query.toLowerCase()) ||
                        (contact.mobile != null &&
                            contact.mobile.contains(query.toLowerCase().trim()))) {
                        visibleContacts.add(contact);
                    }
                }
            }

            if (visibleCustomers.isEmpty()) {
                homeController.setAddCustomerViewVisibility(true, query);
                Analytics.track(AnalyticsEvents.HOME_SEARCH_NO_RESULT);
            }
            homeController.setCustomersAndContacts(visibleCustomers, visibleContacts);

        }
    }

    private void setupNavigationDrawer() {
        profile = new ProfileDrawerItem()
            .withName("")
            .withEmail("");

        account = new PrimaryDrawerItem()
            .withName(R.string.account)
            .withIcon(DrawableUtil.getDrawableWithColor(this, R.drawable.ic_account, R.color
                .grey800))
            .withSelectable(false);
        share = new PrimaryDrawerItem()
            .withName(R.string.share)
            .withIcon(DrawableUtil.getDrawableWithColor(this, R.drawable.ic_share, R.color
                .grey800))
            .withSelectable(false);
        help = new PrimaryDrawerItem()
            .withName(R.string.help)
            .withIcon(DrawableUtil.getDrawableWithColor(this, R.drawable.ic_help, R.color
                .grey800))
            .withSelectable(false);
        about = new PrimaryDrawerItem()
            .withName(R.string.about)
            .withIcon(DrawableUtil.getDrawableWithColor(this, R.drawable.ic_info, R.color
                .grey800))
            .withSelectable(false);
        privacy = new PrimaryDrawerItem()
            .withName(R.string.privacy_policy)
            .withIcon(DrawableUtil.getDrawableWithColor(this, R.drawable.ic_lock, R.color
                .grey800))
            .withSelectable(false);
        logout = new PrimaryDrawerItem()
            .withName(R.string.logout)
            .withIcon(DrawableUtil.getDrawableWithColor(this, R.drawable.ic_logout, R.color
                .grey800))
            .withSelectable(false);

        ViewGroup footer = (ViewGroup) getLayoutInflater().inflate(R.layout.view_nav_footer, null);
        TextView madeInIndia = footer.findViewById(R.id.made);
        TextView version = footer.findViewById(R.id.version);
        madeInIndia.setText("Made with " + '\u2665' + " in India");
        version.setText(String.format("Version: %s", BuildConfig.VERSION_NAME));

        accountHeader =
            new AccountHeaderBuilder()
                .withActivity(this)
                .addProfiles(profile)
                .withSelectionListEnabled(false)
                .withCompactStyle(true)
                .withProfileImagesVisible(false)
                .withHeaderBackground(R.color.primary)
                .build();

        drawer = new DrawerBuilder()
            .withActivity(this)
            .withToolbar(toolbar)
            .withAccountHeader(accountHeader)
            .addDrawerItems(
                account,
                new DividerDrawerItem(),
                help,
                about,
                privacy,
                share,
                new DividerDrawerItem(),
                logout
            )
            .withStickyFooter(footer)
            .withStickyFooterShadow(false)
            .withStickyFooterDivider(true)
            .withOnDrawerItemClickListener((view, position, drawerItem) ->
            {
                if (drawerItem == account) {

                    Analytics.track(
                        AnalyticsEvents.DRAWER_CLICKED,
                        EventProperties
                            .create()
                            .with("type", "account")
                            .with("lifecycle", lifecycle));

                    gotoAccountScreen();
                } else if (drawerItem == share) {
                    Analytics.track(
                        AnalyticsEvents.DRAWER_CLICKED,
                        EventProperties
                            .create()
                            .with("type", "share")
                            .with("lifecycle", lifecycle));

                    gotoShareScreen();
                } else if (drawerItem == help) {
                    Analytics.track(
                        AnalyticsEvents.DRAWER_CLICKED,
                        EventProperties
                            .create()
                            .with("type", "help")
                            .with("lifecycle", lifecycle));

                    gotoHelpScreen();
                } else if (drawerItem == about) {

                    Analytics.track(
                        AnalyticsEvents.DRAWER_CLICKED,
                        EventProperties
                            .create()
                            .with("type", "about")
                            .with("lifecycle", lifecycle));

                    startAboutFlow();
                } else if (drawerItem == privacy) {

                    Analytics.track(
                        AnalyticsEvents.DRAWER_CLICKED,
                        EventProperties
                            .create()
                            .with("type", "privacy_policy")
                            .with("lifecycle", lifecycle));

                    startPrivacyPolicyFlow();
                } else if (drawerItem == logout) {
                    Analytics.track(
                        AnalyticsEvents.DRAWER_CLICKED,
                        EventProperties
                            .create()
                            .with("type", "sign out")
                            .with("lifecycle", lifecycle));

                    if (presenter != null) {
                        logoutConfirmationDialog = LogoutConfirmationDialog.show(
                            this,
                            false,
                            password -> logout());
                    }
                }
                drawer.closeDrawer();
                return true;
            })
            .withSelectedItem(-1)
            .build();
    }

    private void openPlaystore() {
        String url = "https://get.okcredit.in";
        try {
            Uri webpage = Uri.parse(url);
            Intent myIntent = new Intent(Intent.ACTION_VIEW, webpage);
            startActivity(myIntent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, R.string.browser_not_found, Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    private void dismissReminderNotification() {
        homeController.setInAppNotificationVisibility(false);
        presenter.onReminderNotificationClicked();
    }

    private void dismissUpdateNotification() {
        homeController.setInAppNotificationVisibility(false);
        presenter.onUpdateNotificationDismissed();
    }

    private void dismissShareNotification() {
        homeController.setInAppNotificationVisibility(false);
        presenter.onShareNotificationClicked();
    }

    private void dismissAppLockNotification() {
        homeController.setInAppNotificationVisibility(false);
        presenter.onAppLockNotificationClicked();
    }

    private void dismissRatingNotification() {
        homeController.setInAppNotificationVisibility(false);
        presenter.onRatingNotificationClicked();
    }

    public void setAudio(String audioUrl) {
        tutAudioButton.setImageDrawable(ContextCompat.getDrawable(HomeActivity.this, R
            .drawable.ic_play));

        tutAudioButton.setClickable(false);

        Disposable task = Completable
            .fromAction(() -> {
                mediaPlayer.setDataSource(this, Uri.parse(audioUrl), new HashMap<>());
                mediaPlayer.prepare();
            })
            .subscribeOn(in.okcredit.ThreadUtils.newThread())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                () -> {
                    Analytics.track(
                        AnalyticsEvents.AUDIO_STARTED,
                        EventProperties
                            .create()
                            .with("screen", "home")
                            .with("lifecycle", lifecycle)
                    );

                    setAudioState(true);
                    tutAudioButton.setClickable(true);
                },
                throwable -> Timber.e(throwable)
            );

        if (mediaPlayer != null) {
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    Analytics.track(
                        AnalyticsEvents.AUDIO_COMPLETE,
                        EventProperties
                            .create()
                            .with("screen", "home")
                            .with("lifecycle", lifecycle)
                    );

                    tutAudioButton.setImageDrawable(ContextCompat.getDrawable(HomeActivity.this, R
                        .drawable.ic_play));
                    isAudioPlaying = false;
                }
            });
        }

        tasks.add(task);
    }

    private void setAudioState(boolean playAudio) {
        if (mediaPlayer == null) {
            return;
        }

        isAudioPlaying = playAudio;
        if (playAudio) {
            mediaPlayer.start();
            tutAudioButton.setImageDrawable(ContextCompat.getDrawable(HomeActivity.this, R
                .drawable.ic_pause));
        } else {
            mediaPlayer.pause();
            tutAudioButton.setImageDrawable(ContextCompat.getDrawable(HomeActivity.this, R
                .drawable.ic_play));
        }
    }

    private void releaseMediaPlayer() {
        try {
            if (mediaPlayer != null) {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                mediaPlayer.release();
                mediaPlayer = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onSelectedCustomer(Customer customer) {
        gotoCustomerScreen(customer.getId(), LifecycleState.NORMAL_FLOW);
    }

    @Override
    public void onClickImportContact() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            Analytics.track(AnalyticsEvents.HOME_SCREEN_CONTACT_PERMISSION_REQUEST);
            Analytics.track(AnalyticsEvents.ADD_CUSTOMER_IMPORT_CONTACT);
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CONTACTS}, REQ_CODE_CONTACT_PERMISSION);
        } else {
            Completable
                .timer(500, TimeUnit.MILLISECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(() -> {
                    presenter.loadContacts();
                });
        }
    }

    @Override
    public void setContactsLoadingVisibility(boolean visibility) {
        homeController.setContactImportViewVisibility(visibility);
    }

    @Override
    public void onInvalidName() {
        Toast.makeText(context, R.string.invalid_name, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void setContactsLoadingPercentage(int percent) {
        homeController.setPercentage(percent);
    }

    @Override
    public void displayContacts(List<ContactModel> contactModels) {
        this.contacts = contactModels;
        homeController.setContacts(contactModels);
    }

    @Override
    public void onClickRefreshContact() {
        presenter.loadContacts();
        Analytics.track(AnalyticsEvents.HOME_CLICK_CONTACT_REFRESH);
    }

    @Override
    public void onAddContact(ContactModel contact) {
        if (search.isSearchBarFocused()) {
            Analytics.track(
                AnalyticsEvents.ADD_CUSTOMER_ADD_CLICKED,
                EventProperties
                    .create()
                    .with("search", "true")
                    .with("contact", "true")
            );
        } else {
            Analytics.track(
                AnalyticsEvents.ADD_CUSTOMER_ADD_CLICKED,
                EventProperties
                    .create()
                    .with("search", "false")
                    .with("contact", "true")
            );
        }
        presenter.proceedPhone(contact.mobile, contact.name, contact.picUri, null, true);
    }


    private String loadContactPhotoThumbnail(String photoData) {
        // Creates an asset file descriptor for the thumbnail file.
        AssetFileDescriptor afd = null;
        FileOutputStream outputStream = null;
        InputStream inputStream = null;
        // try-catch block for file not found
        try {
            // Creates a holder for the URI.
            Uri thumbUri;
            // If Android 3.0 or later
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
                thumbUri = Uri.parse(photoData);
            } else {
                return null;
            }

            /*
             * Retrieves an AssetFileDescriptor object for the thumbnail
             * URI
             * using ContentResolver.openAssetFileDescriptor
             */
            afd = context.getContentResolver().
                openAssetFileDescriptor(thumbUri, "r");

            FileDescriptor fdd = afd.getFileDescriptor();
            inputStream = new FileInputStream(fdd);
            File file = File.createTempFile("PhoneContactProvider", "tmp");
            file.deleteOnExit();
            outputStream = new FileOutputStream(file);
            byte[] buffer = new byte[1024];
            int len;
            while ((len = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, len);
            }
            inputStream.close();
            outputStream.close();
            return "file://" + file.getAbsolutePath();
        } catch (Exception e) {
            Timber.e(this.getClass().getSimpleName(), e.getMessage());
        }
        // In all cases, close the asset file descriptor
        finally {
            if (afd != null) {
                try {
                    afd.close();
                } catch (IOException e) {
                }
            }
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                }
            }
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                }
            }
        }
        return null;
    }

    @Override
    public void onClickAddFromSearchCustomer() {
        Analytics.track(
            AnalyticsEvents.ADD_CUSTOMER_ADD_CLICKED,
            EventProperties
                .create()
                .with("search", "true")
                .with("contact", "false")
        );
        setAddCustomerState(ADD_CUSTOMER_STATE_NAME_TEXT);

        Disposable subscribe = Completable
            .timer(500, TimeUnit.MILLISECONDS)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(() -> {
                String query = getQuery();
                if (query == null) {
                    query = "";
                }
                this.query = null;
                search.clearQuery();
                refreshRecyclerView();
                inputName.setText(query);
                inputName.setSelection(query.length() > 30 ? 30 : query.length());
            });
    }

    @Override
    public void onNotificationCardClicked(int type) {
        switch (type) {
            case InAppNotification.TYPE_UPDATE:

                Analytics.track(
                    AnalyticsEvents.IN_APP_NOTI_CLICKED,
                    EventProperties
                        .create()
                        .with("type", "update")
                        .with("lifecycle", lifecycle));

                openPlaystore();

                break;
            case InAppNotification.TYPE_REMINDER_TO_BE_SENT:

                Analytics.track(
                    AnalyticsEvents.IN_APP_NOTI_CLICKED,
                    EventProperties
                        .create()
                        .with("type", "reminder to be sent")
                        .with("lifecycle", lifecycle));

                dismissReminderNotification();
                break;

            case InAppNotification.TYPE_SHARE:
                Analytics.track(
                    AnalyticsEvents.IN_APP_NOTI_CLICKED,
                    EventProperties
                        .create()
                        .with("type", "share")
                        .with("lifecycle", lifecycle));

                dismissShareNotification();
                gotoShareScreen();

                break;

            case InAppNotification.TYPE_APP_LOCK:
                Analytics.track(
                    AnalyticsEvents.IN_APP_NOTI_CLICKED,
                    EventProperties
                        .create()
                        .with("type", "app lock")
                        .with("lifecycle", lifecycle));

                startActivity(AppLockPrefActivity.startingIntent(HomeActivity.this));
                dismissAppLockNotification();

                break;

            case InAppNotification.TYPE_RATING:
                Analytics.track(
                    AnalyticsEvents.IN_APP_NOTI_CLICKED,
                    EventProperties
                        .create()
                        .with("type", "rating")
                        .with("lifecycle", lifecycle));

                dismissRatingNotification();
                gotoRatingScreen();

                break;
            default:
                break;
        }
    }

    @Override
    public void onNotificationCloseClicked(int type) {
        switch (type) {
            case InAppNotification.TYPE_UPDATE:

                Analytics.track(
                    AnalyticsEvents.IN_APP_NOTI_CLEARED,
                    EventProperties
                        .create()
                        .with("type", "update")
                        .with("lifecycle", lifecycle));
                dismissUpdateNotification();

                break;
            case InAppNotification.TYPE_REMINDER_TO_BE_SENT:

                Analytics.track(
                    AnalyticsEvents.IN_APP_NOTI_CLEARED,
                    EventProperties
                        .create()
                        .with("type", "reminder to be sent")
                        .with("lifecycle", lifecycle));

                dismissReminderNotification();

            case InAppNotification.TYPE_SHARE:

                Analytics.track(
                    AnalyticsEvents.IN_APP_NOTI_CLEARED,
                    EventProperties
                        .create()
                        .with("type", "share")
                        .with("lifecycle", lifecycle));

                dismissShareNotification();

                break;

            case InAppNotification.TYPE_APP_LOCK:

                Analytics.track(
                    AnalyticsEvents.IN_APP_NOTI_CLEARED,
                    EventProperties
                        .create()
                        .with("type", "app lock")
                        .with("lifecycle", lifecycle));

                dismissAppLockNotification();

                break;

            case InAppNotification.TYPE_RATING:

                Analytics.track(
                    AnalyticsEvents.IN_APP_NOTI_CLEARED,
                    EventProperties
                        .create()
                        .with("type", "rating")
                        .with("lifecycle", lifecycle));

                dismissRatingNotification();

                break;
            default:
                break;
        }
    }
}
