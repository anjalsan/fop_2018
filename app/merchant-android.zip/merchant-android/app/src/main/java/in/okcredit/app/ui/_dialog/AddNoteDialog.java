package in.okcredit.app.ui._dialog;

import android.app.Activity;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;

import in.okcredit.R;

public final class AddNoteDialog {
    public interface Listener {
        void onDone(String note);
    }

    public static AlertDialog show(Activity activity, String prefilledNote, Listener listener) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setCancelable(true);

        LayoutInflater layoutInflater = activity.getLayoutInflater();
        View dialogView = layoutInflater.inflate(R.layout.dialog_add_note, null);
        builder.setView(dialogView);

        EditText note = dialogView.findViewById(R.id.note);
        ViewGroup ok = dialogView.findViewById(R.id.ok);

        note.setText(prefilledNote);
        note.setSelection(note.getText().length());

        AlertDialog alertDialog = builder.create();
        ok.setOnClickListener(v ->
        {
            if (listener != null)
                listener.onDone(note.getText().toString());
            alertDialog.dismiss();
        });
        alertDialog.show();
        note.requestFocus();
        alertDialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);

        return alertDialog;
    }

    private AddNoteDialog() {
    }
}
