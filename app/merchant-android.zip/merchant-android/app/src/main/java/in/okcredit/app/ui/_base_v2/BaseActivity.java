package in.okcredit.app.ui._base_v2;

import android.Manifest;
import android.support.v4.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import butterknife.BindView;
import dagger.android.AndroidInjection;
import dagger.android.AndroidInjector;
import dagger.android.DispatchingAndroidInjector;
import dagger.android.support.HasSupportFragmentInjector;
import in.okcredit.App;
import in.okcredit.AppLockManager;
import in.okcredit.Constants;
import in.okcredit.LocaleManager;
import in.okcredit.R;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui.app_lock.prompt.AppLockPromptActivity;
import in.okcredit.app.ui.login.LoginActivity;
import timber.log.Timber;

public abstract class BaseActivity extends AppCompatActivity {
    @Inject
    AppLockManager appLockManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AndroidInjection.inject(this);
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (App.getInstance().wasAppInBackground)
        {
            AppLockManager.getInstance(this).setAppInBackground();
        }

        App.getInstance().stopActivityTransitionTimer();

        if (!(this instanceof AppLockPromptActivity)) {
            if (AppLockManager.getInstance(this).isAppLockAuthReqd()) {
                startActivity(AppLockPromptActivity.startingIntent(this));
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        App.getInstance().startActivityTransitionTimer();
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleManager.setLocale(base));
    }

    protected void clearFragmentBackStack() {
        int count = getSupportFragmentManager().getBackStackEntryCount();
        for (int i = 0; i < count; i++)
            getSupportFragmentManager().popBackStack();
    }

    protected void help() {
        Analytics.track(AnalyticsEvents.HELP);
        PermissionGrantListener listener = new PermissionGrantListener() {
            @Override
            public void onPermissionGranted(String permission) {
                if (permission.equals(Manifest.permission.CALL_PHONE))
                    callHelp();
            }

            @Override
            public void onPermissionDenied(String permission) {
            }
        };

        if (!requestPermission(Manifest.permission.CALL_PHONE, listener))
            callHelp();
    }

    private void callHelp() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED)
            return;

        Intent intent = new Intent(Intent.ACTION_CALL);
        intent.setData(Uri.parse("tel:" + getHelpNumber()));
        startActivity(intent);
    }

    /****************************************************************
     Permissions
     ****************************************************************/
    private Map<Integer, PermissionGrantListener> permissionGrantListenerMap;

    public boolean requestPermission(String permission, @NonNull PermissionGrantListener permissionGrantListener) {
        if (ActivityCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED)
            return false;
        int requestCode = (int) (1000 * Math.random());
        if (permissionGrantListenerMap == null)
            permissionGrantListenerMap = new HashMap<>();
        permissionGrantListenerMap.put(requestCode, permissionGrantListener);
        ActivityCompat.requestPermissions(this, new String[]{permission}, requestCode);
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        PermissionGrantListener listener = permissionGrantListenerMap.get(requestCode);
        if (permissionGrantListenerMap.containsKey(requestCode) && permissions.length == 1 && grantResults.length == 1) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED)
                listener.onPermissionGranted(permissions[0]);
            else
                listener.onPermissionDenied(permissions[0]);
            permissionGrantListenerMap.remove(requestCode);
        } else
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    /****************************************************************
     Action Bar
     ****************************************************************/
    @Nullable @BindView(R.id.toolbar) Toolbar toolbar;

    private void initActionBar() {
        if (toolbar != null)
            setSupportActionBar(toolbar);
        else
            throw new NullPointerException("toolbar");
    }

    public void showActionBar(boolean showUp) {
        initActionBar();
        if (toolbar != null) {
            toolbar.setVisibility(View.VISIBLE);
            if (getSupportActionBar() != null)
                getSupportActionBar().setDisplayHomeAsUpEnabled(showUp);
        } else {
            throw new NullPointerException("toolbar");
        }
    }

    public void hideActionBar() {
        initActionBar();
        if (toolbar != null && toolbar.getVisibility() != View.GONE)
            toolbar.setVisibility(View.GONE);
    }

    @Override
    public void setTitle(int titleId) {
        if (getSupportActionBar() != null)
            getSupportActionBar().setTitle(titleId);
        else
            throw new NullPointerException("action bar");
    }

    @Override
    public void setTitle(CharSequence title) {
        if (getSupportActionBar() != null)
            getSupportActionBar().setTitle(title);
        else
            throw new NullPointerException("action bar");
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onUpPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    protected void onUpPressed() {
        finish();
    }

    public void gotoLogin() {
        startActivityForResult(LoginActivity.startingIntent(this, LoginActivity.FLAG_AUTH_FAIL), 21);
    }

    public String getHelpNumber() {
        String languagePref = LocaleManager.getLanguage();
        if (languagePref != null && languagePref.equals(LocaleManager.LANGUAGE_MALAYALAM)) {
            return Constants.HELP_MOBILE_MALAYALAM;
        } else {
            return Constants.HELP_MOBILE;
        }
    }
}
