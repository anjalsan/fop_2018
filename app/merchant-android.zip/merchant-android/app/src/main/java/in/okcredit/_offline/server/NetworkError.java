package in.okcredit._offline.server;

import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

import javax.annotation.Nullable;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLHandshakeException;

public class NetworkError extends RuntimeException {
    private Throwable cause;

    private NetworkError(Throwable cause, String error) {
        super(error, cause);
        this.cause = cause;
    }

    @Override
    public Throwable getCause() {
        return cause;
    }


    @Nullable
    public static NetworkError from(final Throwable t) {
        if (t instanceof NetworkError) {
            return (NetworkError) t;
        }

        Throwable throwable = t;
        while (throwable instanceof RuntimeException) {
            // if runtime exception; extract cause
            if (throwable.getCause() == null) {
                break;
            }
            throwable = throwable.getCause();
        }

        if (throwable instanceof IOException) {
            // all network related errors are sub classes of IOException

            if (throwable instanceof UnknownHostException) {
                // Thrown to indicate that the IP address of a host could not be determined
                // DNS resolution failed
                // count = 494
                return new NetworkError(throwable, "unknown_host");
            }

            if (throwable instanceof SocketTimeoutException) {
                // Signals that a timeout has occurred on a socket read or accept.
                // count = 77
                return new NetworkError(throwable, "timeout");
            }

            if (throwable instanceof ConnectException) {
                // Signals that an error occurred while attempting to connect a socket to a remote address and port.
                // count = 58
                return new NetworkError(throwable, "conn_error");
            }

            if (throwable instanceof SSLHandshakeException) {
                // Indicates that the client and server could not negotiate the desired level of security
                return new NetworkError(throwable, "ssl_handshake_error");
            }

            // Generic Network Error
            if (throwable instanceof SocketException) {
                // Thrown to indicate that there is an error creating or accessing a Socket.
                return new NetworkError(throwable, "network_error");
            }

            // Generic SSL Error
            if (throwable instanceof SSLException) {
                // Indicates some kind of error detected by an SSL subsystem.
                return new NetworkError(throwable, "ssl_error");
            }

            // not a network error
            return null;
        } else {
            // not a network error; all derive from IOException
            return null;
        }
    }
}
