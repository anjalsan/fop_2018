package in.okcredit.app.ui.login;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import dagger.android.AndroidInjection;
import in.okcredit.AppLockManager;
import in.okcredit.R;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base.BaseActivity;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui._utils.KeyboardUtil;
import in.okcredit.app.ui.home.HomeActivity;
import in.okcredit.app.ui.mobile.MobileActivity;
import in.okcredit.app.ui.reset_pwd.ResetPwdActivity;
import timber.log.Timber;

public class LoginActivity extends BaseActivity implements Login.View {
    public static final String ARG_MOBILE = "mobile";
    public static final String ARG_FLAG = "flag";

    public static final int FLAG_DEFAULT = 0;
    public static final int FLAG_AUTH_FAIL = 1;
    public static final int FLAG_FORGOT_PATTERN = 2;

    public static final int REQUEST_CODE = 999;

    public static Intent startingIntent(Context context, String mobile) {
        Intent intent = new Intent(context, LoginActivity.class);
        intent.putExtra(ARG_MOBILE, mobile);
        return intent;
    }

    public static Intent startingIntent(Context context, int flag) {
        Intent intent = new Intent(context, LoginActivity.class);
        intent.putExtra(ARG_FLAG, flag);
        return intent;
    }

    /* UI Elements */
    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.mobile)
    TextView mobile;
    @BindView(R.id.password)
    TextInputLayout password;
    @BindView(R.id.ok)
    ViewGroup ok;
    @BindView(R.id.loading)
    ProgressBar loading;
    @BindView(R.id.logoutMsg)
    LinearLayout logoutMsg;

    /* Presenter */
    @Inject
    Login.Presenter presenter;

    /* Lifecycle methods */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AndroidInjection.inject(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.screen_login);
        ButterKnife.bind(this);

        Analytics.track(AnalyticsEvents.SIGN_IN_SCREEN);

        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("");
        }

        logoutMsg.setVisibility(View.GONE);

        if (isAuthFailure()) {
            logoutMsg.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.attachView(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        presenter.detachView();
        hideLoading();
        KeyboardUtil.hideKeyboard(this, password);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.clear();
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_with_help, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.help:
                startHelpFlow();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (grantResults.length > 0 && Arrays.asList(permissions).contains(Manifest.permission
            .CALL_PHONE) && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startHelpFlow();
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    @Override
    public void onBackPressed() {
        if (!isAuthFailure()) {
            gotoMobileScreen();
        }
    }

    private boolean isStartedForResult() {
        Timber.i("isStartedForResult: %s", getCallingActivity());
        return getIntent().getStringExtra(ARG_MOBILE) == null;
    }

    /****************************************************************
     * Listener
     ****************************************************************/
    @OnClick(R.id.ok)
    public void onOkClicked() {
        if (password.getEditText() == null) {
            return;
        }

        presenter.login(password.getEditText().getText().toString());

        // analytics
        Analytics.track(
            AnalyticsEvents.SIGN_IN_CLICK_NEXT,
            EventProperties.create()
                           .with("username", getIntent().getStringExtra(ARG_MOBILE))
        );
        // analytics
    }

    @OnClick(R.id.forgot)
    public void onForgotClicked() {
        Analytics.track(
            AnalyticsEvents.PASSWORD_CHANGE_CLICKED,
            EventProperties
                .create()
                .with("type", "login")
        );
        startActivity(ResetPwdActivity.startingIntent(this, mobile.getText().toString(), ResetPwdActivity.REQUESTED_SCREEN_LOGIN));
    }

    /****************************************************************
     MVP methods
     ****************************************************************/
    @Override
    public void gotoMobileScreen() {
        if (!isAuthFailure()) {
            startActivity(MobileActivity.startingIntent(this));
            finish();
        }
    }


    @Override
    public void setMobile(String mobileNumber) {
        mobile.setText(mobileNumber);
    }

    @Override
    public void showLoading() {
        loading.setVisibility(View.VISIBLE);
        ok.setVisibility(View.GONE);
    }

    @Override
    public void hideLoading() {
        loading.setVisibility(View.GONE);
        ok.setVisibility(View.VISIBLE);
    }

    @Override
    public void onSuccess() {

        Analytics.track(AnalyticsEvents.SIGN_IN_SUCCESS);

        if (getIntent().getIntExtra(ARG_FLAG, FLAG_DEFAULT) == FLAG_FORGOT_PATTERN) {
            AppLockManager.getInstance(this).clearAppLockData();
            startActivity(HomeActivity.startingIntent(this));
            finish();

            return;
        }

        if (isStartedForResult()) {
            finish();
        } else {
            startActivity(HomeActivity.startingIntent(this));
            finish();
        }
    }

    @Override
    public void displayInvalidCredentialsError() {
        password.setErrorEnabled(true);
        password.setError(getString(R.string.txn_incorrect_password));
        Analytics.track(AnalyticsEvents.SIGN_IN_INCORRECT_PASSWORD);
    }

    @Override
    public void onError(String tag) {
        ok.setVisibility(View.VISIBLE);
        Toast.makeText(this, getString(R.string.login_err), Toast.LENGTH_SHORT).show();
        Analytics.track(AnalyticsEvents.SIGN_IN_FAILED);
    }

    @Override
    public void onAuthenticationFailure() {
        // no op
    }

    @Override
    public void onNetworkFailure() {
        new NetworkErrorDialog().show(this, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
            }

            @Override
            public void onCancel() {
            }
        });
    }

    private boolean isAuthFailure() {
        return getIntent().getIntExtra(ARG_FLAG, FLAG_DEFAULT) == FLAG_AUTH_FAIL;
    }
}
