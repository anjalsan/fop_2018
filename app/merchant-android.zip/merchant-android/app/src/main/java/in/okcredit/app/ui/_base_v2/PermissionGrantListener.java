package in.okcredit.app.ui._base_v2;

public interface PermissionGrantListener {
    void onPermissionGranted(String permission);

    void onPermissionDenied(String permission);
}
