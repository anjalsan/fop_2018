package in.okcredit._offline.usecase;

import javax.inject.Inject;

import in.okcredit._offline.server.Server;
import io.reactivex.Completable;

// Internet
public final class Register {
    private Server server;
    private Signin signin;

    @Inject
    public Register(Server server, Signin signin) {
        this.server = server;
        this.signin = signin;
    }

    public Completable execute(String mobile, String name, String password, String token, String lang) {
        return server.register(mobile, name, password, token, lang)
                     .andThen(signin.execute(mobile, password));
    }
}
