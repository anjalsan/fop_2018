package in.okcredit.app.ui.rating._di;

import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import in.okcredit._di.PresenterParam;
import in.okcredit._di.scope.FragmentScope;
import in.okcredit.app.ui.rating.playstore_rating.PlaystoreRatingContract;
import in.okcredit.app.ui.rating.playstore_rating.PlaystoreRatingFragment;
import in.okcredit.app.ui.rating.playstore_rating.PlaystoreRatingPresenter;

@Module
public abstract class PlaystoreRatingFragment_Module {
    @Binds
    @FragmentScope
    public abstract PlaystoreRatingContract.Presenter presenter(PlaystoreRatingPresenter presenter);
}
