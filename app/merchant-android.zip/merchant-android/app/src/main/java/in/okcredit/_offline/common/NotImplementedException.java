package in.okcredit._offline.common;

public class NotImplementedException extends RuntimeException {
    public NotImplementedException() {
        super("not implemented");
    }
}
