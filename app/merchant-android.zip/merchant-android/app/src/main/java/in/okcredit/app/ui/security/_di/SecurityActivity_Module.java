package in.okcredit.app.ui.security._di;

import dagger.Binds;
import dagger.Module;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit.app.ui.security.SecurityContract;
import in.okcredit.app.ui.security.SecurityPresenter;

@Module
public abstract class SecurityActivity_Module {

    @Binds
    @ActivityScope
    public abstract SecurityContract.Presenter presenter(SecurityPresenter presenter);
}
