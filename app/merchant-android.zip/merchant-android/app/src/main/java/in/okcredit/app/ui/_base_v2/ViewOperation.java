package in.okcredit.app.ui._base_v2;

public interface ViewOperation<V extends MVP.View> {
    void runFor(V view);
}
