package in.okcredit.app.ui.account_statement;

import org.joda.time.DateTime;

import java.util.List;

import in.okcredit._offline.model.TransactionWrapper;
import in.okcredit.app.ui._base.BasePresenter;
import in.okcredit.app.ui._base.BaseView;

public interface AccountStatement {
    interface Presenter extends BasePresenter<View> {
        void load(List<Integer> types, DateTime from, DateTime to);
    }

    interface View extends BaseView {
        void showLoading();

        void displayTransactions(List<TransactionWrapper> transactions);

        void displayNoTransactionsMessage();
    }
}
