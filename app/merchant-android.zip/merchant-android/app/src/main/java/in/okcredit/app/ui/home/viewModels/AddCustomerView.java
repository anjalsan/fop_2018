package in.okcredit.app.ui.home.viewModels;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.support.annotation.Nullable;
import android.text.Html;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.airbnb.epoxy.CallbackProp;
import com.airbnb.epoxy.ModelProp;
import com.airbnb.epoxy.ModelView;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.R;

@ModelView(autoLayout = ModelView.Size.MATCH_WIDTH_WRAP_HEIGHT)
public class AddCustomerView extends LinearLayout {

    public interface AddCustomerListener {
        void onClickAddFromSearchCustomer();
    }

    @BindView(R.id.addCustomer)
    TextView addCustomer;

    @BindView(R.id.addCustomerMsg)
    TextView addCustomerMsg;

    public AddCustomerView(Context context) {
        super(context);
        initView();
    }

    public AddCustomerView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public AddCustomerView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }

    @ModelProp
    public void setQuery(String query) {
        addCustomerMsg.setText(Html.fromHtml(getContext().getString(R.string.customer_not_found,
                    query)));
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public AddCustomerView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        initView();
    }

    @CallbackProp
    public void setListener(@Nullable AddCustomerListener listener) {
        if (listener != null) {
            addCustomer.setOnClickListener((OnClickListener) v -> listener.onClickAddFromSearchCustomer());
        }
    }

    private void initView() {
        setOrientation(LinearLayout.HORIZONTAL);
        inflate(getContext(), R.layout.view_add_customer, this);
        ButterKnife.bind(this);
    }
}
