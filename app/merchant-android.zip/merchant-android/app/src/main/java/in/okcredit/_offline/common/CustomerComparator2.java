package in.okcredit._offline.common;

import org.joda.time.DateTime;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import in.okcredit._offline.model.Customer;

public class CustomerComparator2 {
    public static class Name implements Comparator<Customer> {
        @Override
        public int compare(Customer c1, Customer c2) {
            return c1.getDescription().toLowerCase().compareTo(c2.getDescription().toLowerCase());
        }
    }

    public static class AbsoluteBalance implements Comparator<Customer> {
        @Override
        public int compare(Customer c1, Customer c2) {
            float b1 = Math.abs(c1.getBalance());
            float b2 = Math.abs(c2.getBalance());
            if (b1 > b2)
                return -1;
            else if (b1 < b2)
                return 1;
            else
                return 0;
        }
    }

    public static class RecentActivity implements Comparator<Customer> {
        @Override
        public int compare(Customer c1, Customer c2) {
            DateTime a1 = c1.getLastActivity();
            DateTime a2 = c2.getLastActivity();

            if (a1 == null)
                a1 = new DateTime(0);

            if (a2 == null)
                a2 = new DateTime(0);

            if (a1.isAfter(a2))
                return -1;
            else if (a1.isBefore(a2))
                return 1;
            else
                return 0;
        }
    }

    public static class LastPayment implements Comparator<Customer> {
        @Override
        public int compare(Customer c1, Customer c2) {
            DateTime a1 = c1.getLastPayment();
            DateTime a2 = c2.getLastPayment();

            if (a1 == null)
                a1 = c1.getCreatedAt();

            if (a2 == null)
                a2 = c2.getCreatedAt();

            if (a1 == null)
                a1 = new DateTime(2220,1, 2,3,4);

            if (a2 == null)
                a2 = new DateTime(2220,1, 2,3,4);

            if (a1.isAfter(a2))
                return 1;
            else if (a1.isBefore(a2))
                return -1;
            else
                return 0;
        }
    }

    public static class Balance implements Comparator<Customer> {
        @Override
        public int compare(Customer c1, Customer c2) {
            String a1 = "1";
            if (c1.getBalance() > 0) {
                a1 = "2";
            } else if (c1.getBalance() < 0){
                a1 = "0";
            } else {
                a1 ="1";
            }

            String a2 = "1";
            if (c2.getBalance() > 0) {
                a2 = "2";
            } else if (c2.getBalance() < 0){
                a2 = "0";
            } else {
                a2 = "1";
            }

            return a1.compareTo(a2);
        }
    }

    public static class CustomerChainedComparator implements Comparator<Customer> {

        private List<Comparator<Customer>> listComparators;

        @SafeVarargs
        public CustomerChainedComparator(Comparator<Customer>... comparators) {
            this.listComparators = Arrays.asList(comparators);
        }

        @Override
        public int compare(Customer emp1, Customer emp2) {
            for (Comparator<Customer> comparator : listComparators) {
                int result = comparator.compare(emp1, emp2);
                if (result != 0) {
                    return result;
                }
            }
            return 0;
        }
    }

    private CustomerComparator2() {
    }
}
