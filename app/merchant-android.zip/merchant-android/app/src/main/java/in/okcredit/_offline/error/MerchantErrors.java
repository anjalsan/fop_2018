package in.okcredit._offline.error;

public final class MerchantErrors {
    public static class InvalidName extends Exception {
    }

    public static class NameChangeLimitExceeded extends Exception {
    }

    private MerchantErrors() {
    }
}
