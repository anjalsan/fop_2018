package in.okcredit.app.ui.help.main;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.R;
import in.okcredit.domain.help.HelpSection;
import in.okcredit.util.GlideApp;

/**
 * Created by harsh on 20/12/17.
 */

public class HelpSectionViewHolder extends RecyclerView.ViewHolder {
    public static HelpSectionViewHolder create(Context context, ViewGroup parent,
                                               HelpSectionSelectionListener listener) {
        return new HelpSectionViewHolder(
            context,
            LayoutInflater
                .from(context)
                .inflate(R.layout.help_section_item, parent, false),
            listener
        );
    }

    @BindView(R.id.title)
    TextView title;

    @BindView(R.id.subtitle)
    TextView subtitle;

    @BindView(R.id.icon)
    ImageView icon;

    private Context context;
    private HelpSectionSelectionListener listener;

    public HelpSectionViewHolder(Context context, View itemView, HelpSectionSelectionListener
        listener) {
        super(itemView);
        ButterKnife.bind(this, itemView);
        this.context = context;
        this.listener = listener;
    }

    public void bind(HelpSection helpSection) {
        title.setText(helpSection.getTitle());
        subtitle.setText(helpSection.getSubtitle());

        if (helpSection.getIconUrl() != null) {
            GlideApp.with(context)
                .load(helpSection.getIconUrl())
                .placeholder(R.drawable.ic_placeholder_help)
                .error(R.drawable.ic_placeholder_help)
                .into(icon);
        }

        itemView.setOnClickListener(v ->
        {
            if (listener != null) {
                listener.onSelected(helpSection);
            }
        });
    }
}
