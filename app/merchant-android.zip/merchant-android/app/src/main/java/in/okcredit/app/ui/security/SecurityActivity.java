package in.okcredit.app.ui.security;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.R;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui._dialog.LogoutConfirmationDialog;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui.app_lock.preference.AppLockPrefActivity;
import in.okcredit.app.ui.language.LanguageActivity;
import in.okcredit.app.ui.reset_pwd.ResetPwdActivity;

public class SecurityActivity extends BaseActivity implements SecurityContract.View {

    public static Intent startingIntent(Context context) {
        return new Intent(context, SecurityActivity.class);
    }

    @BindView(R.id.app_lock)
    RelativeLayout appLock;

    @BindView(R.id.changePassword)
    RelativeLayout changePassword;

    @BindView(R.id.logout)
    RelativeLayout logout;

    @BindView(R.id.appLockStatus)
    TextView appLockStatus;

    @Inject
    SecurityContract.Presenter presenter;

    AlertDialog logoutConfirmation;

    /* Lifecycle methods */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Analytics.track(AnalyticsEvents.SECURITY_SCREEN);

        setContentView(R.layout.screen_security);
        ButterKnife.bind(this);

        showActionBar(true);
        setTitle(R.string.account_security);

        appLock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Analytics.track(AnalyticsEvents.SECURITY_APP_LOCK_CLICKED);
                gotoAppLockScreen();
            }
        });

        changePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Analytics.track(AnalyticsEvents.SECURITY_CHANGE_PASSWORD_CLICKED);
                presenter.onResetPasswordClicked();
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Analytics.track(AnalyticsEvents.SECURITY_LOGOUT_CLICKED);
                showLogoutConfirmation();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.attachView(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        presenter.detachView();
        hideDialogs();
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    public void gotoAppLockScreen() {
        startActivity(AppLockPrefActivity.startingIntent(this));
    }


    @Override
    public void onLogoutSuccessful() {
        hideDialogs();
        startActivity(LanguageActivity.startingIntent(this));
        finish();
    }

    @Override
    public void gotoResetPasswordScreen(String mobile) {
        Analytics.track(
            AnalyticsEvents.PASSWORD_CHANGE_CLICKED,
            EventProperties
                .create()
                .with("type", "security")
        );
        startActivity(ResetPwdActivity.startingIntent(this, mobile, ResetPwdActivity.REQUESTED_SCREEN_SECURITY));
    }

    @Override
    public void setAppLockStatus(boolean isAppLockActive) {

        if (isAppLockActive) {
            appLockStatus.setText(getString(R.string.status_on));
        } else {
            appLockStatus.setText(getString(R.string.status_off));
        }
    }

    @Override
    public void displayInvalidCredentialsError() {
        hideDialogs();
        Toast.makeText(this, R.string.account_incorrect_password, Toast.LENGTH_SHORT).show();
    }

    private void showLogoutConfirmation() {
        logoutConfirmation = LogoutConfirmationDialog
            .show(SecurityActivity.this, true, password -> presenter.logout(password));
    }

    @Override
    public void showError() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "security screen")
                .with("type", "server error")
        );

        Toast.makeText(this, R.string.err_default, Toast.LENGTH_LONG).show();
        finish();
    }

    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(this, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
            }
        });
    }

    private void hideDialogs() {

        if (logoutConfirmation != null) {
            logoutConfirmation.dismiss();
            logoutConfirmation = null;
        }

    }
}
