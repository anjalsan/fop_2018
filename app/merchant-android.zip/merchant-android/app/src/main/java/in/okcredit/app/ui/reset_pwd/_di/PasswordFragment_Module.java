package in.okcredit.app.ui.reset_pwd._di;

import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import in.okcredit._di.PresenterParam;
import in.okcredit._di.scope.FragmentScope;
import in.okcredit.app.ui.reset_pwd.password.PasswordContract;
import in.okcredit.app.ui.reset_pwd.password.PasswordFragment;
import in.okcredit.app.ui.reset_pwd.password.PasswordPresenter;

@Module
public abstract class PasswordFragment_Module {
    @Binds
    @FragmentScope
    public abstract PasswordContract.Presenter presenter(PasswordPresenter presenter);

    @Provides
    @FragmentScope
    @PresenterParam("mobile")
    public static String mobile(PasswordFragment fragment) {
        return fragment.getArguments().getString(PasswordFragment.ARG_MOBILE);
    }

    @Provides
    @FragmentScope
    @PresenterParam("token")
    public static String token(PasswordFragment fragment) {
        return fragment.getArguments().getString(PasswordFragment.ARG_TOKEN);
    }

    @Provides
    @FragmentScope
    @PresenterParam("requested_screen")
    public static String requestedScreen(PasswordFragment fragment) {
        return fragment.getArguments().getString(PasswordFragment.ARG_REQUESTED_SCREEN);
    }
}
