package in.okcredit.app.ui.help.item;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.R;
import in.okcredit.util.GlideApp;

/**
 * Created by harsh on 20/12/17.
 */

public class ScreenshotsViewHolder extends RecyclerView.ViewHolder {
    public static ScreenshotsViewHolder create(Context context, ViewGroup parent) {
        return new ScreenshotsViewHolder(
            context,
            LayoutInflater
                .from(context)
                .inflate(R.layout.help_item_screenshot, parent, false)
        );
    }

    //
    @BindView(R.id.screenshot)
    ImageView screenshot;

    private Context context;

    public ScreenshotsViewHolder(Context context, View itemView) {
        super(itemView);
        ButterKnife.bind(this, itemView);
        this.context = context;
    }

    public void bind(String screenshotUrl) {
        if (screenshot != null) {
            GlideApp.with(context)
                .load(screenshotUrl)
                .placeholder(R.drawable.ic_placeholder_help)
                .error(R.drawable.ic_receipt)
                .into(screenshot);
        }
    }
}
