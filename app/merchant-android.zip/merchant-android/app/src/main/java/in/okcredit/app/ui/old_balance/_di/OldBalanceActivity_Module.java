package in.okcredit.app.ui.old_balance._di;

import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import in.okcredit._di.PresenterParam;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit.app.ui.old_balance.OldBalanceActivity;
import in.okcredit.app.ui.old_balance.OldBalanceContract;
import in.okcredit.app.ui.old_balance.OldBalancePresenter;
import in.okcredit._offline.model.Customer;

@Module
public abstract class OldBalanceActivity_Module {
    @Binds
    @ActivityScope
    public abstract OldBalanceContract.Presenter presenter(OldBalancePresenter presenter);

    @Provides
    @ActivityScope
    @PresenterParam("customer")
    public static Customer customer(OldBalanceActivity activity) {
        return (Customer) activity.getIntent().getSerializableExtra(OldBalanceActivity
            .ARG_CUSTOMER);
    }

    @Provides
    @ActivityScope
    @PresenterParam("lifecycle")
    public static int getLifecycle(OldBalanceActivity activity) {
        int lifecycle = activity.getIntent().getIntExtra(OldBalanceActivity.ARG_LIFECYCLE, 0);
        if (lifecycle == 0) {
            throw new IllegalArgumentException("lifecycle");
        }
        return lifecycle;
    }
}
