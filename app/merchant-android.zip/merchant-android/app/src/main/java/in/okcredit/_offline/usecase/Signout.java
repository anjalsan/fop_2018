package in.okcredit._offline.usecase;

import javax.inject.Inject;

import in.okcredit.AppLockManager;
import in.okcredit.ThreadUtils;
import in.okcredit._offline.Constants;
import in.okcredit._offline.database.CustomerRepo;
import in.okcredit._offline.database.MerchantRepo;
import in.okcredit._offline.database.TransactionRepo;
import in.okcredit.domain.auth.AuthDomain;
import in.okcredit.service.keyval.KeyValService;
import io.reactivex.Completable;

// Internet (if hard logout)
public final class Signout {
    private AuthDomain authDomain;
    private MerchantRepo merchantRepo;
    private CustomerRepo customerRepo;
    private TransactionRepo transactionRepo;
    private SyncDirtyTransactions syncDirtyTransactions;
    private AppLockManager appLockManager;
    private KeyValService keyValService;

    @Inject
    public Signout(AuthDomain authDomain, MerchantRepo merchantRepo, CustomerRepo customerRepo, TransactionRepo transactionRepo, SyncDirtyTransactions syncDirtyTransactions, AppLockManager appLockManager, KeyValService keyValService) {
        this.authDomain = authDomain;
        this.merchantRepo = merchantRepo;
        this.customerRepo = customerRepo;
        this.transactionRepo = transactionRepo;
        this.syncDirtyTransactions = syncDirtyTransactions;
        this.appLockManager = appLockManager;
        this.keyValService = keyValService;
    }

    public Completable execute(String password) {
        return syncDirtyTransactions
            .execute()
            .andThen(Completable.fromAction(() -> appLockManager.clearAppLockData()))
            .andThen(authDomain.logout(password))
            .andThen(deleteAuthScope())
            .andThen(transactionRepo.clear())
            .andThen(customerRepo.clear())
            .andThen(merchantRepo.clear());
    }

    private Completable deleteAuthScope() {
        return keyValService.delete(Constants.KEY_AUTH_SYNC_TIME)
                            .subscribeOn(ThreadUtils.database());
    }
}
