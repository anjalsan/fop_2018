package in.okcredit.app.ui.rating.playstore_rating;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import dagger.android.AndroidInjection;
import dagger.android.support.AndroidSupportInjection;
import in.okcredit.R;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui.rating.RatingActivity;

public class PlaystoreRatingFragment extends Fragment implements PlaystoreRatingContract.View {

    public static PlaystoreRatingFragment newInstance() {
        Bundle args = new Bundle();
        PlaystoreRatingFragment fragment = new PlaystoreRatingFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @BindView(R.id.rate_playstore)
    TextView ratePlaystore;

    @Inject
    RatingActivity activity;

    @Inject
    PlaystoreRatingContract.Presenter presenter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle
        savedInstanceState) {
        View view = inflater.inflate(R.layout.playstore_rating_fragment, container, false);
        ButterKnife.bind(this, view);

        ratePlaystore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                presenter.goToPlaystore(activity);
                Analytics.track(AnalyticsEvents.RATING_PLAYSTORE_CLICKED);
            }
        });

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        AndroidSupportInjection.inject(this);
        Analytics.track(AnalyticsEvents.RATING_PLAYSTORE_SCREEN);
    }

    @Override
    public void onResume() {
        super.onResume();
        presenter.attachView(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        presenter.detachView();
    }

    /****************************************************************
     MVP methods
     ****************************************************************/



    /****************************************************************
     Unexpected
     ****************************************************************/
    @Override
    public void showError() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "rating playstore")
                .with("type", "server error")
        );

        Toast.makeText(activity, R.string.err_default, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(activity, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
            }
        });
    }
}
