package in.okcredit._offline.usecase;

import javax.inject.Inject;

import in.okcredit._offline.model.Customer;
import io.reactivex.Observable;

public final class GetAccountSummary {
    private GetActiveCustomers getActiveCustomers;

    @Inject
    public GetAccountSummary(GetActiveCustomers getActiveCustomers) {
        this.getActiveCustomers = getActiveCustomers;
    }

    public Observable<AccountSummary> execute() {
        return getActiveCustomers.execute()
                                 .map(customers -> {
                                     float balance = 0.0f;
                                     for (Customer customer : customers) {
                                         balance += customer.getBalance();
                                     }
                                     return new AccountSummary(balance, customers.size());
                                 });
    }

    public static final class AccountSummary {
        public final float balance;
        public final int customerCount;

        public AccountSummary(float balance, int customerCount) {
            this.balance = balance;
            this.customerCount = customerCount;
        }
    }
}
