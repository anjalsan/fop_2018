package in.okcredit._offline.usecase;

import javax.inject.Inject;

import in.okcredit._offline.server.Server;
import io.reactivex.Completable;

// Internet
public final class SubmitFeedback {
    private Server server;

    @Inject
    public SubmitFeedback(Server server) {
        this.server = server;
    }

    public Completable execute(String feedback, int rating) {
        return server.submitFeedback(feedback, rating);
    }
}
