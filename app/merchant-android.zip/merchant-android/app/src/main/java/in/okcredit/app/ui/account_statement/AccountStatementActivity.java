package in.okcredit.app.ui.account_statement;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Pair;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import org.joda.time.DateTime;
import org.joda.time.LocalTime;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import dagger.android.AndroidInjection;
import in.okcredit.LifecycleState;
import in.okcredit.R;
import in.okcredit._offline.model.TransactionWrapper;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base.BaseActivity;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui.transaction.TransactionActivity;

public class AccountStatementActivity extends BaseActivity implements AccountStatement.View {
    public static final int TYPE_ALL = 0;
    public static final int TYPE_CREDIT = 1;
    public static final int TYPE_PAYMENT = 2;
    public static final int TYPE_RETURN = 3;

    public static final int PERIOD_TODAY = 0;
    public static final int PERIOD_YESTERDAY = 1;
    public static final int PERIOD_THIS_WEEK = 2;
    public static final int PERIOD_LAST_WEEK = 3;
    public static final int PERIOD_THIS_MONTH = 4;
    public static final int PERIOD_LAST_MONTH = 5;
    public static final int PERIOD_ALL = 6;

    public static final String ARG_TYPE = "type";
    public static final String ARG_PERIOD = "period";

    public static Intent startingIntent(Context context) {
        return startingIntent(context, TYPE_ALL, PERIOD_TODAY);
    }

    public static Intent startingIntent(Context context, int type, int period) {
        Intent intent = new Intent(context, AccountStatementActivity.class);
        intent.putExtra(ARG_TYPE, type);
        intent.putExtra(ARG_PERIOD, period);
        return intent;
    }

    /* UI Elements */
    @BindView(R.id.typeSelection)
    Spinner typeSelection;

    @BindView(R.id.dateSelection)
    Spinner dateSelection;

    @BindView(R.id.loading)
    View loading;

    @BindView(R.id.noTx)
    View noTx;

    @BindView(R.id.txList)
    RecyclerView txList;

    @BindView(R.id.error)
    View error;

    @BindView(R.id.errorMessage)
    TextView errorMessage;

    @BindView(R.id.tryAgain)
    Button tryAgain;

    /* Data */
    int currentTypeSelection;
    Map<Integer, List<Integer>> typeMapping;

    Map<Integer, Pair<DateTime, DateTime>> dateMappings;
    int currentDateSelection;

    TransactionAdapter transactionAdapter;

    /* Presenter */
    @Inject
    AccountStatement.Presenter presenter;

    /* Lifecycle methods */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AndroidInjection.inject(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.screen_account_statement);
        ButterKnife.bind(this);

        setupActionBar(R.string.account_statement);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Analytics.track(AnalyticsEvents.ACCOUNT_STATEMENT_SCREEN);

        // Setup type options
        currentTypeSelection = getIntent().getIntExtra(ARG_TYPE, TYPE_ALL);
        typeMapping = new HashMap<>();
        typeMapping.put(TYPE_ALL, Collections.unmodifiableList(Arrays.asList(1, 2, 3))); // All Transactions
        typeMapping.put(TYPE_CREDIT, Collections.singletonList(1)); // AddCredit
        typeMapping.put(TYPE_PAYMENT, Collections.singletonList(2)); // AddPayment
        typeMapping.put(TYPE_RETURN, Collections.singletonList(3)); // AddReturn

        ArrayAdapter<CharSequence> typeAdapter = ArrayAdapter.createFromResource(this, R.array.spinner_tx_type, android.R.layout.simple_spinner_item);
        typeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        typeSelection.setAdapter(typeAdapter);
        typeSelection.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                currentTypeSelection = position;
                Analytics.track(
                    AnalyticsEvents.ACCOUNT_STATEMENT_TYPE_SELECTED,
                    EventProperties
                        .create()
                        .with("type", currentTypeSelection));
                reload();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                currentTypeSelection = 0;
                reload();
            }
        });
        typeSelection.setSelection(currentTypeSelection);


        // Setup date options
        currentDateSelection = getIntent().getIntExtra(ARG_PERIOD, PERIOD_TODAY);
        DateTime now = DateTime.now();
        DateTime todayStart = now.withTime(LocalTime.MIDNIGHT);
        DateTime yesterdayStart = todayStart.minusDays(1).withTime(LocalTime.MIDNIGHT);
        DateTime weekStart = todayStart.withDayOfWeek(1).withTime(LocalTime.MIDNIGHT);
        DateTime lastWeekStart = todayStart.withDayOfWeek(1)
                                           .minusWeeks(1)
                                           .withTime(LocalTime.MIDNIGHT);
        DateTime monthStart = todayStart.withDayOfMonth(1).withTime(LocalTime.MIDNIGHT);
        DateTime lastMonthStart = monthStart.minusMonths(1).withTime(LocalTime.MIDNIGHT);
        DateTime start = new DateTime(2017, 04, 03, 00, 00);

        dateMappings = new HashMap<>();
        dateMappings.put(PERIOD_TODAY, new Pair<>(todayStart, now)); // Today
        dateMappings.put(PERIOD_YESTERDAY, new Pair<>(yesterdayStart, todayStart)); // Yesterday
        dateMappings.put(PERIOD_THIS_WEEK, new Pair<>(weekStart, now)); // This Week
        dateMappings.put(PERIOD_LAST_WEEK, new Pair<>(lastWeekStart, weekStart)); // Last Week
        dateMappings.put(PERIOD_THIS_MONTH, new Pair<>(monthStart, now)); // This month
        dateMappings.put(PERIOD_LAST_MONTH, new Pair<>(lastMonthStart, monthStart)); // Last month
        dateMappings.put(PERIOD_ALL, new Pair<>(start, now)); // Last month

        ArrayAdapter<CharSequence> dateAdapter = ArrayAdapter.createFromResource(this, R.array.spinner_date, android.R.layout.simple_spinner_item);
        dateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dateSelection.setAdapter(dateAdapter);
        dateSelection.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                currentDateSelection = position;
                Analytics.track(
                    AnalyticsEvents.ACCOUNT_STATEMENT_DATE_SELECTED,
                    EventProperties
                        .create()
                        .with("type", currentDateSelection));
                reload();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                currentDateSelection = 0;
                reload();
            }
        });
        dateSelection.setSelection(currentDateSelection);

        // error
        tryAgain.setOnClickListener(v -> reload());

        // setup list
        txList.setLayoutManager(new LinearLayoutManager(this));
        transactionAdapter = new TransactionAdapter(this);
        transactionAdapter.setSelectionListener(transaction ->
        {
            startActivity(TransactionActivity.startingIntent(this, transaction.getId(), LifecycleState.NORMAL_FLOW, false));
            Analytics.track(
                AnalyticsEvents.TX_CLICK,
                EventProperties
                    .create()
                    .with("from", "account_statement")
            );
        });
        txList.setAdapter(transactionAdapter);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        presenter.attachView(this);
    }

    @Override
    protected void onStop() {
        super.onStop();
        presenter.detachView();
    }

    /* View methods */
    @Override
    public void onError(String tag) {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "account statement")
                .with("type", tag)
        );

        error.setVisibility(View.VISIBLE);
        txList.setVisibility(View.GONE);
        loading.setVisibility(View.GONE);
        noTx.setVisibility(View.GONE);

        errorMessage.setText(R.string.err_load_tx);
    }

    @Override
    public void showLoading() {
        loading.setVisibility(View.VISIBLE);
        error.setVisibility(View.GONE);
        txList.setVisibility(View.GONE);
        noTx.setVisibility(View.GONE);
    }

    @Override
    public void displayTransactions(List<TransactionWrapper> transactions) {
        error.setVisibility(View.GONE);
        txList.setVisibility(View.VISIBLE);
        loading.setVisibility(View.GONE);
        noTx.setVisibility(View.GONE);
        transactionAdapter.refreshData(transactions);
    }

    @Override
    public void displayNoTransactionsMessage() {
        error.setVisibility(View.GONE);
        txList.setVisibility(View.GONE);
        loading.setVisibility(View.GONE);
        noTx.setVisibility(View.VISIBLE);
    }

    @Override
    public void onNetworkFailure() {
        new NetworkErrorDialog().show(this, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                reload();
            }

            @Override
            public void onCancel() {
                onBackPressed();
            }
        });
    }

    // Helper methods
    private void reload() {
        Pair<DateTime, DateTime> timeRange = dateMappings.get(currentDateSelection);
        presenter.load(typeMapping.get(currentTypeSelection), timeRange.first, timeRange.second);
    }
}
