package in.okcredit.app.ui.customer_profile;

import org.joda.time.DateTime;

import java.io.File;
import java.util.UUID;

import javax.inject.Inject;

import in.okcredit.Constants;
import in.okcredit._di.PresenterParam;
import in.okcredit._di.UiThread;
import in.okcredit._offline.error.CustomerErrors;
import in.okcredit._offline.model.Customer;
import in.okcredit._offline.usecase.CustomerAuth;
import in.okcredit._offline.usecase.GetCustomer;
import in.okcredit._offline.usecase.UpdateCustomer;
import in.okcredit._offline.usecase.UploadFile;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BasePresenter;
import in.okcredit.service.aws.AwsService;
import in.okcredit.service.customerAuthDb.CustomerAuthServiceImpl;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import timber.log.Timber;

public class CustomerProfilePresenter extends BasePresenter<CustomerProfileContract.View> implements CustomerProfileContract.Presenter {
    private CustomerAuthServiceImpl customerAuthDbService;
    private GetCustomer getCustomer;
    private String customerId;
    private UpdateCustomer updateCustomer;
    private boolean isEditMobile;
    private Customer customer;
    private CustomerAuth customerAuth;
    private UploadFile uploadFile;
    private AwsService awsService;
    private boolean isProfilePicChanged = false;

    @Inject
    public CustomerProfilePresenter(@UiThread Scheduler uiScheduler,
                                    GetCustomer getCustomer,
                                    @PresenterParam("customer_id") String customerId,
                                    @PresenterParam("is_edit_mobile") boolean isEditMobile,
                                    UpdateCustomer updateCustomer,
                                    CustomerAuth customerAuth,
                                    UploadFile uploadFile,
                                    AwsService awsService,
                                    CustomerAuthServiceImpl customerAuthDbService) {
        super(uiScheduler);
        this.getCustomer = getCustomer;
        this.customerId = customerId;
        this.updateCustomer = updateCustomer;
        this.isEditMobile = isEditMobile;
        this.customerAuthDbService = customerAuthDbService;
        this.customerAuth = customerAuth;
        this.uploadFile = uploadFile;
        this.awsService = awsService;
    }

    @Override
    protected void loadData() {
        addTask(
            getCustomer
                .execute(customerId)
                .observeOn(uiScheduler)
                .subscribe(
                    customer ->
                    {
                        this.customer = customer;
                        ifAttached(view -> view.setName(customer.getDescription()));

                        ifAttached(view -> view.setMobile(customer.getMobile()));

                        ifAttached(view -> view.setAddress(customer.getAddress()));

                        if (isEditMobile){
                            ifAttached(view -> view.showMobileEditBox());
                            isEditMobile = false;
                        }

                        if (customer.getProfileImage() != null) {
                            addTask(awsService
                                .getFile(customer.getProfileImage())
                                .observeOn(AndroidSchedulers.mainThread())
                                .subscribe(fileInfo -> {
                                    if (fileInfo.isLocal) {
                                        Timber.i("Local Image Url");
                                        if (!isProfilePicChanged) {
                                            ifAttached(view -> view.setProfileImageLocal(fileInfo.localFile));
                                        }
                                    } else {
                                        Timber.i("Remote Image Url");
                                        if (!isProfilePicChanged) {
                                            ifAttached(view -> view.setProfileImageRemote(fileInfo.url));
                                        }
                                    }
                                }));
                        }
                    },
                    throwable ->
                    {
                        if (isInternetIssue(throwable))
                            ifAttached(view -> view.showNoInternetMessage());
                        else if (isAuthenticationIssue(throwable))
                            ifAttached(view -> view.gotoLogin());
                        else
                            ifAttached(view -> view.showError());
                    }
                )
        );

        addTask(
            customerAuth
                .isCustomerMobileState(customerId)
                .observeOn(uiScheduler)
                .subscribe(
                    otpRequestKey ->
                    {
                        if (otpRequestKey != null && otpRequestKey.getCustomerId() != null && otpRequestKey.getExpiryTime().isAfter(DateTime.now())) {
                            ifAttached(view -> view.setMobileVerificationState(otpRequestKey.getCurrentMobile(), otpRequestKey.getMobile()));
                        }
                    },
                    throwable -> {
                        ifAttached(view -> view.hideMobileConfirmContainer());
                    }
                )
        );
    }

    @Override
    public void saveName(String description) {
        if (description != null && description.length() < 1) {
            ifAttached(view -> view.displayInvalidNameError());
            Analytics.track(
                AnalyticsEvents.EDIT_CUSTOMER_NAME_UPDATE,
                EventProperties
                    .create()
                    .with("error", "length error")
            );
            return;
        } else if (description != null && description.equals(customer.getDescription())) {
            ifAttached(view -> view.setName(customer.getDescription()));
            ifAttached(view -> view.hideNameLoading());
            return;
        }
        ifAttached(view -> view.showNameLoading());
        addTask(updateCustomer
            .execute(customerId, description, customer.getAddress(), customer.getProfileImage(), customer.getMobile(), null)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                () -> {
                    Analytics.track(
                        AnalyticsEvents.EDIT_CUSTOMER_NAME_UPDATE,
                        EventProperties
                            .create()
                            .with("error", "false")
                    );
                    ifAttached(view -> view.hideNameLoading());
                    ifAttached(view -> view.setName(customer.getDescription()));
                },
                e -> {
                    Timber.w(e, "update customer failed");
                    ifAttached(view -> view.hideNameLoading());
                    if (isAuthenticationIssue(e)) {
                        Analytics.track(
                            AnalyticsEvents.EDIT_CUSTOMER_NAME_UPDATE,
                            EventProperties
                                .create()
                                .with("error", "authentication failure")
                        );
                        ifAttached(view -> view.gotoLogin());
                    } else if (isInternetIssue(e)) {
                        Analytics.track(
                            AnalyticsEvents.EDIT_CUSTOMER_NAME_UPDATE,
                            EventProperties
                                .create()
                                .with("error", "internet issue")
                        );
                        ifAttached(view -> view.showNoInternetMessage());
                    } else {
                        Analytics.track(
                            AnalyticsEvents.EDIT_CUSTOMER_NAME_UPDATE,
                            EventProperties
                                .create()
                                .with("error", "true")
                        );
                        ifAttached(view -> view.showError());
                    }
                }
            )
        );
    }

    @Override
    public void saveAddress(String address) {

        if (address != null && address.length() < 1) {
            ifAttached(view -> view.displayInvalidAddressError());
            Analytics.track(
                AnalyticsEvents.EDIT_CUSTOMER_ADDRESS_UPDATE,
                EventProperties
                    .create()
                    .with("error", "length error")
            );
            return;
        } else if (address != null && address.equals(customer.getAddress())) {
            ifAttached(view -> view.setAddress(customer.getAddress()));
            return;
        }
        ifAttached(view -> view.showAddressLoading());
        addTask(updateCustomer
            .execute(customerId, customer.getDescription(), address, customer.getProfileImage(), customer.getMobile(), null)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                () -> {
                    Analytics.track(
                        AnalyticsEvents.EDIT_CUSTOMER_ADDRESS_UPDATE,
                        EventProperties
                            .create()
                            .with("error", "false")
                    );
                    ifAttached(view -> view.hideAddressLoading());
                    ifAttached(view -> view.setAddress(customer.getAddress()));
                },
                e -> {
                    Timber.w(e, "update customer failed");
                    ifAttached(view -> view.hideAddressLoading());
                    if (isAuthenticationIssue(e)) {
                        Analytics.track(
                            AnalyticsEvents.EDIT_CUSTOMER_ADDRESS_UPDATE,
                            EventProperties
                                .create()
                                .with("error", "authentication failure")
                        );
                        ifAttached(view -> view.gotoLogin());
                    } else if (isInternetIssue(e)) {
                        Analytics.track(
                            AnalyticsEvents.EDIT_CUSTOMER_ADDRESS_UPDATE,
                            EventProperties
                                .create()
                                .with("error", "internet issue")
                        );
                        ifAttached(view -> view.showNoInternetMessage());
                    } else {
                        Analytics.track(
                            AnalyticsEvents.EDIT_CUSTOMER_ADDRESS_UPDATE,
                            EventProperties
                                .create()
                                .with("error", "true")
                        );
                        ifAttached(view -> view.showError());
                    }
                }
            )
        );
    }

    @Override
    public void editMobile(String mobile) {
        if (mobile != null && mobile.length() != 10) {
            ifAttached(view -> view.displayInvalidMobileError());
            return;
        }
        ifAttached(view -> view.showMobileLoading());

        addTask(customerAuth
            .requestOtp(customerId, mobile, customer.getMobile())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                () -> {
                    Analytics.track(
                        AnalyticsEvents.EDIT_CUSTOMER_PHONE_UPDATE_REQUEST,
                        EventProperties
                            .create()
                            .with("error", "false")
                    );
                    ifAttached(view -> view.hideMobileLoading());
                    ifAttached(view -> view.setMobileVerificationState(customer.getMobile(), mobile));
                    ifAttached(view -> view.gotoEditMobileScreen(customer.getId()));
                },
                e -> {
                    Timber.w(e, "sending otp failed");
                    if (e instanceof CustomerErrors.MobileConflict) {
                        // mobile conflict
                        Analytics.track(
                            AnalyticsEvents.EDIT_CUSTOMER_PHONE_UPDATE_REQUEST,
                            EventProperties
                                .create()
                                .with("error", "mobile conflict")
                        );
                        ifAttached(view -> view.onMobileConflict(
                            ((CustomerErrors.MobileConflict) e).getConflict())
                        );
                    } else if (isAuthenticationIssue(e)) {
                        Analytics.track(
                            AnalyticsEvents.EDIT_CUSTOMER_PHONE_UPDATE_REQUEST,
                            EventProperties
                                .create()
                                .with("error", "authentication failure")
                        );
                        ifAttached(view -> view.hideMobileLoading());
                        ifAttached(view -> view.gotoLogin());
                    } else if (isInternetIssue(e)) {
                        Analytics.track(
                            AnalyticsEvents.EDIT_CUSTOMER_PHONE_UPDATE_REQUEST,
                            EventProperties
                                .create()
                                .with("error", "internet issue")
                        );
                        ifAttached(view -> view.hideMobileLoading());
                        ifAttached(view -> view.showNoInternetMessage());
                    } else {
                        Analytics.track(
                            AnalyticsEvents.EDIT_CUSTOMER_PHONE_UPDATE_REQUEST,
                            EventProperties
                                .create()
                                .with("error", "true")
                        );
                        ifAttached(view -> view.hideMobileLoading());
                        ifAttached(view -> view.showError());
                    }
                }
            )
        );
    }

    @Override
    public void setProfileImage(File profileImage) {
        String receiptUrl = Constants.AWS_RECEIPT_BASE_URL + "/" +
            UUID.randomUUID().toString() + ".jpg";

        addTask(updateCustomer
            .execute(customerId, customer.getDescription(), customer.getAddress(), receiptUrl, customer.getMobile(), null)
            .andThen(uploadFile.schedule(receiptUrl, profileImage.getAbsolutePath()))
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                () -> {
                    isProfilePicChanged = true;
                    ifAttached(view -> view.displayProfileImageFile(profileImage));
                    Analytics.track(
                        AnalyticsEvents.EDIT_CUSTOMER_PROFILE_UPDATE,
                        EventProperties
                            .create()
                            .with("error", "false")
                    );
                },
                e -> {
                    Timber.w(e, "update profile pic failed");
                    if (isAuthenticationIssue(e)) {
                        Analytics.track(
                            AnalyticsEvents.EDIT_CUSTOMER_PROFILE_UPDATE,
                            EventProperties
                                .create()
                                .with("error", "authentication failure")
                        );
                        ifAttached(view -> view.gotoLogin());
                    } else if (isInternetIssue(e)) {
                        Analytics.track(
                            AnalyticsEvents.EDIT_CUSTOMER_PROFILE_UPDATE,
                            EventProperties
                                .create()
                                .with("error", "internet issue")
                        );
                        ifAttached(view -> view.showNoInternetMessage());
                    } else {
                        Analytics.track(
                            AnalyticsEvents.EDIT_CUSTOMER_PROFILE_UPDATE,
                            EventProperties
                                .create()
                                .with("error", "true")
                        );
                        ifAttached(view -> view.showError());
                    }
                }
            )
        );
    }

    @Override
    public void showOtpDialogue(String mobile) {
        addTask(customerAuth
            .validateMobile(customerId, mobile)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                (mob) -> {
                    if (mobile != null && mobile.length() != 10) {
                        ifAttached(view -> view.displayInvalidMobileError());
                    } else if(customer != null && customer.getMobile() != null && customer.getMobile().equals(mobile)){
                        ifAttached(view -> view.onMobileConflict(customer));
                    } else {
                        ifAttached(view -> view.showAlertDialogue(mobile, customer.getDescription()));
                    }
                },
                e -> {
                    if (e instanceof CustomerErrors.MobileConflict) {
                        ifAttached(view -> view.onMobileConflict(
                            ((CustomerErrors.MobileConflict) e).getConflict())
                        );
                    } else {
                        ifAttached(view -> view.hideMobileLoading());
                        ifAttached(view -> view.showError());
                    }
                }
            ));
    }

    @Override
    public void saveMobile(String mobile) {
        if (customer.getMobile() != null) {
            showOtpDialogue(mobile);
        } else {
            if (mobile != null && mobile.length() != 10) {
                ifAttached(view -> view.displayInvalidMobileError());
                return;
            }
            ifAttached(view -> view.showMobileLoading());
            addTask(updateCustomer
                .execute(customerId, customer.getDescription(), customer.getAddress(), customer.getProfileImage(), mobile, null)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    () -> {
                        ifAttached(view -> view.hideMobileLoading());
                        ifAttached(view -> view.setMobile(mobile));
                    },
                    e -> {
                        if (e instanceof CustomerErrors.MobileConflict) {
                            ifAttached(view -> view.onMobileConflict(
                                ((CustomerErrors.MobileConflict) e).getConflict())
                            );
                        } else if (isAuthenticationIssue(e)) {
                            ifAttached(view -> view.hideMobileLoading());
                            ifAttached(view -> view.gotoLogin());
                        } else if (isInternetIssue(e)) {
                            ifAttached(view -> view.hideMobileLoading());
                            ifAttached(view -> view.showNoInternetMessage());
                        } else {
                            ifAttached(view -> view.hideMobileLoading());
                            ifAttached(view -> view.showError());
                        }
                    }
                )
            );
        }
    }

    @Override
    public void onInternetRestored() {
        loadData();
    }

    @Override
    public void onConfirmOtpClicked() {
        ifAttached(view -> view.gotoEditMobileScreen(customerId));
    }

    @Override
    public void onDeleteClicked() {
        ifAttached(view -> view.gotoDeleteScreen(customerId));
    }

    @Override
    public void onCameraClicked() {
        Analytics.track(
            AnalyticsEvents.EDIT_CUSTOMER_PROFILE_CLICKED,
            EventProperties
                .create()
                .with("source", "camera")
        );
        ifAttached(view -> view.openCamera());
    }

    @Override
    public void onGalleryClicked() {
        Analytics.track(
            AnalyticsEvents.EDIT_CUSTOMER_PROFILE_CLICKED,
            EventProperties
                .create()
                .with("source", "gallery")
        );
        ifAttached(view -> view.openGallery());
    }

    @Override
    public void onEditMobileClicked() {
        ifAttached(view -> view.showMobileEditBox());
    }

    @Override
    public void onAuthenticationRestored() {
        loadData();
    }
}
