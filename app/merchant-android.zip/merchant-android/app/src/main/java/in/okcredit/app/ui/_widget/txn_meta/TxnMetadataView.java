package in.okcredit.app.ui._widget.txn_meta;

import android.content.Context;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.R;

public class TxnMetadataView extends LinearLayout {
    public static class TxnMetadata {
        public static final int TYPE_BILL = 1;
        public static final int TYPE_NOTE = 2;

        public static TxnMetadata addBill(Context context, OnClickListener onClickListener) {
            return new TxnMetadata(TYPE_BILL, R.drawable.ic_receipt, context.getString(R.string.txn_meta_bill_added), context.getString(R.string.txn_meta_change), onClickListener);
        }

        public static TxnMetadata addNote(Context context, String note, OnClickListener onClickListener) {
            return new TxnMetadata(TYPE_NOTE, R.drawable.ic_note, note, context.getString(R.string.txn_meta_change), onClickListener);
        }

        public static TxnMetadata bill(Context context, OnClickListener onClickListener) {
            return new TxnMetadata(TYPE_BILL, R.drawable.ic_receipt, context.getString(R.string.txn_receipt_available), context.getString(R.string.view), onClickListener);
        }

        public static TxnMetadata note(Context context, String note, OnClickListener onClickListener) {
            return new TxnMetadata(TYPE_NOTE, R.drawable.ic_note, note, context.getString(R.string.view), onClickListener);
        }

        public final int type;
        public final int iconRes;
        public final String msg;
        public final String actionLabel;
        public final View.OnClickListener onClickListener;

        public TxnMetadata(int type, int iconRes, String msg, String actionLabel, View.OnClickListener onClickListener) {
            this.type = type;
            this.iconRes = iconRes;
            this.msg = msg;
            this.actionLabel = actionLabel;
            this.onClickListener = onClickListener;
        }
    }

    public void addOrReplace(TxnMetadata metadata) {
        if (metadata == null)
            return;

        adapter.add(metadata);
    }

    public void remove(int type) {
        adapter.remove(type);
    }


    @BindView(R.id.meta_list) RecyclerView metaList;
    private TxnMetadataAdapter adapter;

    public TxnMetadataView(Context context) {
        super(context);
        initView(context);
    }

    public TxnMetadataView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public TxnMetadataView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    public TxnMetadataView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        initView(context);
    }

    private void initView(Context context) {
        inflate(context, R.layout.widget_txn_meta, this);
        ButterKnife.bind(this);

        LayoutParams params = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        setLayoutParams(params);
        setOrientation(LinearLayout.VERTICAL);

        metaList.setLayoutManager(new LinearLayoutManager(context));
        adapter = new TxnMetadataAdapter(context);
        metaList.setAdapter(adapter);
    }
}
