package in.okcredit._offline.common;

import org.joda.time.DateTime;

import java.util.Comparator;

import in.okcredit._offline.model.Transaction;

public class CustomerTransactionComparator implements Comparator<Transaction> {
    @Override
    public int compare(Transaction first, Transaction second) {

        DateTime firstTime = first.getCreatedAt();
        DateTime secondTime = second.getCreatedAt();

        if (firstTime.isAfter(secondTime))
            return -1;
        else if (firstTime.isBefore(secondTime))
            return 1;
        else
            return 0;
    }
}
