package in.okcredit._offline.model;

import com.google.gson.annotations.SerializedName;

public final class Version {
    @SerializedName("version")
    private final int version;

    @SerializedName("has_new_features")
    private final boolean hasNewFeatured;

    public Version(int version, boolean hasNewFeatured) {
        this.version = version;
        this.hasNewFeatured = hasNewFeatured;
    }

    public int getVersion() {
        return version;
    }

    public boolean hasNewFeatures() {
        return hasNewFeatured;
    }
}
