package in.okcredit.app.ui._widget;

import android.content.Context;
import android.support.annotation.Nullable;
import android.support.annotation.StringRes;
import android.util.AttributeSet;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.R;

public class EnterAmountView extends LinearLayout {
    @BindView(R.id.tv_label)
    TextView label;
    @BindView(R.id.et_amount)
    EditText amount;
    @BindView(R.id.tv_error)
    TextView error;

    public EnterAmountView(Context context) {
        super(context);
        initView(context);
    }

    public EnterAmountView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public EnterAmountView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    public EnterAmountView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        initView(context);
    }

    public void showError(@StringRes int resId) {
        if (error.getVisibility() != VISIBLE) {
            error.setVisibility(VISIBLE);
        }
        error.setText(resId);
    }

    public void showError(CharSequence msg) {
        if (error.getVisibility() != VISIBLE) {
            error.setVisibility(VISIBLE);
        }
        error.setText(msg);
    }

    public void hideError() {
        if (error.getVisibility() != GONE) {
            error.setVisibility(GONE);
        }
    }

    public void setLabel(@StringRes int resId) {
        label.setText(resId);
    }

    public void setLabel(CharSequence msg) {
        label.setText(msg);
    }

    public void setAmount(float amt) {
        if (amt <= 0.0) {
            return;
        }

        try {
            String amountStr = String.valueOf((int) amt);
            amount.setText(amountStr);
        } catch (Exception e) {
        }
    }

    public float getAmount() {
        try {
            return Float.parseFloat(amount.getText().toString());
        } catch (Exception e) {
            return 0.0f;
        }
    }

    private void initView(Context context) {
        setOrientation(LinearLayout.VERTICAL);
        inflate(context, R.layout.widget_enter_amount, this);
        ButterKnife.bind(this);
    }
}
