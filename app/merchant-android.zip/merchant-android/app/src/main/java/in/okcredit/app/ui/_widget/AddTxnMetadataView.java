package in.okcredit.app.ui._widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.annotation.DrawableRes;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.R;

public class AddTxnMetadataView extends LinearLayout {
    public static final int TYPE_BILL = 1;
    public static final int TYPE_NOTE = 2;
    public static final int TYPE_GALLERY = 3;

    @BindView(R.id.icon) CircularIconView icon;
    @BindView(R.id.label) TextView label;

    private Context context;
    private boolean isDone;
    private int type;

    public void setType(int type) {
        this.type = type;
        refreshView();
    }

    public void setIsDone(boolean isDone) {
        this.isDone = isDone;
        refreshView();
    }

    public AddTxnMetadataView(Context context) {
        super(context);
        initView(context);
    }

    public AddTxnMetadataView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public AddTxnMetadataView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    public AddTxnMetadataView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        initView(context);
    }

    private void initView(Context context) {
        this.context = context;
        setOrientation(LinearLayout.VERTICAL);
        setGravity(Gravity.CENTER_HORIZONTAL);
        inflate(context, R.layout.widget_add_txn_metadata, this);
        ButterKnife.bind(this);
    }

    @SuppressLint({"ResourceAsColor", "ResourceType"})
    private void refreshView() {
        if (isDone) {
            label.setText(getLabel());
            label.setTextColor(ContextCompat.getColor(context, R.color.text_subtitle));
            icon.setIcon(R.drawable.ic_check);
            icon.setBackgroundColor(R.color.grey400);
        } else {
            label.setText(getLabel());
            label.setTextColor(ContextCompat.getColor(context, R.color.primary));
            icon.setIcon(getIcon());
            icon.setBackgroundColor(R.color.primary_light);
        }
    }

    @DrawableRes
    private int getIcon() {
        switch (type) {
            case TYPE_BILL:
                return R.drawable.ic_add_receipt;

            case TYPE_NOTE:
                return R.drawable.ic_add_note;

            case TYPE_GALLERY:
                return R.drawable.ic_add_gallery;

            default:
                return 0;
        }
    }

    private String getLabel() {
        int labelRes = 0;
        switch (type) {
            case TYPE_BILL:
                labelRes = R.string.camera;
                break;

            case TYPE_NOTE:
                labelRes = R.string.txn_meta_note;
                break;

            case TYPE_GALLERY:
                labelRes = R.string.gallery;
                break;
        }

        if (labelRes == 0)
            return "";
        else
            return context.getString(labelRes);
    }
}
