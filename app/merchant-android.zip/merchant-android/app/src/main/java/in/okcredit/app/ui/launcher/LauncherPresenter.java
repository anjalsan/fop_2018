package in.okcredit.app.ui.launcher;

import javax.inject.Inject;

import in.okcredit.app.ui._base_v2.BasePresenter;
import in.okcredit.domain.auth.AuthDomain;
import io.reactivex.android.schedulers.AndroidSchedulers;

public class LauncherPresenter extends BasePresenter<LauncherContract.View> implements LauncherContract.Presenter {
    private AuthDomain authDomain;

    @Inject
    public LauncherPresenter(AuthDomain authDomain) {
        super(AndroidSchedulers.mainThread());
        this.authDomain = authDomain;
    }

    @Override
    public void attachView(LauncherContract.View view) {
        super.attachView(view);

        addTask(authDomain
            .isAccessTokenAvailable()
            .observeOn(uiScheduler)
            .subscribe(
                isAccessTokenAvailable -> {
                    if (isAccessTokenAvailable)
                        ifAttached(view1 -> view1.gotoHome());
                    else
                        ifAttached(view1 -> view1.gotoLanguagueScreen());
                },
                throwable -> ifAttached(view1 -> view1.showError()))
        );
    }
}
