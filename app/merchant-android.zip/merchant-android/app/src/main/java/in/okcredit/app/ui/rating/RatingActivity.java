package in.okcredit.app.ui.rating;

import android.support.v4.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import javax.inject.Inject;

import butterknife.ButterKnife;
import dagger.android.AndroidInjector;
import dagger.android.DispatchingAndroidInjector;
import dagger.android.support.HasSupportFragmentInjector;
import in.okcredit.R;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui.rating.feedback_rating.FeedbackRatingFragment;
import in.okcredit.app.ui.rating.playstore_rating.PlaystoreRatingFragment;
import in.okcredit.app.ui.rating.select_rating.SelectRatingFragment;

public class RatingActivity extends BaseActivity implements HasSupportFragmentInjector {

    public static Intent startingIntent(Context context) {
        return new Intent(context, RatingActivity.class);
    }

    /* Lifecycle methods */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Analytics.track(AnalyticsEvents.RATING_SCREEN);
        setContentView(R.layout.rating_activity);
        ButterKnife.bind(this);

        showActionBar(true);
        setTitle(R.string.rate_okcredit);

        showSelectRatingFragment();
    }

    @Override
    public void onBackPressed() {
        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();
        } else {
            finish();
        }
    }

    @Override
    public void onUpPressed() {
        onBackPressed();
    }


    /****************************************************************
     Navigation
     ****************************************************************/
    public void showFeedbackRatingFragment(int rating) {
        Fragment fragment = FeedbackRatingFragment.newInstance(rating);
        getSupportFragmentManager()
            .beginTransaction()
            .setCustomAnimations(R.animator.enter_from_right, R.animator.exit_to_left, R.animator.enter_from_left, R.animator.exit_to_right)
            .replace(R.id.fragmentContainer, fragment)
            .addToBackStack(fragment.getClass().getName())
            .commit();

    }

    public void showPlaystoreRatingFragment(int rating) {
        Fragment fragment = PlaystoreRatingFragment.newInstance();
        getSupportFragmentManager()
            .beginTransaction()
            .setCustomAnimations(R.animator.enter_from_right, R.animator.exit_to_left, R.animator.enter_from_left, R.animator.exit_to_right)
            .replace(R.id.fragmentContainer, fragment)
            .addToBackStack(fragment.getClass().getName())
            .commit();

    }

    public void showSelectRatingFragment() {
        Fragment fragment = SelectRatingFragment.newInstance();
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit();

    }

    /****************************************************************
     Dependency Injection
     ****************************************************************/
    @Inject
    DispatchingAndroidInjector<Fragment> fragmentInjector;

    @Override
    public AndroidInjector<Fragment> supportFragmentInjector() {
        return fragmentInjector;
    }
}
