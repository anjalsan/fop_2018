package in.okcredit._offline.model;

public class Settlement {
    private final Transaction transaction;
    private final float balanceBefore;
    private final float balanceAfter;

    public Settlement(Transaction transaction, float balanceBefore, float balanceAfter) {
        this.transaction = transaction;
        this.balanceBefore = balanceBefore;
        this.balanceAfter = balanceAfter;
    }

    public Transaction getTransaction() {
        return transaction;
    }

    public float getBalanceBefore() {
        return balanceBefore;
    }

    public float getBalanceAfter() {
        return balanceAfter;
    }
}
