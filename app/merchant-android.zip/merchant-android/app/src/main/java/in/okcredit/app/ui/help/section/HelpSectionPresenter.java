package in.okcredit.app.ui.help.section;

import javax.inject.Inject;

import in.okcredit.LocaleManager;
import in.okcredit._di.PresenterParam;
import in.okcredit._di.UiThread;
import in.okcredit.app.ui._base_v2.BasePresenter;
import in.okcredit.domain.help.HelpSection;
import in.okcredit.domain.help.HelpService;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;

/**
 * Created by harsh on 20/12/17.
 */

public class HelpSectionPresenter extends BasePresenter<SectionContract.View> implements
    SectionContract.Presenter {
    private HelpSection helpSection;
    private String helpSectionId;
    private HelpService helpService;

    @Inject
    public HelpSectionPresenter(@UiThread Scheduler uiScheduler,
                                @PresenterParam("help_section") HelpSection helpSection,
                                @PresenterParam("help_section_id") String helpSectionId,
                                HelpService helpService) {
        super(uiScheduler);
        this.helpSection = helpSection;
        this.helpSectionId = helpSectionId;
        this.helpService = helpService;
    }

    @Override
    protected void loadData() {
        if (helpSection != null && helpSection.getId() != null){
            ifAttached(view -> view.setYoutube(helpSection.getVideoId()));
            ifAttached(view -> view.setHelpItems(helpSection.getId(), helpSection.getHelpItems()));
            ifAttached(view -> view.setActionBarTitle(helpSection.getTitle()));
        } else if (helpSectionId != null){
            ifAttached(view -> view.showLoading());
            String language = LocaleManager.getLanguage();
            addTask(helpService
                .getHelpSection(language, helpSectionId)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    helpSection ->
                    {
                        if (helpSection.getId() != null) {
                            ifAttached(view -> view.setYoutube(helpSection.getVideoId()));
                            ifAttached(view -> view.setHelpItems(helpSection.getId(), helpSection.getHelpItems()));
                            ifAttached(view -> view.setActionBarTitle(helpSection.getTitle()));
                            ifAttached(view -> view.hideLoading());
                        } else {
                            ifAttached(view -> view.showError());
                        }
                    },
                    throwable ->
                    {
                        ifAttached(view -> view.hideLoading());
                        if (isAuthenticationIssue(throwable))
                            ifAttached(view -> view.gotoLogin());
                        else if (isInternetIssue(throwable))
                            ifAttached(view -> view.showNoInternetMessage());
                        else
                            ifAttached(view -> view.showError());
                    }
                ));
        }
    }

    @Override
    public void onInternetRestored() {
        loadData();
    }
}
