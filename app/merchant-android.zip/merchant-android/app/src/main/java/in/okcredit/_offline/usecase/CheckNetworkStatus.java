package in.okcredit._offline.usecase;


import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import in.okcredit.ThreadUtils;
import in.okcredit._offline.server.NetworkHelper;
import io.reactivex.Observable;
import io.reactivex.Single;

public final class CheckNetworkStatus {
    public static final int STATUS_CONNECTED = 0;
    public static final int STATUS_NOT_CONNECTED = -1;

    @Inject
    public CheckNetworkStatus() {
    }

    public Observable<Integer> execute() {
        return Observable.interval(5, TimeUnit.SECONDS, ThreadUtils.newThread())
                         .map(tick -> NetworkHelper.isInternetConnected())
                         .map(isConnected -> {
                             if (isConnected) {
                                 return STATUS_CONNECTED;
                             } else {
                                 return STATUS_NOT_CONNECTED;
                             }
                         })
                         .distinctUntilChanged();
    }

    public Single<Boolean> isInternet() {
        return Single
            .fromCallable(NetworkHelper::isInternetConnected)
            .map(isConnected -> {
                return isConnected;
            })
            .subscribeOn(ThreadUtils.newThread());
    }
}
