package in.okcredit._offline.usecase;

import com.google.common.base.Strings;

import org.joda.time.DateTime;

import java.util.NoSuchElementException;

import javax.inject.Inject;

import in.okcredit._offline.database.CustomerRepo;
import in.okcredit._offline.error.CustomerErrors;
import in.okcredit._offline.model.OtpRequestKey;
import in.okcredit._offline.server.Server;
import in.okcredit.service.customerAuthDb.CustomerAuthServiceImpl;
import io.reactivex.Completable;
import io.reactivex.Single;
import io.reactivex.SingleSource;
import io.reactivex.functions.Function;

public final class CustomerAuth {
    private final UpdateCustomer updateCustomer;
    private Server server;
    private CustomerRepo customerRepo;
    private SafelySaveCustomer safelySaveCustomer;
    private CustomerAuthServiceImpl customerDbAuthService;

    @Inject
    public CustomerAuth(Server server, CustomerRepo customerRepo, UpdateCustomer updateCustomer, SafelySaveCustomer safelySaveCustomer, CustomerAuthServiceImpl customerDbAuthService) {
        this.server = server;
        this.customerDbAuthService = customerDbAuthService;
        this.customerRepo = customerRepo;
        this.safelySaveCustomer = safelySaveCustomer;
        this.updateCustomer = updateCustomer;
    }

    public Completable requestOtp(String customerId, String mobile, String currentMobile) {
        return validateMobile(customerId, mobile)
            .flatMapCompletable(mob -> {
                String _mobile = Strings.emptyToNull(mob);

                if (_mobile == null) {
                    return Completable.error(new IllegalAccessException("invalid mobile number"));
                } else {
                    return server.sendCustomerOtp(customerId, _mobile)
                        .flatMapCompletable(res -> {
                            if (res.expiryTime == null) {
                                return customerDbAuthService.put(new OtpRequestKey(customerId, res.requestId, mobile, currentMobile, DateTime.now(), DateTime.now().plusHours(24)));
                            } else {
                                return customerDbAuthService.put(new OtpRequestKey(customerId, res.requestId, mobile, currentMobile, DateTime.now(), res.expiryTime));
                            }
                        });
                }
            });
    }

    public Single<String> verifyOtp(String customerId, String requestId, String otp, String mobile, String description, String address) {
        return server.verifyCustomerOtp(requestId, otp);
    }

    public Single<OtpRequestKey> isCustomerMobileState(String customerId) {
        return customerDbAuthService.get(customerId)
            .flatMap(otpKey -> {
                if (otpKey != null && otpKey.getCustomerId().equals(customerId)) {
                    return Single.just(otpKey);
                } else {
                    return Single.just(null);
                }
            });
    }

    public Completable deleteKey(String customerId) {
        return customerDbAuthService.delete(customerId);
    }

    public Single<String> validateMobile(String customerId, String mobile) {
        if (mobile == null || mobile.length() != 10) {
            return Single.just("");
        } else {
            return customerRepo.findCustomerByMobile(mobile)
                               .flatMap(customer -> {
                                   if (customer.getId().equals(customerId)) {
                                       return Single.just("");
                                   } else {
                                       return Single.<String>error(new CustomerErrors.MobileConflict(customer));
                                   }
                               })
                               .onErrorResumeNext((Function<Throwable, SingleSource<String>>) throwable -> {
                                   if (throwable instanceof NoSuchElementException) {
                                       return Single.just(mobile);
                                   } else {
                                       return Single.error(throwable);
                                   }
                               });
        }
    }
}
