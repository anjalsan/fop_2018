package in.okcredit.app.ui.account;

import javax.inject.Inject;

import in.okcredit._offline.model.MerchantPreference;
import in.okcredit._offline.usecase.GetAccountSummary;
import in.okcredit._offline.usecase.GetActiveMerchant;
import in.okcredit._offline.usecase.GetMerchantPreference;
import in.okcredit.app.ui._base.ErrorHelper;
import in.okcredit.domain.report.ReportDomain;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.observers.DisposableSingleObserver;

public class AccountPresenter implements Account.Presenter {
    private Account.View view;

    private ReportDomain reportDomain;

    private CompositeDisposable tasks;

    // usecase
    private GetActiveMerchant getActiveMerchant;
    private GetMerchantPreference getMerchantPreference;
    private GetAccountSummary getAccountSummary;

    @Inject
    public AccountPresenter(
        ReportDomain reportDomain,
        GetActiveMerchant getActiveMerchant,
        GetMerchantPreference getMerchantPreference,
        GetAccountSummary getAccountSummary) {
        this.reportDomain = reportDomain;
        tasks = new CompositeDisposable();
        this.getActiveMerchant = getActiveMerchant;
        this.getMerchantPreference = getMerchantPreference;
        this.getAccountSummary = getAccountSummary;
    }

    @Override
    public void attachView(Account.View view) {
        this.view = view;

        tasks.add(
            getActiveMerchant
                .execute()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    merchant -> {
                        if (view != null) {
                            view.displayMerchantDetails(merchant);
                        }
                    }
                )
        );

        tasks.add(
            getAccountSummary
                .execute()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    accountSummary -> {
                        if (view != null) {
                            view.displayMerchantAccountSummary(accountSummary.balance, accountSummary.customerCount);
                        }
                    },
                    throwable -> ErrorHelper.handleDefaults(view, throwable, "attachView_refreshCustomers")
                )
        );

        tasks.add(
            getMerchantPreference
                .execute(MerchantPreference.REMINDER)
                .map(val -> Boolean.parseBoolean(val))
                .onErrorReturnItem(false)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    isReminderOn -> {
                        if (view == null) {
                            return;
                        }
                        view.setReminderStatus(isReminderOn);
                    },
                    throwable -> view.onError("Reminder - " + throwable.getMessage())
                )
        );
    }

    @Override
    public void detachView() {
        view = null;
        tasks.clear();
    }

    @Override
    public void generateYesterdayReport() {
        Disposable task =
            reportDomain
                .generateYesterdayReport()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableSingleObserver<String>() {
                    @Override
                    public void onSuccess(@NonNull String reportUrl) {
                        if (view == null) {
                            return;
                        }

                        view.onReportGenerated(reportUrl);
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        ErrorHelper.handleDefaults(view, e, "generateYesterdayReport");
                    }
                });
        tasks.add(task);
    }
}
