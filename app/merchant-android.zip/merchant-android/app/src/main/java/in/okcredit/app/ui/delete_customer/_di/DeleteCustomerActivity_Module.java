package in.okcredit.app.ui.delete_customer._di;

import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import in.okcredit._di.PresenterParam;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit.app.ui.delete_customer.DeleteCustomerActivity;
import in.okcredit.app.ui.delete_customer.DeleteCustomerContract;
import in.okcredit.app.ui.delete_customer.DeleteCustomerPresenter;

@Module
public abstract class DeleteCustomerActivity_Module {
    @Provides
    @ActivityScope
    @PresenterParam("customer_id")
    public static String customerId(DeleteCustomerActivity activity) {
        return activity.getIntent().getStringExtra(DeleteCustomerActivity.EXTRA_CUSTOMER_ID);
    }

    @Binds
    @ActivityScope
    public abstract DeleteCustomerContract.Presenter presenter(DeleteCustomerPresenter presenter);
}
