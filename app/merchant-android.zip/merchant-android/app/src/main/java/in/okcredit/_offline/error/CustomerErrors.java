package in.okcredit._offline.error;

import in.okcredit._offline.model.Customer;

public final class CustomerErrors {
    public static class InvalidName extends Exception {
    }

    public static class DeletedCustomer extends Exception {
        private Customer conflict;

        public DeletedCustomer(Customer conflict) {
            this.conflict = conflict;
        }

        public Customer getConflict() {
            return conflict;
        }
    }

    public static class MobileConflict extends Exception {
        private Customer conflict;

        public MobileConflict(Customer conflict) {
            this.conflict = conflict;
        }

        public Customer getConflict() {
            return conflict;
        }
    }

    public static class DescriptionConflict extends Exception {
        private Customer conflict;

        public DescriptionConflict(Customer conflict) {
            this.conflict = conflict;
        }

        public Customer getConflict() {
            return conflict;
        }
    }

    public static class MobileUpdateAccessDenied extends Exception {
    }

    public static class DeletePermissionDenied extends Exception {
    }

    private CustomerErrors() {
    }
}
