package in.okcredit.app.ui.addtxn.addTxn;

import java.io.File;

import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;

public interface AddTxnContract {
    interface View extends MVP.View,
        BaseContracts.Online.View,
        BaseContracts.Authenticated.View {
        void setTxnType(int txnType, int lifecycle);

        void setCustomerName(String name);

        void showInvalidAmountError();

        void gotoConfirmation();

        void displayReceipt(File receipt);

        void displayNote(String note);

        void setupTutorialLayout(int lifecycle, int txType);
    }

    interface Presenter extends MVP.Presenter<View>,
        BaseContracts.Online.Presenter<View>,
        BaseContracts.Authenticated.Presenter<View> {
        void addTxn(float amount, File receipt, String note);
    }
}
