package in.okcredit.app.ui.help._di;

import dagger.Binds;
import dagger.Module;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit.app.ui.help.main.HelpContract;
import in.okcredit.app.ui.help.main.HelpPresenter;

@Module
public abstract class HelpActivity_Module {
    @Binds
    @ActivityScope
    public abstract HelpContract.Presenter presenter(HelpPresenter presenter);
}
