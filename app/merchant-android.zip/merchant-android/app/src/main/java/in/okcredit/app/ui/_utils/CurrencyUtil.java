package in.okcredit.app.ui._utils;

import android.support.annotation.ColorRes;
import android.support.v4.content.ContextCompat;
import android.widget.TextView;

import java.text.NumberFormat;
import java.util.Locale;

import in.okcredit.R;

public class CurrencyUtil {
    private static NumberFormat CURRENCY_FORMAT;

    static {
        CURRENCY_FORMAT = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
        CURRENCY_FORMAT.setMaximumFractionDigits(0);
    }

    public static void render(float amount, TextView textView) {
        @ColorRes int color = R.color.tx_payment;
        if (amount < 0) {
            amount *= -1.0;
            color = R.color.tx_credit;
        }
        if (amount == 0.0)
            color = R.color.text_subtitle;
        String value = CURRENCY_FORMAT.format(amount);
        textView.setText(value);
        textView.setTextColor(ContextCompat.getColor(textView.getContext(), color));
    }

    public static String format(float amount) {
        if (amount < 0)
            amount *= -1.0;
        return CURRENCY_FORMAT.format(amount);
    }

    public static String format(String amountStr) {
        try {
            return format(Float.parseFloat(amountStr));
        } catch (Exception e) {
            return "";
        }
    }
}
