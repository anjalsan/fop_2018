package in.okcredit._offline.usecase;

import android.util.Pair;

import org.joda.time.DateTime;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;

import in.okcredit._offline.common.AccountStatementTransactionComparator;
import in.okcredit._offline.database.CustomerRepo;
import in.okcredit._offline.model.Customer;
import in.okcredit._offline.model.Transaction;
import in.okcredit._offline.model.TransactionWrapper;
import in.okcredit._offline.server.Server;
import io.reactivex.Completable;
import io.reactivex.Observable;

public final class GetAccountStatement {
    private Server server;
    private CustomerRepo customerRepo;
    private SyncCustomer syncCustomer;

    @Inject
    public GetAccountStatement(Server server, CustomerRepo customerRepo, SyncCustomer syncCustomer) {
        this.server = server;
        this.customerRepo = customerRepo;
        this.syncCustomer = syncCustomer;
    }

    public Observable<List<TransactionWrapper>> execute(List<Integer> types, DateTime startTime, DateTime endTime) {
        return Observable
            .combineLatest(
                getTransactions(types, startTime, endTime),
                customerRepo.listCustomers(),
                (transactions, customers) -> process(customers, transactions)
            )
            .flatMap(res -> {
                Completable syncMissingCustomers = Completable.complete();
                Set<String> missingCustomers = res.second;
                for (String customerId : missingCustomers) {
                    syncMissingCustomers = syncMissingCustomers.andThen(syncCustomer.schedule(customerId));
                }
                return syncMissingCustomers.andThen(Observable.just(res.first));
            });
    }

    private Observable<List<Transaction>> getTransactions(List<Integer> types, DateTime startTime, DateTime endTime) {
        if (types == null || types.isEmpty()) {
            types = Arrays.asList(Transaction.CREDIT, Transaction.PAYMENT, Transaction.RETURN);
        }

        if (endTime == null) {
            endTime = DateTime.now();
        }

        final List<Integer> _types = types;
        return server.listTransactions(null, startTime, endTime)
                     .map(transactions -> {
                         List<Transaction> filtered = new ArrayList<>();
                         for (Transaction transaction : transactions) {
                             if (_types.contains(transaction.getType())) {
                                 filtered.add(transaction);
                             }
                         }
                         Collections.sort(filtered, new AccountStatementTransactionComparator());
                         return filtered;
                     })
                     .toObservable();
    }

    private Pair<List<TransactionWrapper>, Set<String>> process(List<Customer> customers, List<Transaction> transactions) {
        Map<String, Customer> customerMap = new HashMap<>();
        for (Customer customer : customers) {
            customerMap.put(customer.getId(), customer);
        }

        List<TransactionWrapper> tx = new ArrayList<>();
        Set<String> missingCustomers = new HashSet<>();
        for (Transaction transaction : transactions) {
            Customer customer = customerMap.get(transaction.getCustomerId());
            if (customer != null) {
                tx.add(
                    new TransactionWrapper(
                        transaction,
                        getCustomerName(customer),
                        customer.getStatus() == 1
                    )
                );
            } else {
                missingCustomers.add(transaction.getCustomerId());
                tx.add(
                    new TransactionWrapper(
                        transaction,
                        null,
                        false)
                );
            }
        }
        return new Pair<>(tx, missingCustomers);
    }

    private static String getCustomerName(Customer customer) {
        if (customer.getStatus() == 1) {
            return customer.getDescription();
        } else {
            try {
                return customer.getDescription().substring(0, customer.getDescription().indexOf("" +
                    " ["));
            } catch (Exception e) {
                return customer.getDescription();
            }
        }
    }
}
