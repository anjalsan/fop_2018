package in.okcredit.app.ui.help.main;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;

import java.util.List;

import javax.inject.Inject;

import in.okcredit.domain.help.HelpSection;

public class HelpSectionAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context context;
    private List<HelpSection> sections;
    private HelpSectionSelectionListener listener;

    @Inject
    public HelpSectionAdapter(HelpActivity context) {
        this.context = context;
    }

    public void setSections(List<HelpSection> sections) {
        this.sections = sections;
        notifyDataSetChanged();
    }

    void setSelectionListener(HelpSectionSelectionListener listener) {
        this.listener = listener;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return HelpSectionViewHolder.create(context, parent, listener);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ((HelpSectionViewHolder) holder).bind(sections.get(position));
    }

    @Override
    public int getItemCount() {
        if (sections == null) {
            return 0;
        } else {
            return sections.size();
        }
    }
}
