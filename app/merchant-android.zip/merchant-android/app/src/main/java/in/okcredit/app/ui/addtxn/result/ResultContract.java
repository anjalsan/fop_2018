package in.okcredit.app.ui.addtxn.result;

import org.joda.time.DateTime;

import java.io.File;

import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;

public interface ResultContract {
    interface View extends MVP.View, BaseContracts.Online.View, BaseContracts.Authenticated.View {
        void setStatus(int txnType, boolean isSuccessful);

        void setTransaction(Transaction transaction);

        void gotoHome();

        void gotoAddTxn();

        void gotoConfirmTxn();

        void goToCustomerScreen();

        void setReceiptUrl(String url);

        void setReceiptUrlFile(File localFile);
    }

    interface Presenter extends MVP.Presenter<View>,
        BaseContracts.Online.Presenter<View>,
        BaseContracts.Authenticated.Presenter<View> {
        void onGotoHomeClicked();

        void onAddMoreClicked(int lifecycle);

        void retry();
    }

    class Transaction {
        public int type;
        public String customerName;
        public String customerMobile;
        public float amount;
        public float balanceAfter;
        public String receiptUrl;
        public String note;
        public DateTime createdAt;
    }
}
