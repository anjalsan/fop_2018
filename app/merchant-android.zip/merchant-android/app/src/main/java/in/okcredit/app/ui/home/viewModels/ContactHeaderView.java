package in.okcredit.app.ui.home.viewModels;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.airbnb.epoxy.CallbackProp;
import com.airbnb.epoxy.ModelProp;
import com.airbnb.epoxy.ModelView;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.R;

@ModelView(autoLayout = ModelView.Size.MATCH_WIDTH_WRAP_HEIGHT)
public class ContactHeaderView extends LinearLayout {

    public interface ContactHeaderListener {
        void onClickRefreshContact();
    }

    @BindView(R.id.refresh)
    ImageView refresh;

    public ContactHeaderView(Context context) {
        super(context);
        initView();
    }

    public ContactHeaderView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public ContactHeaderView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public ContactHeaderView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        initView();
    }

    @CallbackProp
    public void setListener(@Nullable ContactHeaderListener listener) {
        if (listener != null) {
            refresh.setOnClickListener((OnClickListener) v -> listener.onClickRefreshContact());
        }
    }

    private void initView() {
        setOrientation(LinearLayout.HORIZONTAL);
        inflate(getContext(), R.layout.import_contact_header, this);
        ButterKnife.bind(this);
    }
}
