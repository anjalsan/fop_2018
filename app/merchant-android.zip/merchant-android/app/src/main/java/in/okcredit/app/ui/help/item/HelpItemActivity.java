package in.okcredit.app.ui.help.item;

/**
 * Created by harsh on 20/12/17.
 */

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.yarolegovich.discretescrollview.DiscreteScrollView;

import java.util.HashMap;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.R;
import in.okcredit.ThreadUtils;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.domain.help.HelpItem;
import io.reactivex.Completable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

public class HelpItemActivity extends BaseActivity implements ItemContract.View {
    public static final String EXTRA_HELP_ITEM = "help_item";

    public static final String EXTRA_HELP_SECTION_ID = "help_section_item";
    public static final String EXTRA_HELP_SECTION_ITEM_ID = "help_section_item_id";

    // Intent
    public static Intent startingIntent(Context context, HelpItem helpItem) {
        Intent intent = new Intent(context, HelpItemActivity.class);
        intent.putExtra(EXTRA_HELP_ITEM, helpItem);
        intent.putExtra(EXTRA_HELP_SECTION_ID, "");
        intent.putExtra(EXTRA_HELP_SECTION_ITEM_ID, "");
        return intent;
    }

    // UI Elements
    @BindView(R.id.picker)
    DiscreteScrollView scrollView;

    // Adapter
    @Inject
    ScreenshotItemAdapter screenshotItemAdapter;

    // Presenter
    @Inject
    ItemContract.Presenter presenter;

    private List<String> screenshotUrls;

    @BindView(R.id.previous)
    LinearLayout previous;

    @BindView(R.id.previousIcon)
    ImageView previousIcon;

    @BindView(R.id.next)
    LinearLayout next;

    @BindView(R.id.nextIcon)
    ImageView nextIcon;

    @BindView(R.id.fabPlay)
    FloatingActionButton play;

    @BindView(R.id.bottom_container)
    CardView bottomContainer;

    @BindView(R.id.loading)
    LinearLayout loading;


    private MediaPlayer mediaPlayer;
    private boolean isAudioPlaying;
    private CompositeDisposable tasks;
    private boolean isEndScrollEventFired = false;
    private long openingTimeInMillis = 0;

    // Lifecycle Methods
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.help_item_activity);
        ButterKnife.bind(this);
        showActionBar(true);

        scrollView.setAdapter(screenshotItemAdapter);
        mediaPlayer = new MediaPlayer();
        play.hide();

        tasks = new CompositeDisposable();

        nextIcon.setColorFilter(getResources().getColor(R.color.primary));
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int currentPosition = scrollView.getCurrentItem();

                if (currentPosition < (screenshotUrls.size() - 1)) {
                    scrollView.smoothScrollToPosition(currentPosition + 1);

                    if (!isEndScrollEventFired && screenshotUrls.size() - 1 == currentPosition) {
                        long diff = (System.currentTimeMillis() - openingTimeInMillis) / 1000;
                        isEndScrollEventFired = true;

                        Analytics.track(
                            AnalyticsEvents.HELP_ITEM_SCREEN_END,
                            EventProperties
                                .create()
                                .with("time_spend", diff));
                    }
                }
            }
        });

        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int currentPosition = scrollView.getCurrentItem();

                if (currentPosition > 0) {
                    scrollView.smoothScrollToPosition(currentPosition - 1);
                }
            }
        });

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isAudioPlaying = !isAudioPlaying;
                setAudioState(isAudioPlaying);
            }
        });

        scrollView.addOnItemChangedListener(new DiscreteScrollView
            .OnItemChangedListener<RecyclerView.ViewHolder>() {
            @Override
            public void onCurrentItemChanged(@Nullable RecyclerView.ViewHolder viewHolder, int
                adapterPosition) {
                if (adapterPosition == (screenshotUrls.size() - 1)) {
                    nextIcon.setColorFilter(getResources().getColor(R.color.grey800));
                    previousIcon.setColorFilter(getResources().getColor(R.color.primary));

                    // analytics
                    if (!isEndScrollEventFired) {
                        long diff = (System.currentTimeMillis() - openingTimeInMillis) / 1000;
                        isEndScrollEventFired = true;

                        Analytics.track(
                            AnalyticsEvents.HELP_ITEM_SCREEN_END,
                            EventProperties
                                .create()
                                .with("time_spend", diff));
                    }
                } else if (adapterPosition == 0) {
                    nextIcon.setColorFilter(getResources().getColor(R.color.primary));
                    previousIcon.setColorFilter(getResources().getColor(R.color.grey800));
                } else {
                    nextIcon.setColorFilter(getResources().getColor(R.color.primary));
                    previousIcon.setColorFilter(getResources().getColor(R.color.primary));
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.attachView(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        presenter.detachView();
        tasks.clear();
        releaseMediaPlayer();
    }


    // View functions
    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(this, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
            }
        });
    }

    @Override
    public void showLoading() {
        bottomContainer.setVisibility(View.GONE);
        scrollView.setVisibility(View.GONE);
        loading.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideLoading() {
        bottomContainer.setVisibility(View.VISIBLE);
        scrollView.setVisibility(View.VISIBLE);
        loading.setVisibility(View.GONE);
    }

    @Override
    public void showError() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "help item")
                .with("type", "server error")
        );

        finish();
    }

    @Override
    public void setScreenshots(String helpItemId, List<String> screenshotUrls) {
        screenshotItemAdapter.setItems(screenshotUrls);
        this.screenshotUrls = screenshotUrls;

        openingTimeInMillis = System.currentTimeMillis();

        Analytics.track(
            AnalyticsEvents.HELP_ITEM_SCREEN,
            EventProperties
                .create()
                .with("type", helpItemId));
    }

    @Override
    public void setAudio(String audioUrl) {
        play.setImageDrawable(ContextCompat.getDrawable(HelpItemActivity.this, R
            .drawable.ic_pause));
        play.show();

        Disposable task = Completable
            .fromAction(() -> {
                mediaPlayer.setDataSource(this, Uri.parse(audioUrl), new HashMap<>());
                mediaPlayer.prepare();
            })
            .subscribeOn(ThreadUtils.newThread())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                () -> {
                    setAudioState(true);
                },
                throwable -> Timber.e(throwable)
            );

        tasks.add(task);
    }

    private void setAudioState(boolean playAudio) {
        if (mediaPlayer == null) {
            return;
        }

        isAudioPlaying = playAudio;
        if (playAudio) {
            mediaPlayer.start();
            play.setImageDrawable(ContextCompat.getDrawable(HelpItemActivity.this, R
                .drawable.ic_pause));
        } else {
            mediaPlayer.pause();
            play.setImageDrawable(ContextCompat.getDrawable(HelpItemActivity.this, R
                .drawable.ic_play));
        }
    }

    @Override
    public void setActionBarTitle(String title) {
        setTitle(title);
    }

    private void releaseMediaPlayer() {
        try {
            if (mediaPlayer != null) {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                mediaPlayer.release();
                mediaPlayer = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void gotoLogin() {
        super.gotoLogin();
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "help item")
                .with("type", "auth error")
        );
    }
}
