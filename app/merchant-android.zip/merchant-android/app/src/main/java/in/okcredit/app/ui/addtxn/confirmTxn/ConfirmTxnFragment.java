package in.okcredit.app.ui.addtxn.confirmTxn;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TextInputLayout;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.HashMap;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import in.okcredit.AudioUrl;
import in.okcredit.LifecycleState;
import in.okcredit.LocaleManager;
import in.okcredit.R;
import in.okcredit.ThreadUtils;
import in.okcredit._offline.model.Transaction;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BaseFragment;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui._dialog.NoteDialog;
import in.okcredit.app.ui._dialog.ReceiptDialog;
import in.okcredit.app.ui._utils.CurrencyUtil;
import in.okcredit.app.ui._utils.KeyboardUtil;
import in.okcredit.app.ui._widget.txn_meta.TxnMetadataView;
import in.okcredit.app.ui.addtxn.AddTxnActivity;
import in.okcredit.app.ui.reset_pwd.ResetPwdActivity;
import io.reactivex.Completable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

public class ConfirmTxnFragment extends BaseFragment<AddTxnActivity> implements
    ConfirmTxnContract.View {
    public static ConfirmTxnFragment newInstance() {
        return new ConfirmTxnFragment();
    }

    @BindView(R.id.txnLabel)
    TextView txnLabel;

    @BindView(R.id.customerName)
    TextView customerName;

    @BindView(R.id.amount)
    TextView amount;

    @BindView(R.id.typeIcon)
    ImageView typeIcon;

    @BindView(R.id.meta)
    TxnMetadataView meta;

    @BindView(R.id.passwordBox)
    ViewGroup passwordBox;

    @BindView(R.id.passwordContainer)
    TextInputLayout passwordContainer;

    @BindView(R.id.password)
    EditText password;

    @BindView(R.id.ok)
    ViewGroup ok;

    @BindView(R.id.loading)
    ProgressBar loading;

    @BindView(R.id.tut_layout)
    RelativeLayout tutorialLayout;

    @BindView(R.id.title)
    TextView tutorialLayoutTitle;

    @BindView(R.id.forgot_password)
    TextView forgotPassword;

    @BindView(R.id.description)
    TextView tutorialLayoutDesc;

    @BindView(R.id.fabPlay)
    FloatingActionButton fabPlay;

    @BindView(R.id.skip)
    Button skip;

    @BindView(R.id.actionButton)
    LinearLayout tutorialLayoutActionButton;

    @Inject
    ConfirmTxnContract.Presenter presenter;

    private File receiptImage;
    private String note;

    private MediaPlayer mediaPlayer;
    private boolean isAudioPlaying;
    private CompositeDisposable tasks;

    private int lifecycle;
    private int txnType;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle
        savedInstanceState) {
        View view = inflater.inflate(R.layout.addtxn_confirm_fragment, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        activity.showActionBar(false);

        if (activity.isOldBalance()) {
            getActivity().setTitle(getString(R.string.confirm_old_balance));
        } else {
            getActivity().setTitle(getString(R.string.txn_confirm_title));
        }

        tutorialLayout.setVisibility(View.VISIBLE);

        mediaPlayer = new MediaPlayer();
        tasks = new CompositeDisposable();

        fabPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Analytics.track(
                    AnalyticsEvents.AUDIO_CLICKED,
                    EventProperties
                        .create()
                        .with("screen", "confirm txn")
                        .with("wasAudioPlaying", isAudioPlaying)
                        .with("lifecycle", lifecycle)
                        .with("txnType", txnType)
                );

                isAudioPlaying = !isAudioPlaying;
                setAudioState(isAudioPlaying);
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        presenter.attachView(this);

        if (mediaPlayer == null) {
            mediaPlayer = new MediaPlayer();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        presenter.detachView();
        releaseMediaPlayer();
    }

    /****************************************************************
     Event Listeners
     ****************************************************************/
    public void onViewReceiptClicked() {
        ReceiptDialog.show(getActivity(), receiptImage);
        Analytics.track(
            AnalyticsEvents.TX_VIEW_META,
            EventProperties
                .create()
                .with("type", "bill")
                .with("from", "confirm_txn")
                .with("lifecycle", lifecycle)
        );
    }

    public void onViewNoteClicked() {
        NoteDialog.show(getActivity(), note);
        Analytics.track(
            AnalyticsEvents.TX_VIEW_META,
            EventProperties
                .create()
                .with("type", "note")
                .with("from", "confirm_txn")
                .with("lifecycle", lifecycle)
        );
    }

    @OnClick(R.id.ok)
    public void onOkClicked() {
        KeyboardUtil.hideKeyboard(this);
        presenter.confirmTxn(password.getText().toString());
        Analytics.track(
            AnalyticsEvents.TX_CONFIRM,
            EventProperties
                .create()
                .with("lifecycle", lifecycle)
        );
    }

    @OnClick(R.id.forgot_password)
    public void onForgotPasswordClicked() {
        Analytics.track(
            AnalyticsEvents.TX_FORGOT_PASSWORD_CLICKED,
            EventProperties
                .create()
                .with("lifecycle", lifecycle)
        );

        presenter.forgotPassword();
    }

    /****************************************************************
     MVP methods
     ****************************************************************/
    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(getActivity(), new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
            }
        });
    }

    @Override
    public void showLoading() {
        ok.setVisibility(View.GONE);
        loading.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideLoading() {
        loading.setVisibility(View.GONE);
        ok.setVisibility(View.VISIBLE);
    }

    @Override
    public void showError() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "confirm tx fragment")
                .with("type", "server error")
        );

        Toast.makeText(getActivity(), R.string.err_default, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void gotoLogin() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "confirm tx fragment")
                .with("type", "auth error")
        );

        activity.gotoLogin();
    }

    @Override
    public void setTxnType(int txnType, int lifecycle) {
        this.lifecycle = lifecycle;
        this.txnType = txnType;

        switch (txnType) {
            case Transaction.CREDIT:
                txnLabel.setText(getString(R.string.txn_give_credit_to));
                typeIcon.setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable
                    .ic_credit));
                typeIcon.setColorFilter(ContextCompat.getColor(getActivity(), R.color.tx_credit));
                passwordBox.setVisibility(View.GONE);
                KeyboardUtil.hideKeyboard(this);
                break;

            case Transaction.PAYMENT:
                txnLabel.setText(R.string.txn_accept_payment_from);
                typeIcon.setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable
                    .ic_payment));
                typeIcon.setColorFilter(ContextCompat.getColor(getActivity(), R.color.tx_payment));
                passwordBox.setVisibility(View.VISIBLE);
                password.requestFocus();
                break;
        }

        Analytics.track(
            AnalyticsEvents.TX_CONFIRM_SCREEN,
            EventProperties
                .create()
                .with("type", txnType)
                .with("lifecycle", lifecycle)
                .with("isOldBalance", activity.isOldBalance())
        );
    }

    @Override
    public void setCustomerName(String name) {
        customerName.setText(name);
    }

    @Override
    public void setAmount(float txnAmount) {
        amount.setText(CurrencyUtil.format(txnAmount));
    }

    @Override
    public void showReceipt(File receiptImage) {
        this.receiptImage = receiptImage;
        meta.addOrReplace(TxnMetadataView.TxnMetadata.bill(getActivity(), view ->
            onViewReceiptClicked()));
    }

    @Override
    public void showNote(String note) {
        this.note = note;
        meta.addOrReplace(TxnMetadataView.TxnMetadata.note(getActivity(), note, view ->
            onViewNoteClicked()));
    }

    @Override
    public void showIncorrectPasswordError() {
        passwordContainer.setErrorEnabled(true);
        passwordContainer.setError(getActivity().getString(R.string.txn_incorrect_password));
        forgotPassword.setVisibility(View.VISIBLE);

        Analytics.track(
            AnalyticsEvents.TX_INCORRECT_PASSWORD,
            EventProperties
                .create()
                .with("lifecycle", lifecycle)
        );
    }

    @Override
    public void setupTutorialLayout(int lifecycle, int txType) {
        switch (txType) {
            case Transaction.CREDIT:

                if (lifecycle == LifecycleState.TRIAL_TRANSACTION) {
                    fabPlay.show();

                    switch (activity.getAudioLang()) {
                        case LocaleManager.LANGUAGE_ENGLISH:
                            setAudio(AudioUrl.CONFIRM_TX_CREDIT_EN);
                            break;
                        case LocaleManager.LANGUAGE_HINDI:
                            setAudio(AudioUrl.CONFIRM_TX_CREDIT_HI);
                            break;
                        case LocaleManager.LANGUAGE_MALAYALAM:
                            setAudio(AudioUrl.CONFIRM_TX_CREDIT_ML);
                            break;
                        default:
                            setAudio(AudioUrl.CONFIRM_TX_CREDIT_HI);
                            break;
                    }
                } else {
                    fabPlay.hide();
                    releaseMediaPlayer();
                }

                tutorialLayoutTitle.setVisibility(View.GONE);
                tutorialLayoutActionButton.setVisibility(View.GONE);
                skip.setVisibility(View.INVISIBLE);
                tutorialLayoutDesc.setText(getString(R.string.tut_confirm_txn_desc_credit));

                break;

            case Transaction.PAYMENT:

                if (lifecycle == LifecycleState.TRIAL_TRANSACTION) {
                    fabPlay.show();

                    switch (activity.getAudioLang()) {
                        case LocaleManager.LANGUAGE_ENGLISH:
                            setAudio(AudioUrl.CONFIRM_TX_PAYMENT_EN);
                            break;
                        case LocaleManager.LANGUAGE_HINDI:
                            setAudio(AudioUrl.CONFIRM_TX_PAYMENT_HI);
                            break;
                        case LocaleManager.LANGUAGE_MALAYALAM:
                            setAudio(AudioUrl.CONFIRM_TX_PAYMENT_ML);
                            break;
                        default:
                            setAudio(AudioUrl.CONFIRM_TX_PAYMENT_HI);
                            break;
                    }
                } else {
                    fabPlay.hide();
                    releaseMediaPlayer();
                }

                tutorialLayoutTitle.setVisibility(View.GONE);
                tutorialLayoutActionButton.setVisibility(View.GONE);
                skip.setVisibility(View.INVISIBLE);
                tutorialLayoutDesc.setText(getString(R.string.tut_confirm_txn_desc_payment));

                break;
        }
    }

    @Override
    public void forgotPassword(String mobile) {
        password.setText("");
        Analytics.track(
            AnalyticsEvents.PASSWORD_CHANGE_CLICKED,
            EventProperties
                .create()
                .with("type", "payment")
        );
        startActivity(ResetPwdActivity.startingIntent(activity, mobile, ResetPwdActivity.REQUESTED_SCREEN_TX));
    }

    @Override
    public void gotoSuccess() {
        activity.gotoResultScreen();
    }

    @Override
    public void gotoFailure() {
        activity.gotoResultScreen();
    }

    public void setAudio(String audioUrl) {
        fabPlay.setImageDrawable(ContextCompat.getDrawable(activity, R
            .drawable.ic_pause));

        fabPlay.setClickable(false);

        Disposable task = Completable
            .fromAction(() -> {
                mediaPlayer.setDataSource(activity, Uri.parse(audioUrl), new HashMap<>());
                mediaPlayer.prepare();
            })
            .subscribeOn(ThreadUtils.newThread())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                () -> {
                    Analytics.track(
                        AnalyticsEvents.AUDIO_STARTED,
                        EventProperties
                            .create()
                            .with("screen", "confirm txn")
                            .with("lifecycle", lifecycle)
                            .with("txnType", txnType)
                    );

                    setAudioState(true);
                    fabPlay.setClickable(true);
                },
                throwable -> Timber.e(throwable)
            );

        if (mediaPlayer != null) {
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    Analytics.track(
                        AnalyticsEvents.AUDIO_COMPLETE,
                        EventProperties
                            .create()
                            .with("screen", "confirm txn")
                            .with("lifecycle", lifecycle)
                            .with("txnType", txnType)
                    );

                    fabPlay.setImageDrawable(ContextCompat.getDrawable(activity, R
                        .drawable.ic_play));
                    isAudioPlaying = false;
                }
            });
        }

        tasks.add(task);
    }

    private void setAudioState(boolean playAudio) {
        if (mediaPlayer == null) {
            return;
        }

        isAudioPlaying = playAudio;
        if (playAudio) {
            mediaPlayer.start();
            fabPlay.setImageDrawable(ContextCompat.getDrawable(activity, R
                .drawable.ic_pause));
        } else {
            mediaPlayer.pause();
            fabPlay.setImageDrawable(ContextCompat.getDrawable(activity, R
                .drawable.ic_play));
        }
    }

    private void releaseMediaPlayer() {
        try {
            if (mediaPlayer != null) {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                mediaPlayer.release();
                mediaPlayer = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
