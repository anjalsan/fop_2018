package in.okcredit.app.ui.help.section;

import in.okcredit.domain.help.HelpItem;

/**
 * Created by harsh on 20/12/17.
 */

public interface HelpItemSelectionListener {
    void onSelected(HelpItem helpItem);
}
