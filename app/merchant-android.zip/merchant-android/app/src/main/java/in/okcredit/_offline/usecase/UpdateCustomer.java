package in.okcredit._offline.usecase;

import android.util.Pair;

import com.google.common.base.Strings;

import java.util.NoSuchElementException;

import javax.inject.Inject;

import in.okcredit._offline.database.CustomerRepo;
import in.okcredit._offline.error.CustomerErrors;
import in.okcredit._offline.server.Server;
import io.reactivex.Completable;
import io.reactivex.Single;
import io.reactivex.SingleSource;
import io.reactivex.functions.Function;

public final class UpdateCustomer {
    private Server server;
    private CustomerRepo customerRepo;
    private SafelySaveCustomer safelySaveCustomer;

    @Inject
    public UpdateCustomer(Server server, CustomerRepo customerRepo, SafelySaveCustomer safelySaveCustomer) {
        this.server = server;
        this.customerRepo = customerRepo;
        this.safelySaveCustomer = safelySaveCustomer;
    }

    public Completable execute(String customerId, String desc, String address, String profileImage, String mobile, String customerToken) {
        return Single
            .zip(
                validateMobile(customerId, mobile),
                validateDesc(customerId, desc, 0),
                (_mobile, _desc) -> new Pair<>(_desc, _mobile)
            )
            .flatMapCompletable(data -> {
                String _desc = Strings.emptyToNull(data.first);
                String _mobile = Strings.emptyToNull(data.second);

                if (_desc == null && _mobile == null && address == null && profileImage == null) {
                    return Completable.complete();
                } else {
                    if (_desc != null) {
                        return server.updateCustomer(customerId, data.first, address, profileImage, mobile, customerToken)
                            .flatMapCompletable(customer -> safelySaveCustomer.execute(customer));
                    } else if(_mobile != null)  {
                        return server.updateCustomer(customerId, desc, address, profileImage,  data.second, customerToken)
                            .flatMapCompletable(customer -> safelySaveCustomer.execute(customer));
                    } else {
                        return server.updateCustomer(customerId, desc, address, profileImage, mobile, customerToken)
                            .flatMapCompletable(customer -> safelySaveCustomer.execute(customer));
                    }
                }
            });
    }

    private Single<String> validateMobile(String customerId, String mobile) {
        if (Strings.isNullOrEmpty(mobile) || mobile.length() != 10) {
            return Single.just("");
        } else {
            return customerRepo.findCustomerByMobile(mobile)
                               .flatMap(customer -> {
                                   if (customer.getId().equals(customerId)) {
                                       return Single.just("");
                                   } else {
                                       return Single.<String>error(new CustomerErrors.MobileConflict(customer));
                                   }
                               })
                               .onErrorResumeNext((Function<Throwable, SingleSource<String>>) throwable -> {
                                   if (throwable instanceof NoSuchElementException) {
                                       return Single.just(mobile);
                                   } else {
                                       return Single.error(throwable);
                                   }
                               });
        }
    }

    private Single<String> validateDesc(String customerId, String desc, int suffix) {
        if (Strings.isNullOrEmpty(desc)) {
            return Single.just("");
        }

        if (desc.length() < 1 || desc.length() > 30) {
            return Single.error(new CustomerErrors.InvalidName());
        }

        return Single.just(desc);

//        String temp = desc;
//        if (suffix > 0) {
//            temp = temp + " " + suffix;
//        }
//        final String _desc = temp;
//
//        return customerRepo
//            .findCustomerMyDesc(_desc)
//            .flatMap(customer -> {
//                if (customer.getId().equals(customerId)) {
//                    return Single.just("");
//                } else {
//                    return validateDesc(customerId, desc, suffix + 1);
//                }
//            })
//            .onErrorResumeNext(throwable -> {
//                if (throwable instanceof NoSuchElementException) {
//                    return Single.just(_desc);
//                } else {
//                    return Single.error(throwable);
//                }
//            });
    }
}
