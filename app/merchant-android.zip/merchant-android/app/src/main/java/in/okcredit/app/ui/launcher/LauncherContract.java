package in.okcredit.app.ui.launcher;

import in.okcredit.app.ui._base_v2.MVP;

public interface LauncherContract {
    interface Presenter extends MVP.Presenter<View> {
    }

    interface View extends MVP.View {
        void gotoHome();

        void gotoLanguagueScreen();
    }
}
