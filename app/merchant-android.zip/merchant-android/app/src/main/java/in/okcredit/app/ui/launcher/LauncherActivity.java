package in.okcredit.app.ui.launcher;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.widget.Toast;

import com.appsee.Appsee;

import javax.inject.Inject;

import dagger.android.AndroidInjection;
import dagger.android.AndroidInjector;
import in.okcredit.R;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui.home.HomeActivity;
import in.okcredit.app.ui.language.LanguageActivity;

public class LauncherActivity extends BaseActivity implements LauncherContract.View {
    /* Presenter */
    @Inject
    LauncherContract.Presenter presenter;

    /* Lifecycle Methods */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AndroidInjection.inject(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.launcher_activity);
        Appsee.start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.attachView(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        presenter.detachView();
    }

    @Override
    public void onBackPressed() {
        // first activity (nothing in back stack)
    }

    /****************************************************************
     MVP methods
     ****************************************************************/
    @Override
    public void gotoHome() {
        // Goto home screen
        startActivity(HomeActivity.startingIntent(this));
        finish();
    }

    @Override
    public void gotoLanguagueScreen() {
        startActivity(LanguageActivity.startingIntent(this));
        finish();
    }

    @Override
    public void showError() {
        Toast.makeText(this, R.string.err_default, Toast.LENGTH_SHORT).show();
    }
}
