package in.okcredit._offline.server.identity.internal;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.arch.persistence.room.TypeConverters;
import android.content.Context;

import in.okcredit._offline.database.internal.DateTimeRoomCodec;

@Database(
    version = IdentityDatabase.DB_VERSION,
    entities = {IdentityMapping.class}
)
@TypeConverters({DateTimeRoomCodec.class})
public abstract class IdentityDatabase extends RoomDatabase {
    static final int DB_VERSION = 1;
    static final String DB_NAME = "okcredit-id-mapping.db";

    private static IdentityDatabase INSTANCE;

    public static IdentityDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(context, IdentityDatabase.class, DB_NAME)
                           .build();
        }
        return INSTANCE;
    }

    public abstract IdentityDao identityDao();
}
