package in.okcredit.app.ui.addtxn.confirmTxn;

import android.support.annotation.Nullable;

import javax.inject.Inject;

import in.okcredit._di.UiThread;
import in.okcredit._offline.usecase.GetActiveMerchant;
import in.okcredit.app.ui._base_v2.BasePresenter;
import in.okcredit.app.ui.addtxn.AddTxnUseCase;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import timber.log.Timber;

public class ConfirmTxnPresenter extends BasePresenter<ConfirmTxnContract.View> implements
    ConfirmTxnContract.Presenter {
    private AddTxnUseCase addTxnUseCase;
    private int lifecycle;
    private GetActiveMerchant getActiveMerchant;

    @Inject
    public ConfirmTxnPresenter(@UiThread Scheduler uiScheduler,
                               AddTxnUseCase addTxnUseCase,
                               GetActiveMerchant getActiveMerchant) {
        super(uiScheduler);
        this.addTxnUseCase = addTxnUseCase;
        this.getActiveMerchant = getActiveMerchant;
    }

    @Override
    protected void loadData() {
        super.loadData();

        lifecycle = addTxnUseCase.getLifecycleState();

        addTask(addTxnUseCase
            .txnType()
            .observeOn(uiScheduler)
            .subscribe(
                txnType -> {
                    ifAttached(view -> view.setTxnType(txnType, lifecycle));
                    ifAttached(view -> view.setupTutorialLayout(lifecycle, txnType));
                },
                throwable ->
                {
                    Timber.e(throwable, "failed to get txn type");
                    if (isAuthenticationIssue(throwable)) {
                        ifAttached(view -> view.gotoLogin());
                    } else if (isInternetIssue(throwable)) {
                        ifAttached(view -> view.showNoInternetMessage());
                    } else {
                        ifAttached(view -> view.showError());
                    }
                }
            )
        );

        addTask(addTxnUseCase
            .customer()
            .observeOn(uiScheduler)
            .subscribe(
                customer -> ifAttached(view -> view.setCustomerName(customer
                    .getDescription())),
                throwable ->
                {
                    Timber.e(throwable, "failed to get customer name");
                    if (isAuthenticationIssue(throwable)) {
                        ifAttached(view -> view.gotoLogin());
                    } else if (isInternetIssue(throwable)) {
                        ifAttached(view -> view.showNoInternetMessage());
                    } else {
                        ifAttached(view -> view.showError());
                    }
                }
            )
        );
        addTask(addTxnUseCase
            .amount()
            .observeOn(uiScheduler)
            .subscribe(
                amount -> ifAttached(view -> view.setAmount(amount)),
                throwable ->
                {
                    Timber.e(throwable, "failed to get amount");
                    if (isAuthenticationIssue(throwable)) {
                        ifAttached(view -> view.gotoLogin());
                    } else if (isInternetIssue(throwable)) {
                        ifAttached(view -> view.showNoInternetMessage());
                    } else {
                        ifAttached(view -> view.showError());
                    }
                }
            )
        );
        addTask(addTxnUseCase
            .receipt()
            .observeOn(uiScheduler)
            .subscribe(
                receipt -> ifAttached(view -> view.showReceipt(receipt)),
                throwable ->
                {
                    Timber.e(throwable, "unexpected failure on receipt stream");
                    if (isAuthenticationIssue(throwable)) {
                        ifAttached(view -> view.gotoLogin());
                    } else if (isInternetIssue(throwable)) {
                        ifAttached(view -> view.showNoInternetMessage());
                    } else {
                        ifAttached(view -> view.showError());
                    }
                }
            )
        );
        addTask(addTxnUseCase
            .note()
            .observeOn(uiScheduler)
            .subscribe(
                note -> ifAttached(view -> view.showNote(note)),
                throwable ->
                {
                    Timber.e(throwable, "unexpected failure on note stream");
                    if (isAuthenticationIssue(throwable)) {
                        ifAttached(view -> view.gotoLogin());
                    } else if (isInternetIssue(throwable)) {
                        ifAttached(view -> view.showNoInternetMessage());
                    } else {
                        ifAttached(view -> view.showError());
                    }
                }
            )
        );
        addTask(addTxnUseCase
            .txnStatus()
            .observeOn(uiScheduler)
            .subscribe(
                txnStatus ->
                {
                    switch (txnStatus) {
                        case AddTxnUseCase.STATUS_PROCESSING:
                            ifAttached(view -> view.showLoading());
                            break;

                        case AddTxnUseCase.STATUS_SUCCESS:
                            ifAttached(view -> view.hideLoading());
                            ifAttached(view -> view.gotoSuccess());
                            break;

                        case AddTxnUseCase.STATUS_INCORRECT_PASSWORD:
                            ifAttached(view -> view.hideLoading());
                            ifAttached(view -> view.showIncorrectPasswordError());
                            break;

                        case AddTxnUseCase.STATUS_FAILURE_AUTH:
                            ifAttached(view -> view.hideLoading());
                            ifAttached(view -> view.gotoLogin());
                            break;

                        case AddTxnUseCase.STATUS_FAILURE_NETWORK:
                            ifAttached(view -> view.hideLoading());
                            ifAttached(view -> view.showNoInternetMessage());
                            break;

                        case AddTxnUseCase.STATUS_FAILURE:
                            ifAttached(view -> view.hideLoading());
                            ifAttached(view -> view.gotoFailure());
                            break;
                    }
                },
                throwable ->
                {
                    Timber.e(throwable, "unexpected failure on txn status stream");
                    if (isAuthenticationIssue(throwable)) {
                        ifAttached(view -> view.gotoLogin());
                    } else if (isInternetIssue(throwable)) {
                        ifAttached(view -> view.showNoInternetMessage());
                    } else {
                        ifAttached(view -> view.showError());
                    }
                }
            )
        );
    }

    @Override
    public void confirmTxn(@Nullable String password) {
        addTxnUseCase.confirmRequest(password);
    }

    @Override
    public void forgotPassword() {
        addTask(
            getActiveMerchant
                .execute()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    merchant -> {
                        ifAttached(view -> view.forgotPassword(merchant.getMobile()));
                    }
                )
        );
    }

    @Override
    public void onInternetRestored() {
        loadData();
    }

    @Override
    public void onAuthenticationRestored() {
        loadData();
    }
}
