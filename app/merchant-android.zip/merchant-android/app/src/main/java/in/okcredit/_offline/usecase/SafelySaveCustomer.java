package in.okcredit._offline.usecase;

import android.util.Pair;

import org.joda.time.DateTime;

import java.util.List;

import javax.inject.Inject;

import in.okcredit._offline.database.CustomerRepo;
import in.okcredit._offline.database.TransactionRepo;
import in.okcredit._offline.model.Customer;
import in.okcredit._offline.model.Transaction;
import io.reactivex.Completable;
import io.reactivex.Single;
import timber.log.Timber;

// saves customer ensuring that the balance is right
public final class SafelySaveCustomer {
    private TransactionRepo transactionRepo;
    private CustomerRepo customerRepo;

    @Inject
    public SafelySaveCustomer(TransactionRepo transactionRepo, CustomerRepo customerRepo) {
        this.transactionRepo = transactionRepo;
        this.customerRepo = customerRepo;
    }

    public Completable execute(Customer customer) {
        return Single
            .zip(
                transactionRepo.listTransactions(customer.getId()).firstOrError(),
                customerRepo.isSyncedWithin(customer.getId(), null),
                (transactions, isSynced) -> new Pair<>(isSynced, transactions)
            )
            .map(data -> {
                if (!data.first) {
                    // if never synced, then probably no transactions, so don't update
                    return customer;
                } else {
                    // update account summary before saving
                    return updateAccountSummary(customer, data.second);
                }
            })
            .flatMapCompletable(updatedCustomer -> customerRepo.putCustomer(updatedCustomer));
    }

    public Customer updateAccountSummary(Customer customer, List<Transaction> transactions) {
        float balance = 0.0f;
        long txnCount = 0;
        DateTime lastPayment = null;
        DateTime lastActivity = null;
        for (Transaction txn : transactions) {
            if (!txn.isDeleted()) {
                // balance
                switch (txn.getType()) {
                    case Transaction.CREDIT:
                        balance -= txn.getAmount();
                        break;

                    case Transaction.PAYMENT:
                        balance += txn.getAmount();
                        break;

                    case Transaction.RETURN:
                        balance += txn.getAmount();
                        break;
                }

                // count
                txnCount++;

                // last activity
                if (lastActivity == null || lastActivity.isBefore(txn.getCreatedAt())) {
                    lastActivity = txn.getCreatedAt();
                }

                // last payment
                if (txn.getType() == Transaction.PAYMENT &&
                    (lastPayment == null || lastPayment.isBefore(txn.getCreatedAt()))) {
                    lastPayment = txn.getCreatedAt();
                }
            }
        }

        Timber.i(
            "Customer account summary updated (id=%s): balance=%.0f, %.0f; txn_count=%d, %d; last_activity=%s, %s; last_payment=%s, %s",
            customer.getId(), customer.getBalance(), balance, customer.getTransactionCount(), txnCount, customer
                .getLastActivity(), lastActivity, customer.getLastPayment(), lastPayment);

        return customer.withAccountSummary(balance, txnCount, lastActivity, lastPayment);
    }
}
