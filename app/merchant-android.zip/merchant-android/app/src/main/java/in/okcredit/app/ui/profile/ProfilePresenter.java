package in.okcredit.app.ui.profile;

import javax.inject.Inject;

import in.okcredit._di.UiThread;
import in.okcredit._offline.model.MerchantPreference;
import in.okcredit._offline.usecase.GetActiveMerchant;
import in.okcredit._offline.usecase.GetMerchantPreference;
import in.okcredit.app.ui._base_v2.BasePresenter;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;

public class ProfilePresenter extends BasePresenter<ProfileContract.View> implements
    ProfileContract.Presenter {
    private GetActiveMerchant getActiveMerchant;
    private GetMerchantPreference getMerchantPreference;

    @Inject
    public ProfilePresenter(@UiThread Scheduler uiScheduler,
                            GetActiveMerchant getActiveMerchant,
                            GetMerchantPreference getMerchantPreference) {
        super(uiScheduler);
        this.getActiveMerchant = getActiveMerchant;
        this.getMerchantPreference = getMerchantPreference;
    }

    @Override
    protected void loadData() {
        addTask(
            getActiveMerchant
                .execute()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    merchant -> {
                        ifAttached(view -> view.setMerchant(merchant));
                    },
                    throwable -> {
                        if (isAuthenticationIssue(throwable)) {
                            ifAttached(view -> view.gotoLogin());
                        } else if (isInternetIssue(throwable)) {
                            ifAttached(view -> view.showNoInternetMessage());
                        } else {
                            ifAttached(view -> view.showError());
                        }
                    }
                )
        );
    }

    @Override
    public void onInternetRestored() {
        loadData();
    }

    @Override
    public void onEditNameClicked() {
        ifAttached(view -> view.gotoEditNameScreen());
    }

    @Override
    public void onAuthenticationRestored() {
        loadData();
    }
}
