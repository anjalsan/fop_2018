package in.okcredit.app.ui.addtxn.result;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;
import com.google.common.base.Strings;

import java.io.File;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import in.okcredit.LifecycleState;
import in.okcredit.R;
import in.okcredit._offline.model.Transaction;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BaseFragment;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui._dialog.NoteDialog;
import in.okcredit.app.ui._dialog.ReceiptDialog;
import in.okcredit.app.ui._utils.CurrencyUtil;
import in.okcredit.app.ui._widget.txn_meta.TxnMetadataView;
import in.okcredit.app.ui.addtxn.AddTxnActivity;
import in.okcredit.app.ui.home.HomeActivity;
import in.okcredit.app.ui.transaction.TransactionActivity;
import in.okcredit.util.DateTimeUtils;

public class ResultFragment extends BaseFragment<AddTxnActivity> implements ResultContract.View {
    private File receiptUrlFile = null;

    public static ResultFragment newInstance() {
        return new ResultFragment();
    }

    @BindView(R.id.header)
    ViewGroup header;
    @BindView(R.id.animation)
    LottieAnimationView animation;
    @BindView(R.id.icon)
    ImageView icon;
    @BindView(R.id.title)
    TextView title;
    @BindView(R.id.success)
    ViewGroup success;
    @BindView(R.id.txnIcon)
    ImageView txnIcon;
    @BindView(R.id.customerName)
    TextView customerName;
    @BindView(R.id.timestamp)
    TextView timestamp;
    @BindView(R.id.amount)
    TextView amount;
    @BindView(R.id.balance)
    TextView balance;
    @BindView(R.id.meta)
    TxnMetadataView meta;
    @BindView(R.id.failure)
    ViewGroup failure;

    @BindView(R.id.defaultActions)
    ViewGroup defaultActions;
    @BindView(R.id.done)
    ViewGroup done;

    @BindView(R.id.addMore)
    Button addMore;

    @Inject
    ResultContract.Presenter presenter;

    private MediaPlayer mediaPlayer;
    private String receiptUrl;
    private String note;

    private int lifecycle;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle
        savedInstanceState) {
        View view = inflater.inflate(R.layout.addtxn_result_fragment, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        activity.hideActionBar();

        if (activity.getMode() == AddTxnActivity.MODE_DEFAULT) {
            defaultActions.setVisibility(View.VISIBLE);
            done.setVisibility(View.GONE);
        } else {
            defaultActions.setVisibility(View.GONE);
            done.setVisibility(View.VISIBLE);
        }

        lifecycle = activity.getLifeCycle();

        if (lifecycle == LifecycleState.TRIAL_TRANSACTION) {
            addMore.setText(getString(R.string.try_payment));
        }

        if (activity.isOldBalance()) {
            addMore.setVisibility(View.GONE);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        presenter.attachView(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        presenter.detachView();
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
    }

    /****************************************************************
     * Event Listeners
     ****************************************************************/
    @OnClick(R.id.done)
    public void onDoneClicked() {
        activity.finish();
    }

    @OnClick(R.id.gotoHome)
    public void onGotoHomeClicked() {
        presenter.onGotoHomeClicked();

        Analytics.track(
            AnalyticsEvents.TX_RESULT_CLICK_DONE,
            EventProperties
                .create()
                .with("lifecycle", lifecycle)
        );
    }

    @OnClick(R.id.addMore)
    public void onAddMoreClicked() {
        presenter.onAddMoreClicked(activity.getLifeCycle());

        Analytics.track(
            AnalyticsEvents.TX_RESULT_CLICK_ADD_MORE,
            EventProperties
                .create()
                .with("lifecycle", lifecycle)
        );
    }

    @OnClick(R.id.tryAgain)
    public void onTryAgainClicked() {
        presenter.retry();
        Analytics.track(AnalyticsEvents.TX_RESULT_TRY_AGAIN);
    }

    public void onViewReceiptClicked() {
        if (receiptUrlFile != null && receiptUrlFile.exists()) {
            ReceiptDialog.show(getActivity(), receiptUrlFile);
        } else {
            ReceiptDialog.show(getActivity(), receiptUrl);
        }
        Analytics.track(
            AnalyticsEvents.TX_VIEW_META,
            EventProperties
                .create()
                .with("type", "bill")
                .with("from", "txn_result")
                .with("lifecycle", lifecycle)
        );
    }

    public void onViewNoteClicked() {
        NoteDialog.show(getActivity(), note);
        Analytics.track(
            AnalyticsEvents.TX_VIEW_META,
            EventProperties
                .create()
                .with("type", "note")
                .with("from", "txn_result")
                .with("lifecycle", lifecycle)
        );
    }

    /****************************************************************
     * MVP methods
     ****************************************************************/
    @Override
    public void showError() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "result tx fragment")
                .with("type", "server error")
        );

        Toast.makeText(getActivity(), R.string.err_default, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void setStatus(int txnType, boolean isSuccessful) {
        Analytics.track(
            AnalyticsEvents.TX_RESULT_SCREEN,
            EventProperties.create()
                .with("type", txnType)
                .with("lifecycle", lifecycle)
                .with("isOldBalance", activity.isOldBalance())
        );

        if (isSuccessful) {
            success.setVisibility(View.VISIBLE);

            header.setBackgroundColor(ContextCompat.getColor(getActivity(), R.color.primary));
            playSuccessTone();

            switch (txnType) {
                case Transaction.CREDIT:
                    if (activity.isOldBalance()) {
                        title.setText(getString(R.string.old_balance_added));
                    } else {
                        title.setText(R.string.txn_credit_success_title);
                    }
                    showCreditSuccessAnimation();
                    break;

                case Transaction.PAYMENT:
                    if (activity.isOldBalance()) {
                        title.setText(getString(R.string.old_balance_added));
                    } else {
                        title.setText(R.string.txn_payment_success_title);
                    }

                    showPaymentSuccessAnimation();
                    break;
            }
        } else {
            failure.setVisibility(View.VISIBLE);
            header.setBackgroundColor(ContextCompat.getColor(getActivity(), R.color.error));
            title.setText(R.string.txn_failure_title);
            icon.setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.ic_warning));
            icon.setVisibility(View.VISIBLE);

            Analytics.track(
                AnalyticsEvents.TX_FAILED,
                EventProperties.create()
                    .with("type", txnType)
                    .with("lifecycle", lifecycle)
                    .with("isOldBalance", activity.isOldBalance())
            );
        }
    }

    @Override
    public void setTransaction(ResultContract.Transaction transaction) {
        switch (transaction.type) {
            case Transaction.CREDIT:
                txnIcon.setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable
                    .ic_credit));
                txnIcon.setColorFilter(ContextCompat.getColor(getActivity(), R.color.tx_credit));
                break;

            case Transaction.PAYMENT:
                txnIcon.setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable
                    .ic_payment));
                txnIcon.setColorFilter(ContextCompat.getColor(getActivity(), R.color.tx_payment));
                break;
        }

        customerName.setText(transaction.customerName);
        timestamp.setText(DateTimeUtils.formatLong(transaction.createdAt));
        amount.setText(CurrencyUtil.format(transaction.amount));
        CurrencyUtil.render(transaction.balanceAfter, balance);

        receiptUrl = transaction.receiptUrl;
        if (!TextUtils.isEmpty(receiptUrl)) {
            meta.addOrReplace(TxnMetadataView.TxnMetadata.bill(getActivity(), view -> onViewReceiptClicked()));
        }

        note = transaction.note;
        if (!TextUtils.isEmpty(note)) {
            meta.addOrReplace(TxnMetadataView.TxnMetadata.note(getActivity(), note, view ->
                onViewNoteClicked()));
        }
    }

    @Override
    public void gotoHome() {
        startActivity(HomeActivity.startingIntent(getActivity()));
        getActivity().finish();
    }

    @Override
    public void gotoAddTxn() {
        activity.gotoAddTxnScreen();
    }

    @Override
    public void gotoConfirmTxn() {
        activity.onBackPressed();
    }

    @Override
    public void goToCustomerScreen() {
        activity.gotoCustomerScreen();
    }

    @Override
    public void setReceiptUrl(String receiptUrl) {
        this.receiptUrl = receiptUrl;
    }

    @Override
    public void setReceiptUrlFile(File localFile) {
        this.receiptUrlFile = localFile;
    }

    /****************************************************************
     * Helpers
     ****************************************************************/
    private void showCreditSuccessAnimation() {
        animation.setAnimation("anim/credit_success.json");
        animation.loop(false);
        animation.setSpeed(1.5f);
        animation.playAnimation();
        animation.setVisibility(View.VISIBLE);
    }

    private void showPaymentSuccessAnimation() {
        animation.setAnimation("anim/payment_success.json");
        animation.loop(false);
        animation.setSpeed(1.5f);
        animation.playAnimation();
        animation.setVisibility(View.VISIBLE);
    }

    private void playSuccessTone() {
        mediaPlayer = MediaPlayer.create(getActivity(), R.raw.success);
        mediaPlayer.start();
    }

    @Override
    public void gotoLogin() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "result tx fragment")
                .with("type", "auth error")
        );

        activity.gotoLogin();
    }

    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(activity, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
            }
        });
    }
}
