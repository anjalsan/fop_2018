package in.okcredit._offline.usecase;

import android.support.annotation.NonNull;

import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import in.okcredit.App;
import in.okcredit._offline.database.MerchantRepo;
import in.okcredit._offline.model.MerchantPreference;
import in.okcredit._offline.server.Server;
import io.reactivex.Completable;
import timber.log.Timber;

// Offline
public final class SetMerchantPreference {
    private MerchantRepo merchantRepo;
    private Server server;

    @Inject
    public SetMerchantPreference(MerchantRepo merchantRepo, Server server) {
        this.merchantRepo = merchantRepo;
        this.server = server;
    }

    public Completable execute(MerchantPreference preference, String value) {
        if (value == null) {
            return Completable.complete();
        }

        return server.setMerchantPreference(preference.getKey(), value)
            .andThen(
                merchantRepo.getActiveMerchant()
                    .flatMapCompletable(
                        merchant -> merchantRepo.putMerchantPreference(
                            new MerchantPreference(
                                merchant.getId(),
                                preference.getKey(),
                                value
                            )
                        )
                    ));
    }

    private Completable schedulePushToServer(String key, String value) {
        return Completable
            .fromAction(() -> {
                Constraints constraints = new Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build();

                OneTimeWorkRequest workRequest = new OneTimeWorkRequest.Builder(ApiTask.class)
                    .setConstraints(constraints)
                    .setBackoffCriteria(BackoffPolicy.LINEAR, 30, TimeUnit.SECONDS)
                    .setInputData(
                        new Data.Builder()
                            .putString(ApiTask.KEY, key)
                            .putString(ApiTask.VALUE, value)
                            .build()
                    )
                    .build();

                WorkManager.getInstance()
                    .beginWith(workRequest)
                    .enqueue();
            });
    }

    public static class ApiTask extends Worker {
        static final String KEY = "key";
        static final String VALUE = "value";

        @Inject
        Server server;

        @NonNull
        @Override
        public Result doWork() {
            App.appComponent().inject(this);

            String key = getInputData().getString(KEY);
            String value = getInputData().getString(VALUE);

            if (key == null || value == null) {
                return Result.FAILURE;
            }

            try {
                server.setMerchantPreference(key, value).blockingAwait();
                return Result.SUCCESS;

            } catch (Exception e) {
                Timber.w(e, "api failed: set merchant preference");
                return Result.FAILURE;
            }
        }
    }
}
