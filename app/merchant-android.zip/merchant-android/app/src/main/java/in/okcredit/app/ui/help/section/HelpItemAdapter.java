package in.okcredit.app.ui.help.section;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;

import java.util.List;

import javax.inject.Inject;

import in.okcredit.domain.help.HelpItem;

public class HelpItemAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context context;
    private List<HelpItem> helpItems;
    private HelpItemSelectionListener listener;

    @Inject
    public HelpItemAdapter(HelpSectionActivity context) {
        this.context = context;
    }

    public void setItems(List<HelpItem> helpItems) {
        this.helpItems = helpItems;
        notifyDataSetChanged();
    }

    public void setItemSelectionListener(HelpItemSelectionListener listener) {
        this.listener = listener;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return HelpItemViewHolder.create(context, parent, listener);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ((HelpItemViewHolder) holder).bind(helpItems.get(position));
    }

    @Override
    public int getItemCount() {
        if (helpItems == null) {
            return 0;
        } else {
            return helpItems.size();
        }
    }
}
