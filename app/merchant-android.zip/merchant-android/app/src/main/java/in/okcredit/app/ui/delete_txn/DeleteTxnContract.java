package in.okcredit.app.ui.delete_txn;

import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;
import in.okcredit._offline.model.Transaction;

public interface DeleteTxnContract {
    interface View extends MVP.View, BaseContracts.Loading.View, BaseContracts.Online.View, BaseContracts.Authenticated.View {
        void setTransaction(Transaction transaction);

        void goToCustomerScreen();

        void showIncorrectPasswordError();

        void gotoTransactionScreen(String transactionId);
    }

    interface Presenter extends MVP.Presenter<View>, BaseContracts.Loading.Presenter<View>, BaseContracts.Online.Presenter<View>, BaseContracts.Authenticated.Presenter<View> {
        void delete(String password, String transactionId);

        void onBackPressed();
    }
}
