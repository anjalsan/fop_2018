package in.okcredit.app.ui.old_balance;

import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;
import in.okcredit._offline.model.Customer;

public interface OldBalanceContract {
    interface Presenter extends MVP.Presenter<OldBalanceContract.View>, BaseContracts.Online
        .Presenter<OldBalanceContract.View>, BaseContracts.Authenticated
        .Presenter<OldBalanceContract.View> {
    }

    interface View extends MVP.View, BaseContracts.Online.View, BaseContracts.Authenticated.View {
        void showLoading();

        void hideLoading();

        void displayCustomerDetails(Customer customer);

        void setUpTutorialLayout(int lifecycle);
    }
}
