package in.okcredit.app.ui.language;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.LocaleManager;
import in.okcredit.R;
import in.okcredit.ThreadUtils;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui.home.HomeActivity;
import in.okcredit.util.ShareHelper;
import io.reactivex.Completable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.observers.DisposableCompletableObserver;
import timber.log.Timber;

public class InAppLanguageActivity extends BaseActivity {
    private String languagePref;

    public static Intent startingIntent(Context context) {
        return new Intent(context, InAppLanguageActivity.class);
    }

    /* UI Elements */
    @BindView(R.id.englishView)
    View englishView;

    @BindView(R.id.hindiView)
    View hindiView;

    @BindView(R.id.punjabiView)
    View punjabiView;

    @BindView(R.id.malayalamView)
    View malayalamView;

    @BindView(R.id.hinglishView)
    View hinglishView;

    @BindView(R.id.englishText)
    TextView englishText;

    @BindView(R.id.hindiText)
    TextView hindiText;

    @BindView(R.id.punjabiText)
    TextView punjabiText;

    @BindView(R.id.malayalamText)
    TextView malayalamText;

    @BindView(R.id.hinglishText)
    TextView hinglishText;

    @BindView(R.id.englishCheck)
    ImageView englishCheck;

    @BindView(R.id.hindiCheck)
    ImageView hindiCheck;

    @BindView(R.id.punjabiCheck)
    ImageView punjabiCheck;

    @BindView(R.id.malayalamCheck)
    ImageView malayalamCheck;

    @BindView(R.id.hinglishCheck)
    ImageView hinglishCheck;

    private Context context;


    /* Lifecycle methods */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Analytics.track(AnalyticsEvents.IN_APP_LANGUAGE_SCREEN);

        setContentView(R.layout._screen_language_in_app);
        ButterKnife.bind(this);
        showActionBar(true);
        setTitle(R.string.account_language);
        context = this;

        englishView.setOnClickListener(view ->
        {
            Analytics.track(
                AnalyticsEvents.LANGUAGE_SELECTED_IN_APP,
                EventProperties
                    .create()
                    .with("type", "english"));

            proceed(LocaleManager.LANGUAGE_ENGLISH);
        });

        hindiView.setOnClickListener(view ->
        {
            Analytics.track(
                AnalyticsEvents.LANGUAGE_SELECTED_IN_APP,
                EventProperties
                    .create()
                    .with("type", "hindi"));

            proceed(LocaleManager.LANGUAGE_HINDI);
        });

        punjabiView.setOnClickListener(view ->
        {
            Analytics.track(
                AnalyticsEvents.LANGUAGE_SELECTED_IN_APP,
                EventProperties
                    .create()
                    .with("type", "punjabi"));

            proceed(LocaleManager.LANGUAGE_PUNJABI);
        });

        malayalamView.setOnClickListener(view ->
        {
            Analytics.track(
                AnalyticsEvents.LANGUAGE_SELECTED_IN_APP,
                EventProperties
                    .create()
                    .with("type", "malayalam"));

            proceed(LocaleManager.LANGUAGE_MALAYALAM);
        });

        hinglishView.setOnClickListener(view ->
        {
            Analytics.track(
                AnalyticsEvents.LANGUAGE_SELECTED_IN_APP,
                EventProperties
                    .create()
                    .with("type", "hinglish"));

            proceed(LocaleManager.LANGUAGE_HINGLISH);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        setLanguage();
    }

    private void setLanguage() {
        languagePref = LocaleManager.getLanguage();

        switch (languagePref) {
            case LocaleManager.LANGUAGE_ENGLISH:
                englishCheck.setVisibility(View.VISIBLE);
                hindiCheck.setVisibility(View.INVISIBLE);
                punjabiCheck.setVisibility(View.INVISIBLE);
                malayalamCheck.setVisibility(View.INVISIBLE);
                hinglishCheck.setVisibility(View.INVISIBLE);
                englishText.setTextColor(ContextCompat.getColor(this, R.color.text_title));
                hindiText.setTextColor(ContextCompat.getColor(this, R.color.text_default));
                punjabiText.setTextColor(ContextCompat.getColor(this, R.color.text_default));
                malayalamText.setTextColor(ContextCompat.getColor(this, R.color.text_default));
                hinglishText.setTextColor(ContextCompat.getColor(this, R.color.text_default));
                return;
            case LocaleManager.LANGUAGE_HINDI:
                englishCheck.setVisibility(View.INVISIBLE);
                hindiCheck.setVisibility(View.VISIBLE);
                punjabiCheck.setVisibility(View.INVISIBLE);
                malayalamCheck.setVisibility(View.INVISIBLE);
                hinglishCheck.setVisibility(View.INVISIBLE);
                englishText.setTextColor(ContextCompat.getColor(this, R.color.text_default));
                hindiText.setTextColor(ContextCompat.getColor(this, R.color.text_title));
                punjabiText.setTextColor(ContextCompat.getColor(this, R.color.text_default));
                malayalamText.setTextColor(ContextCompat.getColor(this, R.color.text_default));
                hinglishText.setTextColor(ContextCompat.getColor(this, R.color.text_default));
                return;
            case LocaleManager.LANGUAGE_PUNJABI:
                englishCheck.setVisibility(View.INVISIBLE);
                hindiCheck.setVisibility(View.INVISIBLE);
                punjabiCheck.setVisibility(View.VISIBLE);
                malayalamCheck.setVisibility(View.INVISIBLE);
                hinglishCheck.setVisibility(View.INVISIBLE);
                englishText.setTextColor(ContextCompat.getColor(this, R.color.text_default));
                hindiText.setTextColor(ContextCompat.getColor(this, R.color.text_default));
                punjabiText.setTextColor(ContextCompat.getColor(this, R.color.text_title));
                malayalamText.setTextColor(ContextCompat.getColor(this, R.color.text_default));
                hinglishText.setTextColor(ContextCompat.getColor(this, R.color.text_default));
                return;
            case LocaleManager.LANGUAGE_MALAYALAM:
                englishCheck.setVisibility(View.INVISIBLE);
                hindiCheck.setVisibility(View.INVISIBLE);
                punjabiCheck.setVisibility(View.INVISIBLE);
                malayalamCheck.setVisibility(View.VISIBLE);
                hinglishCheck.setVisibility(View.INVISIBLE);
                englishText.setTextColor(ContextCompat.getColor(this, R.color.text_default));
                hindiText.setTextColor(ContextCompat.getColor(this, R.color.text_default));
                punjabiText.setTextColor(ContextCompat.getColor(this, R.color.text_default));
                malayalamText.setTextColor(ContextCompat.getColor(this, R.color.text_title));
                hinglishText.setTextColor(ContextCompat.getColor(this, R.color.text_default));
                return;
            case LocaleManager.LANGUAGE_HINGLISH:
                englishCheck.setVisibility(View.INVISIBLE);
                hindiCheck.setVisibility(View.INVISIBLE);
                punjabiCheck.setVisibility(View.INVISIBLE);
                malayalamCheck.setVisibility(View.INVISIBLE);
                hinglishCheck.setVisibility(View.VISIBLE);
                englishText.setTextColor(ContextCompat.getColor(this, R.color.text_default));
                hindiText.setTextColor(ContextCompat.getColor(this, R.color.text_default));
                punjabiText.setTextColor(ContextCompat.getColor(this, R.color.text_default));
                malayalamText.setTextColor(ContextCompat.getColor(this, R.color.text_default));
                hinglishText.setTextColor(ContextCompat.getColor(this, R.color.text_title));
                return;
            default:
                return;
        }
    }

    public void proceed(String language) {
        Completable
            .fromRunnable(() -> LocaleManager.setNewLocale(getApplicationContext(), language))
            .subscribeOn(ThreadUtils.newThread())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeWith(new DisposableCompletableObserver() {
                @Override
                public void onComplete() {
                    if (languagePref != null && (language.equals("ml") || languagePref.equals("ml"))) {
                        ShareHelper.deleteShareResource(context);
                    }
                    LocaleManager.markMerchantLangAsSynced(false);
                    finish();
                    startActivity(HomeActivity.startingIntent(InAppLanguageActivity.this));
                }

                @Override
                public void onError(@NonNull Throwable e) {
                    Timber.e(e, "failed to set language");
                    finish();
                    startActivity(HomeActivity.startingIntent(InAppLanguageActivity.this));
                }
            });
    }
}
