package in.okcredit._offline.usecase;

import android.annotation.SuppressLint;

import javax.inject.Inject;

import in.okcredit._offline.database.TransactionRepo;
import in.okcredit._offline.model.Transaction;
import in.okcredit._offline.server.Server;
import io.reactivex.Completable;

// sync a locally saved "dirty" transaction
public final class SyncDirtyTransaction {
    private TransactionRepo transactionRepo;
    private Server server;

    @Inject
    public SyncDirtyTransaction(TransactionRepo transactionRepo, Server server) {
        this.transactionRepo = transactionRepo;
        this.server = server;
    }

    public Completable execute(String txnId) {
        return transactionRepo.getTransaction(txnId)
                              .firstOrError()
                              .flatMapCompletable(localCopy -> Completable.fromAction(() -> sync(localCopy)));
    }

    private void sync(Transaction localCopy) {
        // proceed only if the local transaction is dirty
        // check if local transaction exists on server, if no, create it (idempotent on server for exactly same request)
        // check if local transaction is deleted, if yes, delete it on server (idempotent on server)

        if (!localCopy.isDirty()) {
            return;
        }

        try {
            server.getTransaction(localCopy.getId()).blockingGet();
        } catch (NullPointerException e) {

            // not created on server, create it
            server.addTransaction(
                localCopy.getCustomerId(),
                localCopy.getId(),
                localCopy.getType(),
                localCopy.getAmount(),
                localCopy.getReceiptUrl(),
                localCopy.getNote(),
                localCopy.getCreatedAt(),
                localCopy.isOnboarding()
            ).blockingGet();
        }

        if (localCopy.isDeleted()) {
            // local copy is deleted, delete on server
            server.deleteTransaction(localCopy.getId()).blockingAwait();
        }

        Transaction syncedTxn = localCopy.withDirty(false);
        transactionRepo.putTransaction(syncedTxn).blockingAwait();
    }
}
