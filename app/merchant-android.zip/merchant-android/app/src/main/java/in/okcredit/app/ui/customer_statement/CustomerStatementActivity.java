package in.okcredit.app.ui.customer_statement;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.Telephony;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.FileProvider;
import android.telephony.SmsManager;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import dagger.android.AndroidInjection;
import in.okcredit.BuildConfig;
import in.okcredit.LocaleManager;
import in.okcredit.R;
import in.okcredit._offline.model.Customer;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;

public class CustomerStatementActivity extends BaseActivity implements CustomerStatementContract.View {

    public static final String ARG_CUSTOMER_ID = "customer_id";
    public static final String ARG_LIFECYCLE = "lifecycle";
    private static int SMS_PERMISSION_REQUEST_CODE = 0, PHONE_STATE_PERMISSION_REQUEST_CODE = 1;
    private static String SENT = "SMS_SENT", DELIVERED = "SMS_DELIVERED";
    private BroadcastReceiver sendSMS;
    private BroadcastReceiver deliverSMS;
    private boolean isBroadcastRegistered = false;

    public static Intent startingIntent(Context context, String customerId, int lifecycle) {
        Intent intent = new Intent(context, CustomerStatementActivity.class);
        intent.putExtra(ARG_CUSTOMER_ID, customerId);
        intent.putExtra(ARG_LIFECYCLE, lifecycle);
        return intent;
    }

    @BindView(R.id.payment_reminder)
    LinearLayout paymentReminder;

    @BindView(R.id.mini_statement)
    LinearLayout miniStatement;

    @BindView(R.id.month_report)
    LinearLayout monthlyReport;

    @BindView(R.id.sms_reminder)
    LinearLayout smsReminder;

    @BindView(R.id.reminder_bottom_sheet)
    LinearLayout reminderBottomSheet;

    @BindView(R.id.reminderFab)
    FloatingActionButton reminderFab;

    @BindView(R.id.shadow)
    View shadow;

    @BindView(R.id.dimLayout)
    View dimLayout;

    @BindView(R.id.merchantName)
    TextView merchantNameTV;

    @BindView(R.id.reminderbalance)
    TextView reminderBalance;

    @BindView(R.id.rootView)
    CoordinatorLayout rootView;

    @BindView(R.id.date)
    TextView date;

    @Inject
    CustomerStatementContract.Presenter presenter;

    private Customer customer;
    private String merchantName;
    private BottomSheetBehavior bottomSheetBehavior;
    private ProgressDialog progressDialog;

    /* Lifecycle methods */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AndroidInjection.inject(this);
        super.onCreate(savedInstanceState);

        Analytics.track(AnalyticsEvents.CUSTOMER_STATEMENT_SCREEN);
        setContentView(R.layout.customer_statement_activity);
        ButterKnife.bind(this);

        showActionBar(true);
        setTitle(R.string.send_to_customer);

        bottomSheetBehavior = BottomSheetBehavior.from(reminderBottomSheet);
        hideReminderSheet();

        bottomSheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                if (newState == BottomSheetBehavior.STATE_HIDDEN || newState ==
                    BottomSheetBehavior.STATE_COLLAPSED) {

                    dimLayout.setVisibility(View.GONE);
                    reminderFab.setVisibility(View.GONE);
                    shadow.setVisibility(View.GONE);
                } else {
                    dimLayout.setVisibility(View.VISIBLE);
                    shadow.setVisibility(View.VISIBLE);
                    reminderFab.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {
                if (slideOffset < 0.25) {
                    dimLayout.setVisibility(View.GONE);
                    shadow.setVisibility(View.GONE);
                } else {
                    dimLayout.setVisibility(View.VISIBLE);
                    shadow.setVisibility(View.VISIBLE);
                }
            }
        });

        dimLayout.setOnClickListener(v -> hideReminderSheet());

        paymentReminder.setOnClickListener(v -> {
            Analytics.track(AnalyticsEvents.CUSTOMER_STATEMENT_SCREEN_REMINDER_CLICKED);
            showReminderSheet();
        });

        smsReminder.setOnClickListener(v -> {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission
                .SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission
                    .SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
                return;
            }

            sendDirectSMS();
        });

        reminderFab.setOnClickListener(v -> presenter.sendReminderOnWhatsapp(customer));

        miniStatement.setOnClickListener(v ->
        {
            Analytics.track(AnalyticsEvents.ACCOUNT_CLICK_DOWNLOAD_CUSTOMER_MINISTATEMENT);

            progressDialog = ProgressDialog.show(CustomerStatementActivity.this, "", getString(R.string
                .account_report_loading));
            progressDialog.show();
            presenter.getMiniStatementUrl();
        });

        monthlyReport.setOnClickListener(v ->
        {
            Analytics.track(AnalyticsEvents.ACCOUNT_CLICK_DOWNLOAD_CUSTOMER_MONTHLY_CUSTOMER_REPORT);

            progressDialog = ProgressDialog.show(CustomerStatementActivity.this, "", getString(R.string
                .account_report_loading));
            progressDialog.show();
            presenter.getMonthlyReportUrl();
        });
    }

    private void sendDirectSMS() {

        int requestCodeSent = (int) (System.currentTimeMillis() % 1000);

        int requestCodeDelivered = (int) (System.currentTimeMillis() % 1000) + 1;

        PendingIntent sentPI = PendingIntent.getBroadcast(this, requestCodeSent, new Intent(
            SENT), 0);

        PendingIntent deliveredPI = PendingIntent.getBroadcast(this, requestCodeDelivered,
            new Intent(DELIVERED), 0);

        String smsText = getSmsText();

        try {
            SmsManager sm = SmsManager.getDefault();
            ArrayList<String> parts =sm.divideMessage(smsText);
            int numParts = parts.size();

            ArrayList<PendingIntent> sentIntents = new ArrayList<PendingIntent>();
            ArrayList<PendingIntent> deliveryIntents = new ArrayList<PendingIntent>();

            for (int i = 0; i < numParts; i++) {
                sentIntents.add(sentPI);
                deliveryIntents.add(deliveredPI);
            }

            sm.sendMultipartTextMessage(customer.getMobile(),null, parts, sentIntents, deliveryIntents);

            Toast.makeText(getBaseContext(), R.string.sms_sending, Toast.LENGTH_SHORT).show();
            Analytics.track(
                AnalyticsEvents.SEND_REMINDER_SMS_APP,
                EventProperties
                    .create()
                    .with("cst_name", customer.getMobile())
            );
        } catch (SecurityException e) {
            String reason = e.getMessage() == null ? "null" : e.getMessage();
            Analytics.track(
                AnalyticsEvents.SEND_REMINDER_SMS_APP_PHONE_STATE_PERMISSION,
                EventProperties
                    .create()
                    .with("reason", reason)
                    .with("cst_name", customer.getMobile())
            );
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission
                .READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE}, PHONE_STATE_PERMISSION_REQUEST_CODE);
            }
        } catch (Exception e) {
            String reason = e.getMessage() == null ? "null" : e.getMessage();
            Analytics.track(
                AnalyticsEvents.SEND_REMINDER_SMS_APP_CRASH,
                EventProperties
                    .create()
                    .with("reason", reason)
                    .with("cst_name", customer.getMobile())
            );
            openSMSApp();
        }
    }

    private void showSnackBar(String text) {
        Snackbar.make(rootView, Html.fromHtml(String.format("<font color=\"#ffffff\">%s</font>", text)), Snackbar.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.attachView(this);
        registerBrodCasts();
    }

    @Override
    protected void onPause() {
        super.onPause();
        unRegisterBrodCasts();
    }

    @Override
    public void onBackPressed() {
        if (bottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {
            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
            hideReminderSheet();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void showError() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "customer statement screen")
                .with("type", "server error")
        );

        Toast.makeText(this, R.string.err_default, Toast.LENGTH_LONG).show();
        finish();
    }

    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(this, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
            }
        });
    }

    private void registerBrodCasts() {
        // DELIVERY BroadcastReceiver
        deliverSMS = new BroadcastReceiver() {
            @Override
            public void onReceive(Context arg0, Intent arg1) {
//                unregisterReceiver(this);
                switch (getResultCode()) {
                    case Activity.RESULT_OK:
                        Log.e("SMS", "Deliver");
                        Toast.makeText(getBaseContext(), R.string.sms_delivered,
                            Toast.LENGTH_SHORT).show();
                        break;
                    case Activity.RESULT_CANCELED:
                        Log.e("SMS", "Deliver failed");
                        Toast.makeText(getBaseContext(), R.string.sms_not_delivered,
                            Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        };

        // SEND BroadcastReceiver
        sendSMS = new BroadcastReceiver() {
            @Override
            public void onReceive(Context arg0, Intent arg1) {
//                unregisterReceiver(this);
                switch (getResultCode()) {
                    case Activity.RESULT_OK:
                        showSnackBar(getString(R.string.sms_sent));
                        Analytics.track(AnalyticsEvents.SEND_REMINDER_SMS_APP_SUCCESS);
                        break;
                    case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                        Toast.makeText(getBaseContext(), R.string.sms_send_failed_try_again,
                            Toast.LENGTH_SHORT).show();
                        Analytics.track(
                            AnalyticsEvents.SEND_REMINDER_SMS_APP_FAILED,
                            EventProperties
                                .create()
                                .with("reason", "generic failure")
                        );
                        openSMSApp();
                        break;
                    case SmsManager.RESULT_ERROR_NO_SERVICE:
                        Toast.makeText(getBaseContext(), R.string.sms_send_failed_try_again,
                            Toast.LENGTH_SHORT).show();
                        Analytics.track(
                            AnalyticsEvents.SEND_REMINDER_SMS_APP_FAILED,
                            EventProperties
                                .create()
                                .with("reason", "no service")
                        );
                        openSMSApp();
                        break;
                    case SmsManager.RESULT_ERROR_NULL_PDU:
                        Toast.makeText(getBaseContext(), R.string.sms_send_failed_try_again,
                            Toast.LENGTH_SHORT).show();
                        Analytics.track(
                            AnalyticsEvents.SEND_REMINDER_SMS_APP_FAILED,
                            EventProperties
                                .create()
                                .with("reason", "null pdu")
                        );
                        openSMSApp();
                        break;
                    case SmsManager.RESULT_ERROR_RADIO_OFF:
                        Toast.makeText(getBaseContext(), R.string.sms_send_failed_try_again,
                            Toast.LENGTH_SHORT).show();
                        Analytics.track(
                            AnalyticsEvents.SEND_REMINDER_SMS_APP_FAILED,
                            EventProperties
                                .create()
                                .with("reason", "radio off")
                        );
                        openSMSApp();
                        break;
                    case SmsManager.RESULT_ERROR_LIMIT_EXCEEDED:
                        Toast.makeText(getBaseContext(), R.string.sms_send_failed_try_again,
                            Toast.LENGTH_SHORT).show();
                        Analytics.track(
                            AnalyticsEvents.SEND_REMINDER_SMS_APP_FAILED,
                            EventProperties
                                .create()
                                .with("reason", "limit exceeded")
                        );
                        openSMSApp();
                        break;
                    case SmsManager.RESULT_ERROR_SHORT_CODE_NEVER_ALLOWED:
                        Toast.makeText(getBaseContext(), R.string.sms_send_failed_try_again,
                            Toast.LENGTH_SHORT).show();
                        Analytics.track(
                            AnalyticsEvents.SEND_REMINDER_SMS_APP_FAILED,
                            EventProperties
                                .create()
                                .with("reason", "short code")
                        );
                        openSMSApp();
                        break;
                    case SmsManager.RESULT_ERROR_SHORT_CODE_NOT_ALLOWED:
                        Toast.makeText(getBaseContext(), R.string.sms_send_failed_try_again,
                            Toast.LENGTH_SHORT).show();
                        Analytics.track(
                            AnalyticsEvents.SEND_REMINDER_SMS_APP_FAILED,
                            EventProperties
                                .create()
                                .with("reason", "short code not allowed")
                        );
                        openSMSApp();
                        break;
                    default:
                        Toast.makeText(getBaseContext(), R.string.sms_send_failed_try_again,
                            Toast.LENGTH_SHORT).show();
                        Analytics.track(
                            AnalyticsEvents.SEND_REMINDER_SMS_APP_FAILED,
                            EventProperties
                                .create()
                                .with("reason", "other")
                        );
                }
            }
        };

        registerReceiver(sendSMS, new IntentFilter(SENT));
        registerReceiver(deliverSMS, new IntentFilter(DELIVERED));
        isBroadcastRegistered = true;
    }

    private void unRegisterBrodCasts() {
        isBroadcastRegistered = false;

        if (sendSMS != null) {
            try {
                unregisterReceiver(sendSMS);
            } catch (Exception e){

            }
        }
        if (deliverSMS != null) {
            try {
                unregisterReceiver(deliverSMS);
            } catch (Exception e){

            }
        }
        presenter.detachView();
    }

    private void hideReminderSheet(){
        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
        reminderFab.setVisibility(View.GONE);
        shadow.setVisibility(View.GONE);
        dimLayout.setVisibility(View.GONE);
    }

    private void showReminderSheet(){
        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
        reminderFab.setVisibility(View.VISIBLE);
        shadow.setVisibility(View.VISIBLE);
        dimLayout.setVisibility(View.VISIBLE);
    }

    private void generateReminderImage() {
        reminderBottomSheet.setDrawingCacheEnabled(true);
        Bitmap bitmap = Bitmap.createBitmap(reminderBottomSheet.getDrawingCache());
        reminderBottomSheet.setDrawingCacheEnabled(false);

        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 40, bytes);

        File storageDir = new File(getExternalFilesDir(null),
            "reminder_images");

        if (!storageDir.exists()) {
            storageDir.mkdirs();
        }

        String fileName = UUID.randomUUID().toString() + "image.jpg";

        File reminderImage = new File(getExternalFilesDir(null),
            "reminder_images/" + fileName);

        try {
            FileOutputStream fo = new FileOutputStream(reminderImage);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (IOException e) {
            Analytics.track(
                AnalyticsEvents.ERROR,
                EventProperties
                    .create()
                    .with("screen", getClass().getSimpleName())
                    .with("type", "reminder: image write failed")
            );
            Toast.makeText(this, R.string.err_default, Toast.LENGTH_SHORT).show();
            e.printStackTrace();
            return;
        }
        hideLoading();

        try {
            Uri reminderUri = FileProvider.getUriForFile(this, BuildConfig.APPLICATION_ID + ".provider", reminderImage);

            Intent sendIntent = new Intent("android.intent.action.MAIN");
            sendIntent.putExtra(Intent.EXTRA_STREAM, reminderUri);
            sendIntent.putExtra("jid", "91" + customer.getMobile() + "@s.whatsapp.net");
            sendIntent.putExtra(Intent.EXTRA_TEXT, getString(R.string.payment_reminder_whatsapp_msg, customer.getAccountUrl()));

            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.setType("image/png");

            sendIntent.setPackage("com.whatsapp");
            if (sendIntent.resolveActivity(getPackageManager()) == null) {
                sendIntent.setPackage("com.whatsapp.w4b");

                if (sendIntent.resolveActivity(getPackageManager()) == null) {
                    // Both WhatsApp and WhatsApp for Business  Not installed.
                    Analytics.track(AnalyticsEvents.CUSTOMER_STATEMENT_WHATSAPP_NOT_INSTALLED);
                    Toast.makeText(this, R.string.whatsapp_not_installed, Toast
                        .LENGTH_SHORT).show();
                } else {
                    // WhatsApp for Business Only Installed
                    startActivity(sendIntent);
                }
            } else {
                sendIntent.setPackage("com.whatsapp.w4b");
                if (sendIntent.resolveActivity(getPackageManager()) != null) {
                    // Both WhatsApp and WhatsApp for Business installed.
                    List<Intent> targetShareIntents=new ArrayList<Intent>();
                    Intent shareIntent= new Intent();
                    shareIntent.setAction(Intent.ACTION_SEND);
                    shareIntent.setType("image/png");

                    List<ResolveInfo> resInfos= getPackageManager().queryIntentActivities(shareIntent, 0);
                    if(!resInfos.isEmpty()){
                        for(ResolveInfo resInfo : resInfos){
                            String packageName=resInfo.activityInfo.packageName;
                            if(packageName.contains("com.whatsapp")) {
                                Intent intent= new Intent();
                                intent.setAction(Intent.ACTION_SEND);
                                intent.setType("image/png");
                                intent.putExtra(Intent.EXTRA_STREAM, reminderUri);
                                intent.putExtra("jid", "91" + customer.getMobile() + "@s.whatsapp.net");
                                intent.putExtra(Intent.EXTRA_TEXT, getString(R.string.payment_reminder_whatsapp_msg, customer.getAccountUrl()));
                                intent.setPackage(packageName);
                                targetShareIntents.add(intent);
                            }
                        }
                        if(!targetShareIntents.isEmpty()){
                            Intent chooserIntent=Intent.createChooser(targetShareIntents.remove(0), "Choose app to share");
                            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, targetShareIntents.toArray(new Parcelable[]{}));

                            startActivity(chooserIntent);
                        } else {
                            Toast.makeText(this, R.string.err_default, Toast
                                .LENGTH_SHORT).show();
                        }
                    }
                } else {
                    // WhatsApp Only Installed.
                    sendIntent.setPackage("com.whatsapp");
                    startActivity(sendIntent);
                }
            }
        } catch (Exception e) {
            Analytics.track(
                AnalyticsEvents.ERROR,
                EventProperties
                    .create()
                    .with("screen", getClass().getSimpleName())
                    .with("type", "reminder: whatsapp error")
            );
            Toast.makeText(this, R.string.err_default, Toast.LENGTH_SHORT).show();
            e.printStackTrace();
            return;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            int pos = Arrays.asList(permissions).indexOf(Manifest.permission
                .SEND_SMS);
            if (pos != -1) {
                if (grantResults[pos] == PackageManager.PERMISSION_GRANTED) {
                    sendDirectSMS();
                } else {
                    openSMSApp();
                }
            }
        } else if (requestCode == PHONE_STATE_PERMISSION_REQUEST_CODE) {
            int pos = Arrays.asList(permissions).indexOf(Manifest.permission.READ_PHONE_STATE);
            if (pos != -1) {
                if (grantResults[pos] == PackageManager.PERMISSION_GRANTED) {
                    sendDirectSMS();
                } else {
                    openSMSApp();
                }
            }
        }
    }

    private String getSmsText() {
        String smsText;
        if (LocaleManager.getLanguage().equals(LocaleManager.LANGUAGE_HINDI)) {
            smsText = String.format("%s %s \n%s %s. %s %s", merchantName, getString(R.string.payment_reminder_by), getString(R.string.payment_reminder_amount), String.valueOf("Rs. " + ((int) (customer.getBalance())) * (-1)), getString(R.string.payment_reminder_check_details), customer.getAccountUrl());
        } else {
            smsText = String.format("%s %s. \n%s %s. %s %s", getString(R.string.payment_reminder_by), merchantName, getString(R.string.payment_reminder_amount), String.valueOf("Rs. " + ((int) (customer.getBalance())) * (-1)), getString(R.string.payment_reminder_check_details), customer.getAccountUrl());
        }
        return smsText;
    }


    /****************************************************************
     MVP methods
     ****************************************************************/

    @Override
    public void showLoading() {

    }

    @Override
    public void hideLoading() {
        if (progressDialog != null) {
            progressDialog.dismiss();
            progressDialog = null;
        }
    }

    @Override
    public void setReminderDetails(String merchantName) {
        this.merchantName = merchantName;
        merchantNameTV.setText(merchantName);

        if (customer != null) {
            reminderBalance.setText(String.valueOf("Rs. " + ((int) (customer.getBalance())) *
                (-1)));
        }

        DateTimeFormatter dtfOut = DateTimeFormat.forPattern("dd MMM, h:mm a").withLocale(LocaleManager.getEnglishLocale());
        date.setText(dtfOut.print(DateTime.now()));
    }

    @Override
    public void showReminderError() {

    }

    @Override
    public void displayCustomerDetails(Customer customer) {
        this.customer = customer;

        if (customer.getBalance() >= 0) {
            paymentReminder.setVisibility(View.GONE);
            smsReminder.setVisibility(View.GONE);
        }

        reminderBalance.setText(String.valueOf("Rs. " + ((int) (customer.getBalance())) *
            (-1)));
    }

    @Override
    public void sendReminderOnWhatsapp() {
        hideReminderSheet();

        progressDialog = ProgressDialog.show(CustomerStatementActivity.this, "", getString(R.string
            .generate_reminder));
        progressDialog.show();

        generateReminderImage();
    }

    @Override
    public void openSMSApp() {
        if (customer == null) {
            return;
        }

        Analytics.track(
            AnalyticsEvents.OPENING_DEFAULT_SMS_APP,
            EventProperties
                .create()
                .with("cst_name", customer.getMobile())
        );

        String smsText = getSmsText();

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
            String defaultSmsPackageName = Telephony.Sms.getDefaultSmsPackage(CustomerStatementActivity.this);

            Intent sendIntent = new Intent(Intent.ACTION_SENDTO); sendIntent.setData(Uri.parse("smsto:"+customer.getMobile()));
            sendIntent.putExtra("sms_body", smsText);

            if (defaultSmsPackageName != null) {
                sendIntent.setPackage(defaultSmsPackageName);
            }
            startActivity(sendIntent);
        } else {
            Intent smsIntent = new Intent(android.content.Intent.ACTION_VIEW);
            smsIntent.setType("vnd.android-dir/mms-sms");
            smsIntent.putExtra("address", customer.getMobile());
            smsIntent.putExtra("sms_body",smsText);
            startActivity(smsIntent);
        }
    }

    @Override
    public void downloadMiniStatement(String reportUrl) {
        if (reportUrl != null) {
            presenter.downloadPdfFile(reportUrl, customer.getMobile(), "Mini Statement.pdf");
        }
    }

    @Override
    public void downloadMonthlyReport(String reportUrl) {
        if (reportUrl != null) {
            presenter.downloadPdfFile(reportUrl, customer.getMobile(), "Monthly Report.pdf");
        }
    }

    @Override
    public void sharePdfSuccess(Intent sendIntent) {
        if (sendIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(sendIntent);
        } else {
            Analytics.track(AnalyticsEvents.CUSTOMER_STATEMENT_WHATSAPP_NOT_INSTALLED);
            Toast.makeText(this, R.string.whatsapp_not_installed, Toast
                .LENGTH_SHORT).show();
        }

        hideLoading();
    }

    @Override
    public void sharePdfFail() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "customer statement screen")
                .with("type", "share pdf")
        );

        hideLoading();
    }

    @Override
    public void showPdfError() {
        Toast.makeText(this, R.string.err_default, Toast.LENGTH_LONG).show();
    }
}
