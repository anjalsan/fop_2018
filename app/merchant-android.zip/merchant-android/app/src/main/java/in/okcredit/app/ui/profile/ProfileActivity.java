package in.okcredit.app.ui.profile;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import in.okcredit.R;
import in.okcredit._offline.model.Merchant;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui.edit_merchant.EditMerchantActivity;

public class ProfileActivity extends BaseActivity implements ProfileContract.View {
    public static Intent startingIntent(Context context) {
        Intent intent = new Intent(context, ProfileActivity.class);
        return intent;
    }

    @BindView(R.id.name)
    TextView name;

    @BindView(R.id.mobileContainer)
    ViewGroup mobileContainer;

    @BindView(R.id.mobile)
    TextView mobile;

    @BindView(R.id.nameEditMsg)
    TextView nameEditmsg;

    @BindView(R.id.editName)
    TextView editName;

    @Inject
    ProfileContract.Presenter presenter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_activity);
        ButterKnife.bind(this);
        showActionBar(true);
        setTitle(R.string.profile_title);

        Analytics.track(AnalyticsEvents.PROFILE_SCREEN);
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.attachView(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        presenter.detachView();
    }

    /****************************************************************
     * Listeners
     ****************************************************************/
    @OnClick(R.id.editName)
    public void onEditNameClicked() {
        presenter.onEditNameClicked();
    }

    /****************************************************************
     * MVP methods
     ****************************************************************/
    @Override
    public void showError() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "profile")
                .with("type", "server error")
        );

        Toast.makeText(this, R.string.err_default, Toast.LENGTH_SHORT).show();
        finish();
    }

    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(this, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
            }
        });
    }

    @Override
    public void setMerchant(Merchant merchant) {
        name.setText(merchant.getName());
        mobile.setText(merchant.getMobile());
    }

    @Override
    public void gotoEditNameScreen() {
        startActivity(EditMerchantActivity.startingIntent(this));
    }

    @Override
    public void gotoLogin() {
        super.gotoLogin();
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "profile")
                .with("type", "auth error")
        );

    }
}
