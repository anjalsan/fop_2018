package in.okcredit._offline.usecase;

import javax.inject.Inject;

import in.okcredit._offline._hack.NotificationManager;

// Offline
public final class MarkInAppNotificationSeen {
    private NotificationManager notificationManager;

    @Inject
    public MarkInAppNotificationSeen(NotificationManager notificationManager) {
        this.notificationManager = notificationManager;

    }

    public void execute(int type) {
        notificationManager.markInAppNotificationSeen(type).subscribe();
    }
}
