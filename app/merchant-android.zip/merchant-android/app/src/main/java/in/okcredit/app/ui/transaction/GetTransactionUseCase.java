package in.okcredit.app.ui.transaction;

import android.util.Pair;

import javax.inject.Inject;

import in.okcredit._di.UseCaseParam;
import in.okcredit._offline.model.Customer;
import in.okcredit._offline.model.Transaction;
import in.okcredit._offline.usecase.GetCustomer;
import in.okcredit._offline.usecase.GetTransaction;
import io.reactivex.Observable;

public class GetTransactionUseCase {

    private String transactionId;
    private Observable<TransactionScreenContract.Transaction> transaction;

    private GetCustomer getCustomer;
    private GetTransaction getTransaction;

    @Inject
    public GetTransactionUseCase(@UseCaseParam("transaction_id") String transactionId,
                                 GetCustomer getCustomer,
                                 GetTransaction getTransaction) {
        this.transactionId = transactionId;
        this.getCustomer = getCustomer;
        this.getTransaction = getTransaction;
    }

    public Observable<TransactionScreenContract.Transaction> getObservable() {
        if (transaction == null) {
            transaction =
                transactionObservable()
                    .flatMap(
                        transaction ->
                            getCustomer
                                .execute(transaction.getCustomerId())
                                .map(customer -> new Pair<>(transaction, customer))
                    )
                    .map(GetTransactionUseCase::map)
                    .replay(1)
                    .autoConnect();
        }
        return transaction;
    }

    public Observable<Transaction> transactionObservable() {
        return getTransaction.execute(transactionId);

    }

    /****************************************************************
     Model Mapper
     ****************************************************************/
    private static TransactionScreenContract.Transaction map(Pair<Transaction, Customer> data) {
        Transaction transaction = data.first;
        Customer customer = data.second;

        TransactionScreenContract.Transaction model = new TransactionScreenContract.Transaction();
        model.id = transaction.getId();
        model.type = transaction.getType();
        model.customer = map(customer);
        model.amount = transaction.getAmount();
        model.createdAt = transaction.getCreatedAt();
        model.receiptUrl = transaction.getReceiptUrl();
        model.note = transaction.getNote();
        model.isOnboarding = transaction.isOnboarding();
        model.isDeleted = transaction.isDeleted();
        model.deletedAt = transaction.getDeleteTime();
        model.isDirty = transaction.isDirty();
        return model;
    }

    private static TransactionScreenContract.Customer map(Customer customer) {
        TransactionScreenContract.Customer model = new TransactionScreenContract.Customer();
        model.id = customer.getId();
        model.name = customer.getDescription();
        model.balance = customer.getBalance();
        model.status = customer.getStatus();
        model.mobile = customer.getMobile();
        return model;
    }
}
