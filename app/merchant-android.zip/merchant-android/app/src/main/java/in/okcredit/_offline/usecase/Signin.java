package in.okcredit._offline.usecase;

import javax.inject.Inject;

import in.okcredit.domain.auth.AuthDomain;
import io.reactivex.Completable;

// Internet
public final class Signin {
    private AuthDomain authDomain;
    private ResumeAuthScope resumeAuthScope;

    @Inject
    public Signin(AuthDomain authDomain, ResumeAuthScope resumeAuthScope) {
        this.authDomain = authDomain;
        this.resumeAuthScope = resumeAuthScope;
    }

    public Completable execute(String mobile, String password) {
        return authDomain.authenticate(mobile, password)
                         .andThen(resumeAuthScope.execute());
    }
}
