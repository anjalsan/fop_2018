package in.okcredit.app.ui.app_lock.prompt._di;

import dagger.Module;

@Module
public abstract class AppLockPromptActivity_Module {

}
