package in.okcredit.app.ui.app_lock.forgot._di;

import dagger.Module;

@Module
public abstract class ForgotAppLockActivity_Module {

}
