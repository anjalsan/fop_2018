package in.okcredit._offline.server.internal;

import com.google.common.base.Converter;

import javax.inject.Inject;

import in.okcredit._offline.model.Transaction;
import in.okcredit._offline.server.identity.Identity;

public class TransactionMapper extends Converter<ApiMessages.Transaction, Transaction> {
    private Identity identity;

    @Inject
    public TransactionMapper(Identity identity) {
        this.identity = identity;
    }

    @Override
    protected Transaction doForward(ApiMessages.Transaction apiEntity) {
        String serverId = apiEntity.id;
        String localId = identity.serverToLocal(Identity.TYPE_TRANSACTION, serverId);
        if (localId == null) {
            localId = serverId;
            identity.createMapping(Identity.TYPE_TRANSACTION, localId, serverId);
        }

        return new Transaction(
            localId,
            apiEntity.type,
            apiEntity.customerId,
            apiEntity.amount,
            apiEntity.receiptUrl,
            apiEntity.note,
            apiEntity.createdAt,
            apiEntity.isOnboarding,
            apiEntity.isDeleted,
            apiEntity.deleteTime,
            false
        );
    }

    @Override
    protected ApiMessages.Transaction doBackward(Transaction transaction) {
        throw new RuntimeException("illegal operation: cannot convert transaction domain entity to api entity");
    }
}
