package in.okcredit.app.ui.customer_profile;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomSheetDialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import in.okcredit.R;

public class BottomSheetMediaFragment extends BottomSheetDialogFragment {

    private OnBottomSheetFragmentListner mListener;

    @BindView(R.id.addFromGallery)
    LinearLayout addFromGallery;

    @BindView(R.id.addFromCamera)
    LinearLayout addFromCamera;


    static BottomSheetMediaFragment newInstance() {
        return new BottomSheetMediaFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.media_bottom_sheet, container, false);
        ButterKnife.bind(this, v);
        return v;
    }

    @OnClick(R.id.addFromCamera)
    public void onCameraClicked(){
        mListener.onClickCamera();
    }

    @OnClick(R.id.addFromGallery)
    public void onGalleryClicked(){
        mListener.onClickGallery();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnBottomSheetFragmentListner) {
            mListener = (OnBottomSheetFragmentListner) context;
        } else {
            throw new RuntimeException(context.toString()
                + " must implement OnFeedInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnBottomSheetFragmentListner {
        void onClickCamera();
        void onClickGallery();
    }
}
