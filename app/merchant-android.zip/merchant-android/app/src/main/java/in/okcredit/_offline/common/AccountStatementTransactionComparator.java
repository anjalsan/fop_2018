package in.okcredit._offline.common;

import org.joda.time.DateTime;

import java.util.Comparator;

import in.okcredit._offline.model.Transaction;

public class AccountStatementTransactionComparator implements Comparator<Transaction> {
    @Override
    public int compare(Transaction first, Transaction second) {

        DateTime firstTime = first.getCreatedAt();

        if (first.isDeleted())
        {
            firstTime = first.getDeleteTime();
        }

        DateTime secondTime = second.getCreatedAt();

        if (second.isDeleted())
        {
            secondTime = second.getDeleteTime();
        }


        if (firstTime.isAfter(secondTime))
            return -1;
        else if (firstTime.isBefore(secondTime))
            return 1;
        else
            return 0;
    }
}
