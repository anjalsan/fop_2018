package in.okcredit._offline.model;

import org.joda.time.DateTime;

import java.io.Serializable;

public final class Merchant implements Serializable {
    private final String id;
    private final String name;
    private final String mobile;
    private final DateTime createdAt;

    public Merchant(String id, String name, String mobile, DateTime createdAt) {
        this.id = id;
        this.name = name;
        this.mobile = mobile;
        this.createdAt = createdAt;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getMobile() {
        return mobile;
    }

    public DateTime getCreatedAt() {
        return createdAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Merchant merchant = (Merchant) o;
        return id.equals(merchant.id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }
}
