package in.okcredit.app.ui.account_statement;

import org.joda.time.DateTime;

import java.util.Comparator;

import in.okcredit._offline.model.TransactionWrapper;

public class TransactionWrapperComparator implements Comparator<TransactionWrapper> {
    @Override
    public int compare(TransactionWrapper first, TransactionWrapper second) {

        DateTime firstTime = first.getTransaction().getCreatedAt();

        if (first.getTransaction().isDeleted())
        {
            firstTime = first.getTransaction().getDeleteTime();
        }

        DateTime secondTime = second.getTransaction().getCreatedAt();

        if (second.getTransaction().isDeleted())
        {
            secondTime = second.getTransaction().getDeleteTime();
        }


        if (firstTime.isAfter(secondTime))
            return -1;
        else if (firstTime.isBefore(secondTime))
            return 1;
        else
            return 0;
    }
}
