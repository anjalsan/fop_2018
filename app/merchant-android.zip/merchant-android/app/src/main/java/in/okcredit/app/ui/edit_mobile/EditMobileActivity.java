package in.okcredit.app.ui.edit_mobile;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.text.Html;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.goodiebag.pinview.Pinview;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import dagger.android.AndroidInjection;
import in.okcredit.R;
import in.okcredit._offline.model.Customer;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.util.AnimationUtils;

public class EditMobileActivity extends BaseActivity implements EditMobileContract.View {
    public static final String ARG_CUSTOMER_ID = "customer_id";

    public static Intent startingIntent(Context context,@NonNull String customerId) {
        Intent intent = new Intent(context, EditMobileActivity.class);
        intent.putExtra(ARG_CUSTOMER_ID, customerId);
        return intent;
    }

    /* UI Elements */
    @BindView(R.id.nameContainer)
    CardView nameContainer;
    @BindView(R.id.mobile_number)
    TextView mobileNumber;
    @BindView(R.id.otp)
    Pinview otp;
    @BindView(R.id.reset)
    LinearLayout reset;
    @BindView(R.id.resend_text)
    TextView resendText;
    @BindView(R.id.counter)
    TextView counter;
    @BindView(R.id.cancel)
    LinearLayout cancel;
    @BindView(R.id.error_text)
    TextView errorText;
    @BindView(R.id.customer_name)
    TextView customerName;
    @BindView(R.id.rootView)
    LinearLayout rootView;

    private Context context;

    /* Presenter */
    @Inject
    EditMobileContract.Presenter presenter;

    /* Lifecycle methods */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AndroidInjection.inject(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_mobile_activity);
        ButterKnife.bind(this);
        context = this;
        showActionBar(true);
        setTitle(R.string.edit_mobile);

        otp.setPinViewEventListener((pinview, fromUser) ->
        {
            presenter.verifyOtp(otp.getValue());
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.attachView(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        presenter.detachView();
    }

    /****************************************************************
     * Listeners
     ****************************************************************/
    @OnClick(R.id.cancel)
    public void onCancelOtp() {
        presenter.cancelMobileEditRequest();
    }

    @OnClick(R.id.reset)
    public void onReset() {
        Analytics.track(AnalyticsEvents.EDIT_MOBILE_SCREEN_RESET);
        presenter.requestOtp();
    }

    /****************************************************************
     * MVP methods
     ****************************************************************/

    @Override
    public void showLoading() {

    }

    @Override
    public void hideLoading() {

    }

    @Override
    public void showError() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "edit mobile")
                .with("type", "server error")
        );

        Toast.makeText(this, R.string.err_default, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(this, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
            }
        });
    }

    @Override
    public void gotoLogin() {
        super.gotoLogin();

        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "edit mobile")
                .with("type", "auth error")
        );
    }

    @Override
    public void setCustomerName(String description) {
        customerName.setText(description);
    }

    @Override
    public void setCustomerNewNumber(String mobile) {
        mobileNumber.setText(String.format("%s %s", getString(R.string.txn_confirm_title), mobile));
    }

    @Override
    public void canceledRequest() {
        Analytics.track(AnalyticsEvents.EDIT_CUSTOMER_OTP_CANCEL);
        finish();
    }

    @Override
    public void setResetTimer(long time) {
        counter.setText(String.format("%s %s", String.valueOf((int) time), getString(R.string.seconds)));
    }

    @Override
    public void enableReset() {
        resendText.setTextColor(ContextCompat.getColor(context, R.color.primary));
        counter.setVisibility(View.GONE);
    }

    @Override
    public void disableReset() {
        resendText.setTextColor(ContextCompat.getColor(context, R.color.black_66));
        counter.setVisibility(View.VISIBLE);
    }

    @Override
    public void onMobileConflict(Customer customer) {
        if (customer == null) {
            Toast.makeText(context, getString(R.string.err_mobile_conflict_default), Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(context, getString(R.string.err_mobile_conflict, customer.getDescription()), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void showSendOpt() {
        Snackbar.make(rootView, Html.fromHtml(String.format("<font color=\"#ffffff\">%s</font>", R.string.register_send_otp)), Snackbar.LENGTH_SHORT).show();
    }

    @Override
    public void showChangeMobileSuccess() {
        Toast.makeText(context, getString(R.string.successfully_completed_mobile), Toast.LENGTH_LONG).show();
    }

    @Override
    public void showInvalidOtpError() {
        Analytics.track(AnalyticsEvents.EDIT_CUSTOMER_INCORRECT_OTP);
        errorText.setVisibility(View.VISIBLE);
        errorText.setText(getString(R.string.register_err_incorrect_otp));
        AnimationUtils.shake(otp);
    }

    @Override
    public void hideErrorText() {
        errorText.setVisibility(View.INVISIBLE);
    }

    @Override
    public void showExpiredOtpError() {
        Analytics.track(AnalyticsEvents.EDIT_CUSTOMER_OTP_EXPIRED);
        errorText.setVisibility(View.VISIBLE);
        errorText.setText(getString(R.string.reset_otp));
        AnimationUtils.shake(otp);
    }
}
