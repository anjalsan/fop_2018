package in.okcredit.app.ui.edit_merchant;

import javax.inject.Inject;

import in.okcredit._di.UiThread;
import in.okcredit._offline.usecase.GetActiveMerchant;
import in.okcredit._offline.usecase.UpdateMerchant;
import in.okcredit.app.ui._base_v2.BasePresenter;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import timber.log.Timber;

public class EditMerchantPresenter extends BasePresenter<EditMerchantContract.View> implements
    EditMerchantContract.Presenter {

    private GetActiveMerchant getActiveMerchant;
    private UpdateMerchant updateMerchant;

    @Inject
    public EditMerchantPresenter(@UiThread Scheduler uiScheduler,
                                 GetActiveMerchant getActiveMerchant,
                                 UpdateMerchant updateMerchant) {
        super(uiScheduler);
        this.getActiveMerchant = getActiveMerchant;
        this.updateMerchant = updateMerchant;
    }

    private String sanitize(String s) {
        if (s == null || s.isEmpty()) {
            return null;
        } else {
            return s.trim();
        }
    }

    @Override
    protected void loadData() {
        addTask(
            getActiveMerchant
                .execute()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    merchant -> {
                        ifAttached(view -> view.setMerchant(merchant));
                    },
                    throwable -> {
                        Timber.e("Unable to fetch merchant");
                    })
        );
    }

    @Override
    public void save(String name) {
        name = sanitize(name);

        if (name != null && name.length() < 3) {
            ifAttached(view -> view.displayInvalidNameError());
            return;
        }

        ifAttached(view -> view.showLoading());

        addTask(
            updateMerchant
                .execute(name)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    () -> {
                        ifAttached(view -> view.hideLoading());
                        ifAttached(view -> view.goToMerchantProfileScreen());
                    },
                    throwable -> {

                        ifAttached(view -> view.hideLoading());

                        if (isAuthenticationIssue(throwable))
                            ifAttached(view -> view.gotoLogin());
                        else if (isInternetIssue(throwable))
                            ifAttached(view -> view.showNoInternetMessage());
                        else
                            ifAttached(view -> view.showError());
                    })
        );


    }

    @Override
    public void onInternetRestored() {
        loadData();
    }

    @Override
    public void onAuthenticationRestored() {
        loadData();
    }
}
