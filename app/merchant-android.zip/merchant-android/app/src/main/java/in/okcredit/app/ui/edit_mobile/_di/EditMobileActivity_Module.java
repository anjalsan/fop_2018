package in.okcredit.app.ui.edit_mobile._di;

import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import in.okcredit._di.PresenterParam;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit.app.ui.edit_mobile.EditMobileActivity;
import in.okcredit.app.ui.edit_mobile.EditMobileContract;
import in.okcredit.app.ui.edit_mobile.EditMobilePresenter;

@Module
public abstract class EditMobileActivity_Module {

    @Provides
    @ActivityScope
    @PresenterParam("customer_id")
    public static String customerId(EditMobileActivity activity) {
        return activity.getIntent().getStringExtra(EditMobileActivity.ARG_CUSTOMER_ID);
    }

    @Binds
    @ActivityScope
    public abstract EditMobileContract.Presenter presenter(EditMobilePresenter presenter);
}

