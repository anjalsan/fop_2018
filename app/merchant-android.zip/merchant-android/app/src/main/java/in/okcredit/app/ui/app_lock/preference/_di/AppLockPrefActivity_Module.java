package in.okcredit.app.ui.app_lock.preference._di;

import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import in.okcredit._di.PresenterParam;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit.app.ui.app_lock.preference.AppLockPrefActivity;
import in.okcredit.app.ui.app_lock.preference.AppLockPrefContract;
import in.okcredit.app.ui.app_lock.preference.AppLockPrefPresenter;

@Module
public abstract class AppLockPrefActivity_Module {

    @Binds
    @ActivityScope
    public abstract AppLockPrefContract.Presenter presenter(AppLockPrefPresenter presenter);
}
