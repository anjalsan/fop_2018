package in.okcredit.app.ui.rating._di;

import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import in.okcredit._di.PresenterParam;
import in.okcredit._di.scope.FragmentScope;
import in.okcredit.app.ui.rating.select_rating.SelectRatingContract;
import in.okcredit.app.ui.rating.select_rating.SelectRatingFragment;
import in.okcredit.app.ui.rating.select_rating.SelectRatingPresenter;

@Module
public abstract class SelectRatingFragment_Module {
    @Binds
    @FragmentScope
    public abstract SelectRatingContract.Presenter presenter(SelectRatingPresenter presenter);
}
