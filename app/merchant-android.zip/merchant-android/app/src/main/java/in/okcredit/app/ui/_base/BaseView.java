package in.okcredit.app.ui._base;

public interface BaseView {
    void onError(String tag);

    void onNetworkFailure();

    void onAuthenticationFailure();
}
