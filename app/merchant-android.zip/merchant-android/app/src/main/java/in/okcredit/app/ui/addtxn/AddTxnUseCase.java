package in.okcredit.app.ui.addtxn;

import android.support.annotation.Nullable;

import java.io.File;
import java.io.IOException;

import javax.inject.Inject;

import in.okcredit.ThreadUtils;
import in.okcredit._di.UseCaseParam;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit._offline.model.Customer;
import in.okcredit._offline.model.Transaction;
import in.okcredit._offline.usecase.AddTransaction;
import in.okcredit._offline.usecase.GetCustomer;
import in.okcredit.domain.auth.AuthErrors;
import io.reactivex.Completable;
import io.reactivex.Observable;
import io.reactivex.observers.DisposableSingleObserver;
import io.reactivex.subjects.BehaviorSubject;
import timber.log.Timber;

import static in.okcredit._offline.model.Transaction.CREDIT;
import static in.okcredit._offline.model.Transaction.PAYMENT;

@ActivityScope
public class AddTxnUseCase {
    public static final int STATUS_PROCESSING = 1;
    public static final int STATUS_SUCCESS = 2;
    public static final int STATUS_INCORRECT_PASSWORD = 3;
    public static final int STATUS_FAILURE_NETWORK = 4;
    public static final int STATUS_FAILURE_AUTH = 5;
    public static final int STATUS_FAILURE = 6;

    private String customerId;
    private int txnType;
    private int lifecycle;

    private float amount;
    private File receipt;
    private String note;

    private boolean inProgress, isOldBalance;
    private BehaviorSubject<Transaction> result;
    private BehaviorSubject<Integer> txnStatus;

    private GetCustomer getCustomer;
    private AddTransaction addTransaction;

    @Inject
    public AddTxnUseCase(@UseCaseParam("customer_id") String customerId,
                         @UseCaseParam("txn_type") int txnType,
                         @UseCaseParam("lifecycle") int lifecycle,
                         @UseCaseParam("is_old_balance") boolean isOldBalance,
                         GetCustomer getCustomer,
                         AddTransaction addTransaction) {
        this.customerId = customerId;
        this.txnType = txnType;
        this.lifecycle = lifecycle;
        this.isOldBalance = isOldBalance;
        result = BehaviorSubject.create();
        txnStatus = BehaviorSubject.create();
        this.getCustomer = getCustomer;
        this.addTransaction = addTransaction;
    }

    public Observable<Customer> customer() {
        return getCustomer.execute(customerId);
    }

    public Observable<Integer> txnType() {
        if (txnType == CREDIT || txnType == PAYMENT) {
            return Observable.fromCallable(() -> txnType);
        } else {
            return Observable.error(new IllegalStateException("invalid txn_type"));
        }
    }

    public Observable<Float> amount() {
        if (amount <= 0.0) {
            return Observable.error(new IllegalStateException("amount not set"));
        } else {
            return Observable.fromCallable(() -> amount);
        }
    }

    public Observable<File> receipt() {
        if (receipt != null && receipt.length() > 0) {
            return Observable.fromCallable(() -> receipt);
        } else {
            return Observable.empty();
        }
    }

    public Observable<String> note() {
        if (note != null && note.length() > 0) {
            return Observable.fromCallable(() -> note);
        } else {
            return Observable.empty();
        }
    }

    public Observable<Integer> txnStatus() {
        return txnStatus;
    }

    public Observable<Transaction> result() {
        return result;
    }

    public Completable createRequest(float amount, File receipt, String note) {
        reset();
        if (amount <= 0) {
            return Completable.error(new AddTxnUseCaseErrors.InvalidAmount());
        }

        this.amount = amount;
        this.receipt = receipt;
        this.note = note;
        return Completable.complete();
    }

    public void confirmRequest(@Nullable String password) {
        if (inProgress) {
            return;
        }

        if (txnType != Transaction.CREDIT) {
            if (password == null || password.length() < 6) {
                txnStatus.onNext(STATUS_INCORRECT_PASSWORD);
                return;
            }
        }

        inProgress = true;
        txnStatus.onNext(STATUS_PROCESSING);
        addTransaction
            .execute(txnType, customerId, amount, receipt, note, isOldBalance, password)
            .subscribeOn(ThreadUtils.worker())
            .subscribe(new DisposableSingleObserver<Transaction>() {
                @Override
                public void onSuccess(Transaction transaction) {
                    inProgress = false;
                    txnStatus.onNext(STATUS_SUCCESS);
                    result = BehaviorSubject.createDefault(transaction);
                }

                @Override
                public void onError(Throwable e) {
                    inProgress = false;
                    if (e instanceof IOException || e.getCause() instanceof IOException) {
                        txnStatus.onNext(STATUS_FAILURE_NETWORK);
                    } else if (e instanceof AuthErrors.Unauthenticated || e.getCause()
                        instanceof AuthErrors.Unauthenticated) {
                        txnStatus.onNext(STATUS_FAILURE_AUTH);
                    } else if (e instanceof AuthErrors.IncorrectPassword || e.getCause()
                        instanceof AuthErrors.IncorrectPassword) {
                        txnStatus.onNext(STATUS_INCORRECT_PASSWORD);
                    } else {
                        Timber.e(e, "unknown failure while creating transaction");
                        txnStatus.onNext(STATUS_FAILURE);
                    }
                }
            });
    }

    public Completable resetTx() {
        reset();
        return Completable.complete();
    }

    private void reset() {
        result = BehaviorSubject.create();
        txnStatus = BehaviorSubject.create();
        amount = 0.0f;
        receipt = null;
        note = null;
    }

    public int getLifecycleState() {
        return lifecycle;
    }
}
