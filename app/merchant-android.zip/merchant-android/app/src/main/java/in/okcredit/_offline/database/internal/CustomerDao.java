package in.okcredit._offline.database.internal;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Transaction;
import android.arch.persistence.room.Update;

import org.joda.time.DateTime;

import java.util.List;

import io.reactivex.Flowable;
import io.reactivex.Maybe;
import io.reactivex.Single;

@Dao
public abstract class CustomerDao {
    @Query("SELECT * FROM customer ORDER BY description")
    public abstract Flowable<List<DbEntities.Customer>> listCustomers();

    @Query("SELECT * FROM customer WHERE id = :customerId LIMIT 1")
    public abstract Flowable<DbEntities.Customer> getCustomer(String customerId);

    @Query("DELETE FROM customer")
    public abstract void deleteAllCustomers();

    @Insert(onConflict = OnConflictStrategy.FAIL)
    public abstract void insertCustomer(DbEntities.Customer... customer);

    @Update
    public abstract int updateCustomer(DbEntities.Customer customer);

    @Transaction
    public void putCustomer(DbEntities.Customer customer) {
        if (updateCustomer(customer) != 1) {
            insertCustomer(customer);
        }
    }

    @Transaction
    public void resetCustomerList(DbEntities.Customer... customers) {
        deleteAllCustomers();
        insertCustomer(customers);
    }

    @Query("SELECT count(*) FROM customersync WHERE customerId = :customerId")
    public abstract Single<Integer> isCustomerSynced(String customerId);

    @Query("SELECT lastSync FROM customersync WHERE customerId = :customerId")
    public abstract Single<DateTime> getLastSyncTime(String customerId);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public abstract void insertCustomerSync(DbEntities.CustomerSync... customerSync);

    @Query("DELETE FROM customersync")
    public abstract void deleteAllSyncData();

    @Query("SELECT * FROM customer WHERE mobile = :mobile LIMIT 1")
    public abstract Single<DbEntities.Customer> findCustomerByMobile(String mobile);

    @Query("SELECT * FROM customer WHERE lower(description) = lower(:desc) LIMIT 1")
    public abstract Single<DbEntities.Customer> findCustomerByDesc(String desc);
}
