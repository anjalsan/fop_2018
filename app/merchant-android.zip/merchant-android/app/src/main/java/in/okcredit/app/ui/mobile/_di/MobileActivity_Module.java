package in.okcredit.app.ui.mobile._di;

import dagger.Binds;
import dagger.Module;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit.app.ui.mobile.EnterMobile;
import in.okcredit.app.ui.mobile.EnterMobilePresenter;

@Module
public abstract class MobileActivity_Module {
    @Binds
    @ActivityScope
    public abstract EnterMobile.Presenter presenter(EnterMobilePresenter presenter);
}
