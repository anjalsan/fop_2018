package in.okcredit._offline.usecase;

import android.util.Pair;

import org.joda.time.DateTime;
import org.joda.time.Hours;

import javax.inject.Inject;

import in.okcredit._offline.database.CustomerRepo;
import in.okcredit._offline.database.TransactionRepo;
import in.okcredit._offline.model.Customer;
import io.reactivex.Observable;
import io.reactivex.Single;
import timber.log.Timber;

public final class GetCustomer {
    private CustomerRepo customerRepo;
    private SyncCustomer syncCustomer;
    private TransactionRepo transactionRepo;

    @Inject
    public GetCustomer(CustomerRepo customerRepo, SyncCustomer syncCustomer, TransactionRepo transactionRepo) {
        this.customerRepo = customerRepo;
        this.syncCustomer = syncCustomer;
        this.transactionRepo = transactionRepo;
    }

    public Observable<Customer> execute(String customerId) {
        return isHardSyncRequired(customerId)
            .flatMapObservable(isHardSyncRequired -> {
                if (!isHardSyncRequired) {
                    // hard sync not required (do asynchronously if not done in the last hour)
                    return isBackgroundSyncRequired(customerId)
                        .flatMapObservable(isBackgroundSyncRequired -> {
                            if (!isBackgroundSyncRequired) {
                                Timber.i("no sync required for %s", customerId);
                                return customerRepo.getCustomer(customerId);
                            } else {
                                Timber.i("background sync required for %s", customerId);
                                return syncCustomer.schedule(customerId)
                                    .andThen(customerRepo.getCustomer(customerId));
                            }
                        });
                } else {
                    Timber.i("hard sync required for %s", customerId);
                    // hard sync required (do synchronously)
                    return syncCustomer.execute(customerId, null)
                        .andThen(customerRepo.getCustomer(customerId));
                }
            });
    }

    private Single<Boolean> isHardSyncRequired(String customerId) {
        return customerRepo
            .isSyncedWithin(customerId, null)
            .flatMap(isSyncedEver -> {
                if (!isSyncedEver) {
                    return Single.just(true); // never synced, hard sync required
                } else {

                    return transactionRepo
                        .listDirtyTransactions(customerId)
                        .flatMap(dirtyList -> {
                            if (dirtyList.isEmpty()) {
                                return Single.just(false); // synced once, no dirty transactions, hard sync not required
                            } else {
                                return customerRepo.isSyncedWithin(customerId, Hours.hours(24)) // synced once, has dirty transactions, hard sync required if `not synced withing last 2 hours`
                                    .map(isSynced -> !isSynced);
                            }
                        });
                }
            });
    }

    private Single<Boolean> isBackgroundSyncRequired(String customerId) {
        return transactionRepo
            .listDirtyTransactions(customerId)
            .flatMap(dirtyList -> {
                if (dirtyList.isEmpty()) {
                    // no dirty transactions
                    return customerRepo.getCustomer(customerId)
                        .firstOrError()
                        .flatMap(customer ->
                            customerRepo.getLastSyncTime(customerId)
                                .map(lastSync -> {
                                    if (customer.getLastActivity().isAfter(lastSync)) {
                                        // txn added for customer after last sync, do background sync
                                        return true;
                                    } else if (lastSync.isBefore(DateTime.now().minus(Hours.hours(1)))) {
                                        // last sync is older than 1hr, do background sync
                                        return true;
                                    } else {
                                        return false;
                                    }
                                })
                        )
                        .onErrorReturnItem(true);

//                    return customerRepo.isSyncedWithin(customerId, Hours.hours(1))
//                        .map(isSynced -> !isSynced);
                } else {
                    // dirty transactions present, do background sync
                    return Single.just(true);
                }
            });
    }
}
