package in.okcredit._offline.model;

import org.joda.time.DateTime;

import java.io.Serializable;

public final class Customer implements Serializable {
    private final String id;
    private final int status;
    private final String mobile;
    private final String description;
    private final DateTime createdAt;
    private final String accountUrl;
    private final float balance;
    private final long transactionCount;
    private final DateTime lastActivity;
    private final DateTime lastPayment;
    private final String profileImage;
    private final String address;
    private final String email;

    public Customer(String id, int status, String mobile, String description, DateTime createdAt, float balance,
                    long transactionCount, DateTime lastActivity, DateTime lastPayment, String accountUrl,
                    String profileImage, String address, String email) {
        this.id = id;
        this.status = status;
        this.mobile = mobile;
        this.description = description;
        this.createdAt = createdAt;
        this.balance = balance;
        this.transactionCount = transactionCount;
        this.lastActivity = lastActivity;
        this.lastPayment = lastPayment;
        this.accountUrl = accountUrl;
        this.profileImage = profileImage;
        this.address = address;
        this.email = email;
    }

    public String getId() {
        return id;
    }

    public int getStatus() {
        return status;
    }

    public String getMobile() {
        return mobile;
    }

    public String getDescription() {
        return description;
    }

    public DateTime getCreatedAt() {
        return createdAt;
    }

    public float getBalance() {
        return balance;
    }

    public long getTransactionCount() {
        return transactionCount;
    }

    public DateTime getLastActivity() {
        return lastActivity;
    }

    public DateTime getLastPayment() {
        return lastPayment;
    }

    public String getAccountUrl() {
        return accountUrl;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public String getAddress() {
        return address;
    }

    public String getEmail() {
        return email;
    }

    public Customer withAccountSummary(float balance, long txnCount, DateTime lastActivity, DateTime lastPayment) {
        return new Customer(
            id,
            status,
            mobile,
            description,
            createdAt,
            balance,
            txnCount,
            lastActivity,
            lastPayment,
            accountUrl,
            profileImage,
            address,
            email
        );
    }

    public Customer withId(String id) {
        return new Customer(
            id,
            status,
            mobile,
            description,
            createdAt,
            balance,
            transactionCount,
            lastActivity,
            lastPayment,
            accountUrl,
            profileImage,
            address,
            email
        );
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Customer customer = (Customer) o;

        if (status != customer.status) return false;
        if (Float.compare(customer.balance, balance) != 0) return false;
        if (transactionCount != customer.transactionCount) return false;
        if (!id.equals(customer.id)) return false;
        if (mobile != null ? !mobile.equals(customer.mobile) : customer.mobile != null)
            return false;
        if (!description.equals(customer.description)) return false;
        if (lastActivity != null ? !lastActivity.equals(customer.lastActivity) : customer.lastActivity != null)
            return false;
        if (lastPayment != null ? !lastPayment.equals(customer.lastPayment) : customer.lastPayment != null)
            return false;
        if (profileImage != null ? !profileImage.equals(customer.profileImage) : customer.profileImage != null)
            return false;
        return address != null ? address.equals(customer.address) : customer.address == null;
    }

    @Override
    public int hashCode() {
        int result = id.hashCode();
        result = 31 * result + status;
        result = 31 * result + (mobile != null ? mobile.hashCode() : 0);
        result = 31 * result + description.hashCode();
        result = 31 * result + (balance != +0.0f ? Float.floatToIntBits(balance) : 0);
        result = 31 * result + (int) (transactionCount ^ (transactionCount >>> 32));
        result = 31 * result + (lastActivity != null ? lastActivity.hashCode() : 0);
        result = 31 * result + (lastPayment != null ? lastPayment.hashCode() : 0);
        result = 31 * result + (profileImage != null ? profileImage.hashCode() : 0);
        result = 31 * result + (address != null ? address.hashCode() : 0);
        return result;
    }
}
