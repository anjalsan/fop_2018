package in.okcredit.app.ui.addtxn.result;

import android.util.Pair;

import javax.inject.Inject;

import in.okcredit.LifecycleState;
import in.okcredit.ThreadUtils;
import in.okcredit._di.UiThread;
import in.okcredit._offline.usecase.CheckNetworkStatus;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BasePresenter;
import in.okcredit.app.ui.addtxn.AddTxnUseCase;
import in.okcredit.service.aws.AwsService;
import io.reactivex.Observable;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import timber.log.Timber;

public class ResultPresenter extends BasePresenter<ResultContract.View> implements ResultContract.Presenter {
    private AddTxnUseCase addTxnUseCase;
    private CheckNetworkStatus checkNetworkStatus;
    private AwsService awsService;
    private int lifecycle;

    @Inject
    public ResultPresenter(@UiThread Scheduler uiScheduler, AwsService awsService, AddTxnUseCase addTxnUseCase, CheckNetworkStatus checkNetworkStatus) {
        super(uiScheduler);
        this.addTxnUseCase = addTxnUseCase;
        this.checkNetworkStatus = checkNetworkStatus;
        this.awsService = awsService;
    }

    @Override
    protected void loadData() {
        lifecycle = addTxnUseCase.getLifecycleState();
        addTask(Observable
            .zip(
                addTxnUseCase.txnType(),
                addTxnUseCase.txnStatus(),
                (type, status) -> new Pair<>(type, (status == AddTxnUseCase.STATUS_SUCCESS))
            )
            .observeOn(uiScheduler)
            .subscribe(
                result -> ifAttached(view -> {
                    view.setStatus(result.first, result.second);

                    checkNetworkStatus
                        .isInternet()
                        .subscribe(
                            isInternet -> {
                                Timber.tag("isConnectedToInternet" + String.valueOf(isInternet));
                                Analytics.track(
                                    AnalyticsEvents.TX_SUCCESSFUL,
                                    EventProperties.create()
                                        .with("type", result.first)
                                        .with("internet", isInternet)
                                        .with("lifecycle", lifecycle)
                                );
                            }
                        );

                }),
                throwable ->
                {
                    Timber.e(throwable, "failed to get txn status");
                    if (isAuthenticationIssue(throwable)) {
                        ifAttached(view -> view.gotoLogin());
                    } else if (isInternetIssue(throwable)) {
                        ifAttached(view -> view.showNoInternetMessage());
                    } else {
                        ifAttached(view -> view.showError());
                    }
                }
            )
        );

        addTask(Observable
            .combineLatest(
                addTxnUseCase.result(),
                addTxnUseCase.customer(),
                (transaction, customer) ->
                {
                    ResultContract.Transaction txn = new ResultContract.Transaction();
                    txn.type = transaction.getType();
                    txn.customerName = customer.getDescription();
                    txn.customerMobile = customer.getMobile();
                    txn.amount = transaction.getAmount();
                    txn.balanceAfter = customer.getBalance();
                    txn.receiptUrl = transaction.getReceiptUrl();
                    txn.note = transaction.getNote();
                    txn.createdAt = transaction.getCreatedAt();
                    return txn;
                }
            )
            .subscribeOn(ThreadUtils.worker())
            .observeOn(uiScheduler)
            .subscribe(
                transaction -> ifAttached(view -> {
                    view.setTransaction(transaction);
                    if (transaction.receiptUrl != null) {
                        addTask(
                            awsService
                                .getFile(transaction.receiptUrl)
                                .observeOn(AndroidSchedulers.mainThread())
                                .subscribe(fileInfo -> {
                                    if (fileInfo.isLocal) {
                                        Timber.i("Local Image Url");
                                        view.setReceiptUrlFile(fileInfo.localFile);
                                    } else {
                                        view.setReceiptUrl(fileInfo.url);

                                    }
                                }));
                    }
                }),
                throwable ->
                {
                    Timber.e(throwable, "failed to get successful txn");
                    if (isAuthenticationIssue(throwable)) {
                        ifAttached(view -> view.gotoLogin());
                    } else if (isInternetIssue(throwable)) {
                        ifAttached(view -> view.showNoInternetMessage());
                    } else {
                        ifAttached(view -> view.showError());
                    }
                }
            )
        );
    }

    @Override
    public void onGotoHomeClicked() {
        ifAttached(view -> view.gotoHome());
    }

    @Override
    public void onAddMoreClicked(int lifecycle) {
        if (lifecycle == LifecycleState.TRIAL_TRANSACTION) {
            ifAttached(view -> view.goToCustomerScreen());
        } else {
            addTask(addTxnUseCase
                .resetTx()
                .subscribeOn(ThreadUtils.newThread())
                .subscribe(
                    () -> ifAttached(view -> view.gotoAddTxn()),
                    throwable ->
                    {
                        Timber.e(throwable, "failed to reset tx screen");
                    }
                ));
        }
    }

    @Override
    public void retry() {
        ifAttached(view -> view.gotoConfirmTxn());
    }

    @Override
    public void onInternetRestored() {
        loadData();
    }

    @Override
    public void onAuthenticationRestored() {
        loadData();
    }
}
