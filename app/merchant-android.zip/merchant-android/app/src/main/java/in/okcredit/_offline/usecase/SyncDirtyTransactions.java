package in.okcredit._offline.usecase;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import in.okcredit._offline.common.RxJavaUtils;
import in.okcredit._offline.database.TransactionRepo;
import in.okcredit._offline.model.Transaction;
import io.reactivex.Completable;

// Syncs all dirty transactions
public class SyncDirtyTransactions {
    private TransactionRepo transactionRepo;
    private SyncDirtyTransaction syncDirtyTransaction;

    @Inject
    public SyncDirtyTransactions(TransactionRepo transactionRepo, SyncDirtyTransaction syncDirtyTransaction) {
        this.transactionRepo = transactionRepo;
        this.syncDirtyTransaction = syncDirtyTransaction;
    }

    public Completable execute() {
        return transactionRepo
            .listDirtyTransactions(null)
            .flatMapCompletable(
                transactions -> {
                    List<Completable> jobs = new ArrayList<>();
                    for (Transaction transaction : transactions) {
                        jobs.add(syncDirtyTransaction.execute(transaction.getId()));
                    }
                    return RxJavaUtils.runConcurrently(jobs, 4);
                }
            );
    }
}
