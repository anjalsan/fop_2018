package in.okcredit.app.ui.help.main;

import in.okcredit.domain.help.HelpSection;

/**
 * Created by harsh on 20/12/17.
 */

public interface HelpSectionSelectionListener {
    void onSelected(HelpSection helpSection);
}
