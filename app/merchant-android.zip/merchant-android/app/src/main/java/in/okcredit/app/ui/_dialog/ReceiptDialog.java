package in.okcredit.app.ui._dialog;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;

import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.github.chrisbanes.photoview.PhotoView;

import java.io.File;

import in.okcredit.R;
import in.okcredit.util.GlideApp;

public final class ReceiptDialog {
    public static AlertDialog show(Context context, String receiptUrl) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setCancelable(true);

        View dialogView = LayoutInflater.from(context).inflate(R.layout.view_receipt, null);
        builder.setView(dialogView);
        dialogView.setPadding(0, 0, 0, 0);

        PhotoView receipt = dialogView.findViewById(R.id.receipt);
        View loading = dialogView.findViewById(R.id.loading);
        View noReceipt = dialogView.findViewById(R.id.noReceipt);

        receipt.setVisibility(View.GONE);
        noReceipt.setVisibility(View.VISIBLE);

        AlertDialog alertDialog = builder.create();
        alertDialog.show();

        if (receiptUrl != null) {
            loading.setVisibility(View.VISIBLE);
            receipt.setVisibility(View.VISIBLE);
            noReceipt.setVisibility(View.GONE);
            GlideApp.with(context)
                .load(receiptUrl)
                .error(R.drawable.ic_no_recipt)
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        loading.setVisibility(View.GONE);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        loading.setVisibility(View.GONE);
                        return false;
                    }
                })
                .into(receipt);
        }

        return alertDialog;
    }

    public static AlertDialog show(Context context, File receiptImage) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setCancelable(true);

        View dialogView = LayoutInflater.from(context).inflate(R.layout.view_receipt, null);
        builder.setView(dialogView);
        dialogView.setPadding(0, 0, 0, 0);

        PhotoView receipt = dialogView.findViewById(R.id.receipt);
        View loading = dialogView.findViewById(R.id.loading);
        View noReceipt = dialogView.findViewById(R.id.noReceipt);

        receipt.setVisibility(View.GONE);
        noReceipt.setVisibility(View.VISIBLE);

        AlertDialog alertDialog = builder.create();
        alertDialog.show();

        if (receiptImage != null && receiptImage.exists()) {
            receipt.setVisibility(View.VISIBLE);
            noReceipt.setVisibility(View.GONE);
            GlideApp.with(context)
                .load(receiptImage)
                .error(R.drawable.ic_receipt)
                .into(receipt);
        }

        return alertDialog;
    }

    private ReceiptDialog() {
    }
}
