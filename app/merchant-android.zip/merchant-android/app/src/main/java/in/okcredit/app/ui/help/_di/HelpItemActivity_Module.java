package in.okcredit.app.ui.help._di;

import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import in.okcredit._di.PresenterParam;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit.app.ui.help.item.HelpItemActivity;
import in.okcredit.app.ui.help.item.HelpItemPresenter;
import in.okcredit.app.ui.help.item.ItemContract;
import in.okcredit.app.ui.help.section.HelpSectionActivity;
import in.okcredit.domain.help.HelpItem;

@Module
public abstract class HelpItemActivity_Module {
    @Provides
    @ActivityScope
    @PresenterParam("help_item")
    public static HelpItem helpItem(HelpItemActivity activity) {
        return (HelpItem) activity.getIntent().getSerializableExtra(HelpItemActivity
            .EXTRA_HELP_ITEM);
    }

    @Provides
    @ActivityScope
    @PresenterParam("help_section_id")
    public static String helpSectionId(HelpItemActivity activity) {
        return activity.getIntent().getStringExtra(HelpItemActivity
            .EXTRA_HELP_SECTION_ID);
    }

    @Provides
    @ActivityScope
    @PresenterParam("help_section_item_id")
    public static String helpSubSectionId(HelpItemActivity activity) {
        return activity.getIntent().getStringExtra(HelpItemActivity
            .EXTRA_HELP_SECTION_ITEM_ID);
    }

    @Binds
    @ActivityScope
    public abstract ItemContract.Presenter presenter(HelpItemPresenter presenter);
}
