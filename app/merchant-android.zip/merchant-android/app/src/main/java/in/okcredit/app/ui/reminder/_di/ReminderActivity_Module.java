package in.okcredit.app.ui.reminder._di;

import dagger.Binds;
import dagger.Module;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit.app.ui.reminder.ReminderContract;
import in.okcredit.app.ui.reminder.ReminderPresenter;

@Module
public abstract class ReminderActivity_Module {
    @Binds
    @ActivityScope
    public abstract ReminderContract.Presenter presenter(ReminderPresenter presenter);
}
