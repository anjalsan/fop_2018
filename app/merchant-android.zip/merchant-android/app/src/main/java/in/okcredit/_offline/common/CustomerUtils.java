package in.okcredit._offline.common;

public class CustomerUtils {
    public static boolean isDescriptionEqual(String d1, String d2) {
        if (d1 == null || d2 == null)
            return false;
        return d1.toLowerCase().equals(d2.toLowerCase());
    }
}
