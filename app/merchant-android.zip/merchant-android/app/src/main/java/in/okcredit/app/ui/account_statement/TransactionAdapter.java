package in.okcredit.app.ui.account_statement;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.StrikethroughSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.R;
import in.okcredit._offline.model.Transaction;
import in.okcredit._offline.model.TransactionWrapper;
import in.okcredit.app.ui._utils.CurrencyUtil;
import in.okcredit.util.DateTimeUtils;

public class TransactionAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int TYPE_SUMMARY = 0;
    private static final int TYPE_TX = 1;

    Context context;
    TxSelectionListener listener;
    List<TransactionWrapper> transactions;
    float netBalance;
    int count;

    public TransactionAdapter(Context context) {
        this.context = context;
        transactions = new ArrayList<>();
    }

    public void refreshData(List<TransactionWrapper> transactions) {
        Collections.sort(transactions, new TransactionWrapperComparator());
        this.transactions = transactions;
        count = 0;
        netBalance = 0.0f;
        for (TransactionWrapper transaction : transactions) {
            Transaction tx = transaction.getTransaction();
            switch (tx.getType()) {
                case Transaction.CREDIT:
                    if (!tx.isDeleted()) {
                        netBalance -= tx.getAmount();
                    }
                    break;

                case Transaction.PAYMENT:
                    if (!tx.isDeleted()) {
                        netBalance += tx.getAmount();
                    }
                    break;

                case Transaction.RETURN:
                    if (!tx.isDeleted()) {
                        netBalance += tx.getAmount();
                    }
                    break;
            }
            count++;
        }
        notifyDataSetChanged();
    }

    public void setSelectionListener(TxSelectionListener listener) {
        this.listener = listener;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == TYPE_SUMMARY) {
            View view = LayoutInflater.from(context)
                                      .inflate(R.layout.item_account_statement_summary, parent, false);
            return new SummaryViewHolder(view);
        } else {
            View view = LayoutInflater.from(context)
                                      .inflate(R.layout.item_tx, parent, false);
            return new TransactionViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        int type = getItemViewType(position);
        if (type == TYPE_SUMMARY)
            ((SummaryViewHolder) holder).render(netBalance, count);
        else
            ((TransactionViewHolder) holder).render(transactions.get(position - 1));
    }

    @Override
    public int getItemCount() {
        if (transactions.isEmpty())
            return 0;
        else
            return transactions.size() + 1;
    }

    @Override
    public int getItemViewType(int position) {
        if (position == 0)
            return TYPE_SUMMARY;
        else
            return TYPE_TX;
    }

    public interface TxSelectionListener {
        void onSelected(Transaction transaction);
    }

    class SummaryViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.balance)
        TextView balance;

        @BindView(R.id.count)
        TextView count;

        public SummaryViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }

        public void render(float netBalance, int txCount) {
            CurrencyUtil.render(netBalance, balance);
            count.setText(String.valueOf(txCount));
        }
    }

    class TransactionViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.icon)
        ImageView icon;

        @BindView(R.id.title)
        TextView customerName;

        @BindView(R.id.subtitle)
        TextView date;

        @BindView(R.id.amount)
        TextView amount;

        @BindView(R.id.receiptAvailable)
        View receiptAvailable;

        @BindView(R.id.layoutContainer)
        LinearLayout layoutContainer;

        @BindView(R.id.titleContainer)
        LinearLayout titleContainer;

        @BindView(R.id.sync)
        ImageView sync;

        public TransactionViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }

        void render(TransactionWrapper tx) {
            itemView.setOnClickListener(null);
            Transaction transaction = tx.getTransaction();
            receiptAvailable.setVisibility(View.GONE);
            switch (transaction.getType()) {
                case Transaction.CREDIT:
                    icon.setColorFilter(ContextCompat.getColor(context, R.color.tx_credit));
                    icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_credit));
                    itemView.setOnClickListener(v ->
                    {
                        if (listener != null)
                            listener.onSelected(transaction);
                    });
                    if (TextUtils.isEmpty(transaction.getReceiptUrl()))
                        receiptAvailable.setVisibility(View.GONE);
                    else
                        receiptAvailable.setVisibility(View.VISIBLE);

                    break;

                case Transaction.PAYMENT:
                    icon.setColorFilter(ContextCompat.getColor(context, R.color.tx_payment));
                    icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_payment));
                    itemView.setOnClickListener(v ->
                    {
                        if (listener != null)
                            listener.onSelected(transaction);
                    });
                    if (TextUtils.isEmpty(transaction.getReceiptUrl()))
                        receiptAvailable.setVisibility(View.GONE);
                    else
                        receiptAvailable.setVisibility(View.VISIBLE);
                    break;

                case Transaction.RETURN:
                    icon.setColorFilter(ContextCompat.getColor(context, R.color.tx_return));
                    icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_return));
                    itemView.setOnClickListener(v ->
                    {
                        if (listener != null)
                            listener.onSelected(transaction);
                    });
                    if (TextUtils.isEmpty(transaction.getReceiptUrl()))
                        receiptAvailable.setVisibility(View.GONE);
                    else
                        receiptAvailable.setVisibility(View.VISIBLE);
                    break;
            }

            date.setText(DateTimeUtils.format(transaction.getCreatedAt()));
            date.setTextColor(ContextCompat.getColor(context, R.color.text_subtitle));
            amount.setText(CurrencyUtil.format(transaction.getAmount()));

            if (tx.isActive()) {
                customerName.setText(tx.getCustomerName());

                if (transaction.isDeleted()) {
                    icon.setColorFilter(ContextCompat.getColor(context, R.color.grey400));

                    if (transaction.getType() == Transaction.CREDIT) {
                        date.setText(context.getString(R.string.credit_cancelled));
                    } else if (transaction.getType() == Transaction.PAYMENT) {
                        date.setText(context.getString(R.string.payment_cancelled));
                    }

                    date.setTextColor(ContextCompat.getColor(context, R.color.tx_credit));
                    strikeAllTextViews(context, layoutContainer, titleContainer);
                }
            } else {

                date.setText(context.getString(R.string.cst_deleted));
                date.setTextColor(ContextCompat.getColor(context, R.color.tx_credit));

                strikeOffTextView(customerName, tx.getCustomerName());

                if (tx.getTransaction().isDeleted()) {
                    strikeOffTextView(amount, CurrencyUtil.format(transaction
                        .getAmount()));
                    icon.setColorFilter(ContextCompat.getColor(context, R.color.grey400));
                }
            }

            sync.setVisibility(View.GONE);
        }

        private void strikeAllTextViews(Context context, ViewGroup primary, ViewGroup secondary) {
            ArrayList<TextView> textViews = new ArrayList<TextView>();

            for (int i = 0; i < primary.getChildCount(); i++)
                if (primary.getChildAt(i) instanceof TextView)
                    textViews.add((TextView) primary.getChildAt(i));

            for (int i = 0; i < secondary.getChildCount(); i++) {
                if (secondary.getChildAt(i) instanceof TextView)
                    textViews.add((TextView) secondary.getChildAt(i));
            }

            for (TextView textView : textViews) {
                if (textView.getId() != R.id.subtitle) {
                    strikeOffTextView(textView, textView.getText().toString());
                }
            }
        }

        private void strikeOffTextView(TextView textView, String text) {
            if (text == null) {
                return;
            }

            SpannableString spannable = new SpannableString(text);
            spannable.setSpan(new StrikethroughSpan(), 0, text.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
            textView.setText(spannable);
        }
    }
}
