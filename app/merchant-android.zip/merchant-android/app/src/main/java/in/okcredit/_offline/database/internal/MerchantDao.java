package in.okcredit._offline.database.internal;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Transaction;

import io.reactivex.Flowable;

@Dao
public abstract class MerchantDao {
    @Query("SELECT * FROM merchant LIMIT 1")
    public abstract Flowable<DbEntities.Merchant> getActiveMerchant();

    @Query("DELETE FROM merchant")
    public abstract void deleteAllMerchants();

    @Insert
    abstract void insertMerchant(DbEntities.Merchant merchant);

    @Transaction
    public void setActiveMerchant(DbEntities.Merchant merchant) {
        deleteAllMerchants();
        insertMerchant(merchant);
    }

    @Query("SELECT count(*) FROM merchantpreference WHERE merchantId = :merchantId AND `key` = :key")
    public abstract Flowable<Integer> isMerchantPreferenceAvailable(String merchantId, String key);

    @Query("SELECT value FROM merchantpreference WHERE merchantId = :merchantId and `key` = :key")
    public abstract Flowable<String> getMerchantPreference(String merchantId, String key);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public abstract void insertMerchantPreference(DbEntities.MerchantPreference merchantPreference);
}
