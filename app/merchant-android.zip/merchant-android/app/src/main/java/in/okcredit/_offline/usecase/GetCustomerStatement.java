package in.okcredit._offline.usecase;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.inject.Inject;

import in.okcredit._offline.common.CustomerTransactionComparator;
import in.okcredit._offline.database.TransactionRepo;
import in.okcredit._offline.model.Customer;
import in.okcredit._offline.model.CustomerStatement;
import in.okcredit._offline.model.Settlement;
import in.okcredit._offline.model.Transaction;
import io.reactivex.Observable;
import timber.log.Timber;

public final class GetCustomerStatement {
    private GetCustomer getCustomer;
    private TransactionRepo transactionRepo;

    @Inject
    public GetCustomerStatement(GetCustomer getCustomer, TransactionRepo transactionRepo) {
        this.getCustomer = getCustomer;
        this.transactionRepo = transactionRepo;
    }

    public Observable<CustomerStatement> execute(String customerId) {
        return Observable
            .combineLatest(
                getCustomer.execute(customerId)
                           .doOnNext(x -> Timber.i("got customer: %s", x.getId())),
                transactionRepo.listTransactions(customerId)
                               .doOnNext(x -> Timber.i("got txns: %d", x.size())),
                (customer, transactions) -> createCustomerStatement(customer, transactions)
            );
    }

    private CustomerStatement createCustomerStatement(Customer customer, List<Transaction> allTransactions) {
        if (allTransactions.size() == 1 && allTransactions.get(0).isOnboarding()) {
            return new CustomerStatement(customer, allTransactions, null, new ArrayList<>());
        }

        Settlement settlement = null;
        Transaction settlementTx = null;

        for (Transaction transaction : allTransactions) {
            if (transaction.getType() == Transaction.PAYMENT) {
                if (settlementTx == null || settlementTx.getCreatedAt().isBefore
                    (transaction.getCreatedAt())) {

                    if (!transaction.isDeleted()) {
                        settlementTx = transaction;
                    }
                }
            }
        }

        List<Transaction> transactions = new ArrayList<>();
        List<Transaction> settledTransactions = new ArrayList<>();

        if (settlementTx == null) {
            // No settlement till now; all transactions are unsettled transactions
            transactions.addAll(allTransactions);
        } else {
            // balance_after_settlement = balance_before_settlement + payment
            // current_balance = balance_before_settlement + payment + balanceDelta

            float balanceDelta = 0.0f;
            for (Transaction transaction : allTransactions) {
                if (!transaction.equals(settlementTx)) {
                    if (transaction.getCreatedAt().isAfter(settlementTx.getCreatedAt
                        ())) {
                        transactions.add(transaction);
                        switch (transaction.getType()) {
                            case Transaction.CREDIT:
                                if (!transaction.isDeleted()) {
                                    balanceDelta -= transaction.getAmount();
                                }
                                break;
                            case Transaction.PAYMENT:
                                if (!transaction.isDeleted()) {
                                    balanceDelta += transaction.getAmount();
                                }
                                break;
                            case Transaction.RETURN:
                                balanceDelta += transaction.getAmount();
                                break;
                        }
                    } else {
                        settledTransactions.add(transaction);
                    }
                }
            }

            float balanceBefore = customer.getBalance() - (settlementTx.getAmount() +
                balanceDelta);
            float balanceAfter = balanceBefore + settlementTx.getAmount();
            settlement = new Settlement(settlementTx, balanceBefore, balanceAfter);
        }

        Collections.sort(transactions, new CustomerTransactionComparator());
        return new CustomerStatement(customer, transactions, settlement, settledTransactions);
    }
}
