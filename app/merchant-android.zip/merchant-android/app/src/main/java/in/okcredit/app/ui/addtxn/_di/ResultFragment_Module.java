package in.okcredit.app.ui.addtxn._di;

import dagger.Binds;
import dagger.Module;
import in.okcredit._di.scope.FragmentScope;
import in.okcredit.app.ui.addtxn.result.ResultContract;
import in.okcredit.app.ui.addtxn.result.ResultPresenter;

@Module
public abstract class ResultFragment_Module {
    @Binds
    @FragmentScope
    public abstract ResultContract.Presenter presenter(ResultPresenter presenter);
}
