package in.okcredit.app.ui._utils;

import android.content.Context;

import java.io.File;

import timber.log.Timber;

public class FileUtils {
    public static final String RECEIPT_DIR = "receipts";

    private FileUtils() {
    }

    public static File getReceiptDir(Context context) {
        File storageDir = new File(context.getFilesDir(), RECEIPT_DIR);
        Timber.i("Usable space (receipt dir): %dB", storageDir.getUsableSpace());
        storageDir.mkdirs();
        return storageDir;
    }
}
