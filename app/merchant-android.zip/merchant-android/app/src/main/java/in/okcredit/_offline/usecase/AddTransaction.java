package in.okcredit._offline.usecase;

import org.joda.time.DateTime;

import java.io.File;
import java.util.UUID;

import javax.inject.Inject;

import in.okcredit.Constants;
import in.okcredit._offline.database.CustomerRepo;
import in.okcredit._offline.database.TransactionRepo;
import in.okcredit._offline.model.Transaction;
import in.okcredit.domain.auth.AuthDomain;
import io.reactivex.Completable;
import io.reactivex.Single;

public final class AddTransaction {
    private AuthDomain authDomain;
    private TransactionRepo transactionRepo;
    private SyncCustomer syncCustomer;
    private UploadFile uploadFile;
    private CustomerRepo customerRepo;
    private SafelySaveCustomer safelySaveCustomer;


    @Inject
    public AddTransaction(AuthDomain authDomain,
                          TransactionRepo transactionRepo,
                          SyncCustomer syncCustomer,
                          UploadFile uploadFile,
                          CustomerRepo customerRepo,
                          SafelySaveCustomer safelySaveCustomer) {
        this.authDomain = authDomain;
        this.transactionRepo = transactionRepo;
        this.syncCustomer = syncCustomer;
        this.uploadFile = uploadFile;
        this.customerRepo = customerRepo;
        this.safelySaveCustomer = safelySaveCustomer;
    }

    public Single<Transaction> execute(
        int type,
        String customerId,
        float amount,
        File receipt,
        String note,
        boolean isOnboarding,
        String password) {

        Completable authCheck = Completable.complete();
        if (type == Transaction.PAYMENT) {
            authCheck = authDomain.verifyPassword(password);
        }

        Completable uploadReceiptTask = Completable.complete();
        String receiptUrl = null;
        if (receipt != null && receipt.exists()) {
            receiptUrl = Constants.AWS_RECEIPT_BASE_URL + "/" +
                UUID.randomUUID().toString() + ".jpg";

            uploadReceiptTask = uploadFile.schedule(receiptUrl, receipt.getAbsolutePath());
        }

        // id and timestamo
        String requestId = UUID.randomUUID().toString();
        DateTime timestamp = DateTime.now();

        return authCheck
            .andThen(uploadReceiptTask)
            .andThen(createTransaction(customerId, requestId, type, amount, receiptUrl, note, timestamp, isOnboarding))
            .flatMap(transaction ->
                transactionRepo.putTransaction(transaction)
                               .andThen(updateCustomerAccountSummary(transaction.getCustomerId()))
                               .andThen(syncCustomer.schedule(transaction.getCustomerId()))
                               .andThen(Single.just(transaction))
            );
    }

    private Single<Transaction> createTransaction(String customerId,
                                                  String requestId,
                                                  int type,
                                                  float amount,
                                                  String receiptUrl,
                                                  String note,
                                                  DateTime timestamp,
                                                  boolean isOnboarding) {
        Transaction localCopy = new Transaction(
            requestId,
            type,
            customerId,
            amount,
            receiptUrl,
            note,
            timestamp,
            isOnboarding,
            false,
            null,
            true
        );
        return Single.just(localCopy);

//        return server.addTransaction(
//            customerId,
//            requestId,
//            type,
//            amount,
//            receiptUrl,
//            note,
//            timestamp,
//            isOnboarding
//        );
    }

    private Completable updateCustomerAccountSummary(String customerId) {
        return customerRepo.getCustomer(customerId)
                           .firstOrError()
                           .flatMapCompletable(customer -> safelySaveCustomer.execute(customer));
    }
}
