package in.okcredit.app.ui.home._di;

import dagger.Binds;
import dagger.Module;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit.app.ui.home.HomeScreenContract;
import in.okcredit.app.ui.home.HomeScreenPresenter;

@Module
public abstract class HomeActivity_Module {
    @Binds
    @ActivityScope
    public abstract HomeScreenContract.Presenter presenter(HomeScreenPresenter presenter);
}
