package in.okcredit._offline.usecase;


import android.util.Pair;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import in.okcredit._offline.model.Customer;
import in.okcredit._offline.server.Server;
import io.reactivex.Completable;
import io.reactivex.Single;

public final class BulkAddCustomers {
    private Server server;
    private SafelySaveCustomer safelySaveCustomer;

    @Inject
    public BulkAddCustomers(Server server, SafelySaveCustomer safelySaveCustomer) {
        this.server = server;
        this.safelySaveCustomer = safelySaveCustomer;
    }

    // contacts => (mobile, desc)
    public Single<Map<String, Throwable>> execute(List<Pair<String, String>> contacts, boolean reactivate) {
        return server.bulkAddCustomers(contacts, reactivate)
                     .flatMap(result -> saveCustomers(result.first).andThen(Single.just(result.second)));
    }

    private Completable saveCustomers(List<Customer> customers) {
        List<Completable> saveCustomers = new ArrayList<>();
        for (Customer customer : customers) {
            saveCustomers.add(safelySaveCustomer.execute(customer));
        }
        return Completable.merge(saveCustomers);
    }
}
