package in.okcredit.app.ui.rating.select_rating;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.Toast;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import dagger.android.AndroidInjection;
import dagger.android.support.AndroidSupportInjection;
import in.okcredit.R;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui._utils.KeyboardUtil;
import in.okcredit.app.ui.rating.RatingActivity;

public class SelectRatingFragment extends Fragment implements SelectRatingContract.View {

    public static SelectRatingFragment newInstance() {
        Bundle args = new Bundle();
        SelectRatingFragment fragment = new SelectRatingFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @BindView(R.id.rating_bar)
    RatingBar ratingBar;

    @Inject
    RatingActivity activity;

    @Inject
    SelectRatingContract.Presenter presenter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle
        savedInstanceState) {
        View view = inflater.inflate(R.layout.select_rating_fragment, container, false);
        ButterKnife.bind(this, view);

        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                if (rating == 0) {
                    ratingBar.setRating(1);
                    presenter.setRating(1);
                } else {
                    presenter.setRating((int) rating);
                }

                Analytics.track(
                    AnalyticsEvents.RATING_SELECT_RATING_SCREEN,
                    EventProperties
                        .create()
                        .with("rating", String.valueOf(ratingBar.getRating()))
                );

            }
        });

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        AndroidSupportInjection.inject(this);

    }

    @Override
    public void onResume() {
        super.onResume();
        presenter.attachView(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        KeyboardUtil.hideKeyboard(this);
        presenter.detachView();
    }

    /****************************************************************
     MVP methods
     ****************************************************************/

    @Override
    public void showError() {
        Toast.makeText(activity, R.string.err_default, Toast.LENGTH_SHORT).show();
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "select rating page")
                .with("type", "server error")
        );
    }

    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(activity, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
            }
        });
    }

    @Override
    public void showPlaystoreRatingPage() {
        activity.showPlaystoreRatingFragment(5);
    }

    @Override
    public void showFeedbackAndRatingPage(int rating) {
        activity.showFeedbackRatingFragment(rating);
    }

    /****************************************************************
     Unexpected
     ****************************************************************/
}
