package in.okcredit.app.ui.help.item;

import javax.inject.Inject;

import in.okcredit.LocaleManager;
import in.okcredit._di.PresenterParam;
import in.okcredit._di.UiThread;
import in.okcredit.app.ui._base_v2.BasePresenter;
import in.okcredit.domain.help.HelpItem;
import in.okcredit.domain.help.HelpService;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;

public class HelpItemPresenter extends BasePresenter<ItemContract.View> implements ItemContract
    .Presenter {

    private final String helpSectionId;
    private final String helpSubSectionId;
    private HelpService helpService;
    private HelpItem helpItem;

    @Inject
    public HelpItemPresenter(@UiThread Scheduler uiScheduler,
                             @PresenterParam("help_item") HelpItem helpItem,
                             @PresenterParam("help_section_id") String helpSectionId,
                             @PresenterParam("help_section_item_id") String helpSubSectionId,
                             HelpService helpService) {
        super(uiScheduler);
        this.helpItem = helpItem;
        this.helpService = helpService;
        this.helpSectionId = helpSectionId;
        this.helpSubSectionId = helpSubSectionId;
    }

    @Override
    protected void loadData() {
        if (helpItem != null && helpItem.getId() != null){
            ifAttached(view -> view.setScreenshots(helpItem.getId(), helpItem.getScreenshots()));
            ifAttached(view -> view.setActionBarTitle(helpItem.getTitle()));
            ifAttached(view -> view.setAudio(helpItem.getAudioUrl()));
        } else if(helpSectionId != null && helpSubSectionId != null){
            ifAttached(view -> view.showLoading());
            String language = LocaleManager.getLanguage();
            addTask(helpService
                .getHelpSubSection(language, helpSectionId, helpSubSectionId)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    helpItem ->
                    {
                        if (helpItem.getId() != null) {
                            ifAttached(view -> view.setScreenshots(helpItem.getId(), helpItem.getScreenshots()));
                            ifAttached(view -> view.setActionBarTitle(helpItem.getTitle()));
                            ifAttached(view -> view.setAudio(helpItem.getAudioUrl()));
                            ifAttached(view -> view.hideLoading());
                        } else {
                            ifAttached(view -> view.showError());
                        }
                    },
                    throwable ->
                    {
                        ifAttached(view -> view.hideLoading());
                        if (isAuthenticationIssue(throwable))
                            ifAttached(view -> view.gotoLogin());
                        else if (isInternetIssue(throwable))
                            ifAttached(view -> view.showNoInternetMessage());
                        else
                            ifAttached(view -> view.showError());
                    }
                ));
        }
    }

    @Override
    public void onInternetRestored() {
        loadData();
    }
}
