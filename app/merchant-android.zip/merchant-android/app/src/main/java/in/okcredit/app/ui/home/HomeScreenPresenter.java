package in.okcredit.app.ui.home;

import android.util.Log;
import android.util.Pair;
import android.widget.Toast;

import java.util.Collections;
import java.util.List;

import javax.inject.Inject;

import in.okcredit.LifecycleState;
import in.okcredit.LocaleManager;
import in.okcredit._offline._hack.LifecycleManager;
import in.okcredit._offline.common.CustomerComparator2;
import in.okcredit._offline.error.CustomerErrors;
import in.okcredit._offline.model.Customer;
import in.okcredit._offline.model.InAppNotification;
import in.okcredit._offline.model.MerchantPreference;
import in.okcredit._offline.server.NetworkHelper;
import in.okcredit._offline.usecase.AddCustomer;
import in.okcredit._offline.usecase.CheckNetworkStatus;
import in.okcredit._offline.usecase.GetActiveCustomers;
import in.okcredit._offline.usecase.GetActiveMerchant;
import in.okcredit._offline.usecase.GetInAppNotification;
import in.okcredit._offline.usecase.MarkInAppNotificationSeen;
import in.okcredit._offline.usecase.RefreshCustomers;
import in.okcredit._offline.usecase.ResumeAuthScope;
import in.okcredit._offline.usecase.SetMerchantPreference;
import in.okcredit._offline.usecase.Signout;
import in.okcredit._offline.usecase.SyncDirtyTransactions;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base.ErrorHelper;
import in.okcredit.domain.auth.AuthErrors;
import in.okcredit.service.phonebook.ContactModel;
import in.okcredit.service.phonebook.GetContactsUseCase;
import in.okcredit.util.ShareHelper;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.observers.DisposableObserver;
import io.reactivex.subjects.BehaviorSubject;
import timber.log.Timber;

public class HomeScreenPresenter implements HomeScreenContract.Presenter {
    private HomeScreenContract.View view;

    private ShareHelper shareHelper;

    // use cases
    private GetActiveCustomers getActiveCustomers;
    private GetActiveMerchant getActiveMerchant;
    private SetMerchantPreference setMerchantPreference;
    private GetInAppNotification getInAppNotification;
    private MarkInAppNotificationSeen markInAppNotificationSeen;
    private LifecycleManager lifecycleManager;
    private Signout signout;
    private ResumeAuthScope resumeAuthScope;
    private CheckNetworkStatus checkNetworkStatus;
    private RefreshCustomers refreshCustomers;
    private SyncDirtyTransactions syncDirtyTransactions;
    private AddCustomer addCustomer;
    private GetContactsUseCase getContactsUseCase;

    private CompositeDisposable tasks;
    private DisposableObserver<Float> progressDisposible = null;
    private BehaviorSubject<Integer> sortType;
    private boolean isAttachViewLoadingDone;
    private Integer lifecycle = LifecycleState.NORMAL_FLOW;

    @Inject
    public HomeScreenPresenter(
        ShareHelper shareHelper,
        GetActiveCustomers getActiveCustomers,
        GetActiveMerchant getActiveMerchant,
        SetMerchantPreference setMerchantPreference,
        GetInAppNotification getInAppNotification,
        MarkInAppNotificationSeen markInAppNotificationSeen,
        LifecycleManager lifecycleManager,
        Signout signout,
        ResumeAuthScope resumeAuthScope,
        CheckNetworkStatus checkNetworkStatus,
        RefreshCustomers refreshCustomers,
        SyncDirtyTransactions syncDirtyTransactions,
        AddCustomer addCustomer,
        GetContactsUseCase getContactsUseCase
    ) {
        tasks = new CompositeDisposable();
        sortType = BehaviorSubject.createDefault(HomeScreenContract.SORT_TYPE_RECENT_ACTIVITY);
        this.shareHelper = shareHelper;
        this.isAttachViewLoadingDone = false;
        this.getActiveCustomers = getActiveCustomers;
        this.getActiveMerchant = getActiveMerchant;
        this.setMerchantPreference = setMerchantPreference;
        this.getInAppNotification = getInAppNotification;
        this.markInAppNotificationSeen = markInAppNotificationSeen;
        this.lifecycleManager = lifecycleManager;
        this.signout = signout;
        this.resumeAuthScope = resumeAuthScope;
        this.checkNetworkStatus = checkNetworkStatus;
        this.refreshCustomers = refreshCustomers;
        this.syncDirtyTransactions = syncDirtyTransactions;
        this.addCustomer = addCustomer;
        this.getContactsUseCase = getContactsUseCase;
    }

    @Override
    public void logout() {
        tasks.add(
            signout
                .execute(null)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    () -> {
                        if (view == null) {
                            return;
                        }
                        view.onLogoutSuccess();
                    },
                    throwable -> {
                        if (view == null) {
                            return;
                        }

                        if (NetworkHelper.isNetworkError(throwable)) {
                            view.onNetworkFailure();
                        } else {
                            view.onError("logout");
                        }
                    }
                )
        );
    }

    @Override
    public void refresh() {
        if (view == null) {
            return;
        }

        view.showLoading();
        tasks.add(
            syncDirtyTransactions
                .execute()
                .andThen(refreshCustomers.execute())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    () -> {
                        view.hideLoading();
                        if (lifecycle == LifecycleState.TRIAL_ADD_CUSTOMER) {
                            view.displayNoAndOneCustomerMessage(true);
                        }
                    },
                    throwable -> {
                        if (view != null) {
                            view.hideLoading();
                            ErrorHelper.handleDefaults(view, throwable, "refresh");
                        }
                    }
                )
        );
    }

    @Override
    public void onReminderNotificationClicked() {
        markInAppNotificationSeen.execute(InAppNotification.TYPE_REMINDER_TO_BE_SENT);
//        serverDomain.markReminderNotificationViewed();
    }

    @Override
    public void onShareNotificationClicked() {
        markInAppNotificationSeen.execute(InAppNotification.TYPE_SHARE);
//        serverDomain.markShareNotificationViewed();
    }

    @Override
    public void onAppLockNotificationClicked() {
        markInAppNotificationSeen.execute(InAppNotification.TYPE_APP_LOCK);
//        serverDomain.markAppLockNotificationViewed();
    }

    @Override
    public void onUpdateNotificationDismissed() {
        markInAppNotificationSeen.execute(InAppNotification.TYPE_UPDATE);
//        serverDomain.markUpdateNotificationViewed(version);
    }

    @Override
    public void onRatingNotificationClicked() {
        markInAppNotificationSeen.execute(InAppNotification.TYPE_RATING);
//        serverDomain.markShareNotificationViewed();
    }

    @Override
    public void proceedName(String name) {
        if (view == null) {
            return;
        }
        if (name.isEmpty() || name.length() > 30) {
            view.shakeNameContainer();
        } else {
            view.setAddCustomerState(HomeActivity.ADD_CUSTOMER_STATE_PHONE_TEXT);
        }
    }

    @Override
    public void proceedPhone(String phone, String name, String profileImage, String email, boolean isFromContact) {
        if (view == null) {
            return;
        }

        String analyticsEvent = isFromContact ? AnalyticsEvents.ADD_CUSTOMER_ADD_CLICKED : AnalyticsEvents.ADD_CUSTOMER_MOBILE_ENTERED;
        boolean has_mobile = true;
        if (phone == null) {
            phone = "";
        }
        if (phone.length() == 0) {
            has_mobile = false;
        }
        if (phone.length() > 0 && phone.length() != 10) {
            view.shakePhoneContainer();
            Analytics.track(
                analyticsEvent,
                EventProperties
                    .create()
                    .with("has_mobile", has_mobile)
                    .with("error", "length error")
            );
        } else {
            view.showAddCustomerLoader();
            boolean finalHas_mobile = has_mobile;
            tasks.add(addCustomer
                .execute(name, phone, profileImage, email)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    customer -> {
                        if (view != null) {
                            view.hideAddCustomerLoader();
                            view.addCustomerSuccess(customer, isFromContact);

                            Analytics.track(
                                analyticsEvent,
                                EventProperties
                                    .create()
                                    .with("has_mobile", finalHas_mobile)
                                    .with("error", "false")
                            );
                        }
                    },
                    e -> {
                        view.hideAddCustomerLoader();

                        if (e instanceof CustomerErrors.MobileConflict) {
                            view.onMobileConflict(((CustomerErrors.MobileConflict) e).getConflict());

                            Analytics.track(
                                analyticsEvent,
                                EventProperties
                                    .create()
                                    .with("has_mobile", finalHas_mobile)
                                    .with("error", "conflict existing")
                            );
                        } else if (e instanceof CustomerErrors.InvalidName) {
                            view.onInvalidName();

                            Analytics.track(
                                analyticsEvent,
                                EventProperties
                                    .create()
                                    .with("has_mobile", finalHas_mobile)
                                    .with("error", "conflict existing")
                            );
                        } else if ((e instanceof AuthErrors.Unauthenticated) || (e.getCause() instanceof AuthErrors.Unauthenticated)) {
                            view.onAuthenticationFailure();
                            Analytics.track(
                                analyticsEvent,
                                EventProperties
                                    .create()
                                    .with("has_mobile", finalHas_mobile)
                                    .with("error", "authentication failed")
                            );
                        } else if (NetworkHelper.isNetworkError(e)) {
                            view.onNetworkFailure();
                            Analytics.track(
                                analyticsEvent,
                                EventProperties
                                    .create()
                                    .with("has_mobile", finalHas_mobile)
                                    .with("error", "network issue")
                            );
                        } else {
                            if (e.getMessage() != null) {
                                Analytics.track(
                                    analyticsEvent,
                                    EventProperties
                                        .create()
                                        .with("has_mobile", finalHas_mobile)
                                        .with("error", e.getMessage())
                                );
                            } else {
                                Analytics.track(
                                    analyticsEvent,
                                    EventProperties
                                        .create()
                                        .with("has_mobile", finalHas_mobile)
                                        .with("error", "failed")
                                );
                            }

                            view.showError();
                        }
                    }
                ));
        }
    }

    @Override
    public void loadContacts() {
        if (view == null) {
            return;
        }
        Analytics.track(AnalyticsEvents.ADD_CUSTOMER_IMPORT_CONTACT);
        view.setContactsLoadingPercentage(0);

        if (progressDisposible != null && !progressDisposible.isDisposed()) {
            progressDisposible.dispose();
        }

        progressDisposible = getContactsUseCase
            .restartProgressObservable()
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeWith(new DisposableObserver<Float>() {
                @Override
                public void onNext(@NonNull Float progress) {
                    Analytics.track(AnalyticsEvents.ADD_CUSTOMER_IMPORT_CONTACT_SUCEESS);
                    view.setContactsLoadingPercentage((int) (progress * 100));
                    view.setContactsLoadingVisibility(true);
                    if (progress == 1) {
                        view.setContactsLoadingVisibility(false);
                        view.setContactsLoadingPercentage(0);
                    }
                }

                @Override
                public void onError(@NonNull Throwable throwable) {
                    Timber.e(throwable, "failed to get progress");
                }

                @Override
                public void onComplete() {
                }
            });

        Observable<List<ContactModel>> getContactsObservable =
            getContactsUseCase.refreshContactsObservable();

        Analytics.track(AnalyticsEvents.HOME_SCREEN_IMPORT_CONTACT_STARTED);
        tasks.add(
            getContactsObservable
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(contacts -> {
                    view.displayContacts(contacts);
                    Analytics.track(AnalyticsEvents.HOME_SCREEN_IMPORT_CONTACT_SUCCESS);
                }, throwable -> {
                    Analytics.track(AnalyticsEvents.HOME_SCREEN_IMPORT_CONTACT_FAILED);
                    if (throwable instanceof SecurityException) {
                        view.onClickImportContact();
                    } else {
                        Timber.d("Failed to load contact import page - " + throwable.getMessage());
                        view.setContactsLoadingPercentage(0);
                        view.showError();
                    }
                }));
    }

    @Override
    public void attachView(HomeScreenContract.View view) {
        this.view = view;

        if (!isAttachViewLoadingDone) {
            this.view.showLoading();
            isAttachViewLoadingDone = true;
        }

        tasks.add(
            getActiveMerchant
                .execute()
                .doOnNext(merchant -> {
                    try {
                        shareHelper.downloadShareResource(merchant.getId());
                    } catch (Exception e) {
                        Analytics.track(AnalyticsEvents.ERROR, EventProperties
                            .create()
                            .with("screen", "app start")
                            .with("type", "Download failed share resource"));
                    }
                })
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(merchant -> {
                    if (view != null) {
                        view.displayMerchantDetails(merchant);
                    }
                })
        );

        tasks.add(
            Observable
                .combineLatest(
                    getCustomers(),
                    lifecycleManager.getLifecycleState(),
                    (customers, lifecycleState) -> new Pair<>(customers, lifecycleState)
                )
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    data -> {
                        if (view == null) {
                            return;
                        }

                        this.lifecycle = data.second;
                        view.hideLoading();
                        List<Customer> customers = data.first;
                        if (customers.isEmpty()) {
                            view.displayNoAndOneCustomerMessage(true);
                        } else {
                            view.displayCustomers(customers, data.second);
                        }
                    },
                    throwable -> {
                        if (view != null) {
                            view.hideLoading();
                            ErrorHelper.handleDefaults(view, throwable, "refresh");
                        }
                    }
                )
        );


        tasks.add(
            getInAppNotification
                .execute()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(inAppNotification -> {
                    if (view != null) {
                        view.showNotificaton(inAppNotification);
                    }
                }, throwable -> {
                    Analytics.track(
                        AnalyticsEvents.ERROR,
                        EventProperties
                            .create()
                            .with("screen", "home")
                            .with("type", "InAppNotification error")
                    );
                })
        );

        // check if merchant language is synced
        boolean isMerchantLangSynced = LocaleManager.isMerchantLanguageSynced();
        if (!isMerchantLangSynced) {
            tasks.add(
                setMerchantPreference
                    .execute(MerchantPreference.LANGUAGE, LocaleManager.getLanguage())
                    .subscribe(
                        () -> LocaleManager.markMerchantLangAsSynced(true),
                        throwable -> {
                        }
                    )
            );
        }

        // network status
        tasks.add(
            checkNetworkStatus
                .execute()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    networkStatus -> {
                        if (view == null) {
                            return;
                        }

                        if (networkStatus == CheckNetworkStatus.STATUS_CONNECTED) {
                            view.setNetworkStatus(true);
                        } else {
                            view.setNetworkStatus(false);
                        }
                    }
                )
        );

        tasks.add(
            getContactsUseCase.getContactsFromCache()
                              .observeOn(AndroidSchedulers.mainThread())
                              .toObservable()
                              .map(GetContactsUseCase::map)
                              .subscribe(contacts -> {
                                  if (contacts != null && contacts.size() > 0) {
                                      view.displayContacts(contacts);
                                      view.setContactsLoadingVisibility(false);
                                  } else {
                                      view.setContactsLoadingVisibility(true);
                                  }
                              }, throwable -> {
                                  Timber.d("Failed to load contact import page - " + throwable.getMessage());
                                  view.setContactsLoadingVisibility(true);
                                  view.setContactsLoadingPercentage(0);
                                  view.showError();
                              }));
    }

    @Override
    public void detachView() {
        if (progressDisposible != null && !progressDisposible.isDisposed()) {
            if (view != null) {
                view.setContactsLoadingPercentage(0);
            }
            progressDisposible.dispose();
        }
        view = null;
        tasks.clear();
    }

    @Override
    public void setSortType(int type) {
        sortType.onNext(type);
    }

    private Observable<Integer> getSortType() {
        return sortType;
    }

    private Observable<List<Customer>> getCustomers() {
        return Observable
            .combineLatest(
                resumeAuthScope.execute()
                               .andThen(getActiveCustomers.execute()),
                getSortType(),
                (customers, sort) -> {
                    switch (sort) {
                        case HomeScreenContract.SORT_TYPE_ABS_BALANCE:
                            Collections.sort(customers, new CustomerComparator2.AbsoluteBalance());
                            break;

                        case HomeScreenContract.SORT_TYPE_RECENT_ACTIVITY:
                            Collections.sort(customers, new CustomerComparator2.RecentActivity());
                            break;

                        case HomeScreenContract.SORT_TYPE_LAST_PAYMENT:
                            Collections.sort(customers, new CustomerComparator2.CustomerChainedComparator(
                                new CustomerComparator2.Balance(),
                                new CustomerComparator2.LastPayment()));
                            break;

                        default:
                            Collections.sort(customers, new CustomerComparator2.Name());
                            break;
                    }
                    return customers;
                });
    }
}
