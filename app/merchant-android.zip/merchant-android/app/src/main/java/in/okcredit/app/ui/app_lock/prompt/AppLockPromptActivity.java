package in.okcredit.app.ui.app_lock.prompt;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.andrognito.patternlockview.PatternLockView;
import com.andrognito.patternlockview.listener.PatternLockViewListener;
import com.andrognito.patternlockview.utils.PatternLockUtils;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.AppLockManager;
import in.okcredit.R;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui.app_lock.forgot.ForgotAppLockActivity;

public class AppLockPromptActivity extends BaseActivity {
    public static Intent startingIntent(Context context) {
        return new Intent(context, AppLockPromptActivity.class);
    }

    @BindView(R.id.subtitle)
    TextView subtitle;

    @BindView(R.id.pattern_lock_view)
    PatternLockView patternLock;

    @BindView(R.id.forgot)
    Button forgot;

    /* Lifecycle methods */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Analytics.track(AnalyticsEvents.APP_LOCK_PROMPT_SCREEN);

        setContentView(R.layout.screen_app_lock_prompt);
        ButterKnife.bind(this);

        forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppLockManager.getInstance(AppLockPromptActivity.this).setLocked(false);
                startActivity(ForgotAppLockActivity.startingIntent(AppLockPromptActivity.this));
            }
        });

        forgot.setVisibility(View.INVISIBLE);

        patternLock.addPatternLockListener(new PatternLockViewListener() {
            @Override
            public void onStarted() {

            }

            @Override
            public void onProgress(List<PatternLockView.Dot> progressPattern) {

            }

            @Override
            public void onComplete(List<PatternLockView.Dot> pattern) {

                String patternString = PatternLockUtils.patternToString(patternLock, pattern);

                if (AppLockManager.getInstance(AppLockPromptActivity.this)
                                  .authenticatePattern(patternString)) {
                    patternLock.setViewMode(PatternLockView.PatternViewMode.CORRECT);
                    subtitle.setText(getString(R.string.pattern_verified));
                    closeScreen();
                } else {
                    patternLock.setViewMode(PatternLockView.PatternViewMode.WRONG);
                    Toast.makeText(AppLockPromptActivity.this, getString(R.string.incorrect_pattern), Toast.LENGTH_SHORT)
                         .show();
                    patternLock.clearPattern();
                    forgot.setVisibility(View.VISIBLE);
                    subtitle.setText(getString(R.string.incorrect_pattern));
                }
            }

            @Override
            public void onCleared() {

            }
        });
    }

    private void closeScreen() {
        finish();
    }

    @Override
    public void onBackPressed() {
    }
}
