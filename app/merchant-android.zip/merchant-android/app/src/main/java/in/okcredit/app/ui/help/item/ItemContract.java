package in.okcredit.app.ui.help.item;

import java.util.List;

import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;

public interface ItemContract {
    interface View extends MVP.View, BaseContracts.Online.View, BaseContracts.Loading.View {
        void setScreenshots(String id, List<String> screenshotUrls);

        void setAudio(String audioUrl);

        void setActionBarTitle(String title);

        void gotoLogin();
    }

    interface Presenter extends MVP.Presenter<View>,
        BaseContracts.Loading.Presenter<View>,
        BaseContracts.Online.Presenter<View> {
    }
}
