package in.okcredit._offline.usecase;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import in.okcredit._offline.database.CustomerRepo;
import in.okcredit._offline.model.Customer;
import io.reactivex.Observable;

// Offline
public final class GetActiveCustomers {
    private CustomerRepo customerRepo;

    @Inject
    public GetActiveCustomers(CustomerRepo customerRepo) {
        this.customerRepo = customerRepo;
    }

    public Observable<List<Customer>> execute() {
        return customerRepo.listCustomers()
                           .map(customers -> {
                               List<Customer> filtered = new ArrayList<>();
                               for (Customer customer : customers) {
                                   if (customer.getStatus() == 1) {
                                       filtered.add(customer);
                                   }
                               }
                               return filtered;
                           });

    }
}
