package in.okcredit._offline._di;

import android.content.Context;

import dagger.Module;
import dagger.Provides;
import in.okcredit.App;
import in.okcredit._di.AppContext;
import in.okcredit._di.scope.AppScope;
import in.okcredit._offline.database.internal.CoreDatabase;
import in.okcredit._offline.database.internal.CustomerDao;
import in.okcredit._offline.database.internal.MerchantDao;
import in.okcredit._offline.database.internal.TransactionDao;
import in.okcredit._offline.server.identity.internal.IdentityDao;
import in.okcredit._offline.server.identity.internal.IdentityDatabase;
import in.okcredit._offline.server.interceptor.AuthInterceptor;
import in.okcredit._offline.server.interceptor.HttpLoggingInterceptor;
import in.okcredit._offline.server.interceptor.HttpUserAgentInterceptor;
import in.okcredit._offline.server.interceptor.NetworkErrorInterceptor;
import in.okcredit._offline.server.internal.ApiClient;
import in.okcredit.domain.auth.AuthDomain;
import in.okcredit.domain.device.DeviceService;
import in.okcredit.util.GsonUtil;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

@Module
public abstract class OfflineModule {
    @Provides
    @AppScope
    public static CoreDatabase coreDatabase(@AppContext Context context) {
        return CoreDatabase.getInstance(context);
    }

    @Provides
    @AppScope
    public static MerchantDao merchantDao(CoreDatabase database) {
        return database.merchantDao();
    }

    @Provides
    @AppScope
    public static CustomerDao customerDao(CoreDatabase database) {
        return database.customerDao();
    }

    @Provides
    @AppScope
    public static TransactionDao transactionDao(CoreDatabase database) {
        return database.transactionDao();
    }

    @Provides
    @AppScope
    public static IdentityDatabase identityDatabase(@AppContext Context context) {
        return IdentityDatabase.getInstance(context);
    }

    @Provides
    @AppScope
    public static IdentityDao identityDao(IdentityDatabase identityDatabase) {
        return identityDatabase.identityDao();
    }

    @Provides
    @AppScope
    public static ApiClient apiClient(AuthDomain authDomain, DeviceService deviceService) {
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
            .addInterceptor(new NetworkErrorInterceptor())
            .addInterceptor(new HttpUserAgentInterceptor(deviceService))
            .addInterceptor(new AuthInterceptor(authDomain))
            .addInterceptor(new HttpLoggingInterceptor())
            .build();

        Retrofit retrofit = new Retrofit.Builder()
            .baseUrl(App.getBaseUrl())
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create(GsonUtil.getGson()))
            .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
            .build();

        return retrofit.create(ApiClient.class);
    }
}
