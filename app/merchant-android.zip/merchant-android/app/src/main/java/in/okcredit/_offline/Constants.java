package in.okcredit._offline;

public final class Constants {
    public static final String KEY_AUTH_SYNC_TIME = "auth_sync_time";
}
