package in.okcredit.app.ui._utils;

import android.content.Context;
import android.util.TypedValue;

public class DimensionUtil {
    public static float dp2px(Context context, float dp) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, context.getResources().getDisplayMetrics());
    }
}
