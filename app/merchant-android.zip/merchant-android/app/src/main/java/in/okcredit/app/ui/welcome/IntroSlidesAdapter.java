package in.okcredit.app.ui.welcome;

import android.content.Context;
import android.graphics.Color;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.R;

public class IntroSlidesAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int TYPE_WELCOME = 0;
    private static final int TYPE_INTRO = 1;

    private Context context;

    public IntroSlidesAdapter(Context context) {
        this.context = context;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
            case TYPE_WELCOME:
                return new WelcomeViewHolder(
                    LayoutInflater
                        .from(context)
                        .inflate(R.layout.item_intro_welcome, parent, false)
                );

            case TYPE_INTRO:
                return new IntroViewHolder(
                    LayoutInflater
                        .from(context)
                        .inflate(R.layout.item_intro_slide, parent, false)
                );

            default:
                throw new IllegalStateException("invalid view type");
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        int type = getItemViewType(position);
        switch (type) {
            case TYPE_WELCOME:
                ((WelcomeViewHolder) holder).render();
                break;

            case TYPE_INTRO:
                ((IntroViewHolder) holder).render(position);
                break;
        }
    }

    @Override
    public int getItemCount() {
        return 4;
    }

    @Override
    public int getItemViewType(int position) {
        if (position == 0) {
            return TYPE_WELCOME;
        } else {
            return TYPE_INTRO;
        }
    }

    class WelcomeViewHolder extends RecyclerView.ViewHolder {

        public WelcomeViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }

        public void render() {

        }
    }

    class IntroViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.title)
        TextView title;

        @BindView(R.id.subtitle)
        TextView subtitle;

        @BindView(R.id.slide)
        ImageView slide;

        public IntroViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }

        public void render(int position) {
            switch (position) {
                case 1:
                    title.setText(R.string.slide1_title);
                    subtitle.setText(R.string.slide1_subtitle);
                    slide.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.intro1));
                    break;
                case 2:
                    title.setText(R.string.slide2_title);
                    subtitle.setText(R.string.slide2_subtitle);
                    slide.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.intro2));
                    break;
                case 3:
                    title.setText(R.string.slide3_title);
                    subtitle.setText(R.string.slide3_subtitle);
                    slide.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.intro3));
                    break;
                default:
                    throw new IllegalStateException("invalid position in introview adapter");
            }
        }
    }
}
