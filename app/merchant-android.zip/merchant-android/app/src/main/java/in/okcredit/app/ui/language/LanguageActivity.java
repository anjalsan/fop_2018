package in.okcredit.app.ui.language;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.widget.Button;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.LocaleManager;
import in.okcredit.R;
import in.okcredit.ThreadUtils;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base.BaseActivity;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui.welcome.WelcomeActivity;
import io.reactivex.Completable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.observers.DisposableCompletableObserver;
import timber.log.Timber;

public class LanguageActivity extends BaseActivity {
    public static Intent startingIntent(Context context) {
        Timber.d("ABC - STARTING INTENT");
        Intent intent = new Intent(context, LanguageActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent
            .FLAG_ACTIVITY_CLEAR_TASK);
        return intent;
    }

    /* UI Elements */
    @BindView(R.id.english)
    Button english;

    @BindView(R.id.hindi)
    Button hindi;

    @BindView(R.id.punjabi)
    Button punjabi;

    @BindView(R.id.malayalam)
    Button malayalam;

    @BindView(R.id.hinglish)
    Button hinglish;

    /* Lifecycle methods */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Analytics.track(AnalyticsEvents.LANGUAGE_SCREEN);
        Timber.d("ABC - onCreate");

        setContentView(R.layout.screen_language);
        ButterKnife.bind(this);

        english.setOnClickListener(view ->
        {
            proceed(LocaleManager.LANGUAGE_ENGLISH);

            Analytics.track(
                AnalyticsEvents.LANGUAGE_SELECT_LANGUAGE,
                EventProperties
                    .create()
                    .with("language", LocaleManager.LANGUAGE_ENGLISH));
        });

        hindi.setOnClickListener(view ->
        {
            proceed(LocaleManager.LANGUAGE_HINDI);

            Analytics.track(
                AnalyticsEvents.LANGUAGE_SELECT_LANGUAGE,
                EventProperties
                    .create()
                    .with("language", LocaleManager.LANGUAGE_HINDI));
        });

        punjabi.setOnClickListener(view ->
        {
            proceed(LocaleManager.LANGUAGE_PUNJABI);

            Analytics.track(
                AnalyticsEvents.LANGUAGE_SELECT_LANGUAGE,
                EventProperties
                    .create()
                    .with("language", LocaleManager.LANGUAGE_PUNJABI));
        });

        malayalam.setOnClickListener(view ->
        {
            proceed(LocaleManager.LANGUAGE_MALAYALAM);

            Analytics.track(
                AnalyticsEvents.LANGUAGE_SELECT_LANGUAGE,
                EventProperties
                    .create()
                    .with("language", LocaleManager.LANGUAGE_MALAYALAM));
        });

        hinglish.setOnClickListener(view ->
        {
            proceed(LocaleManager.LANGUAGE_HINGLISH);

            Analytics.track(
                AnalyticsEvents.LANGUAGE_SELECT_LANGUAGE,
                EventProperties
                    .create()
                    .with("language", LocaleManager.LANGUAGE_HINGLISH));
        });

        LocaleManager.markMerchantLangAsSynced(false);

        Timber.d("ABC - after marking language as synced");
    }

    @Override
    public void onBackPressed() {
        // nothing in back stack
    }

    public void proceed(String language) {
        Completable
            .fromRunnable(() -> LocaleManager.setNewLocale(getApplicationContext(), language))
            .subscribeOn(ThreadUtils.newThread())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeWith(new DisposableCompletableObserver() {
                @Override
                public void onComplete() {
                    gotoWelcomeScreen();
                }

                @Override
                public void onError(@NonNull Throwable e) {
                    Timber.e(e, "failed to set language");
                    gotoWelcomeScreen();
                }
            });
    }

    private void gotoWelcomeScreen() {
        startActivity(WelcomeActivity.startingIntent(this));
        finish();
    }

    @Override
    public void onNetworkFailure() {
        new NetworkErrorDialog().show(this, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
            }

            @Override
            public void onCancel() {
            }
        });
    }

    @Override
    public void onError(String tag) {
        // no op
    }

    @Override
    public void onAuthenticationFailure() {
        // no op
    }
}
