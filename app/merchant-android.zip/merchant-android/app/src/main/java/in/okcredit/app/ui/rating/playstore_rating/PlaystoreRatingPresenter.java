package in.okcredit.app.ui.rating.playstore_rating;

import android.content.Intent;
import android.net.Uri;

import javax.inject.Inject;

import in.okcredit.BuildConfig;
import in.okcredit.app.ui._base_v2.BasePresenter;
import in.okcredit.app.ui.rating.RatingActivity;
import io.reactivex.android.schedulers.AndroidSchedulers;

public class PlaystoreRatingPresenter extends BasePresenter<PlaystoreRatingContract.View> implements PlaystoreRatingContract.Presenter {

    @Inject
    public PlaystoreRatingPresenter() {
        super(AndroidSchedulers.mainThread());
    }

    @Override
    public void onInternetRestored() {

    }

    @Override
    public void goToPlaystore(RatingActivity activity) {
        final String appId = BuildConfig.APPLICATION_ID;
        try {
            activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appId)));
        } catch (android.content.ActivityNotFoundException anfe) {
            activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appId)));
        }
    }
}
