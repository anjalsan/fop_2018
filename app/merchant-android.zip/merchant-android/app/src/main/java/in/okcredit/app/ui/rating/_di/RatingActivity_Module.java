package in.okcredit.app.ui.rating._di;

import dagger.Module;
import dagger.Provides;
import in.okcredit._di.PresenterParam;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit.app.ui.rating.RatingActivity;

@Module
public abstract class RatingActivity_Module {

}
