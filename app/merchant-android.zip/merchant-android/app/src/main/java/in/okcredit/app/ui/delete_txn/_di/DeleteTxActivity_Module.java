package in.okcredit.app.ui.delete_txn._di;

import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import in.okcredit._di.PresenterParam;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit.app.ui.delete_txn.DeleteTransactionActivity;
import in.okcredit.app.ui.delete_txn.DeleteTxnContract;
import in.okcredit.app.ui.delete_txn.DeleteTxnPresenter;
import in.okcredit._offline.model.Transaction;

@Module
public abstract class DeleteTxActivity_Module {
    @Provides
    @ActivityScope
    @PresenterParam("tx_id")
    public static String transactionId(DeleteTransactionActivity activity) {
        return activity.getIntent().getStringExtra(DeleteTransactionActivity.EXTRA_TX_ID);
    }

    @Provides
    @ActivityScope
    @PresenterParam("tx")
    public static Transaction transaction(DeleteTransactionActivity activity) {
        return (Transaction) activity.getIntent().getSerializableExtra(DeleteTransactionActivity.EXTRA_TX);
    }

    @Binds
    @ActivityScope
    public abstract DeleteTxnContract.Presenter presenter(DeleteTxnPresenter presenter);
}
