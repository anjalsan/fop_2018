package in.okcredit.app.ui.rating.select_rating;

import javax.inject.Inject;

import in.okcredit.app.ui._base_v2.BasePresenter;
import io.reactivex.android.schedulers.AndroidSchedulers;

public class SelectRatingPresenter extends BasePresenter<SelectRatingContract.View> implements
    SelectRatingContract.Presenter {

    @Inject
    public SelectRatingPresenter() {
        super(AndroidSchedulers.mainThread());
    }

    @Override
    public void onInternetRestored() {

    }

    @Override
    public void setRating(int rating) {
        if (rating == 5) {
            ifAttached(view -> view.showPlaystoreRatingPage());
        } else {
            ifAttached(view -> view.showFeedbackAndRatingPage(rating));
        }
    }
}
