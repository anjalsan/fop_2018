package in.okcredit.app.ui.help.item;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;

import java.util.List;

import javax.inject.Inject;

public class ScreenshotItemAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context context;
    private List<String> screenshots;

    @Inject
    public ScreenshotItemAdapter(HelpItemActivity context) {
        this.context = context;
    }

    public void setItems(List<String> screenshots) {
        this.screenshots = screenshots;
        notifyDataSetChanged();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return ScreenshotsViewHolder.create(context, parent);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ((ScreenshotsViewHolder) holder).bind(screenshots.get(position));
    }

    @Override
    public int getItemCount() {
        if (screenshots == null) {
            return 0;
        } else {
            return screenshots.size();
        }
    }
}
