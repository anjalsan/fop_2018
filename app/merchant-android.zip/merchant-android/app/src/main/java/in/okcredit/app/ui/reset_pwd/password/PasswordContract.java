package in.okcredit.app.ui.reset_pwd.password;

import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;

public interface PasswordContract {
    interface View extends MVP.View, BaseContracts.Online.View, BaseContracts.Loading.View {
        void showInvalidPasswordError();

        void gotoHomeScreen(String requestedScreen);
    }

    interface Presenter extends MVP.Presenter<View>, BaseContracts.Online.Presenter<View>, BaseContracts.Loading.Presenter<View> {
        void resetPassword(String newPassword);
    }
}
