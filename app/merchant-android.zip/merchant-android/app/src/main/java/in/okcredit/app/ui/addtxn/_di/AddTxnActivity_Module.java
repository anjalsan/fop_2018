package in.okcredit.app.ui.addtxn._di;

import dagger.Module;
import dagger.Provides;
import in.okcredit._di.UseCaseParam;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit.app.ui.addtxn.AddTxnActivity;

@Module
public abstract class AddTxnActivity_Module {
    @Provides
    @ActivityScope
    @UseCaseParam("customer_id")
    public static String customerId(AddTxnActivity activity) {
        return activity.getIntent().getStringExtra(AddTxnActivity.EXTRA_CUSTOMER_ID);
    }

    @Provides
    @ActivityScope
    @UseCaseParam("txn_type")
    public static int getTxnType(AddTxnActivity activity) {
        int txnType = activity.getIntent().getIntExtra(AddTxnActivity.EXTRA_TXN_TYPE, -1);
        if (txnType == -1) {
            throw new IllegalArgumentException("txn type");
        }
        return txnType;
    }

    @Provides
    @ActivityScope
    @UseCaseParam("lifecycle")
    public static int getLifecycle(AddTxnActivity activity) {
        int lifecycle = activity.getIntent().getIntExtra(AddTxnActivity.EXTRA_LIFECYCLE, 0);
        if (lifecycle == 0) {
            throw new IllegalArgumentException("lifecycle");
        }
        return lifecycle;
    }

    @Provides
    @ActivityScope
    @UseCaseParam("is_old_balance")
    public static boolean getIsOldBalance(AddTxnActivity activity) {
        boolean isOldBalance = activity.getIntent().getBooleanExtra(AddTxnActivity
            .EXTRA_IS_OLD_BALANCE, false);

        return isOldBalance;
    }
}
