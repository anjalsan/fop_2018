package in.okcredit.app.ui.reset_pwd._di;

import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import in.okcredit._di.PresenterParam;
import in.okcredit._di.scope.FragmentScope;
import in.okcredit.app.ui.reset_pwd.otp.OtpContract;
import in.okcredit.app.ui.reset_pwd.otp.OtpFragment;
import in.okcredit.app.ui.reset_pwd.otp.OtpPresenter;
import in.okcredit.app.ui.reset_pwd.otp.SmsHelper;

@Module
public abstract class OtpFragment_Module {
    @Binds
    @FragmentScope
    public abstract OtpContract.Presenter presenter(OtpPresenter presenter);

    @Provides
    @FragmentScope
    @PresenterParam("mobile")
    public static String mobile(OtpFragment fragment) {
        return fragment.getArguments().getString(OtpFragment.ARG_MOBILE);
    }

    @Provides
    @FragmentScope
    public static SmsHelper smsHelper(OtpFragment fragment) {
        return new SmsHelper(fragment.getActivity());
    }
}
