package in.okcredit._offline.server.internal;

import com.google.common.base.Converter;

import in.okcredit._offline.model.Customer;
import in.okcredit._offline.model.Merchant;

public final class ApiEntityMapper {
    public static Converter<ApiMessages.Merchant, Merchant> MERCHANT = new Converter<ApiMessages.Merchant, Merchant>() {
        @Override
        protected Merchant doForward(ApiMessages.Merchant apiEntity) {
            return new Merchant(
                apiEntity.id,
                apiEntity.name,
                apiEntity.mobile,
                apiEntity.createdAt
            );
        }

        @Override
        protected ApiMessages.Merchant doBackward(Merchant merchant) {
            throw new RuntimeException("illegal operation: cannot convert merchant domain entity to api entity");
        }
    };

    public static Converter<ApiMessages.Customer, Customer> CUSTOMER = new Converter<ApiMessages.Customer, Customer>() {
        @Override
        protected Customer doForward(ApiMessages.Customer apiEntity) {
            return new Customer(
                apiEntity.id,
                apiEntity.status,
                apiEntity.mobile,
                apiEntity.description,
                apiEntity.createdAt,
                apiEntity.balance,
                apiEntity.transactionCount,
                apiEntity.lastActivity,
                apiEntity.lastPayment,
                apiEntity.accountUrl,
                apiEntity.profileImage,
                apiEntity.address,
                apiEntity.email
            );
        }

        @Override
        protected ApiMessages.Customer doBackward(Customer customer) {
            throw new RuntimeException("illegal operation: cannot convert customer domain entity to api entity");
        }
    };
}
