package in.okcredit.app.ui.profile._di;

import dagger.Binds;
import dagger.Module;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit.app.ui.profile.ProfileContract;
import in.okcredit.app.ui.profile.ProfilePresenter;

@Module
public abstract class ProfileActivity_Module {
    @Binds
    @ActivityScope
    public abstract ProfileContract.Presenter presenter(ProfilePresenter presenter);
}
