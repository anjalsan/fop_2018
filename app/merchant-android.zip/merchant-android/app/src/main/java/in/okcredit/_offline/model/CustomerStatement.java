package in.okcredit._offline.model;

import java.util.List;

public final class CustomerStatement {
    private final Customer customer;
    private final List<Transaction> transactions;
    private final Settlement settlement;
    private final List<Transaction> settledTransactions;

    public CustomerStatement(Customer customer, List<Transaction> transactions, Settlement settlement, List<Transaction> settledTransactions) {
        this.customer = customer;
        this.transactions = transactions;
        this.settlement = settlement;
        this.settledTransactions = settledTransactions;
    }

    public Customer getCustomer() {
        return customer;
    }

    public List<Transaction> getTransactions() {
        return transactions;
    }

    public Settlement getSettlement() {
        return settlement;
    }

    public List<Transaction> getSettledTransactions() {
        return settledTransactions;
    }
}
