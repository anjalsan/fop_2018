package in.okcredit.app.ui.customer_statement;

import android.content.Intent;

import in.okcredit._offline.model.Customer;
import in.okcredit._offline.model.Merchant;
import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;

public interface CustomerStatementContract {
    interface Presenter extends MVP.Presenter<View>, BaseContracts.Online.Presenter<View>, BaseContracts.Authenticated.Presenter<View> {
        void sendReminderOnWhatsapp(Customer customer);

        void getMiniStatementUrl();

        void getMonthlyReportUrl();

        void downloadPdfFile(String url, String mobile, String fileName);
    }

    interface View extends MVP.View, BaseContracts.Online.View, BaseContracts.Authenticated.View {
        void showLoading();

        void hideLoading();

        void setReminderDetails(String merchantName);

        void showReminderError();

        void displayCustomerDetails(Customer customer);

        void sendReminderOnWhatsapp();

        void openSMSApp();

        void downloadMiniStatement(String reportUrl);

        void downloadMonthlyReport(String reportUrl);

        void sharePdfSuccess(Intent sendIntent);

        void sharePdfFail();

        void showPdfError();
    }
}
