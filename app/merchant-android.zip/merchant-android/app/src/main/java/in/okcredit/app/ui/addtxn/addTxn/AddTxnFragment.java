package in.okcredit.app.ui.addtxn.addTxn;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.github.aakira.expandablelayout.ExpandableLinearLayout;

import java.io.File;
import java.util.HashMap;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import in.okcredit.AudioUrl;
import in.okcredit.LifecycleState;
import in.okcredit.LocaleManager;
import in.okcredit.R;
import in.okcredit.ThreadUtils;
import in.okcredit._offline.model.Transaction;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BaseFragment;
import in.okcredit.app.ui._base_v2.PermissionGrantListener;
import in.okcredit.app.ui._dialog.AddNoteDialog;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui._widget.AddTxnMetadataView;
import in.okcredit.app.ui._widget.EnterAmountView;
import in.okcredit.app.ui._widget.txn_meta.TxnMetadataView;
import in.okcredit.app.ui.addtxn.AddTxnActivity;
import io.reactivex.Completable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

public class AddTxnFragment extends BaseFragment<AddTxnActivity> implements
    AddTxnContract.View, PermissionGrantListener {
    public static AddTxnFragment newInstance() {
        return new AddTxnFragment();
    }

    private static final int REQUEST_CODE_CAMERA = 21, REQUEST_CODE_GALLERY = 22;
    private static final int CAMERA_MODE = 1, GALLERY_MODE = 2;

    @BindView(R.id.addTxnIcon)
    ImageView addTxnIcon;
    @BindView(R.id.customerName)
    TextView customerName;
    @BindView(R.id.amount)
    EnterAmountView amount;

    @BindView(R.id.attachments)
    ExpandableLinearLayout attachments;

    @BindView(R.id.addBill)
    AddTxnMetadataView addBill;

    @BindView(R.id.addNote)
    AddTxnMetadataView addNote;

    @BindView(R.id.addFromGallery)
    AddTxnMetadataView addFromGallery;

    @BindView(R.id.tut_layout)
    RelativeLayout tutorialLayout;

    @BindView(R.id.meta)
    TxnMetadataView meta;

    @BindView(R.id.title)
    TextView tutorialLayoutTitle;

    @BindView(R.id.description)
    TextView tutorialLayoutDesc;

    @BindView(R.id.fabPlay)
    FloatingActionButton fabPlay;

    @BindView(R.id.skip)
    Button skip;

    @BindView(R.id.actionButton)
    LinearLayout tutorialLayoutActionButton;

    @Inject
    AddTxnContract.Presenter presenter;

    @Inject
    CameraHelper cameraHelper;

    @Inject
    GalleryHelper galleryHelper;

    private String noteVal;
    private File receiptImg;
    private int image_mode = CAMERA_MODE;

    private MediaPlayer mediaPlayer;
    private boolean isAudioPlaying;
    private CompositeDisposable tasks;

    private int lifecycle;
    private int txnType;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle
        savedInstanceState) {
        View view = inflater.inflate(R.layout.addtxn_fragment, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        activity.showActionBar(true);
        addBill.setType(AddTxnMetadataView.TYPE_BILL);
        addNote.setType(AddTxnMetadataView.TYPE_NOTE);
        addFromGallery.setType(AddTxnMetadataView.TYPE_GALLERY);
        amount.setAmount(activity.getIntent().getFloatExtra(AddTxnActivity.EXTRA_AMOUNT, 0.0f));

        lifecycle = 0;
        txnType = 0;

        tutorialLayout.setVisibility(View.VISIBLE);

        mediaPlayer = new MediaPlayer();
        tasks = new CompositeDisposable();

        fabPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Analytics.track(
                    AnalyticsEvents.AUDIO_CLICKED,
                    EventProperties
                        .create()
                        .with("screen", "add txn details")
                        .with("wasAudioPlaying", isAudioPlaying)
                        .with("lifecycle", lifecycle)
                        .with("txnType", txnType)
                );

                isAudioPlaying = !isAudioPlaying;
                setAudioState(isAudioPlaying);
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE_CAMERA && resultCode == Activity.RESULT_OK) {
            this.receiptImg = cameraHelper.getImage();
            image_mode = CAMERA_MODE;
            displayReceipt(receiptImg);
        } else if (requestCode == REQUEST_CODE_GALLERY && resultCode == Activity.RESULT_OK) {
            this.receiptImg = galleryHelper.getImage(data, activity);
            if (receiptImg != null) {
                image_mode = GALLERY_MODE;
                displayReceipt(receiptImg);
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        presenter.attachView(this);

        if (mediaPlayer == null) {
            mediaPlayer = new MediaPlayer();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        presenter.detachView();
        releaseMediaPlayer();

        try {
            InputMethodManager inputMethodManager = (InputMethodManager) getActivity()
                .getSystemService(Activity.INPUT_METHOD_SERVICE);

            if (inputMethodManager != null) {
                inputMethodManager.hideSoftInputFromWindow(getActivity().getCurrentFocus()
                                                                        .getWindowToken(), 0);
            }
        } catch (Exception e) {
            Timber.e("Exception while hiding keyboard");
        }
    }

    /****************************************************************
     Event Listeners
     ****************************************************************/
    @OnClick(R.id.addTxn)
    public void onAddTxnClicked() {
        presenter.addTxn(amount.getAmount(), receiptImg, noteVal);
    }

    @OnClick(R.id.attachment)
    public void onAttachmentsClicked() {
        Analytics.track(
            AnalyticsEvents.TX_ADD_SCREEN_ATTACHMENT_CLICKED,
            EventProperties
                .create()
                .with("lifecycle", lifecycle)
        );

        try {
            InputMethodManager inputMethodManager = (InputMethodManager) getActivity()
                .getSystemService(Activity.INPUT_METHOD_SERVICE);

            if (inputMethodManager != null) {
                inputMethodManager.hideSoftInputFromWindow(getActivity().getCurrentFocus()
                                                                        .getWindowToken(), 0);
            }
        } catch (Exception e) {
            Timber.e("Exception while hiding keyboard");
        }
        attachments.toggle();
    }

    @OnClick(R.id.addBill)
    public void onAddBillClicked() {
        Analytics.track(
            AnalyticsEvents.TX_ADD_META,
            EventProperties
                .create()
                .with("type", "bill")
                .with("source", "camera")
                .with("lifecycle", lifecycle)
        );

        attachments.collapse();
        openCamera();
    }

    @OnClick(R.id.addFromGallery)
    public void onAddFromGalleryClicked() {
        Analytics.track(
            AnalyticsEvents.TX_ADD_META,
            EventProperties
                .create()
                .with("type", "bill")
                .with("source", "gallery")
                .with("lifecycle", lifecycle)
        );

        attachments.collapse();
        openGallery();
    }

    public void onChangeBillClicked() {
        Analytics.track(
            AnalyticsEvents.TX_CHANGE_META,
            EventProperties
                .create()
                .with("type", "bill")
                .with("lifecycle", lifecycle)
        );

        if (image_mode == CAMERA_MODE) {
            openCamera();
        } else {
            openGallery();
        }
    }

    @OnClick(R.id.addNote)
    public void onAddNoteClicked() {
        Analytics.track(
            AnalyticsEvents.TX_ADD_META,
            EventProperties
                .create()
                .with("type", "note")
                .with("lifecycle", lifecycle)
        );

        attachments.collapse();
        showAddNoteDialog();
    }

    public void onChangeNoteClicked() {
        Analytics.track(
            AnalyticsEvents.TX_CHANGE_META,
            EventProperties
                .create()
                .with("type", "note")
                .with("lifecycle", lifecycle)
        );

        showAddNoteDialog();
    }

    @Override
    public void onPermissionGranted(String permission) {
        if (permission.equals(Manifest.permission.CAMERA)) {
            openCamera();
        } else if (permission.equals(Manifest.permission.READ_EXTERNAL_STORAGE)) {
            openGallery();
        }
    }

    @Override
    public void onPermissionDenied(String permission) {
        if (permission.equals(Manifest.permission.CAMERA)) {
            Toast.makeText(getActivity(), R.string.txn_camera_permission_msg, Toast.LENGTH_SHORT)
                 .show();
            Analytics.track(AnalyticsEvents.TX_CAMERA_PERMISSION_DENIED);
        } else if (permission.equals(Manifest.permission.READ_EXTERNAL_STORAGE)) {
            Toast.makeText(getActivity(), R.string.txn_gallery_permission_msg, Toast.LENGTH_SHORT)
                 .show();
            Analytics.track(AnalyticsEvents.TX_GALLERY_PERMISSION_DENIED);
        }
    }

    /****************************************************************
     MVP methods
     ****************************************************************/
    @Override
    public void showError() {
        Toast.makeText(getActivity(), R.string.err_default, Toast.LENGTH_SHORT).show();

        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "add tx fragment")
                .with("type", "server error")
        );
    }

    @Override
    public void setTxnType(int txnType, int lifecycle) {
        this.lifecycle = lifecycle;
        this.txnType = txnType;

        switch (txnType) {
            case Transaction.CREDIT:
                if (activity.isOldBalance()) {
                    getActivity().setTitle(getString(R.string.old_balance_button_text));
                } else {
                    getActivity().setTitle(getString(R.string.txn_add_credit_title));
                }

                addTxnIcon.setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable
                    .ic_credit));

                break;

            case Transaction.PAYMENT:
                if (activity.isOldBalance()) {
                    getActivity().setTitle(getString(R.string.old_balance_button_text));
                } else {
                    getActivity().setTitle(getString(R.string.txn_add_payment_title));
                }

                addTxnIcon.setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable
                    .ic_payment));
                break;
        }

        Analytics.track(
            AnalyticsEvents.TX_ADD_SCREEN,
            EventProperties
                .create()
                .with("type", txnType)
                .with("lifecycle", lifecycle)
                .with("isOldBalance", activity.isOldBalance())
        );
    }

    @Override
    public void setCustomerName(String name) {
        customerName.setText(name);
    }

    @Override
    public void showInvalidAmountError() {
        amount.showError(R.string.txn_invalid_amount);
        Analytics.track(
            AnalyticsEvents.TX_INVALID_AMOUNT,
            EventProperties
                .create()
                .with("lifecycle", lifecycle)
        );
    }

    @Override
    public void gotoConfirmation() {
        activity.gotoConfirmScreen();
    }

    @Override
    public void gotoLogin() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "add tx fragment")
                .with("type", "auth error")
        );

        activity.gotoLogin();
    }

    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(activity, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
            }
        });
    }

    @Override
    public void displayReceipt(File receipt) {
        if (receipt == null || !receipt.exists() || receipt.length() == 0) {
            addBill.setIsDone(false);
            addBill.setOnClickListener(view -> onAddBillClicked());
            addFromGallery.setIsDone(false);
            addFromGallery.setOnClickListener(view -> onAddFromGalleryClicked());

            meta.remove(TxnMetadataView.TxnMetadata.TYPE_BILL);
        } else {
            if (image_mode == CAMERA_MODE) {
                addBill.setIsDone(true);
                addBill.setOnClickListener(null);

                addFromGallery.setIsDone(false);
                addFromGallery.setOnClickListener(view -> onAddFromGalleryClicked());
            } else {
                addFromGallery.setIsDone(true);
                addFromGallery.setOnClickListener(null);

                addBill.setIsDone(false);
                addBill.setOnClickListener(view -> onAddBillClicked());
            }

            meta.addOrReplace(TxnMetadataView.TxnMetadata.addBill(getActivity(), view ->
                onChangeBillClicked()));
        }
    }

    @Override
    public void displayNote(String note) {
        noteVal = note;
        if (TextUtils.isEmpty(note)) {
            addNote.setIsDone(false);
            addNote.setOnClickListener(view -> onAddNoteClicked());

            meta.remove(TxnMetadataView.TxnMetadata.TYPE_NOTE);
        } else {
            addNote.setIsDone(true);
            addNote.setOnClickListener(null);

            meta.addOrReplace(TxnMetadataView.TxnMetadata.addNote(getActivity(), noteVal, view ->
                onChangeNoteClicked()));
        }
    }

    @Override
    public void setupTutorialLayout(int lifecycle, int txType) {
        switch (txType) {
            case Transaction.CREDIT:

                if (lifecycle == LifecycleState.TRIAL_TRANSACTION) {
                    fabPlay.show();

                    switch (activity.getAudioLang()) {
                        case LocaleManager.LANGUAGE_ENGLISH:
                            setAudio(AudioUrl.ADD_TX_CREDIT_EN);
                            break;
                        case LocaleManager.LANGUAGE_HINDI:
                            setAudio(AudioUrl.ADD_TX_CREDIT_HI);
                            break;
                        case LocaleManager.LANGUAGE_MALAYALAM:
                            setAudio(AudioUrl.ADD_TX_CREDIT_ML);
                            break;
                        default:
                            setAudio(AudioUrl.ADD_TX_CREDIT_HI);
                            break;
                    }
                } else {
                    fabPlay.hide();
                    releaseMediaPlayer();
                }

                tutorialLayoutTitle.setVisibility(View.GONE);
                tutorialLayoutActionButton.setVisibility(View.GONE);
                skip.setVisibility(View.INVISIBLE);
                tutorialLayoutDesc.setText(getString(R.string.tut_add_txn_desc_credit));

                break;

            case Transaction.PAYMENT:

                if (lifecycle == LifecycleState.TRIAL_TRANSACTION) {
                    fabPlay.show();

                    switch (activity.getAudioLang()) {
                        case LocaleManager.LANGUAGE_ENGLISH:
                            setAudio(AudioUrl.ADD_TX_PAYMENT_EN);
                            break;
                        case LocaleManager.LANGUAGE_HINDI:
                            setAudio(AudioUrl.ADD_TX_PAYMENT_HI);
                            break;
                        case LocaleManager.LANGUAGE_MALAYALAM:
                            setAudio(AudioUrl.ADD_TX_PAYMENT_ML);
                            break;
                        default:
                            setAudio(AudioUrl.ADD_TX_PAYMENT_HI);
                            break;
                    }
                } else {
                    fabPlay.hide();
                    releaseMediaPlayer();
                }

                tutorialLayoutTitle.setVisibility(View.GONE);
                tutorialLayoutActionButton.setVisibility(View.GONE);
                skip.setVisibility(View.INVISIBLE);
                tutorialLayoutDesc.setText(getString(R.string.tut_add_txn_desc_payment));

                break;
        }
    }

    /****************************************************************
     Helpers
     ****************************************************************/
    private void openCamera() {
        Intent cameraIntent = cameraHelper.getIntent(this);
        if (cameraIntent != null) {
            startActivityForResult(cameraIntent, REQUEST_CODE_CAMERA);
        }
    }

    private void openGallery() {
        Intent galleryIntent = galleryHelper.getIntent(this);
        if (galleryIntent != null) {
            startActivityForResult(Intent.createChooser(galleryIntent, "Select Picture"), REQUEST_CODE_GALLERY);
        }
    }

    private void showAddNoteDialog() {
        AddNoteDialog.show(
            getActivity(),
            noteVal,
            note1 -> displayNote(note1)
        );
    }

    public void setAudio(String audioUrl) {
        fabPlay.setImageDrawable(ContextCompat.getDrawable(activity, R
            .drawable.ic_pause));

        fabPlay.setClickable(false);

        Disposable task = Completable
            .fromAction(() -> {
                mediaPlayer.setDataSource(activity, Uri.parse(audioUrl), new HashMap<>());
                mediaPlayer.prepare();
            })
            .subscribeOn(ThreadUtils.newThread())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                () -> {
                    Analytics.track(
                        AnalyticsEvents.AUDIO_STARTED,
                        EventProperties
                            .create()
                            .with("screen", "add txn details")
                            .with("lifecycle", lifecycle)
                            .with("txnType", txnType)
                    );
                    setAudioState(true);
                    fabPlay.setClickable(true);
                },
                throwable -> Timber.e(throwable)
            );

        if (mediaPlayer != null) {
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    Analytics.track(
                        AnalyticsEvents.AUDIO_COMPLETE,
                        EventProperties
                            .create()
                            .with("screen", "add txn details")
                            .with("lifecycle", lifecycle)
                            .with("txnType", txnType)
                    );

                    fabPlay.setImageDrawable(ContextCompat.getDrawable(activity, R
                        .drawable.ic_play));
                    isAudioPlaying = false;
                }
            });
        }

        tasks.add(task);
    }

    private void setAudioState(boolean playAudio) {
        if (mediaPlayer == null) {
            return;
        }

        isAudioPlaying = playAudio;
        if (playAudio) {
            mediaPlayer.start();
            fabPlay.setImageDrawable(ContextCompat.getDrawable(activity, R
                .drawable.ic_pause));
        } else {
            mediaPlayer.pause();
            fabPlay.setImageDrawable(ContextCompat.getDrawable(activity, R
                .drawable.ic_play));
        }
    }

    private void releaseMediaPlayer() {
        try {
            if (mediaPlayer != null) {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                mediaPlayer.release();
                mediaPlayer = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
