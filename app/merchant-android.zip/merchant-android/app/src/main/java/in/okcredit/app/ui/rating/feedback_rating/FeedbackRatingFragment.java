package in.okcredit.app.ui.rating.feedback_rating;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import dagger.android.AndroidInjection;
import dagger.android.support.AndroidSupportInjection;
import in.okcredit.R;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui._utils.KeyboardUtil;
import in.okcredit.app.ui.rating.RatingActivity;

public class FeedbackRatingFragment extends Fragment implements FeedbackRatingContract.View {
    public static final String ARG_RATING = "rating";
    private int rating;

    public static FeedbackRatingFragment newInstance(int rating) {
        Bundle args = new Bundle();
        args.putInt(ARG_RATING, rating);
        FeedbackRatingFragment fragment = new FeedbackRatingFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Inject
    RatingActivity activity;

    @Inject
    FeedbackRatingContract.Presenter presenter;

    @BindView(R.id.rating_bar)
    RatingBar ratingBar;

    @BindView(R.id.feedback_text)
    EditText feedbackText;

    @BindView(R.id.submit_feedback)
    TextView submitFeedback;

    @BindView(R.id.loader)
    ProgressBar loader;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle
        savedInstanceState) {
        View view = inflater.inflate(R.layout.rating_and_feedback_fragment, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        AndroidSupportInjection.inject(this);

        Analytics.track(AnalyticsEvents.RATING_FEEDBACK_RATING_SCREEN);

        rating = getArguments().getInt(ARG_RATING);
        ratingBar.setRating(rating);

        submitFeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Analytics.track(AnalyticsEvents.RATING_SUBMIT_FEEDBACK_CLICKED);
                presenter.submitFeedback(feedbackText.getText().toString(), rating);
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        presenter.attachView(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        presenter.detachView();
    }


    /****************************************************************
     MVP methods
     ****************************************************************/

    @Override
    public void showError() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "rating and feedback")
                .with("type", "server error")
        );

        Toast.makeText(activity, R.string.err_default, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(activity, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
            }
        });
    }

    @Override
    public void displayInvalidFeedbackError() {
        Toast.makeText(activity, R.string.please_enter_feedback, Toast.LENGTH_SHORT).show();
        KeyboardUtil.hideKeyboard(this);
    }

    @Override
    public void showLoading() {
        loader.setVisibility(View.VISIBLE);
        submitFeedback.setEnabled(false);
    }

    @Override
    public void hideLoading() {
        loader.setVisibility(View.GONE);
        submitFeedback.setEnabled(true);
    }

    @Override
    public void goToHomeScreen() {
        Toast.makeText(activity, R.string.thanks_for_feedback, Toast.LENGTH_SHORT).show();
        activity.finish();
    }

    /****************************************************************
     Unexpected
     ****************************************************************/
}
