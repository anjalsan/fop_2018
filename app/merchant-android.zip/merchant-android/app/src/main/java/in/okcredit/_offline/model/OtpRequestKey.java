package in.okcredit._offline.model;

import org.joda.time.DateTime;

public class OtpRequestKey {
    private final String customerId;
    private final String requestId;
    private final String mobile;
    private final String currentMobile;
    private final DateTime createdAt;
    private final DateTime expiryTime;

    public OtpRequestKey(String customerId, String requestId, String mobile, String currentMobile, DateTime createdAt, DateTime expiryTime) {
        this.customerId = customerId;
        this.requestId = requestId;
        this.mobile = mobile;
        this.currentMobile = currentMobile;
        this.createdAt = createdAt;
        this.expiryTime = expiryTime;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getRequestId() {
        return requestId;
    }

    public String getMobile() {
        return mobile;
    }

    public String getCurrentMobile() {
        return currentMobile;
    }

    public DateTime getCreatedAt() {
        return createdAt;
    }

    public DateTime getExpiryTime() {
        return expiryTime;
    }
}
