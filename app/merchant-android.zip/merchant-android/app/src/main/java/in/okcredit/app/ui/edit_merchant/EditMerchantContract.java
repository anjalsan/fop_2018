package in.okcredit.app.ui.edit_merchant;

import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;
import in.okcredit._offline.model.Merchant;

public interface EditMerchantContract {
    interface Presenter extends MVP.Presenter<View>,
        BaseContracts.Loading.Presenter<View>,
        BaseContracts.Online.Presenter<View>,
        BaseContracts.Authenticated.Presenter<View> {
        void save(String description);
    }

    interface View extends MVP.View, BaseContracts.Loading.View, BaseContracts.Online.View, BaseContracts.Authenticated.View {

        void displayInvalidNameError();

        void setMerchant(Merchant merchant);

        void goToMerchantProfileScreen();
    }
}
