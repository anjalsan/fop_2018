package in.okcredit.app.ui.app_lock.preference;

import javax.inject.Inject;

import in.okcredit.AppLockManager;
import in.okcredit._di.UiThread;
import in.okcredit.app.ui._base_v2.BasePresenter;
import io.reactivex.Scheduler;

public class AppLockPrefPresenter extends BasePresenter<AppLockPrefContract.View> implements AppLockPrefContract.Presenter {

    private AppLockManager appLockManager;
    private boolean isActive;

    @Inject
    public AppLockPrefPresenter(@UiThread Scheduler uiScheduler, AppLockManager appLockManager) {
        super(uiScheduler);
        this.isActive = isActive;
        this.appLockManager = appLockManager;
    }

    @Override
    protected void loadData() {
        ifAttached(view -> view.setAppLockStatus(appLockManager.isAppLockActive()));
    }

    @Override
    public void onInternetRestored() {
        loadData();
    }

    @Override
    public void onAuthenticationRestored() {
        loadData();
    }
}
