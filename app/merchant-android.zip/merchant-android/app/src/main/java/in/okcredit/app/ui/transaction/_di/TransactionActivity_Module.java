package in.okcredit.app.ui.transaction._di;

import android.support.annotation.Nullable;

import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import in.okcredit._di.PresenterParam;
import in.okcredit._di.UseCaseParam;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit.app.ui.transaction.TransactionActivity;
import in.okcredit.app.ui.transaction.TransactionScreenContract;
import in.okcredit.app.ui.transaction.TransactionScreenPresenter;
import in.okcredit._offline.model.Transaction;

@Module
public abstract class TransactionActivity_Module {
    @Provides
    @ActivityScope
    @UseCaseParam("transaction_id")
    public static String transactionId(TransactionActivity activity) {
        return activity.getIntent().getStringExtra(TransactionActivity.EXTRA_TRANSACTION_ID);
    }

    @Provides
    @ActivityScope
    @Nullable
    @UseCaseParam("transaction")
    public static Transaction transaction(TransactionActivity activity) {
        return (Transaction) activity.getIntent()
                                     .getSerializableExtra(TransactionActivity.EXTRA_TRANSACTION);
    }

    @Provides
    @ActivityScope
    @PresenterParam("is_cancel_visible")
    public static boolean isCancelVisible(TransactionActivity activity) {
        return activity.getIntent()
                       .getBooleanExtra(TransactionActivity.EXTRA_IS_CANCEl_VISIBLE, false);
    }

    @Binds
    @ActivityScope
    public abstract TransactionScreenContract.Presenter presenter(TransactionScreenPresenter presenter);
}
