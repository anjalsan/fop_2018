package in.okcredit._offline.usecase;

import javax.inject.Inject;

import in.okcredit._offline.database.MerchantRepo;
import in.okcredit._offline.server.Server;
import io.reactivex.Completable;

public final class FetchActiveMerchant {
    private Server server;
    private MerchantRepo merchantRepo;

    @Inject
    public FetchActiveMerchant(Server server, MerchantRepo merchantRepo) {
        this.server = server;
        this.merchantRepo = merchantRepo;
    }

    public Completable execute() {
        return server.getActiveMerchant()
                     .flatMapCompletable(merchant -> merchantRepo.setActiveMerchant(merchant));
    }
}
