package in.okcredit.app.ui.welcome._di;

import dagger.Module;
import dagger.Provides;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit.app.ui.welcome.IntroSlidesAdapter;
import in.okcredit.app.ui.welcome.WelcomeActivity;

@Module
public abstract class WelcomeActivity_Module {
    @Provides
    @ActivityScope
    public static IntroSlidesAdapter introSlidesAdapter(WelcomeActivity activity) {
        return new IntroSlidesAdapter(activity);
    }
}
