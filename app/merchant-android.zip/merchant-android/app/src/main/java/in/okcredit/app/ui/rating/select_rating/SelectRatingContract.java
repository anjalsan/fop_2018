package in.okcredit.app.ui.rating.select_rating;


import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;

public interface SelectRatingContract {
    interface View extends MVP.View, BaseContracts.Online.View {
        void showPlaystoreRatingPage();

        void showFeedbackAndRatingPage(int rating);
    }

    interface Presenter extends MVP.Presenter<SelectRatingContract.View>, BaseContracts.Online.Presenter<SelectRatingContract.View> {
        void setRating(int rating);
    }
}