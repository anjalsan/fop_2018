package in.okcredit.app.ui.app_lock.set;

import javax.inject.Inject;

import in.okcredit.AppLockManager;
import in.okcredit._di.UiThread;
import in.okcredit.app.ui._base_v2.BasePresenter;
import io.reactivex.Scheduler;

public class AppLockPresenter extends BasePresenter<AppLockContract.View> implements AppLockContract.Presenter {

    private boolean isActive;
    private AppLockManager appLockManager;

    @Inject
    public AppLockPresenter(@UiThread Scheduler uiScheduler, AppLockManager appLockManager) {
        super(uiScheduler);
        this.appLockManager = appLockManager;
        this.isActive = isActive;
    }

    @Override
    protected void loadData() {
        ifAttached(view -> view.setAppLockStatus(appLockManager.isAppLockActive()));
    }

    @Override
    public void onInternetRestored() {
        loadData();
    }

    @Override
    public void onAuthenticationRestored() {
        loadData();
    }

    @Override
    public void enableAppLock(String pattern) {

        appLockManager.enableAppLock(pattern);
        ifAttached(view -> view.goToAppLockPrefActivity(true));
    }

    @Override
    public void disableAppLock(String oldPatternAttempt) {

        if (appLockManager.disableAppLock(oldPatternAttempt)) {
            ifAttached(view -> view.goToAppLockPrefActivity(false));
        } else {
            ifAttached(view -> view.showIncorrectOldPatternMessage());
        }
    }
}
