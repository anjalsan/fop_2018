package in.okcredit.app.ui.launcher._di;

import dagger.Binds;
import dagger.Module;
import in.okcredit._di.scope.ActivityScope;
import in.okcredit.app.ui.launcher.LauncherContract;
import in.okcredit.app.ui.launcher.LauncherPresenter;

@Module
public abstract class LauncherActivity_Module {
    @Binds
    @ActivityScope
    public abstract LauncherContract.Presenter presenter(LauncherPresenter presenter);
}
