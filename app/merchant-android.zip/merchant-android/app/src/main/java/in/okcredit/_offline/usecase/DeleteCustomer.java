package in.okcredit._offline.usecase;

import javax.inject.Inject;

import in.okcredit._offline.server.Server;
import io.reactivex.Completable;

public final class DeleteCustomer {
    private Server server;
    private SyncCustomer syncCustomer;
    private SafelySaveCustomer safelySaveCustomer;

    @Inject
    public DeleteCustomer(Server server, SyncCustomer syncCustomer, SafelySaveCustomer safelySaveCustomer) {
        this.server = server;
        this.syncCustomer = syncCustomer;
        this.safelySaveCustomer = safelySaveCustomer;
    }

    public Completable execute(String customerId) {
        return syncCustomer
            .execute(customerId, null) // sync customer (to handle any dirty transactions)
            .andThen(server.deleteCustomer(customerId)) // delete on server
            .andThen(server.getCustomer(customerId)) // fetch updated copy
            .flatMapCompletable(customer -> safelySaveCustomer.execute(customer)); // save locally
    }
}
