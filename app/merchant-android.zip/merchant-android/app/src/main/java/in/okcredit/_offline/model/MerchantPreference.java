package in.okcredit._offline.model;

public final class MerchantPreference {
    public static final MerchantPreference REMINDER =
        new MerchantPreference(null, "reminder", String.valueOf(false));

    public static final MerchantPreference NAME_CHANGE_COUNT =
        new MerchantPreference(null, "name_change_count", String.valueOf(0));

    public static final MerchantPreference SKIP_TUTORIAL =
        new MerchantPreference(null, "skip_tutorial", String.valueOf(false));

    public static final MerchantPreference LANGUAGE = new MerchantPreference(null, "lang", "en");

    private String merchantId;
    private String key;
    private String value;

    public MerchantPreference(String merchantId, String key, String value) {
        this.merchantId = merchantId;
        this.key = key;
        this.value = value;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public String getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }
}
