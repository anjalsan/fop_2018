package in.okcredit.app.ui.delete_customer;

import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;
import in.okcredit._offline.model.Customer;

public interface DeleteCustomerContract {
    interface View extends MVP.View, BaseContracts.Loading.View, BaseContracts.Online.View, BaseContracts.Authenticated.View {
        void setCustomer(Customer customer);

        void gotoAddTxnScreen(String customerId, int type, float amount);

        void gotoHomeScreen();

        void showIncorrectPasswordError();
    }

    interface Presenter extends MVP.Presenter<View>, BaseContracts.Loading.Presenter<View>, BaseContracts.Online.Presenter<View>, BaseContracts.Authenticated.Presenter<View> {
        void delete(String passsword);

        void settle();
    }
}
