package in.okcredit.app.ui.welcome;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.yarolegovich.discretescrollview.DiscreteScrollView;

import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.R;
import in.okcredit.ThreadUtils;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui.language.LanguageActivity;
import in.okcredit.app.ui.mobile.MobileActivity;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;

public class WelcomeActivity extends BaseActivity {
    public static Intent startingIntent(Context context) {
        return new Intent(context, WelcomeActivity.class);
    }

    @BindView(R.id.getStarted)
    Button getStarted;

    @BindView(R.id.slides)
    DiscreteScrollView slides;

    @BindView(R.id.dot0)
    ImageView dot0;

    @BindView(R.id.dot1)
    ImageView dot1;

    @BindView(R.id.dot2)
    ImageView dot2;

    @BindView(R.id.dot3)
    ImageView dot3;

    @BindView(R.id.swipe)
    TextView swipe;

    // Adapter
    @Inject
    IntroSlidesAdapter introSlidesAdapter;

    private int maxScreen;

    /* Lifecycle methods */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Analytics.track(AnalyticsEvents.WELCOME_SCREEN);

        setContentView(R.layout.screen_welcome);
        ButterKnife.bind(this);

        slides.setAdapter(introSlidesAdapter);

        maxScreen = 0;

        getStarted.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Analytics.track(
                    AnalyticsEvents.GET_STARTED_CLICKED,
                    EventProperties
                        .create()
                        .with("clicked_on_screen", slides.getCurrentItem())
                        .with("max_screen", maxScreen));
                gotoMobileScreen();
            }
        });

        slides.addOnItemChangedListener(new DiscreteScrollView.OnItemChangedListener<RecyclerView
            .ViewHolder>() {
            @Override
            public void onCurrentItemChanged(@Nullable RecyclerView.ViewHolder viewHolder, int
                adapterPosition) {
                switch (adapterPosition) {
                    case 0:
                        swipe.setVisibility(View.VISIBLE);
                        dot0.setImageDrawable(ContextCompat.getDrawable(WelcomeActivity.this, R.drawable.active_dot));
                        dot1.setImageDrawable(ContextCompat.getDrawable(WelcomeActivity.this, R.drawable.non_active_dot));
                        dot2.setImageDrawable(ContextCompat.getDrawable(WelcomeActivity.this, R.drawable.non_active_dot));
                        dot3.setImageDrawable(ContextCompat.getDrawable(WelcomeActivity.this, R.drawable.non_active_dot));
                        break;
                    case 1:

                        if (maxScreen < 1) {
                            maxScreen = 1;
                        }

                        swipe.setVisibility(View.INVISIBLE);
                        dot0.setImageDrawable(ContextCompat.getDrawable(WelcomeActivity.this, R.drawable.non_active_dot));
                        dot1.setImageDrawable(ContextCompat.getDrawable(WelcomeActivity.this, R.drawable.active_dot));
                        dot2.setImageDrawable(ContextCompat.getDrawable(WelcomeActivity.this, R.drawable.non_active_dot));
                        dot3.setImageDrawable(ContextCompat.getDrawable(WelcomeActivity.this, R.drawable.non_active_dot));
                        break;
                    case 2:

                        if (maxScreen < 2) {
                            maxScreen = 2;
                        }

                        swipe.setVisibility(View.INVISIBLE);
                        dot0.setImageDrawable(ContextCompat.getDrawable(WelcomeActivity.this, R.drawable.non_active_dot));
                        dot1.setImageDrawable(ContextCompat.getDrawable(WelcomeActivity.this, R.drawable.non_active_dot));
                        dot2.setImageDrawable(ContextCompat.getDrawable(WelcomeActivity.this, R.drawable.active_dot));
                        dot3.setImageDrawable(ContextCompat.getDrawable(WelcomeActivity.this, R.drawable.non_active_dot));
                        break;
                    case 3:

                        if (maxScreen < 3) {
                            maxScreen = 3;
                        }

                        swipe.setVisibility(View.INVISIBLE);
                        dot0.setImageDrawable(ContextCompat.getDrawable(WelcomeActivity.this, R.drawable.non_active_dot));
                        dot1.setImageDrawable(ContextCompat.getDrawable(WelcomeActivity.this, R.drawable.non_active_dot));
                        dot2.setImageDrawable(ContextCompat.getDrawable(WelcomeActivity.this, R.drawable.non_active_dot));
                        dot3.setImageDrawable(ContextCompat.getDrawable(WelcomeActivity.this, R.drawable.active_dot));
                        break;
                }
            }
        });

        Observable.timer(2, TimeUnit.SECONDS, ThreadUtils.newThread())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                timeInterval -> {
                    slides.smoothScrollToPosition(1);
                },
                throwable -> {

                });

        Observable.timer((long) 2.3, TimeUnit.SECONDS, ThreadUtils.newThread())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                timeInterval -> {
                    getStarted.setBackgroundResource(R.drawable.btn_primary_ghost);

                    if (Build.VERSION.SDK_INT < 23) {
                        getStarted.setTextAppearance(this, R.style.PrimaryGhostButton);
                    } else {
                        getStarted.setTextAppearance(R.style.PrimaryGhostButton);
                    }
                },
                throwable -> {

                });
    }

    private void gotoMobileScreen() {
        startActivity(MobileActivity.startingIntent(this));
        finish();
    }

    @Override
    public void onBackPressed() {
        startActivity(LanguageActivity.startingIntent(this));
        finish();
    }
}
