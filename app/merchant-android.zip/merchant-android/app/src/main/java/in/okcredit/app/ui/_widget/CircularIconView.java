package in.okcredit.app.ui._widget;

import android.content.Context;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.support.annotation.ColorRes;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.ImageView;

import butterknife.BindView;
import butterknife.ButterKnife;
import in.okcredit.R;
import in.okcredit.app.ui._utils.DrawableUtil;

public class CircularIconView extends FrameLayout {
    @BindView(R.id.iv_icon) ImageView icon;

    @DrawableRes int iconRes;
    @ColorRes int iconColor;
    @ColorRes int bgColor;

    private Context context;

    public void setIcon(@DrawableRes int iconRes) {
        this.iconRes = iconRes;
        refreshView();
    }

    public void setIconColor(@ColorRes int iconColor) {
        this.iconColor = iconColor;
        refreshView();
    }

    public void setBackgroundColor(@ColorRes int bgColor) {
        this.bgColor = bgColor;
        refreshView();
    }

    public CircularIconView(@NonNull Context context) {
        super(context);
        initView(context);
    }

    public CircularIconView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public CircularIconView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    public CircularIconView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        initView(context);
    }

    private void initView(Context context) {
        this.context = context;
        inflate(context, R.layout.widget_circular_icon, this);
        ButterKnife.bind(this);
        iconColor = R.color.white;
        bgColor = R.color.grey400;
    }

    private void refreshView() {
        if (iconRes != 0)
            icon.setImageDrawable(DrawableUtil.getDrawableWithColor(context, iconRes, iconColor));
        ShapeDrawable bg = new ShapeDrawable(new OvalShape());
        bg.getPaint().setColor(ContextCompat.getColor(context, bgColor));
        setBackground(bg);

        int iconHeight = getLayoutParams().height / 2;
        int iconWidth = getLayoutParams().width / 2;
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(iconWidth, iconHeight);
        params.gravity = Gravity.CENTER;
        icon.setLayoutParams(params);
        icon.requestLayout();
    }
}
