package in.okcredit._offline.server.identity;

import android.arch.persistence.room.EmptyResultSetException;
import javax.annotation.Nullable;
import javax.inject.Inject;
import in.okcredit._offline.server.identity.internal.IdentityDao;
import in.okcredit._offline.server.identity.internal.IdentityMapping;
import timber.log.Timber;

public class Identity {
    public static final int TYPE_TRANSACTION = 1;

    private IdentityDao identityDao;

    @Inject
    public Identity(IdentityDao identityDao) {
        this.identityDao = identityDao;
    }

    // returns null if the given serverId is not present locally
    @Nullable
    public String serverToLocal(int type, String serverId) {
        if (type == TYPE_TRANSACTION) {
            try {
                return identityDao.getLocalId(TYPE_TRANSACTION, serverId);
            } catch (EmptyResultSetException e) {
                return null;
            }

        } else {
            return serverId;
        }
    }

    // returns null if the entity corresponding to the given localId is created locally and never synced
    @Nullable
    public String localToServer(int type, String localId) {
        if (type == TYPE_TRANSACTION) {
            try {
                return identityDao.getServerId(TYPE_TRANSACTION, localId);
            } catch (EmptyResultSetException e) {
                return null;
            }

        } else {
            return localId;
        }
    }

    public void createMapping(int type, String localId, String serverId) {
        if (type == TYPE_TRANSACTION) {
            Timber.i("Txn ID mapping created: local(%s) => server(%s)", localId, serverId);
            identityDao.putIdentityMapping(new IdentityMapping(type, localId, serverId));
        }
    }
}
