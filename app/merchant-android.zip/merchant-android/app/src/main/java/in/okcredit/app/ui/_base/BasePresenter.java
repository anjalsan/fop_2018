package in.okcredit.app.ui._base;

public interface BasePresenter<V extends BaseView> {
    void attachView(V view);

    void detachView();
}
