package in.okcredit.app.ui.help.main;

/**
 * Created by harsh on 20/12/17.
 */

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerFragment;

import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import in.okcredit.Constants;
import in.okcredit.R;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.app.ui._base_v2.BaseActivity;
import in.okcredit.app.ui._base_v2.PermissionGrantListener;
import in.okcredit.app.ui._dialog.NetworkErrorDialog;
import in.okcredit.app.ui.help.section.HelpSectionActivity;
import in.okcredit.domain.help.HelpSection;
import timber.log.Timber;

public class HelpActivity extends BaseActivity implements HelpContract.View,
    HelpSectionSelectionListener {
    // Intent
    public static Intent startingIntent(Context context) {
        return new Intent(context, HelpActivity.class);
    }

    // Youtube Fragment
//    private YouTubePlayerFragment youtube;

    // UI Elements
    @BindView(R.id.sections)
    RecyclerView sections;

    @BindView(R.id.whatsapp)
    LinearLayout whatsapp;

//    @BindView(R.id.loading)
//    LinearLayout loading;

//    @BindView(R.id.youtube)
//    FrameLayout youtubeFrameLayout;
//
//    @BindView(R.id.divider)
//    View divider;

    // Adapter
    @Inject
    HelpSectionAdapter helpSectionAdapter;

    // Presenter
    @Inject
    HelpContract.Presenter presenter;

    PermissionGrantListener permissionGrantListener;

    // Lifecycle Methods
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.help_activity);
        ButterKnife.bind(this);
        showActionBar(true);
        setTitle(R.string.help_screen_action_title);

        sections.setLayoutManager(new LinearLayoutManager(this));
        sections.setAdapter(helpSectionAdapter);
        helpSectionAdapter.setSelectionListener(this);

        Analytics.track(AnalyticsEvents.HELP_SCREEN);

        permissionGrantListener = new PermissionGrantListener() {
            @Override
            public void onPermissionGranted(String permission) {
                if (permission.equals(Manifest.permission.WRITE_CONTACTS)) {
                    presenter.onWhatsappClicked(true);
                }
            }

            @Override
            public void onPermissionDenied(String permission) {
                if (permission.equals(Manifest.permission.WRITE_CONTACTS)) {
                    presenter.onWhatsappClicked(false);
                }
            }
        };
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.attachView(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        presenter.detachView();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.clear();
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_help, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.call:
                Analytics.track(AnalyticsEvents.HELP_SCREEN_CALL);
                help();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    // Listeners
    @OnClick(R.id.whatsapp)
    public void whatsappUsClicked() {
        Analytics.track(AnalyticsEvents.HELP_SCREEN_WHATSAPP);

        if (!requestPermission(Manifest.permission.WRITE_CONTACTS, permissionGrantListener)) {
            presenter.onWhatsappClicked(true);
        }
    }

    @Override
    public void onSelected(HelpSection helpSection) {
        goToHelpSectionActivity(helpSection);
    }

    // View functions


    @Override
    public void openWhatsapp() {
        Uri uri = Uri.parse("whatsapp://send")
            .buildUpon()
            .appendQueryParameter("text", getString(R.string.help_whatsapp_msg))
            .appendQueryParameter("phone", ("91" + getHelpNumber()))
            .build();

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(uri);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            Toast.makeText(this, R.string.whatsapp_not_installed, Toast.LENGTH_SHORT).show();
        }
    }

//    @Override
//    public void setYoutube(String videoId) {
//        youtube = YouTubePlayerFragment.newInstance();
//        getSupportFragmentManager()
//            .beginTransaction()
//            .replace(R.id.youtube, youtube)
//            .commit();
//
//        youtube.initialize(Constants.GOOGLE_API_KEY, new YouTubePlayer.OnInitializedListener() {
//            @Override
//            public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer
//                player, boolean b) {
//                player.loadVideo(videoId);
//                player.setShowFullscreenButton(false);
//                player.setPlayerStateChangeListener(new YouTubePlayer.PlayerStateChangeListener() {
//                    @Override
//                    public void onLoading() {
//                    }
//
//                    @Override
//                    public void onLoaded(String s) {
//                    }
//
//                    @Override
//                    public void onAdStarted() {
//                    }
//
//                    @Override
//                    public void onVideoStarted() {
//                        Analytics.track(
//                            AnalyticsEvents.HELP_VIDEO_STARTED,
//                            EventProperties
//                                .create()
//                                .with("type", videoId));
//                    }
//
//                    @Override
//                    public void onVideoEnded() {
//                        Analytics.track(
//                            AnalyticsEvents.HELP_VIDEO_ENDED,
//                            EventProperties
//                                .create()
//                                .with("type", videoId));
//                    }
//
//                    @Override
//                    public void onError(YouTubePlayer.ErrorReason errorReason) {
//                        Timber.e(errorReason.toString());
//                        Analytics.track(
//                            AnalyticsEvents.HELP_VIDEO_FAILED,
//                            EventProperties
//                                .create()
//                                .with("type", videoId));
//                    }
//                });
//            }
//
//            @Override
//            public void onInitializationFailure(YouTubePlayer.Provider provider,
//                                                YouTubeInitializationResult res) {
//                Timber.e("youtube init failed");
//                Analytics.track(
//                    AnalyticsEvents.HELP_VIDEO_FAILED,
//                    EventProperties
//                        .create()
//                        .with("type", videoId));
//            }
//        });
//    }

    @Override
    public void setSections(List<HelpSection> sections) {
        helpSectionAdapter.setSections(sections);
    }

    @Override
    public void showError() {
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "help")
                .with("type", "server error")
        );

        Toast.makeText(this, R.string.err_default, Toast.LENGTH_SHORT).show();
        finish();
    }

    @Override
    public void showNoInternetMessage() {
        new NetworkErrorDialog().show(this, new NetworkErrorDialog.Listener() {
            @Override
            public void onNetworkOk() {
                presenter.onInternetRestored();
            }

            @Override
            public void onCancel() {
                onBackPressed();
            }
        });
    }

    private void goToHelpSectionActivity(HelpSection helpSection) {
        startActivity(HelpSectionActivity.startingIntent(this, helpSection));
    }

    @Override
    public void gotoLogin() {
        super.gotoLogin();
        Analytics.track(
            AnalyticsEvents.ERROR,
            EventProperties
                .create()
                .with("screen", "help")
                .with("type", "auth error")
        );
    }

    @Override
    public void showLoading() {

    }

    @Override
    public void hideLoading() {

    }
}
