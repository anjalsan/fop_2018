package in.okcredit.app.ui.addtxn._di;

import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import in.okcredit._di.scope.FragmentScope;
import in.okcredit.app.ui.addtxn.AddTxnActivity;
import in.okcredit.app.ui.addtxn.addTxn.AddTxnContract;
import in.okcredit.app.ui.addtxn.addTxn.AddTxnPresenter;
import in.okcredit.app.ui.addtxn.addTxn.CameraHelper;
import in.okcredit.app.ui.addtxn.addTxn.GalleryHelper;

@Module
public abstract class AddTxnFragment_Module {
    @Binds
    @FragmentScope
    public abstract AddTxnContract.Presenter presenter(AddTxnPresenter presenter);

    @Provides
    @FragmentScope
    public static CameraHelper cameraHelper(AddTxnActivity activity) {
        return new CameraHelper(activity);
    }

    @Provides
    @FragmentScope
    public static GalleryHelper galleryHelper(AddTxnActivity activity) {
        return new GalleryHelper(activity);
    }
}
