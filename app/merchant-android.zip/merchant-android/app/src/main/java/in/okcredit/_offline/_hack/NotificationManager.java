package in.okcredit._offline._hack;

import android.support.annotation.NonNull;
import android.util.Pair;

import org.joda.time.DateTime;
import org.joda.time.Days;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import in.okcredit.App;
import in.okcredit.AppLockManager;
import in.okcredit.BuildConfig;
import in.okcredit.LifecycleState;
import in.okcredit.ThreadUtils;
import in.okcredit._offline.database.CustomerRepo;
import in.okcredit._offline.database.MerchantRepo;
import in.okcredit._offline.database.TransactionRepo;
import in.okcredit._offline.model.Customer;
import in.okcredit._offline.model.InAppNotification;
import in.okcredit._offline.model.Merchant;
import in.okcredit._offline.model.MerchantPreference;
import in.okcredit._offline.model.Transaction;
import in.okcredit._offline.model.Version;
import in.okcredit._offline.server.Server;
import in.okcredit._offline.usecase.CheckNetworkStatus;
import in.okcredit._offline.usecase.LinkDevice;
import in.okcredit.analytics.Analytics;
import in.okcredit.analytics.AnalyticsEvents;
import in.okcredit.analytics.EventProperties;
import in.okcredit.service.keyval.KeyValService;
import in.okcredit.util.GsonUtil;
import io.reactivex.Completable;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import timber.log.Timber;

public final class NotificationManager {
    // used to check if app update is available
    public static final String KEY_SERVER_VERSION = "notification.server_version";

    // latest month for which the user has seen "reminder to be sent" notification
    private static final String KEY_REMINDER_VIEW_MONTH = "notification.reminder_view_month";

    // tlatest app version for which the user has seen update prompt
    private static final String KEY_UPDATE_NOTI_VIEW_VERSION = "notification.update_noti_view_version";

    // whether the user has seen "enable app lock" notification
    private static final String KEY_APP_LOCK_NOTI_VIEWED = "notification.app_lock_noti_viewed";

    // whether the user has seen "share app" notification
    private static final String KEY_SHARE_NOTI_VIEWED = "notification.share_noti_viewed";

    // whether the user has seen "share app" notification
    private static final String KEY_RATING_NOTI_VIEWED = "notification.rating_noti_viewed";

    private LifecycleManager lifecycleManager;
    private MerchantRepo merchantRepo;
    private CustomerRepo customerRepo;
    private TransactionRepo transactionRepo;
    private KeyValService keyValService;
    private AppLockManager appLockManager;
    private CheckNetworkStatus checkNetworkStatus;
    private int versionCode;

    @Inject
    public NotificationManager(LifecycleManager lifecycleManager,
                               MerchantRepo merchantRepo,
                               CustomerRepo customerRepo,
                               TransactionRepo transactionRepo,
                               KeyValService keyValService,
                               AppLockManager appLockManager,
                               CheckNetworkStatus checkNetworkStatus) {
        this.lifecycleManager = lifecycleManager;
        this.merchantRepo = merchantRepo;
        this.customerRepo = customerRepo;
        this.transactionRepo = transactionRepo;
        this.keyValService = keyValService;
        this.appLockManager = appLockManager;
        this.checkNetworkStatus = checkNetworkStatus;
        this.versionCode = BuildConfig.VERSION_CODE;
    }

    public Single<InAppNotification> getInAppNotification() {
        return lifecycleManager
            .getLifecycleState()
            .take(1)
            .firstOrError()
            .flatMap(lifecycleState -> {
                if (lifecycleState == LifecycleState.NORMAL_FLOW) {
                    return checkNotification_reminderToBeSent()
                        .onErrorResumeNext(checkNotification_updateAvailable())
                        .onErrorResumeNext(checkNotification_appLock())
                        .onErrorResumeNext(checkNotification_share())
                        .onErrorResumeNext(checkNotification_rating());
                } else {
                    return Single.error(new NullPointerException());
                }
            })
            .onErrorReturnItem(new InAppNotification(InAppNotification.TYPE_EMPTY));
    }

    public Completable markInAppNotificationSeen(int type) {
        switch (type) {
            case InAppNotification.TYPE_SHARE:
                return keyValService
                    .put(KEY_SHARE_NOTI_VIEWED, String.valueOf(true))
                    .subscribeOn(ThreadUtils.database());


            case InAppNotification.TYPE_APP_LOCK:
                return keyValService
                    .put(KEY_APP_LOCK_NOTI_VIEWED, String.valueOf(true))
                    .subscribeOn(ThreadUtils.database());

            case InAppNotification.TYPE_UPDATE:
                return keyValService
                    .put(KEY_UPDATE_NOTI_VIEW_VERSION, String.valueOf(getLatestVersion().getVersion()))
                    .subscribeOn(ThreadUtils.database());

            case InAppNotification.TYPE_REMINDER_TO_BE_SENT:
                return keyValService
                    .put(KEY_REMINDER_VIEW_MONTH, String.valueOf(DateTime.now().getMonthOfYear()))
                    .subscribeOn(ThreadUtils.database());

            case InAppNotification.TYPE_RATING:
                return keyValService
                    .put(KEY_RATING_NOTI_VIEWED, String.valueOf(true))
                    .subscribeOn(ThreadUtils.database());

            default:
                return Completable.complete();
        }
    }


    private Single<InAppNotification> checkNotification_reminderToBeSent() {
        return merchantRepo
            .isMerchantPreferenceAvailable(MerchantPreference.REMINDER)
            .flatMap(isAvailable -> {
                if (isAvailable) {
                    return merchantRepo.getMerchantPreference(MerchantPreference.REMINDER)
                                       .firstOrError()
                                       .map(isReminderOn -> Boolean.parseBoolean(isReminderOn));
                } else {
                    return Single.error(new NullPointerException());
                }
            })
            .map(isReminderOn -> {
                if (isReminderOn) {
                    DateTime now = DateTime.now();
                    if (now.getDayOfMonth() < 5) {

                        int lastViewedReminderNotiMonth = -1;
                        try {
                            if (keyValService.contains(KEY_REMINDER_VIEW_MONTH).blockingGet()) {
                                lastViewedReminderNotiMonth = Integer.parseInt(
                                    keyValService.get(KEY_REMINDER_VIEW_MONTH).blockingFirst()
                                );
                            }
                        } catch (Exception ignored) {
                        }

                        if (lastViewedReminderNotiMonth < now.getMonthOfYear()) {
                            return new InAppNotification(InAppNotification.TYPE_REMINDER_TO_BE_SENT);
                        }
                    }
                }
                throw new NullPointerException();
            })
            .subscribeOn(ThreadUtils.newThread())
            .timeout(1, TimeUnit.SECONDS);
    }

    private Single<InAppNotification> checkNotification_updateAvailable() {
        return Single
            .fromCallable(() -> {
                Version appVersionSummary = getLatestVersion();
                if (appVersionSummary == null) {
                    throw new NullPointerException();
                }

                if (versionCode < appVersionSummary.getVersion()) {
                    int lastViewedVersion = -1;
                    try {
                        if (keyValService.contains(KEY_UPDATE_NOTI_VIEW_VERSION).blockingGet()) {
                            lastViewedVersion = Integer.parseInt(
                                keyValService.get(KEY_UPDATE_NOTI_VIEW_VERSION).blockingFirst()
                            );
                        }
                    } catch (Exception ignored) {
                    }

                    if (lastViewedVersion < appVersionSummary.getVersion()) {
                        if (appVersionSummary.hasNewFeatures()) {
                            return new InAppNotification(InAppNotification.TYPE_UPDATE);
                        }
                    }
                }

                throw new NullPointerException();
            })
            .timeout(1, TimeUnit.SECONDS)
            .subscribeOn(ThreadUtils.newThread());
    }

    private Single<InAppNotification> checkNotification_appLock() {
        return Single
            .zip(
                merchantRepo.getActiveMerchant().firstOrError(),
                customerRepo.listCustomers().firstOrError(),
                (merchant, customers) -> {

                    if (!appLockManager.isAppLockActive()) {
                        if (DateTime.now()
                                    .minusDays(1)
                                    .isAfter(merchant.getCreatedAt()) || customers.size() > 5) {


                            boolean isViewed = false;
                            try {
                                if (keyValService.contains(KEY_APP_LOCK_NOTI_VIEWED)
                                                 .blockingGet()) {
                                    isViewed = true;
                                }
                            } catch (Exception ignored) {
                            }

                            if (!isViewed) {
                                return new InAppNotification(InAppNotification.TYPE_APP_LOCK);
                            }
                        }
                    }

                    throw new NullPointerException();
                }
            )
            .subscribeOn(ThreadUtils.newThread())
            .timeout(1, TimeUnit.SECONDS);
    }

    private Single<InAppNotification> checkNotification_share() {
        return merchantRepo
            .getActiveMerchant()
            .firstOrError()
            .map(merchant -> {
                if (DateTime.now().isBefore(merchant.getCreatedAt().plus(Days.days(1)))) {
                    // don't show on  first day
                    throw new NullPointerException();
                }

                Pair<Integer, Boolean> sharePair = shouldShowShare(merchant.getId());
                if (sharePair.second) {
                    int day = sharePair.first;
                    int daysSinceRegistered = Days.daysBetween(
                        DateTime.now().withTimeAtStartOfDay(),
                        merchant.getCreatedAt().withTimeAtStartOfDay()
                    ).getDays();
                    int remainder = daysSinceRegistered % 7;

                    if (day == remainder) {
                        return new InAppNotification(InAppNotification.TYPE_SHARE, sharePair.first);
                    }
                }
                throw new NullPointerException();
            })
            .timeout(1, TimeUnit.SECONDS)
            .subscribeOn(ThreadUtils.newThread());
    }

    public Single<InAppNotification> checkNotification_rating() {
        return Single
            .zip(
                merchantRepo.getActiveMerchant().firstOrError(),
                customerRepo.listCustomers().firstOrError(),
                transactionRepo.listTransactions().firstOrError(),
                (merchant, customers, transactions) -> {
                    if (DateTime.now()
                                .isAfter(merchant.getCreatedAt()
                                                 .plus(Days.days(30))) && transactions.size() > 50 && customers
                        .size() > 10) {

                        boolean isViewed = false;
                        try {
                            if (keyValService.contains(KEY_RATING_NOTI_VIEWED)
                                             .blockingGet()) {
                                isViewed = true;
                            }
                        } catch (Exception ignored) {
                        }

                        if (!isViewed) {
                            return new InAppNotification(InAppNotification.TYPE_RATING);
                        }
                    }
                    throw new NullPointerException();
                }
            )
            .subscribeOn(ThreadUtils.newThread())
            .timeout(1, TimeUnit.SECONDS);
    }


    private Pair<Integer, Boolean> shouldShowShare(String merchantId) {
        ArrayList<String> day0 = new ArrayList<>(Arrays.asList("a", "b", "c", "d", "e"));
        ArrayList<String> day1 = new ArrayList<>(Arrays.asList("f", "g", "h", "i", "j"));
        ArrayList<String> day2 = new ArrayList<>(Arrays.asList("k", "l", "m", "n", "o"));
        ArrayList<String> day3 = new ArrayList<>(Arrays.asList("p", "q", "r", "s", "t"));
        ArrayList<String> day4 = new ArrayList<>(Arrays.asList("u", "v", "w", "x", "y"));
        ArrayList<String> day5 = new ArrayList<>(Arrays.asList("z", "0", "1", "2", "3"));
        ArrayList<String> day6 = new ArrayList<>(Arrays.asList("4", "5", "6", "7", "8", "9"));

        String firstChar = String.valueOf(merchantId.toLowerCase().charAt(0));

        boolean isViewed = false;
        try {
            if (keyValService.contains(KEY_SHARE_NOTI_VIEWED).blockingGet()) {
                isViewed = true;
            }
        } catch (Exception ignored) {
        }

        if (!isViewed) {
            if (day0.contains(firstChar)) {
                return new Pair<>(0, true);
            } else if (day1.contains(firstChar)) {
                return new Pair<>(1, true);
            } else if (day2.contains(firstChar)) {
                return new Pair<>(2, true);
            } else if (day3.contains(firstChar)) {
                return new Pair<>(3, true);
            } else if (day4.contains(firstChar)) {
                return new Pair<>(4, true);
            } else if (day5.contains(firstChar)) {
                return new Pair<>(5, true);
            } else if (day6.contains(firstChar)) {
                return new Pair<>(6, true);
            }
        }

        return new Pair<>(-1, false);
    }

    private Version getLatestVersion() {
        Version version = null;
        boolean isVersionAvailable = keyValService.contains(KEY_SERVER_VERSION).blockingGet();
        if (isVersionAvailable) {
            try {
                version = GsonUtil.getGson()
                                  .fromJson(
                                      keyValService.get(KEY_SERVER_VERSION).blockingFirst(),
                                      Version.class
                                  );
            } catch (Exception e) {
                version = null;
            }
        }
        sync();
        return version;
    }

    // schedule to sync everything required for notification manager to work
    public void sync() {
        Constraints constraints = new Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build();

        OneTimeWorkRequest workRequest = new OneTimeWorkRequest.Builder(LinkDevice.Worker.class)
            .setBackoffCriteria(BackoffPolicy.LINEAR, 30, TimeUnit.SECONDS)
            .setConstraints(constraints)
            .build();

        WorkManager.getInstance()
                   .beginUniqueWork("latest-version", ExistingWorkPolicy.KEEP, workRequest)
                   .enqueue();
    }

    public static class FetchVersionTask extends androidx.work.Worker {
        private Server server;
        private KeyValService keyValService;

        @NonNull
        @Override
        public Result doWork() {
            App.appComponent().inject(this);

            try {
                Version version = server.getLatestVersion().blockingGet();
                if (version != null) {
                    keyValService.put(KEY_SERVER_VERSION, GsonUtil.getGson().toJson(version))
                                 .blockingAwait();
                    return Result.SUCCESS;

                } else {
                    throw new RuntimeException("api failed: get latest version");
                }

            } catch (Exception e) {
                return Result.RETRY;
            }
        }
    }


    public Single<InAppNotification> _getInAppNotification() {

        Single<Boolean> isReminderOnSingle = merchantRepo
            .isMerchantPreferenceAvailable(MerchantPreference.REMINDER)
            .flatMap(isAvailable -> {
                if (isAvailable) {
                    return merchantRepo.getMerchantPreference(MerchantPreference.REMINDER)
                        .firstOrError()
                        .map(isReminderOn -> Boolean.parseBoolean(isReminderOn));
                } else {
                    return Single.just(false);
                }
            });

        Single<Merchant> meSingle = merchantRepo
            .getActiveMerchant()
            .firstOrError();

        Single<List<Customer>> customerCountSingle = customerRepo
            .listCustomers()
            .firstOrError();

        Single<List<Transaction>> transactionsCountSingle = transactionRepo
            .listTransactions()
            .firstOrError();

        Single<Boolean> isInternetStatus = checkNetworkStatus
            .isInternet()
            .flatMap(aBoolean -> Single.just(aBoolean));

        return Single.zip(isReminderOnSingle, meSingle, customerCountSingle, transactionsCountSingle, isInternetStatus, (isReminderOn, merchant, customers, transactions, isInternet) -> {


            // check Notification reminder To Be Sent
            if (isReminderOn) {
                DateTime now = DateTime.now();
                if (now.getDayOfMonth() < 5) {

                    int lastViewedReminderNotiMonth = -1;
                    try {
                        if (keyValService.contains(KEY_REMINDER_VIEW_MONTH).blockingGet()) {
                            lastViewedReminderNotiMonth = Integer.parseInt(
                                keyValService.get(KEY_REMINDER_VIEW_MONTH).blockingFirst()
                            );
                        }
                    } catch (Exception ignored) {
                    }

                    if (lastViewedReminderNotiMonth < now.getMonthOfYear()) {
                        return new InAppNotification(InAppNotification.TYPE_REMINDER_TO_BE_SENT);
                    }
                }
            }

            // check Notification updateAvailable
            Version appVersionSummary = getLatestVersion();
            if (appVersionSummary != null && versionCode < appVersionSummary.getVersion()) {
                int lastViewedVersion = -1;
                try {
                    if (keyValService.contains(KEY_UPDATE_NOTI_VIEW_VERSION).blockingGet()) {
                        lastViewedVersion = Integer.parseInt(
                            keyValService.get(KEY_UPDATE_NOTI_VIEW_VERSION).blockingFirst()
                        );
                    }
                } catch (Exception ignored) {
                }

                if (lastViewedVersion < appVersionSummary.getVersion()) {
                    if (appVersionSummary.hasNewFeatures()) {
                        return new InAppNotification(InAppNotification.TYPE_UPDATE);
                    }
                }
            }


            // check Notification appLock
            if (!appLockManager.isAppLockActive()) {
                if (DateTime.now()
                            .minusDays(1)
                            .isAfter(merchant.getCreatedAt()) || customers.size() > 5) {


                    boolean isViewed = false;
                    try {
                        if (keyValService.contains(KEY_APP_LOCK_NOTI_VIEWED)
                                         .blockingGet()) {
                            isViewed = true;
                        }
                    } catch (Exception ignored) {
                    }

                    if (!isViewed) {
                        return new InAppNotification(InAppNotification.TYPE_APP_LOCK);
                    }
                }
            }

            // check Notification share
            if (!(DateTime.now().isBefore(merchant.getCreatedAt().plus(Days.days(1))))) {
                // don't show on  first day
                Pair<Integer, Boolean> sharePair = shouldShowShare(merchant.getId());
                if (sharePair.second) {
                    int day = sharePair.first;
                    int daysSinceRegistered = Days.daysBetween(
                        DateTime.now().withTimeAtStartOfDay(),
                        merchant.getCreatedAt().withTimeAtStartOfDay()
                    ).getDays();
                    int remainder = daysSinceRegistered % 7;

                    if (day == remainder) {
                        return new InAppNotification(InAppNotification.TYPE_SHARE, sharePair.first);
                    }
                }
            }


            // check Notification rating
            if (DateTime.now()
                        .isAfter(merchant.getCreatedAt()
                                         .plus(Days.days(30))) && transactions.size() > 50 && customers
                .size() > 10) {

                boolean isViewed = false;
                try {
                    if (keyValService.contains(KEY_RATING_NOTI_VIEWED)
                                     .blockingGet()) {
                        isViewed = true;
                    }
                } catch (Exception ignored) {
                }

                if (!isViewed && isInternet) {
                    return new InAppNotification(InAppNotification.TYPE_RATING);
                }
            }

            return new InAppNotification(InAppNotification.TYPE_EMPTY);

        })
                     .observeOn(AndroidSchedulers.mainThread())
                     .doOnError(throwable -> {
                         Analytics.track(
                             AnalyticsEvents.ERROR,
                             EventProperties
                                 .create()
                                 .with("screen", "home")
                                 .with("type", "InAppNotification error - Exception while fetching in app notifications")
                         );
                         Timber.e(throwable, "Exception while fetching in app notifications");
                     })
                     .subscribeOn(ThreadUtils.newThread());
    }
}
