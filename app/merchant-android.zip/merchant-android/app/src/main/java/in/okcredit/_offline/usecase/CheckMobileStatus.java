package in.okcredit._offline.usecase;

import javax.inject.Inject;

import in.okcredit._offline.server.Server;
import io.reactivex.Single;

// Internet
public final class CheckMobileStatus {
    private Server server;

    @Inject
    public CheckMobileStatus(Server server) {
        this.server = server;
    }

    public Single<Boolean> execute(String mobile) {
        return server.checkMobileStatus(mobile);
    }
}
