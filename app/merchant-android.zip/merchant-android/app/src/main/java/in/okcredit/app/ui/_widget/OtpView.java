package in.okcredit.app.ui._widget;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import butterknife.BindViews;
import butterknife.ButterKnife;
import butterknife.OnClick;
import in.okcredit.R;

public class OtpView extends LinearLayout {
    interface Listener {
        void onOtpEntered(String otp);
    }

    @BindViews({
        R.id.otp_1,
        R.id.otp_2,
        R.id.otp_3,
        R.id.otp_4,
        R.id.otp_5,
        R.id.otp_6
    })
    List<TextView> otp;

    int cursorPosition;
    Listener listener;

    public OtpView(Context context) {
        super(context);
        initView(context);
    }

    public OtpView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public OtpView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    public OtpView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        initView(context);
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public void unsetListener() {
        listener = null;
    }

    @OnClick(R.id.num_0)
    public void onNum0Clicked() {
        setVal(0);
    }

    @OnClick(R.id.num_1)
    public void onNum1Clicked() {
        setVal(1);
    }

    @OnClick(R.id.num_2)
    public void onNum2Clicked() {
        setVal(2);
    }

    @OnClick(R.id.num_3)
    public void onNum3Clicked() {
        setVal(3);
    }

    @OnClick(R.id.num_4)
    public void onNum4Clicked() {
        setVal(4);
    }

    @OnClick(R.id.num_5)
    public void onNum5Clicked() {
        setVal(5);
    }

    @OnClick(R.id.num_6)
    public void onNum6Clicked() {
        setVal(6);
    }

    @OnClick(R.id.num_7)
    public void onNum7Clicked() {
        setVal(7);
    }

    @OnClick(R.id.num_8)
    public void onNum8Clicked() {
        setVal(8);
    }

    @OnClick(R.id.num_9)
    public void onNum9Clicked() {
        setVal(9);
    }

    @OnClick(R.id.backspace)
    public void onBackspaceClicked() {
        if (cursorPosition == 0)
            return;
        cursorPosition--;
        otp.get(cursorPosition).setText("");
    }

    public void clear() {
        for (TextView o : otp)
            o.setText("");
        cursorPosition = 0;
    }

    private void setVal(int num) {
        if (cursorPosition >= 6)
            return;

        otp.get(cursorPosition).setText(String.valueOf(num));
        cursorPosition++;
        if (cursorPosition == 6) {
            if (listener != null) {
                StringBuilder in = new StringBuilder();
                for (TextView t : otp)
                    in.append(t.getText().toString());
                listener.onOtpEntered(in.toString());
            }
        }

    }


    private void initView(Context context) {
        setOrientation(LinearLayout.VERTICAL);
        inflate(context, R.layout.widget_otp, this);
        ButterKnife.bind(this);
    }
}
