package in.okcredit._offline.server.identity.internal;

import android.arch.persistence.room.Entity;
import android.support.annotation.NonNull;

@Entity(primaryKeys = {"type", "localId"})
public final class IdentityMapping {
    public final int type;
    @NonNull public final String localId;
    @NonNull public final String serverId;

    public IdentityMapping(int type, @NonNull String localId, @NonNull String serverId) {
        this.type = type;
        this.localId = localId;
        this.serverId = serverId;
    }
}
