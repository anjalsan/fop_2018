package in.okcredit.app.ui.app_lock.preference;

import in.okcredit.app.ui._base_v2.BaseContracts;
import in.okcredit.app.ui._base_v2.MVP;

public interface AppLockPrefContract {
    interface Presenter extends MVP.Presenter<View>, BaseContracts.Online.Presenter<View>, BaseContracts.Authenticated.Presenter<View> {
    }

    interface View extends MVP.View, BaseContracts.Online.View, BaseContracts.Authenticated.View {
        void setAppLockStatus(boolean isActive);
    }
}
